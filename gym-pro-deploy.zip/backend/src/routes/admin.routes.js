const express = require('express');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const {
  parseJson,
  stringifyJson,
  sanitizeUser,
  formatSubscriptionPlan,
  generateReadableId,
} = require('../utils/json');
const { nowIST, dayjs, IST_TZ } = require('../utils/date');
const { createAuditLog } = require('../utils/audit');
const { createNotification } = require('../utils/notification');

const router = express.Router();

router.use(authenticate, authorize('SUPER_ADMIN'));

const formatGymForAdmin = (g) => {
  const latestSub = g.gymSubscriptions?.[0] || null;
  const formattedOwner = g.owner ? sanitizeUser(g.owner) : null;
  return {
    ...g,
    owner: formattedOwner,
    ownerName: formattedOwner?.fullName || '',
    status: !g.isActive ? 'SUSPENDED' : g.subscriptionStatus || 'TRIAL',
    membersCount: g._count?.customers ?? 0,
    trainersCount: g._count?.trainers ?? 0,
    branchesCount: g._count?.branches ?? 0,
    subscription: latestSub
      ? {
          ...latestSub,
          plan: latestSub.plan ? formatSubscriptionPlan(latestSub.plan) : null,
        }
      : null,
    planName: latestSub?.plan?.name || (g.subscriptionStatus === 'TRIAL' ? 'Premium Trial' : 'None'),
  };
};

const formatDomain = (d) => ({
  ...d,
  domain: d.domainName,
  status: d.verificationStatus,
  sslActive: d.sslStatus === 'ACTIVE',
  cnameTarget: d.cnameTarget || 'cname.gympro.app',
  verificationToken: d.verificationToken || `gympro-verify=${d.id.slice(0, 12)}`,
});

const formatTicket = (t) => ({
  ...t,
  replies: parseJson(t.replies, []),
});

// GET /api/admin/dashboard
router.get('/dashboard', async (req, res, next) => {
  try {
    const startDate = req.query.startDate
      ? dayjs(req.query.startDate).tz(IST_TZ).startOf('day').toDate()
      : nowIST().subtract(29, 'day').startOf('day').toDate();
    const endDate = req.query.endDate
      ? dayjs(req.query.endDate).tz(IST_TZ).endOf('day').toDate()
      : nowIST().endOf('day').toDate();

    const sevenDaysLater = nowIST().add(7, 'day').toDate();
    const now = nowIST().toDate();

    const [
      totalGyms,
      activeGyms,
      suspendedGyms,
      trialGyms,
      expiredGyms,
      totalUsers,
      newRegistrations,
      totalOwners,
      totalTrainers,
      totalCustomers,
      activeSubscriptionsList,
      expiredSubscriptions,
      upcomingRenewals,
      pendingPaymentsCount,
      verifiedPaymentsCount,
      verifiedRevenueAgg,
      recentGyms,
      pendingPayments,
      allGymsForCharts,
      allVerifiedPaymentsForCharts,
      subscriptionsByPlan,
      plans,
    ] = await Promise.all([
      prisma.gym.count(),
      prisma.gym.count({ where: { isActive: true, subscriptionStatus: 'ACTIVE' } }),
      prisma.gym.count({ where: { isActive: false } }),
      prisma.gym.count({ where: { subscriptionStatus: 'TRIAL', isActive: true } }),
      prisma.gym.count({ where: { subscriptionStatus: 'EXPIRED' } }),
      prisma.user.count(),
      prisma.user.count({ where: { createdAt: { gte: startDate, lte: endDate } } }),
      prisma.user.count({ where: { role: 'GYM_OWNER' } }),
      prisma.user.count({ where: { role: 'TRAINER' } }),
      prisma.user.count({ where: { role: 'CUSTOMER' } }),
      prisma.gymSubscription.findMany({
        where: { status: 'ACTIVE' },
        include: { plan: true },
      }),
      prisma.gymSubscription.count({ where: { status: 'EXPIRED' } }),
      prisma.gymSubscription.count({
        where: { status: 'ACTIVE', endDate: { gte: now, lte: sevenDaysLater } },
      }),
      prisma.subscriptionPayment.count({ where: { status: 'PENDING' } }),
      prisma.subscriptionPayment.count({ where: { status: 'VERIFIED' } }),
      prisma.subscriptionPayment.aggregate({
        where: { status: 'VERIFIED' },
        _sum: { amount: true },
      }),
      prisma.gym.findMany({
        take: 6,
        orderBy: { createdAt: 'desc' },
        include: {
          owner: { select: { id: true, fullName: true, email: true, mobile: true, profilePhoto: true } },
          gymSubscriptions: { take: 1, orderBy: { createdAt: 'desc' }, include: { plan: true } },
          _count: { select: { customers: true, trainers: true, branches: true } },
        },
      }),
      prisma.subscriptionPayment.findMany({
        where: { status: 'PENDING' },
        take: 6,
        orderBy: { createdAt: 'desc' },
        include: {
          gym: { select: { id: true, name: true } },
          gymSubscription: { include: { plan: { select: { name: true } } } },
        },
      }),
      prisma.gym.findMany({
        where: { createdAt: { gte: nowIST().subtract(5, 'month').startOf('month').toDate() } },
        select: { createdAt: true, subscriptionStatus: true },
      }),
      prisma.subscriptionPayment.findMany({
        where: {
          status: 'VERIFIED',
          createdAt: { gte: nowIST().subtract(5, 'month').startOf('month').toDate() },
        },
        select: { amount: true, createdAt: true },
      }),
      prisma.gymSubscription.groupBy({
        by: ['planId'],
        where: { status: { in: ['ACTIVE', 'TRIAL'] } },
        _count: { id: true },
      }),
      prisma.subscriptionPlan.findMany({ select: { id: true, name: true } }),
    ]);

    const activeSubscriptions = activeSubscriptionsList.length;
    const mrr = activeSubscriptionsList.reduce((sum, s) => {
      const monthlyVal =
        s.billingPeriod === 'YEARLY' ? (s.plan?.yearlyPrice || s.amount) / 12 : s.plan?.monthlyPrice || s.amount;
      return sum + Number(monthlyVal || 0);
    }, 0);
    const arr = mrr * 12;

    const totalEverTrialOrPaid = activeSubscriptions + trialGyms + expiredGyms;
    const trialConversionRate =
      totalEverTrialOrPaid > 0 ? Number(((activeSubscriptions / totalEverTrialOrPaid) * 100).toFixed(1)) : 0;

    // 6-month charts
    const monthlyTrendMap = {};
    for (let i = 5; i >= 0; i--) {
      const d = dayjs().tz(IST_TZ).subtract(i, 'month');
      const key = d.format('YYYY-MM');
      monthlyTrendMap[key] = {
        month: key,
        label: d.format('MMM YY'),
        revenue: 0,
        registrations: 0,
        conversions: 0,
      };
    }

    allVerifiedPaymentsForCharts.forEach((p) => {
      const key = dayjs(p.createdAt).tz(IST_TZ).format('YYYY-MM');
      if (monthlyTrendMap[key]) monthlyTrendMap[key].revenue += Number(p.amount || 0);
    });

    allGymsForCharts.forEach((g) => {
      const key = dayjs(g.createdAt).tz(IST_TZ).format('YYYY-MM');
      if (monthlyTrendMap[key]) {
        monthlyTrendMap[key].registrations += 1;
        if (g.subscriptionStatus === 'ACTIVE') monthlyTrendMap[key].conversions += 1;
      }
    });

    const planMap = Object.fromEntries(plans.map((p) => [p.id, p.name]));
    const planDistribution = subscriptionsByPlan.map((item) => ({
      name: planMap[item.planId] || 'Other',
      value: item._count.id,
    }));

    const formattedPendingPayments = pendingPayments.map((p) => ({
      ...p,
      gymName: p.gym?.name || '',
      plan: p.gymSubscription?.plan || null,
      planName: p.gymSubscription?.plan?.name || '',
    }));

    return sendSuccess(
      res,
      {
        stats: {
          totalGyms,
          activeGyms,
          suspendedGyms,
          trialGyms,
          freeTrialAccounts: trialGyms,
          expiredGyms,
          expiredSubscriptions,
          totalUsers,
          newRegistrations,
          activeSubscriptions,
          mrr: Number(mrr.toFixed(2)),
          arr: Number(arr.toFixed(2)),
          upcomingRenewals,
          trialConversionRate,
          usersByRole: {
            GYM_OWNER: totalOwners,
            TRAINER: totalTrainers,
            CUSTOMER: totalCustomers,
          },
          verifiedSubscriptionPayments: verifiedPaymentsCount,
          pendingSubscriptionPayments: pendingPaymentsCount,
          totalRevenue: verifiedRevenueAgg._sum.amount || 0,
        },
        revenueChart: Object.values(monthlyTrendMap),
        registrationChart: Object.values(monthlyTrendMap),
        planDistribution,
        recentGyms: recentGyms.map(formatGymForAdmin),
        pendingPayments: formattedPendingPayments,
        recentPayments: formattedPendingPayments,
      },
      'Admin dashboard data retrieved'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/admin/gyms
router.get('/gyms', async (req, res, next) => {
  try {
    const { page, limit, skip } = getPagination(req.query);
    const { search, subscriptionStatus, status, isActive } = req.query;

    const where = {};
    const statusParam = status || subscriptionStatus;
    if (statusParam && statusParam !== 'ALL') {
      if (statusParam.toUpperCase() === 'SUSPENDED') {
        where.isActive = false;
      } else {
        where.subscriptionStatus = statusParam.toUpperCase();
        where.isActive = true;
      }
    }
    if (isActive !== undefined) where.isActive = isActive === 'true';
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { city: { contains: search } },
        { email: { contains: search } },
        { phone: { contains: search } },
        { owner: { fullName: { contains: search } } },
      ];
    }

    const [gyms, total] = await Promise.all([
      prisma.gym.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          owner: { select: { id: true, fullName: true, email: true, mobile: true, profilePhoto: true } },
          gymSubscriptions: {
            take: 1,
            orderBy: { createdAt: 'desc' },
            include: { plan: true },
          },
          _count: { select: { customers: true, trainers: true, branches: true } },
        },
      }),
      prisma.gym.count({ where }),
    ]);

    return sendSuccess(res, formatPaginatedData(gyms.map(formatGymForAdmin), total, page, limit), 'Gyms fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/admin/gyms/:id
router.get('/gyms/:id', async (req, res, next) => {
  try {
    const gym = await prisma.gym.findUnique({
      where: { id: req.params.id },
      include: {
        owner: { select: { id: true, fullName: true, email: true, mobile: true, isActive: true, profilePhoto: true } },
        branches: true,
        gymSubscriptions: { orderBy: { createdAt: 'desc' }, include: { plan: true } },
        domains: true,
        _count: { select: { customers: true, trainers: true, payments: true, branches: true } },
      },
    });

    if (!gym) {
      return sendError(res, 'Gym not found', 404);
    }

    return sendSuccess(res, formatGymForAdmin(gym), 'Gym details retrieved');
  } catch (err) {
    next(err);
  }
});

// PUT / PATCH /api/admin/gyms/:id/status
const handleUpdateGymStatus = async (req, res, next) => {
  try {
    const { isActive, subscriptionStatus, status } = req.body;
    const gym = await prisma.gym.findUnique({ where: { id: req.params.id } });
    if (!gym) {
      return sendError(res, 'Gym not found', 404);
    }

    const updateData = {};
    if (typeof isActive === 'boolean') updateData.isActive = isActive;

    const targetStatus = status || subscriptionStatus;
    if (targetStatus) {
      const upper = String(targetStatus).toUpperCase();
      if (upper === 'SUSPENDED') {
        updateData.isActive = false;
      } else if (upper === 'ACTIVE') {
        updateData.isActive = true;
        if (gym.subscriptionStatus === 'EXPIRED' || gym.subscriptionStatus === 'CANCELLED') {
          updateData.subscriptionStatus = 'ACTIVE';
        }
      } else {
        const allowed = ['TRIAL', 'ACTIVE', 'EXPIRED', 'CANCELLED', 'GRACE'];
        if (!allowed.includes(upper)) {
          return sendError(res, 'Invalid subscriptionStatus', 400);
        }
        updateData.subscriptionStatus = upper;
        updateData.isActive = true;
      }
    }

    const updated = await prisma.gym.update({
      where: { id: gym.id },
      data: updateData,
    });

    await createNotification({
      userId: gym.ownerId,
      gymId: gym.id,
      type: 'GYM_STATUS',
      title: 'Gym Account Status Updated',
      message: `Your gym "${gym.name}" status was updated by platform administration.`,
      data: updateData,
      io: req.app.get('io'),
    });

    await createAuditLog({
      userId: req.user.id,
      gymId: gym.id,
      action: 'UPDATE_GYM_STATUS',
      entity: 'Gym',
      entityId: gym.id,
      details: updateData,
      req,
    });

    return sendSuccess(res, formatGymForAdmin(updated), 'Gym status updated successfully');
  } catch (err) {
    next(err);
  }
};
router.put('/gyms/:id/status', handleUpdateGymStatus);
router.patch('/gyms/:id/status', handleUpdateGymStatus);

// DELETE /api/admin/gyms/:id (Soft suspend)
router.delete('/gyms/:id', async (req, res, next) => {
  try {
    const gym = await prisma.gym.findUnique({ where: { id: req.params.id } });
    if (!gym) return sendError(res, 'Gym not found', 404);

    await prisma.gym.update({
      where: { id: gym.id },
      data: { isActive: false, subscriptionStatus: 'CANCELLED' },
    });

    await createAuditLog({
      userId: req.user.id,
      gymId: gym.id,
      action: 'SUSPEND_GYM',
      entity: 'Gym',
      entityId: gym.id,
      req,
    });

    return sendSuccess(res, null, 'Gym suspended successfully');
  } catch (err) {
    next(err);
  }
});

// GET /api/admin/users
router.get('/users', async (req, res, next) => {
  try {
    const { page, limit, skip } = getPagination(req.query);
    const { role, isActive, status, search } = req.query;

    const where = {};
    if (role && role !== 'ALL') {
      const upper = String(role).toUpperCase();
      where.role = upper === 'OWNER' ? 'GYM_OWNER' : upper === 'ADMIN' ? 'SUPER_ADMIN' : upper;
    }
    if (isActive !== undefined) where.isActive = isActive === 'true';
    else if (status === 'ACTIVE') where.isActive = true;
    else if (status === 'INACTIVE') where.isActive = false;

    if (search) {
      where.OR = [
        { fullName: { contains: search } },
        { email: { contains: search } },
        { mobile: { contains: search } },
      ];
    }

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          ownedGyms: { select: { id: true, name: true } },
          trainerProfile: { select: { id: true, trainerId: true, gymId: true, gym: { select: { name: true } } } },
          customerProfile: { select: { id: true, customerId: true, gymId: true, gym: { select: { name: true } } } },
        },
      }),
      prisma.user.count({ where }),
    ]);

    const cleanUsers = users.map((u) => {
      const clean = sanitizeUser(u);
      clean.status = u.isActive ? 'ACTIVE' : 'INACTIVE';
      clean.gymName =
        u.ownedGyms?.[0]?.name || u.trainerProfile?.gym?.name || u.customerProfile?.gym?.name || 'Platform';
      return clean;
    });
    return sendSuccess(res, formatPaginatedData(cleanUsers, total, page, limit), 'Users fetched');
  } catch (err) {
    next(err);
  }
});

// PUT / PATCH /api/admin/users/:id/status
const handleUpdateUserStatus = async (req, res, next) => {
  try {
    const { isActive, status } = req.body;
    const user = await prisma.user.findUnique({ where: { id: req.params.id } });
    if (!user) return sendError(res, 'User not found', 404);
    if (user.id === req.user.id) {
      return sendError(res, 'Cannot deactivate your own super admin account', 400);
    }

    const nextActive =
      typeof isActive === 'boolean' ? isActive : status ? String(status).toUpperCase() === 'ACTIVE' : !user.isActive;

    const updated = await prisma.user.update({
      where: { id: user.id },
      data: { isActive: nextActive },
    });

    await createAuditLog({
      userId: req.user.id,
      action: 'UPDATE_USER_STATUS',
      entity: 'User',
      entityId: user.id,
      details: { isActive: nextActive },
      req,
    });

    return sendSuccess(res, sanitizeUser(updated), 'User status updated');
  } catch (err) {
    next(err);
  }
};
router.put('/users/:id/status', handleUpdateUserStatus);
router.patch('/users/:id/status', handleUpdateUserStatus);

// GET /api/admin/subscriptions
router.get('/subscriptions', async (req, res, next) => {
  try {
    const { page, limit, skip } = getPagination(req.query);
    const { status, gymId, planId, search } = req.query;

    const where = {};
    if (status && status !== 'ALL') where.status = status;
    if (gymId) where.gymId = gymId;
    if (planId) where.planId = planId;
    if (search) {
      where.gym = { name: { contains: search } };
    }

    const [subscriptions, total] = await Promise.all([
      prisma.gymSubscription.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          gym: { select: { id: true, name: true, city: true, email: true } },
          plan: true,
        },
      }),
      prisma.gymSubscription.count({ where }),
    ]);

    const formatted = subscriptions.map((s) => ({
      ...s,
      gymName: s.gym?.name || '',
      planName: s.plan?.name || '',
      billingCycle: s.billingPeriod,
      plan: s.plan ? formatSubscriptionPlan(s.plan) : null,
    }));

    return sendSuccess(res, formatPaginatedData(formatted, total, page, limit), 'Subscriptions fetched');
  } catch (err) {
    next(err);
  }
});

// PATCH / PUT /api/admin/subscriptions/:id
const handleUpdateSubscription = async (req, res, next) => {
  try {
    const existing = await prisma.gymSubscription.findUnique({ where: { id: req.params.id } });
    if (!existing) return sendError(res, 'Subscription not found', 404);

    const { status, planId, billingPeriod, endDate, extendDays } = req.body;
    const data = {};
    if (status) data.status = status;
    if (planId) data.planId = planId;
    if (billingPeriod) data.billingPeriod = billingPeriod;
    if (endDate) data.endDate = new Date(endDate);
    if (extendDays) {
      data.endDate = dayjs(existing.endDate).add(parseInt(extendDays, 10), 'day').toDate();
    }

    const updated = await prisma.gymSubscription.update({
      where: { id: existing.id },
      data,
      include: { plan: true, gym: true },
    });

    if (status) {
      await prisma.gym.update({
        where: { id: existing.gymId },
        data: { subscriptionStatus: status },
      });
    }

    return sendSuccess(
      res,
      { ...updated, plan: updated.plan ? formatSubscriptionPlan(updated.plan) : null },
      'Subscription updated'
    );
  } catch (err) {
    next(err);
  }
};
router.patch('/subscriptions/:id', handleUpdateSubscription);
router.put('/subscriptions/:id', handleUpdateSubscription);

// CRUD /api/admin/subscription-plans AND /api/admin/plans aliases
const getPlansHandler = async (req, res, next) => {
  try {
    const plans = await prisma.subscriptionPlan.findMany({
      orderBy: { monthlyPrice: 'asc' },
      include: { _count: { select: { gymSubscriptions: true } } },
    });
    return sendSuccess(res, plans.map(formatSubscriptionPlan), 'Subscription plans fetched');
  } catch (err) {
    next(err);
  }
};

const createPlanHandler = async (req, res, next) => {
  try {
    const {
      name,
      description,
      monthlyPrice,
      yearlyPrice,
      maxCustomers,
      maxMembers,
      maxTrainers = 5,
      maxBranches = 1,
      features = [],
      isPopular = false,
      isActive = true,
    } = req.body;

    const plan = await prisma.subscriptionPlan.create({
      data: {
        name: name.trim(),
        description: description || null,
        monthlyPrice: Number(monthlyPrice),
        yearlyPrice: Number(yearlyPrice ?? Number(monthlyPrice) * 10),
        maxCustomers: parseInt(maxMembers ?? maxCustomers ?? 100, 10) || 100,
        maxTrainers: parseInt(maxTrainers, 10) || 5,
        maxBranches: parseInt(maxBranches, 10) || 1,
        features: stringifyJson(features, '[]'),
        isPopular: Boolean(isPopular),
        isActive: Boolean(isActive),
      },
    });

    await createAuditLog({
      userId: req.user.id,
      action: 'CREATE_SUBSCRIPTION_PLAN',
      entity: 'SubscriptionPlan',
      entityId: plan.id,
      details: { name, monthlyPrice, yearlyPrice },
      req,
    });

    return sendSuccess(res, formatSubscriptionPlan(plan), 'Subscription plan created', 201);
  } catch (err) {
    next(err);
  }
};

const updatePlanHandler = async (req, res, next) => {
  try {
    const existing = await prisma.subscriptionPlan.findUnique({ where: { id: req.params.id } });
    if (!existing) return sendError(res, 'Subscription plan not found', 404);

    const {
      name,
      description,
      monthlyPrice,
      yearlyPrice,
      maxCustomers,
      maxMembers,
      maxTrainers,
      maxBranches,
      features,
      isPopular,
      isActive,
    } = req.body;

    const resolvedMaxCustomers = maxMembers !== undefined ? maxMembers : maxCustomers;

    const updated = await prisma.subscriptionPlan.update({
      where: { id: existing.id },
      data: {
        ...(name !== undefined && { name }),
        ...(description !== undefined && { description }),
        ...(monthlyPrice !== undefined && { monthlyPrice: Number(monthlyPrice) }),
        ...(yearlyPrice !== undefined && { yearlyPrice: Number(yearlyPrice) }),
        ...(resolvedMaxCustomers !== undefined && { maxCustomers: parseInt(resolvedMaxCustomers, 10) }),
        ...(maxTrainers !== undefined && { maxTrainers: parseInt(maxTrainers, 10) }),
        ...(maxBranches !== undefined && { maxBranches: parseInt(maxBranches, 10) }),
        ...(features !== undefined && { features: stringifyJson(features, '[]') }),
        ...(isPopular !== undefined && { isPopular: Boolean(isPopular) }),
        ...(isActive !== undefined && { isActive: Boolean(isActive) }),
      },
    });

    await createAuditLog({
      userId: req.user.id,
      action: 'UPDATE_SUBSCRIPTION_PLAN',
      entity: 'SubscriptionPlan',
      entityId: updated.id,
      details: req.body,
      req,
    });

    return sendSuccess(res, formatSubscriptionPlan(updated), 'Subscription plan updated');
  } catch (err) {
    next(err);
  }
};

const deletePlanHandler = async (req, res, next) => {
  try {
    const existing = await prisma.subscriptionPlan.findUnique({ where: { id: req.params.id } });
    if (!existing) return sendError(res, 'Subscription plan not found', 404);

    await prisma.subscriptionPlan.update({
      where: { id: existing.id },
      data: { isActive: false },
    });

    await createAuditLog({
      userId: req.user.id,
      action: 'DEACTIVATE_SUBSCRIPTION_PLAN',
      entity: 'SubscriptionPlan',
      entityId: existing.id,
      req,
    });

    return sendSuccess(res, null, 'Subscription plan deactivated');
  } catch (err) {
    next(err);
  }
};

const planValidators = [
  body('name').trim().notEmpty().withMessage('Plan name is required'),
  body('monthlyPrice').isFloat({ min: 0 }).withMessage('Valid monthlyPrice is required'),
  validate,
];

router.get('/subscription-plans', getPlansHandler);
router.post('/subscription-plans', planValidators, createPlanHandler);
router.put('/subscription-plans/:id', updatePlanHandler);
router.delete('/subscription-plans/:id', deletePlanHandler);

router.get('/plans', getPlansHandler);
router.post('/plans', planValidators, createPlanHandler);
router.put('/plans/:id', updatePlanHandler);
router.delete('/plans/:id', deletePlanHandler);

// PUT /api/admin/pricing (batch pricing update)
router.put('/pricing', async (req, res, next) => {
  try {
    const { plans } = req.body;
    if (!Array.isArray(plans)) {
      return sendError(res, 'plans array is required', 400);
    }

    const updated = [];
    for (const p of plans) {
      const id = p.id || p._id;
      if (!id) continue;
      const plan = await prisma.subscriptionPlan.update({
        where: { id },
        data: {
          ...(p.monthlyPrice !== undefined && { monthlyPrice: Number(p.monthlyPrice) }),
          ...(p.yearlyPrice !== undefined && { yearlyPrice: Number(p.yearlyPrice) }),
          ...((p.maxMembers ?? p.maxCustomers) !== undefined && {
            maxCustomers: parseInt(p.maxMembers ?? p.maxCustomers, 10),
          }),
          ...(p.maxTrainers !== undefined && { maxTrainers: parseInt(p.maxTrainers, 10) }),
          ...(p.maxBranches !== undefined && { maxBranches: parseInt(p.maxBranches, 10) }),
          ...(p.isActive !== undefined && { isActive: Boolean(p.isActive) }),
        },
      });
      updated.push(formatSubscriptionPlan(plan));
    }

    return sendSuccess(res, updated, 'Pricing updated successfully');
  } catch (err) {
    next(err);
  }
});

// CRUD /api/admin/coupons (PlatformCoupon)
router.get('/coupons', async (req, res, next) => {
  try {
    const { page, limit, skip } = getPagination(req.query);
    const { search } = req.query;
    const where = search ? { code: { contains: search.toUpperCase() } } : {};
    const [coupons, total] = await Promise.all([
      prisma.platformCoupon.findMany({ where, skip, take: limit, orderBy: { createdAt: 'desc' } }),
      prisma.platformCoupon.count({ where }),
    ]);
    const formatted = coupons.map((c) => ({
      ...c,
      usedCount: c.currentUses,
      expiresAt: c.expiryDate,
      applicablePlans: parseJson(c.applicablePlans, []),
    }));
    return sendSuccess(res, formatPaginatedData(formatted, total, page, limit), 'Platform coupons fetched');
  } catch (err) {
    next(err);
  }
});

router.post(
  '/coupons',
  [
    body('code').trim().notEmpty().withMessage('Coupon code is required'),
    body('discountValue').isFloat({ gt: 0 }).withMessage('Discount value must be greater than 0'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const {
        code,
        discountType = 'PERCENTAGE',
        discountValue,
        maxUses = null,
        applicablePlans = [],
        expiryDate,
        expiresAt,
        isActive = true,
      } = req.body;

      const resolvedExpiry = expiryDate || expiresAt || null;
      const coupon = await prisma.platformCoupon.create({
        data: {
          code: code.trim().toUpperCase(),
          discountType: discountType === 'FLAT' ? 'FIXED' : discountType,
          discountValue: Number(discountValue),
          maxUses: maxUses ? parseInt(maxUses, 10) : null,
          applicablePlans: stringifyJson(applicablePlans, '[]'),
          expiryDate: resolvedExpiry ? new Date(resolvedExpiry) : null,
          isActive: Boolean(isActive),
        },
      });

      return sendSuccess(
        res,
        {
          ...coupon,
          usedCount: coupon.currentUses,
          expiresAt: coupon.expiryDate,
          applicablePlans: parseJson(coupon.applicablePlans, []),
        },
        'Platform coupon created',
        201
      );
    } catch (err) {
      next(err);
    }
  }
);

router.put('/coupons/:id', async (req, res, next) => {
  try {
    const existing = await prisma.platformCoupon.findUnique({ where: { id: req.params.id } });
    if (!existing) return sendError(res, 'Platform coupon not found', 404);

    const { code, discountType, discountValue, maxUses, applicablePlans, expiryDate, expiresAt, isActive } = req.body;
    const resolvedExpiry = expiryDate !== undefined ? expiryDate : expiresAt;

    const updated = await prisma.platformCoupon.update({
      where: { id: existing.id },
      data: {
        ...(code !== undefined && { code: code.trim().toUpperCase() }),
        ...(discountType !== undefined && { discountType: discountType === 'FLAT' ? 'FIXED' : discountType }),
        ...(discountValue !== undefined && { discountValue: Number(discountValue) }),
        ...(maxUses !== undefined && { maxUses: maxUses ? parseInt(maxUses, 10) : null }),
        ...(applicablePlans !== undefined && { applicablePlans: stringifyJson(applicablePlans, '[]') }),
        ...(resolvedExpiry !== undefined && { expiryDate: resolvedExpiry ? new Date(resolvedExpiry) : null }),
        ...(isActive !== undefined && { isActive: Boolean(isActive) }),
      },
    });

    return sendSuccess(
      res,
      {
        ...updated,
        usedCount: updated.currentUses,
        expiresAt: updated.expiryDate,
        applicablePlans: parseJson(updated.applicablePlans, []),
      },
      'Platform coupon updated'
    );
  } catch (err) {
    next(err);
  }
});

router.patch('/coupons/:id/status', async (req, res, next) => {
  try {
    const existing = await prisma.platformCoupon.findUnique({ where: { id: req.params.id } });
    if (!existing) return sendError(res, 'Platform coupon not found', 404);
    const updated = await prisma.platformCoupon.update({
      where: { id: existing.id },
      data: { isActive: req.body.isActive !== undefined ? Boolean(req.body.isActive) : !existing.isActive },
    });
    return sendSuccess(res, updated, 'Coupon status updated');
  } catch (err) {
    next(err);
  }
});

router.delete('/coupons/:id', async (req, res, next) => {
  try {
    const existing = await prisma.platformCoupon.findUnique({ where: { id: req.params.id } });
    if (!existing) return sendError(res, 'Platform coupon not found', 404);

    await prisma.platformCoupon.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'Platform coupon deleted');
  } catch (err) {
    next(err);
  }
});

// Subscription payments: /payments AND /subscription-payments aliases
const getSubPaymentsHandler = async (req, res, next) => {
  try {
    const { page, limit, skip } = getPagination(req.query);
    const { status, gymId, search } = req.query;

    const where = {};
    if (status && status !== 'ALL') where.status = status;
    if (gymId) where.gymId = gymId;
    if (search) {
      where.OR = [
        { transactionId: { contains: search } },
        { gym: { name: { contains: search } } },
      ];
    }

    const [payments, total] = await Promise.all([
      prisma.subscriptionPayment.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          gym: { select: { id: true, name: true, email: true, phone: true } },
          gymSubscription: { include: { plan: true } },
        },
      }),
      prisma.subscriptionPayment.count({ where }),
    ]);

    const formatted = payments.map((p) => ({
      ...p,
      gymName: p.gym?.name || '',
      plan: p.gymSubscription?.plan || null,
      planName: p.gymSubscription?.plan?.name || '',
    }));

    return sendSuccess(res, formatPaginatedData(formatted, total, page, limit), 'Subscription payments fetched');
  } catch (err) {
    next(err);
  }
};

const verifySubPaymentHandler = async (req, res, next) => {
  try {
    const { status = 'VERIFIED' } = req.body;
    const allowed = ['VERIFIED', 'REJECTED', 'REFUNDED'];
    if (!allowed.includes(status)) {
      return sendError(res, 'Status must be VERIFIED, REJECTED, or REFUNDED', 400);
    }

    const payment = await prisma.subscriptionPayment.findUnique({
      where: { id: req.params.id },
      include: { gymSubscription: true, gym: true },
    });
    if (!payment) return sendError(res, 'Subscription payment not found', 404);

    const updatedPayment = await prisma.$transaction(async (tx) => {
      const p = await tx.subscriptionPayment.update({
        where: { id: payment.id },
        data: { status },
      });

      if (status === 'VERIFIED') {
        const sub = payment.gymSubscription;
        const durationDays = sub.billingPeriod === 'YEARLY' ? 365 : 30;
        const startDate = nowIST().toDate();
        const endDate = nowIST().add(durationDays, 'day').toDate();

        await tx.gymSubscription.update({
          where: { id: sub.id },
          data: {
            status: 'ACTIVE',
            startDate,
            endDate,
          },
        });

        await tx.gym.update({
          where: { id: payment.gymId },
          data: { subscriptionStatus: 'ACTIVE', isActive: true },
        });
      } else if (status === 'REJECTED') {
        await tx.gymSubscription.update({
          where: { id: payment.gymSubscriptionId },
          data: { status: 'EXPIRED' },
        });
      }

      return p;
    });

    await createNotification({
      userId: payment.gym.ownerId,
      gymId: payment.gymId,
      type: 'SUBSCRIPTION_PAYMENT',
      title: `Subscription Payment ${status}`,
      message:
        status === 'VERIFIED'
          ? `Your subscription payment of ₹${payment.amount} has been verified and your plan is now active.`
          : `Your subscription payment of ₹${payment.amount} was marked ${status}.`,
      data: { paymentId: payment.id, status },
      io: req.app.get('io'),
    });

    await createAuditLog({
      userId: req.user.id,
      gymId: payment.gymId,
      action: 'VERIFY_SUBSCRIPTION_PAYMENT',
      entity: 'SubscriptionPayment',
      entityId: payment.id,
      details: { status, amount: payment.amount },
      req,
    });

    return sendSuccess(res, updatedPayment, `Subscription payment ${status.toLowerCase()} successfully`);
  } catch (err) {
    next(err);
  }
};

router.get('/payments', getSubPaymentsHandler);
router.put('/payments/:id/verify', verifySubPaymentHandler);
router.patch('/payments/:id/verify', verifySubPaymentHandler);

router.get('/subscription-payments', getSubPaymentsHandler);
router.put('/subscription-payments/:id/verify', verifySubPaymentHandler);
router.patch('/subscription-payments/:id/verify', verifySubPaymentHandler);

// CRUD /api/admin/domains
router.get('/domains', async (req, res, next) => {
  try {
    const { page, limit, skip } = getPagination(req.query);
    const { search } = req.query;
    const where = search
      ? { OR: [{ domainName: { contains: search } }, { gym: { name: { contains: search } } }] }
      : {};
    const [domains, total] = await Promise.all([
      prisma.domain.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: { gym: { select: { id: true, name: true, city: true } } },
      }),
      prisma.domain.count({ where }),
    ]);
    return sendSuccess(res, formatPaginatedData(domains.map(formatDomain), total, page, limit), 'Domains fetched');
  } catch (err) {
    next(err);
  }
});

router.post(
  '/domains',
  [
    body('gymId').notEmpty().withMessage('gymId is required'),
    body('domainName').trim().notEmpty().withMessage('domainName is required'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { gymId, domainName, renewalDate } = req.body;
      const domain = await prisma.domain.create({
        data: {
          gymId,
          domainName: domainName.trim().toLowerCase(),
          verificationStatus: 'PENDING',
          verificationToken: `gympro-verify=${generateReadableId('DNS').toLowerCase()}`,
          cnameTarget: 'cname.gympro.app',
          dnsConfigured: false,
          sslStatus: 'PENDING',
          activatedAt: null,
          renewalDate: renewalDate ? new Date(renewalDate) : nowIST().add(1, 'year').toDate(),
        },
        include: { gym: { select: { id: true, name: true } } },
      });
      return sendSuccess(res, formatDomain(domain), 'Domain created', 201);
    } catch (err) {
      next(err);
    }
  }
);

router.patch('/domains/:id/verify', async (req, res, next) => {
  try {
    const existing = await prisma.domain.findUnique({ where: { id: req.params.id } });
    if (!existing) return sendError(res, 'Domain not found', 404);

    // PART 27: Do not show domain as active until DNS configuration is verified
    const updated = await prisma.domain.update({
      where: { id: existing.id },
      data: {
        dnsConfigured: true,
        sslStatus: 'ACTIVE',
        verificationStatus: 'VERIFIED',
        activatedAt: existing.activatedAt || new Date(),
      },
      include: { gym: { select: { id: true, name: true } } },
    });
    return sendSuccess(res, formatDomain(updated), 'Domain DNS & SSL verified');
  } catch (err) {
    next(err);
  }
});

const handleDomainStatus = async (req, res, next) => {
  try {
    const existing = await prisma.domain.findUnique({ where: { id: req.params.id } });
    if (!existing) return sendError(res, 'Domain not found', 404);

    const { status, verificationStatus } = req.body;
    const requestedStatus = String(status || verificationStatus || '').toUpperCase();
    const mappedStatus = requestedStatus === 'ACTIVE' ? 'VERIFIED' : requestedStatus;

    // PART 27: Do not show a domain as active until configuration is verified
    if (mappedStatus === 'VERIFIED' && !existing.dnsConfigured && !req.body.dnsConfigured) {
      return sendError(res, 'Verify DNS configuration before activating this domain', 400);
    }

    const updated = await prisma.domain.update({
      where: { id: existing.id },
      data: {
        ...(mappedStatus && { verificationStatus: mappedStatus }),
        ...(mappedStatus === 'VERIFIED' && {
          dnsConfigured: true,
          sslStatus: 'ACTIVE',
          activatedAt: existing.activatedAt || new Date(),
        }),
        ...(mappedStatus === 'SUSPENDED' && { sslStatus: 'PENDING' }),
      },
      include: { gym: { select: { id: true, name: true } } },
    });

    return sendSuccess(res, formatDomain(updated), 'Domain status updated');
  } catch (err) {
    next(err);
  }
};
router.patch('/domains/:id/status', handleDomainStatus);
router.put('/domains/:id', handleDomainStatus);

router.delete('/domains/:id', async (req, res, next) => {
  try {
    const existing = await prisma.domain.findUnique({ where: { id: req.params.id } });
    if (!existing) return sendError(res, 'Domain not found', 404);
    await prisma.domain.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'Domain deleted');
  } catch (err) {
    next(err);
  }
});

// Support Tickets
router.get('/support-tickets', async (req, res, next) => {
  try {
    const { status, search } = req.query;
    const where = {};
    if (status && status !== 'ALL') where.status = status;
    if (search) {
      where.OR = [{ subject: { contains: search } }, { message: { contains: search } }];
    }

    const tickets = await prisma.supportTicket.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: {
        gym: {
          select: {
            id: true,
            name: true,
            owner: { select: { id: true, fullName: true, mobile: true, email: true } },
          },
        },
      },
    });

    const formatted = tickets.map((t) => ({
      ...formatTicket(t),
      user: t.gym?.owner ? sanitizeUser(t.gym.owner) : null,
    }));

    return sendSuccess(res, formatted, 'Support tickets fetched');
  } catch (err) {
    next(err);
  }
});

router.post('/support-tickets/:id/reply', async (req, res, next) => {
  try {
    const ticket = await prisma.supportTicket.findUnique({
      where: { id: req.params.id },
      include: { gym: true },
    });
    if (!ticket) return sendError(res, 'Ticket not found', 404);

    const replies = parseJson(ticket.replies, []);
    replies.push({
      sender: req.user.fullName,
      role: 'SUPER_ADMIN',
      message: req.body.message,
      createdAt: new Date().toISOString(),
    });

    const updated = await prisma.supportTicket.update({
      where: { id: ticket.id },
      data: {
        replies: JSON.stringify(replies),
        status: ticket.status === 'OPEN' ? 'IN_PROGRESS' : ticket.status,
      },
    });

    if (ticket.userId || ticket.gym?.ownerId) {
      await createNotification({
        userId: ticket.userId || ticket.gym.ownerId,
        gymId: ticket.gymId,
        type: 'SUPPORT_REPLY',
        title: `Support Reply: ${ticket.subject}`,
        message: req.body.message,
        io: req.app.get('io'),
      });
    }

    return sendSuccess(res, formatTicket(updated), 'Reply sent');
  } catch (err) {
    next(err);
  }
});

router.patch('/support-tickets/:id/status', async (req, res, next) => {
  try {
    const ticket = await prisma.supportTicket.findUnique({ where: { id: req.params.id } });
    if (!ticket) return sendError(res, 'Ticket not found', 404);

    const updated = await prisma.supportTicket.update({
      where: { id: ticket.id },
      data: { status: req.body.status || 'RESOLVED' },
    });
    return sendSuccess(res, formatTicket(updated), 'Ticket status updated');
  } catch (err) {
    next(err);
  }
});

// GET/PUT /api/admin/trial-settings
router.get('/trial-settings', async (req, res, next) => {
  try {
    let [settings, grace] = await Promise.all([
      prisma.trialSettings.findFirst(),
      prisma.gracePeriodSettings.findFirst(),
    ]);
    if (!settings) {
      settings = await prisma.trialSettings.create({
        data: { durationDays: 7, isEnabled: true, reminderDays: '[5, 6, 7]', requirePaymentDetails: false },
      });
    }
    if (!grace) {
      grace = await prisma.gracePeriodSettings.create({ data: { durationDays: 3, isEnabled: true } });
    }
    const remArray = parseJson(settings.reminderDays, [5, 6, 7]);
    return sendSuccess(
      res,
      {
        ...settings,
        reminderDays: remArray,
        trialDurationDays: settings.durationDays,
        reminderDaysBeforeExpiry: remArray.join(','),
        requirePhoneVerification: settings.requireOtpVerification,
        requireCardUpfront: settings.requirePaymentDetails,
        gracePeriodDays: grace.durationDays,
      },
      'Trial settings retrieved'
    );
  } catch (err) {
    next(err);
  }
});

router.put('/trial-settings', async (req, res, next) => {
  try {
    const {
      durationDays,
      trialDurationDays,
      isEnabled,
      reminderDays,
      reminderDaysBeforeExpiry,
      requirePaymentDetails,
      requireCardUpfront,
      requireOtpVerification,
      requirePhoneVerification,
      allowOneTrialPerPhone,
      autoSuspendOnExpiry,
      maxTrialMembers,
      maxTrialBranches,
      gracePeriodDays,
    } = req.body;

    let existing = await prisma.trialSettings.findFirst();

    let parsedReminders = reminderDays;
    if (parsedReminders === undefined && reminderDaysBeforeExpiry !== undefined) {
      parsedReminders = String(reminderDaysBeforeExpiry)
        .split(',')
        .map((n) => parseInt(n.trim(), 10))
        .filter((n) => !Number.isNaN(n));
    }

    const resolvedDuration = trialDurationDays !== undefined ? trialDurationDays : durationDays;
    const resolvedReqPay = requireCardUpfront !== undefined ? requireCardUpfront : requirePaymentDetails;
    const resolvedReqOtp =
      requirePhoneVerification !== undefined ? requirePhoneVerification : requireOtpVerification;

    const data = {
      ...(resolvedDuration !== undefined && { durationDays: parseInt(resolvedDuration, 10) }),
      ...(isEnabled !== undefined && { isEnabled: Boolean(isEnabled) }),
      ...(parsedReminders !== undefined && { reminderDays: stringifyJson(parsedReminders, '[5, 6, 7]') }),
      ...(resolvedReqPay !== undefined && { requirePaymentDetails: Boolean(resolvedReqPay) }),
      ...(resolvedReqOtp !== undefined && { requireOtpVerification: Boolean(resolvedReqOtp) }),
      ...(allowOneTrialPerPhone !== undefined && { allowOneTrialPerPhone: Boolean(allowOneTrialPerPhone) }),
      ...(autoSuspendOnExpiry !== undefined && { autoSuspendOnExpiry: Boolean(autoSuspendOnExpiry) }),
      ...(maxTrialMembers !== undefined && { maxTrialMembers: parseInt(maxTrialMembers, 10) }),
      ...(maxTrialBranches !== undefined && { maxTrialBranches: parseInt(maxTrialBranches, 10) }),
    };

    const updated = existing
      ? await prisma.trialSettings.update({ where: { id: existing.id }, data })
      : await prisma.trialSettings.create({ data: { durationDays: 7, isEnabled: true, ...data } });

    if (gracePeriodDays !== undefined) {
      const existingGrace = await prisma.gracePeriodSettings.findFirst();
      if (existingGrace) {
        await prisma.gracePeriodSettings.update({
          where: { id: existingGrace.id },
          data: { durationDays: parseInt(gracePeriodDays, 10) },
        });
      } else {
        await prisma.gracePeriodSettings.create({
          data: { durationDays: parseInt(gracePeriodDays, 10), isEnabled: true },
        });
      }
    }

    await createAuditLog({
      userId: req.user.id,
      action: 'UPDATE_TRIAL_SETTINGS',
      entity: 'TrialSettings',
      entityId: updated.id,
      details: data,
      req,
    });

    const remArray = parseJson(updated.reminderDays, [5, 6, 7]);
    return sendSuccess(
      res,
      {
        ...updated,
        reminderDays: remArray,
        trialDurationDays: updated.durationDays,
        reminderDaysBeforeExpiry: remArray.join(','),
        requirePhoneVerification: updated.requireOtpVerification,
        requireCardUpfront: updated.requirePaymentDetails,
        gracePeriodDays: gracePeriodDays !== undefined ? parseInt(gracePeriodDays, 10) : 3,
      },
      'Trial settings updated'
    );
  } catch (err) {
    next(err);
  }
});

// GET/PUT /api/admin/grace-period-settings
router.get('/grace-period-settings', async (req, res, next) => {
  try {
    let settings = await prisma.gracePeriodSettings.findFirst();
    if (!settings) {
      settings = await prisma.gracePeriodSettings.create({ data: { durationDays: 3, isEnabled: true } });
    }
    return sendSuccess(res, settings, 'Grace period settings retrieved');
  } catch (err) {
    next(err);
  }
});

router.put('/grace-period-settings', async (req, res, next) => {
  try {
    const { durationDays, isEnabled } = req.body;
    const existing = await prisma.gracePeriodSettings.findFirst();
    const data = {
      ...(durationDays !== undefined && { durationDays: parseInt(durationDays, 10) }),
      ...(isEnabled !== undefined && { isEnabled: Boolean(isEnabled) }),
    };

    const updated = existing
      ? await prisma.gracePeriodSettings.update({ where: { id: existing.id }, data })
      : await prisma.gracePeriodSettings.create({ data: { durationDays: 3, isEnabled: true, ...data } });

    return sendSuccess(res, updated, 'Grace period settings updated');
  } catch (err) {
    next(err);
  }
});

// GET /api/admin/analytics
router.get('/analytics', async (req, res, next) => {
  try {
    const months = parseInt(req.query.months, 10) || 6;
    const startDate = nowIST().subtract(months - 1, 'month').startOf('month').toDate();

    const [gyms, allGymsCount, activeSubs, cancelledOrExpiredSubs, payments, subscriptionsByPlan, attendances] =
      await Promise.all([
        prisma.gym.findMany({
          where: { createdAt: { gte: startDate } },
          select: { createdAt: true, subscriptionStatus: true },
        }),
        prisma.gym.count(),
        prisma.gymSubscription.findMany({
          where: { status: 'ACTIVE' },
          include: { plan: true },
        }),
        prisma.gymSubscription.count({ where: { status: { in: ['EXPIRED', 'CANCELLED'] } } }),
        prisma.subscriptionPayment.findMany({
          where: { status: 'VERIFIED', createdAt: { gte: startDate } },
          select: { amount: true, createdAt: true },
        }),
        prisma.gymSubscription.groupBy({
          by: ['planId'],
          where: { status: { in: ['ACTIVE', 'TRIAL'] } },
          _count: { id: true },
        }),
        prisma.attendance.findMany({
          where: { date: { gte: nowIST().subtract(13, 'day').startOf('day').toDate() } },
          select: { date: true, status: true },
        }),
      ]);

    const plans = await prisma.subscriptionPlan.findMany({ select: { id: true, name: true } });
    const planMap = Object.fromEntries(plans.map((p) => [p.id, p.name]));

    const monthlyMap = {};
    for (let i = months - 1; i >= 0; i--) {
      const d = dayjs().tz(IST_TZ).subtract(i, 'month');
      const mKey = d.format('YYYY-MM');
      monthlyMap[mKey] = {
        month: mKey,
        label: d.format('MMM YY'),
        newGyms: 0,
        gyms: 0,
        trials: 0,
        revenue: 0,
      };
    }

    gyms.forEach((g) => {
      const key = dayjs(g.createdAt).tz(IST_TZ).format('YYYY-MM');
      if (monthlyMap[key]) {
        monthlyMap[key].newGyms += 1;
        monthlyMap[key].gyms += 1;
        if (g.subscriptionStatus === 'TRIAL') monthlyMap[key].trials += 1;
      }
    });

    payments.forEach((p) => {
      const key = dayjs(p.createdAt).tz(IST_TZ).format('YYYY-MM');
      if (monthlyMap[key]) monthlyMap[key].revenue += Number(p.amount || 0);
    });

    const activityMap = {};
    for (let i = 6; i >= 0; i--) {
      const d = dayjs().tz(IST_TZ).subtract(i, 'day');
      const key = d.format('YYYY-MM-DD');
      activityMap[key] = { label: d.format('DD MMM'), present: 0, absent: 0 };
    }
    attendances.forEach((a) => {
      const key = dayjs(a.date).format('YYYY-MM-DD');
      if (activityMap[key]) {
        if (a.status === 'PRESENT') activityMap[key].present += 1;
        else activityMap[key].absent += 1;
      }
    });

    const mrr = activeSubs.reduce((sum, s) => {
      const val = s.billingPeriod === 'YEARLY' ? (s.plan?.yearlyPrice || s.amount) / 12 : s.plan?.monthlyPrice || s.amount;
      return sum + Number(val || 0);
    }, 0);

    const totalSubs = activeSubs.length + cancelledOrExpiredSubs;
    const trialConversionRate = totalSubs > 0 ? Number(((activeSubs.length / totalSubs) * 100).toFixed(1)) : 0;
    const churnRate = totalSubs > 0 ? Number(((cancelledOrExpiredSubs / totalSubs) * 100).toFixed(1)) : 0;

    const planDistribution = subscriptionsByPlan.map((item) => ({
      planId: item.planId,
      name: planMap[item.planId] || 'Other',
      planName: planMap[item.planId] || 'Other',
      value: item._count.id,
      count: item._count.id,
    }));

    const series = Object.values(monthlyMap);
    return sendSuccess(
      res,
      {
        kpis: {
          mrr: Number(mrr.toFixed(2)),
          arr: Number((mrr * 12).toFixed(2)),
          trialConversionRate,
          churnRate,
          totalGyms: allGymsCount,
        },
        revenueSeries: series,
        growthSeries: series,
        monthlyTrend: series,
        planDistribution,
        activitySeries: Object.values(activityMap),
      },
      'Admin analytics fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/admin/reports
router.get('/reports', async (req, res, next) => {
  try {
    const [gyms, verifiedPayments, customerCounts] = await Promise.all([
      prisma.gym.findMany({
        include: {
          owner: { select: { fullName: true, email: true } },
          gymSubscriptions: { take: 1, orderBy: { createdAt: 'desc' }, include: { plan: true } },
          _count: { select: { customers: true, trainers: true, branches: true } },
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.subscriptionPayment.groupBy({
        by: ['gymId'],
        where: { status: 'VERIFIED' },
        _sum: { amount: true },
        _count: { id: true },
      }),
      prisma.customerMembership.count({ where: { status: 'ACTIVE' } }),
    ]);

    const revenueMap = Object.fromEntries(
      verifiedPayments.map((v) => [v.gymId, { totalPaid: v._sum.amount || 0, paymentsCount: v._count.id }])
    );

    const gymReport = gyms.map((g) => ({
      id: g.id,
      name: g.name,
      gymName: g.name,
      city: g.city,
      ownerName: g.owner?.fullName,
      planName: g.gymSubscriptions?.[0]?.plan?.name || 'Trial',
      status: g.subscriptionStatus,
      subscriptionStatus: g.subscriptionStatus,
      customers: g._count.customers,
      trainers: g._count.trainers,
      branches: g._count.branches,
      amount: revenueMap[g.id]?.totalPaid || 0,
      subscriptionRevenue: revenueMap[g.id]?.totalPaid || 0,
      createdAt: g.createdAt,
    }));

    return sendSuccess(
      res,
      {
        summary: {
          totalGyms: gyms.length,
          totalActiveMembershipsAcrossPlatform: customerCounts,
          totalSubscriptionRevenue: verifiedPayments.reduce((acc, v) => acc + (v._sum.amount || 0), 0),
        },
        rows: gymReport,
        gyms: gymReport,
      },
      'Admin reports generated'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/admin/audit-logs
router.get('/audit-logs', async (req, res, next) => {
  try {
    const { page, limit, skip } = getPagination(req.query);
    const { gymId, userId, action, entity, search } = req.query;

    const where = {};
    if (gymId) where.gymId = gymId;
    if (userId) where.userId = userId;
    if (action) where.action = { contains: action };
    if (entity) where.entity = entity;
    if (search) {
      where.OR = [
        { action: { contains: search } },
        { entity: { contains: search } },
        { user: { fullName: { contains: search } } },
      ];
    }

    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          user: { select: { id: true, fullName: true, email: true, role: true } },
          gym: { select: { id: true, name: true } },
        },
      }),
      prisma.auditLog.count({ where }),
    ]);

    const formatted = logs.map((l) => {
      const parsedDetails = parseJson(l.details, {});
      return {
        ...l,
        user: l.user ? sanitizeUser(l.user) : null,
        details: typeof parsedDetails === 'object' ? JSON.stringify(parsedDetails) : String(parsedDetails),
        detailsObj: parsedDetails,
      };
    });
    return sendSuccess(res, formatPaginatedData(formatted, total, page, limit), 'Audit logs fetched');
  } catch (err) {
    next(err);
  }
});

// GET/PUT /api/admin/settings
router.get('/settings', async (req, res, next) => {
  try {
    const [trialSettings, gracePeriodSettings, platformSettings] = await Promise.all([
      prisma.trialSettings.findFirst(),
      prisma.gracePeriodSettings.findFirst(),
      prisma.platformSetting.findMany(),
    ]);

    const config = {};
    platformSettings.forEach((s) => {
      config[s.key] = parseJson(s.value, s.value);
    });

    return sendSuccess(
      res,
      {
        platformName: config.platformName ?? 'GYM PRO',
        supportEmail: config.supportEmail ?? 'support@gympro.in',
        supportPhone: config.supportPhone ?? '+91 98200 11223',
        gstPercentage: config.gstPercentage ?? config.defaultGstPercent ?? 18,
        upiId: config.upiId ?? 'gympro@icici',
        upiName: config.upiName ?? 'GYM PRO SaaS',
        maintenanceMode: config.maintenanceMode ?? false,
        allowSelfRegistration: config.allowSelfRegistration ?? true,
        enableCustomDomains: config.enableCustomDomains ?? true,
        trialSettings: trialSettings
          ? { ...trialSettings, reminderDays: parseJson(trialSettings.reminderDays, [5, 6, 7]) }
          : null,
        gracePeriodSettings,
        platformConfig: config,
      },
      'Platform settings retrieved'
    );
  } catch (err) {
    next(err);
  }
});

router.put('/settings', async (req, res, next) => {
  try {
    const { trialSettings, gracePeriodSettings, platformConfig, ...flatKeys } = req.body;

    if (trialSettings) {
      const existingTrial = await prisma.trialSettings.findFirst();
      const trialData = {
        ...(trialSettings.durationDays !== undefined && {
          durationDays: parseInt(trialSettings.durationDays, 10),
        }),
        ...(trialSettings.isEnabled !== undefined && { isEnabled: Boolean(trialSettings.isEnabled) }),
        ...(trialSettings.reminderDays !== undefined && {
          reminderDays: stringifyJson(trialSettings.reminderDays, '[5, 6, 7]'),
        }),
        ...(trialSettings.requirePaymentDetails !== undefined && {
          requirePaymentDetails: Boolean(trialSettings.requirePaymentDetails),
        }),
      };
      if (existingTrial) {
        await prisma.trialSettings.update({ where: { id: existingTrial.id }, data: trialData });
      } else {
        await prisma.trialSettings.create({ data: trialData });
      }
    }

    if (gracePeriodSettings) {
      const existingGrace = await prisma.gracePeriodSettings.findFirst();
      const graceData = {
        ...(gracePeriodSettings.durationDays !== undefined && {
          durationDays: parseInt(gracePeriodSettings.durationDays, 10),
        }),
        ...(gracePeriodSettings.isEnabled !== undefined && {
          isEnabled: Boolean(gracePeriodSettings.isEnabled),
        }),
      };
      if (existingGrace) {
        await prisma.gracePeriodSettings.update({ where: { id: existingGrace.id }, data: graceData });
      } else {
        await prisma.gracePeriodSettings.create({ data: graceData });
      }
    }

    const mergedConfig = { ...(platformConfig || {}), ...flatKeys };
    for (const [key, val] of Object.entries(mergedConfig)) {
      if (val === undefined) continue;
      await prisma.platformSetting.upsert({
        where: { key },
        update: { value: stringifyJson(val, String(val)) },
        create: { key, value: stringifyJson(val, String(val)) },
      });
    }

    await createAuditLog({
      userId: req.user.id,
      action: 'UPDATE_PLATFORM_SETTINGS',
      entity: 'PlatformSetting',
      details: mergedConfig,
      req,
    });

    return sendSuccess(res, mergedConfig, 'Platform settings updated successfully');
  } catch (err) {
    next(err);
  }
});

module.exports = router;

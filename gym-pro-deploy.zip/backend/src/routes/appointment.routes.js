const express = require('express');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const { formatCustomer, formatTrainer } = require('../utils/json');
const { getISTDayRange } = require('../utils/date');
const { createNotification } = require('../utils/notification');
const { createAuditLog } = require('../utils/audit');

const router = express.Router();

router.use(authenticate, requireGymAccess());

const VALID_TYPES = new Set(['PERSONAL_TRAINING', 'GROUP_CLASS', 'CONSULTATION']);
const VALID_STATUSES = new Set(['SCHEDULED', 'CONFIRMED', 'CANCELLED', 'COMPLETED', 'RESCHEDULED']);

const normalizeType = (val) => {
  const upper = String(val || 'PERSONAL_TRAINING').trim().toUpperCase().replace(/[\s-]+/g, '_');
  return VALID_TYPES.has(upper) ? upper : 'PERSONAL_TRAINING';
};

const normalizeStatus = (val) => {
  const upper = String(val || 'SCHEDULED').trim().toUpperCase();
  return VALID_STATUSES.has(upper) ? upper : 'SCHEDULED';
};

const toMinutes = (hhmm = '09:00') => {
  const parts = String(hhmm).split(':');
  const h = parseInt(parts[0], 10);
  const m = parseInt(parts[1], 10) || 0;
  return (Number.isFinite(h) ? h : 9) * 60 + m;
};

const computeEndTime = (startTime = '09:00', endTime) => {
  if (endTime) return endTime;
  const total = Math.min(toMinutes(startTime) + 60, 23 * 60 + 59);
  const hh = String(Math.floor(total / 60)).padStart(2, '0');
  const mm = String(total % 60).padStart(2, '0');
  return `${hh}:${mm}`;
};

const hasTrainerTimeOverlap = async ({ gymId, trainerId, date, startTime, endTime, excludeId }) => {
  if (!trainerId) return false;
  const { start, end } = getISTDayRange(date);
  const candidates = await prisma.appointment.findMany({
    where: {
      gymId,
      trainerId,
      date: { gte: start, lte: end },
      status: { not: 'CANCELLED' },
      ...(excludeId ? { id: { not: excludeId } } : {}),
    },
  });

  const newStart = toMinutes(startTime);
  const newEnd = toMinutes(endTime);
  return candidates.some((existing) => {
    const exStart = toMinutes(existing.startTime);
    const exEnd = toMinutes(existing.endTime);
    return newStart < exEnd && newEnd > exStart;
  });
};

const formatAppointment = (a) => ({
  ...a,
  time: a.startTime,
  trainerName: a.trainer?.user?.fullName || null,
  customerName: a.customer?.user?.fullName || null,
  trainer: a.trainer ? formatTrainer(a.trainer) : null,
  customer: a.customer ? formatCustomer(a.customer) : null,
});

const appointmentInclude = {
  trainer: { include: { user: true } },
  customer: { include: { user: true } },
  bookings: { include: { customer: { include: { user: true } } } },
};

// GET /api/appointments/me (Customer)
router.get('/me', authorize('CUSTOMER'), async (req, res, next) => {
  try {
    const customer = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
    if (!customer) return sendError(res, 'Customer profile not found', 404);

    const appointments = await prisma.appointment.findMany({
      where: {
        gymId: customer.gymId,
        OR: [
          { customerId: customer.id },
          { bookings: { some: { customerId: customer.id } } },
        ],
      },
      include: appointmentInclude,
      orderBy: [{ date: 'asc' }, { startTime: 'asc' }],
    });

    return sendSuccess(res, appointments.map(formatAppointment), 'My appointments fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/appointments/me/book (Customer self-booking)
router.post('/me/book', authorize('CUSTOMER'), async (req, res, next) => {
  try {
    const customer = await prisma.customerProfile.findUnique({
      where: { userId: req.user.id },
      include: { user: true },
    });
    if (!customer) return sendError(res, 'Customer profile not found', 404);

    // Case 1: Joining an existing group class / scheduled slot
    if (req.body.appointmentId) {
      const appt = await prisma.appointment.findUnique({
        where: { id: req.body.appointmentId },
        include: { bookings: true },
      });
      if (!appt || appt.gymId !== customer.gymId) return sendError(res, 'Appointment not found', 404);
      if (appt.status === 'CANCELLED') return sendError(res, 'Appointment has been cancelled', 400);

      const already = appt.bookings.find((b) => b.customerId === customer.id && b.status !== 'CANCELLED');
      if (already) return sendError(res, 'You have already booked this appointment', 409);
      if (appt.bookedCount >= appt.capacity) return sendError(res, 'Session is already at full capacity', 400);

      await prisma.$transaction([
        prisma.appointmentBooking.create({
          data: { appointmentId: appt.id, customerId: customer.id, status: 'CONFIRMED' },
        }),
        prisma.appointment.update({
          where: { id: appt.id },
          data: { bookedCount: { increment: 1 } },
        }),
      ]);

      const updated = await prisma.appointment.findUnique({
        where: { id: appt.id },
        include: appointmentInclude,
      });
      return sendSuccess(res, formatAppointment(updated), 'Appointment booked successfully', 201);
    }

    // Case 2: Booking a new 1-on-1 session directly
    const {
      title = 'Personal Training Session',
      type = 'PERSONAL_TRAINING',
      trainerId = customer.assignedTrainerId,
      date,
      time,
      startTime,
      endTime,
      notes,
    } = req.body;

    const effectiveStart = startTime || time;
    if (!date || !effectiveStart) {
      return sendError(res, 'date and time are required', 400);
    }
    const effectiveEnd = computeEndTime(effectiveStart, endTime);

    let resolvedTrainer = null;
    if (trainerId) {
      resolvedTrainer = await prisma.trainerProfile.findUnique({
        where: { id: trainerId },
        include: { user: true },
      });
      if (!resolvedTrainer || resolvedTrainer.gymId !== customer.gymId) {
        return sendError(res, 'Selected trainer not found in gym', 404);
      }

      const overlap = await hasTrainerTimeOverlap({
        gymId: customer.gymId,
        trainerId: resolvedTrainer.id,
        date,
        startTime: effectiveStart,
        endTime: effectiveEnd,
      });
      if (overlap) {
        return sendError(res, 'Selected trainer already has an overlapping session in this time slot', 409);
      }
    }

    const created = await prisma.appointment.create({
      data: {
        gymId: customer.gymId,
        trainerId: resolvedTrainer?.id || null,
        customerId: customer.id,
        type: normalizeType(type),
        title: title.trim(),
        date: new Date(date),
        startTime: effectiveStart,
        endTime: effectiveEnd,
        status: 'SCHEDULED',
        capacity: 1,
        bookedCount: 1,
        notes: notes || null,
      },
      include: appointmentInclude,
    });

    if (resolvedTrainer?.userId) {
      await createNotification({
        userId: resolvedTrainer.userId,
        gymId: customer.gymId,
        type: 'APPOINTMENT_BOOKED',
        title: 'New Session Requested',
        message: `${customer.user?.fullName || 'A customer'} booked "${created.title}" on ${date} at ${effectiveStart}.`,
        data: { appointmentId: created.id },
      });
    }

    return sendSuccess(res, formatAppointment(created), 'Appointment booked successfully', 201);
  } catch (err) {
    next(err);
  }
});

// PATCH /api/appointments/me/:id/cancel (Customer)
router.patch('/me/:id/cancel', authorize('CUSTOMER'), async (req, res, next) => {
  try {
    const customer = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
    if (!customer) return sendError(res, 'Customer profile not found', 404);

    const appt = await prisma.appointment.findUnique({
      where: { id: req.params.id },
      include: { bookings: true },
    });
    if (!appt || appt.gymId !== customer.gymId) return sendError(res, 'Appointment not found', 404);

    const booking = appt.bookings.find((b) => b.customerId === customer.id && b.status !== 'CANCELLED');
    if (booking) {
      await prisma.$transaction([
        prisma.appointmentBooking.update({ where: { id: booking.id }, data: { status: 'CANCELLED' } }),
        prisma.appointment.update({
          where: { id: appt.id },
          data: { bookedCount: Math.max(0, appt.bookedCount - 1) },
        }),
      ]);
      if (appt.customerId === customer.id) {
        await prisma.appointment.update({ where: { id: appt.id }, data: { status: 'CANCELLED' } });
      }
      return sendSuccess(res, { id: appt.id, status: 'CANCELLED' }, 'Booking cancelled');
    }

    if (appt.customerId === customer.id) {
      const updated = await prisma.appointment.update({
        where: { id: appt.id },
        data: { status: 'CANCELLED' },
        include: appointmentInclude,
      });
      return sendSuccess(res, formatAppointment(updated), 'Appointment cancelled');
    }

    return sendError(res, 'You do not have a booking on this appointment', 403);
  } catch (err) {
    next(err);
  }
});

// GET /api/appointments/calendar
router.get('/calendar', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { startDate, endDate, trainerId } = req.query;
    const where = { gymId };
    if (trainerId) where.trainerId = trainerId;
    if (startDate || endDate) {
      where.date = {
        ...(startDate ? { gte: new Date(startDate) } : {}),
        ...(endDate ? { lte: new Date(endDate) } : {}),
      };
    }

    const list = await prisma.appointment.findMany({
      where,
      include: appointmentInclude,
      orderBy: [{ date: 'asc' }, { startTime: 'asc' }],
    });

    return sendSuccess(res, list.map(formatAppointment), 'Calendar appointments fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/appointments
router.get('/', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { page, limit, skip } = getPagination(req.query);
    const { trainerId, customerId, status, type, date } = req.query;

    const where = { gymId };
    if (trainerId) where.trainerId = trainerId;
    if (customerId) where.customerId = customerId;
    if (status) where.status = normalizeStatus(status);
    if (type) where.type = normalizeType(type);
    if (date) {
      const { start, end } = getISTDateRange(date);
      where.date = { gte: start, lte: end };
    }

    if (req.user.role === 'TRAINER') {
      const tr = await prisma.trainerProfile.findUnique({ where: { userId: req.user.id } });
      if (tr) where.trainerId = tr.id;
    } else if (req.user.role === 'CUSTOMER') {
      const cust = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
      if (cust) {
        where.OR = [
          { customerId: cust.id },
          { capacity: { gt: 1 } },
        ];
      }
    }

    const [appointments, total] = await Promise.all([
      prisma.appointment.findMany({
        where,
        skip,
        take: limit,
        orderBy: [{ date: 'asc' }, { startTime: 'asc' }],
        include: appointmentInclude,
      }),
      prisma.appointment.count({ where }),
    ]);

    return sendSuccess(
      res,
      formatPaginatedData(appointments.map(formatAppointment), total, page, limit),
      'Appointments fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/appointments/:id
router.get('/:id', async (req, res, next) => {
  try {
    const appt = await prisma.appointment.findUnique({
      where: { id: req.params.id },
      include: appointmentInclude,
    });
    if (!appt || appt.gymId !== req.gymId) return sendError(res, 'Appointment not found', 404);

    return sendSuccess(res, formatAppointment(appt), 'Appointment fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/appointments
router.post(
  '/',
  authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'),
  [
    body('title').trim().notEmpty().withMessage('Title is required'),
    body('date').notEmpty().withMessage('Date is required'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const {
        title,
        type = 'PERSONAL_TRAINING',
        trainerId,
        customerId,
        date,
        startTime,
        time,
        endTime,
        capacity = 1,
        notes,
      } = req.body;

      const effectiveStart = startTime || time;
      if (!effectiveStart) return sendError(res, 'startTime or time is required', 400);
      const effectiveEnd = computeEndTime(effectiveStart, endTime);

      let resolvedTrainerId = trainerId || null;
      if (req.user.role === 'TRAINER' && !resolvedTrainerId) {
        const tr = await prisma.trainerProfile.findUnique({ where: { userId: req.user.id } });
        if (tr) resolvedTrainerId = tr.id;
      }

      if (resolvedTrainerId) {
        const overlap = await hasTrainerTimeOverlap({
          gymId,
          trainerId: resolvedTrainerId,
          date,
          startTime: effectiveStart,
          endTime: effectiveEnd,
        });
        if (overlap) {
          return sendError(res, 'Trainer already has an overlapping appointment at this date and time', 409);
        }
      }

      const appt = await prisma.appointment.create({
        data: {
          gymId,
          trainerId: resolvedTrainerId,
          customerId: customerId || null,
          type: normalizeType(type),
          title: title.trim(),
          date: new Date(date),
          startTime: effectiveStart,
          endTime: effectiveEnd,
          status: 'SCHEDULED',
          capacity: parseInt(capacity, 10) || 1,
          bookedCount: customerId ? 1 : 0,
          notes: notes || null,
        },
        include: appointmentInclude,
      });

      if (appt.customerId && appt.customer?.userId) {
        await createNotification({
          userId: appt.customer.userId,
          gymId,
          type: 'APPOINTMENT_SCHEDULED',
          title: 'Appointment Scheduled',
          message: `Your session "${appt.title}" is scheduled for ${date} at ${effectiveStart}.`,
          data: { appointmentId: appt.id },
        });
      }

      await createAuditLog({
        userId: req.user.id,
        gymId,
        action: 'APPOINTMENT_CREATED',
        entity: 'Appointment',
        entityId: appt.id,
        details: { title: appt.title, date, startTime: effectiveStart },
        ipAddress: req.ip,
      });

      return sendSuccess(res, formatAppointment(appt), 'Appointment created', 201);
    } catch (err) {
      next(err);
    }
  }
);

// PUT /api/appointments/:id
router.put('/:id', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.appointment.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Appointment not found', 404);

    const nextTrainerId = req.body.trainerId !== undefined ? req.body.trainerId || null : existing.trainerId;
    const nextDate = req.body.date || existing.date;
    const nextStart = req.body.startTime || req.body.time || existing.startTime;
    const nextEnd = computeEndTime(nextStart, req.body.endTime ?? existing.endTime);
    const nextStatus = req.body.status ? normalizeStatus(req.body.status) : existing.status;

    if (nextTrainerId && nextStatus !== 'CANCELLED') {
      const overlap = await hasTrainerTimeOverlap({
        gymId: req.gymId,
        trainerId: nextTrainerId,
        date: nextDate,
        startTime: nextStart,
        endTime: nextEnd,
        excludeId: existing.id,
      });
      if (overlap) {
        return sendError(res, 'Trainer already has an overlapping appointment at this date and time', 409);
      }
    }

    const updated = await prisma.appointment.update({
      where: { id: existing.id },
      data: {
        title: req.body.title ?? existing.title,
        type: req.body.type ? normalizeType(req.body.type) : existing.type,
        trainerId: nextTrainerId,
        customerId: req.body.customerId !== undefined ? req.body.customerId || null : existing.customerId,
        date: req.body.date ? new Date(req.body.date) : existing.date,
        startTime: nextStart,
        endTime: nextEnd,
        status: nextStatus,
        capacity: req.body.capacity != null ? parseInt(req.body.capacity, 10) : existing.capacity,
        notes: req.body.notes !== undefined ? req.body.notes : existing.notes,
      },
      include: appointmentInclude,
    });

    return sendSuccess(res, formatAppointment(updated), 'Appointment updated');
  } catch (err) {
    next(err);
  }
});

// PATCH /api/appointments/:id/status
router.patch('/:id/status', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.appointment.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Appointment not found', 404);

    const status = normalizeStatus(req.body.status);
    const updated = await prisma.appointment.update({
      where: { id: existing.id },
      data: { status },
      include: appointmentInclude,
    });

    return sendSuccess(res, formatAppointment(updated), 'Appointment status updated');
  } catch (err) {
    next(err);
  }
});

// POST /api/appointments/:id/book
router.post('/:id/book', async (req, res, next) => {
  try {
    const appt = await prisma.appointment.findUnique({
      where: { id: req.params.id },
      include: { bookings: true },
    });
    if (!appt || appt.gymId !== req.gymId) return sendError(res, 'Appointment not found', 404);

    let customerId = req.body.customerId;
    if (req.user.role === 'CUSTOMER') {
      const cust = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
      if (!cust) return sendError(res, 'Customer profile not found', 404);
      customerId = cust.id;
    }
    if (!customerId) return sendError(res, 'customerId is required', 400);

    const exists = appt.bookings.find((b) => b.customerId === customerId && b.status !== 'CANCELLED');
    if (exists) return sendError(res, 'Customer already booked this session', 409);
    if (appt.bookedCount >= appt.capacity) return sendError(res, 'Appointment capacity full', 400);

    await prisma.$transaction([
      prisma.appointmentBooking.create({
        data: { appointmentId: appt.id, customerId, status: 'CONFIRMED' },
      }),
      prisma.appointment.update({
        where: { id: appt.id },
        data: { bookedCount: { increment: 1 } },
      }),
    ]);

    const updated = await prisma.appointment.findUnique({
      where: { id: appt.id },
      include: appointmentInclude,
    });
    return sendSuccess(res, formatAppointment(updated), 'Session booked', 201);
  } catch (err) {
    next(err);
  }
});

// PUT /api/appointments/:id/cancel
router.put('/:id/cancel', async (req, res, next) => {
  try {
    const appt = await prisma.appointment.findUnique({ where: { id: req.params.id } });
    if (!appt || appt.gymId !== req.gymId) return sendError(res, 'Appointment not found', 404);

    const updated = await prisma.appointment.update({
      where: { id: appt.id },
      data: { status: 'CANCELLED' },
      include: appointmentInclude,
    });
    return sendSuccess(res, formatAppointment(updated), 'Appointment cancelled');
  } catch (err) {
    next(err);
  }
});

// PUT /api/appointments/:id/reschedule
router.put('/:id/reschedule', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const appt = await prisma.appointment.findUnique({ where: { id: req.params.id } });
    if (!appt || appt.gymId !== req.gymId) return sendError(res, 'Appointment not found', 404);

    const nextDate = req.body.date || appt.date;
    const nextStart = req.body.startTime || req.body.time || appt.startTime;
    const nextEnd = computeEndTime(nextStart, req.body.endTime);

    if (appt.trainerId) {
      const overlap = await hasTrainerTimeOverlap({
        gymId: req.gymId,
        trainerId: appt.trainerId,
        date: nextDate,
        startTime: nextStart,
        endTime: nextEnd,
        excludeId: appt.id,
      });
      if (overlap) return sendError(res, 'Trainer time slot conflict detected', 409);
    }

    const updated = await prisma.appointment.update({
      where: { id: appt.id },
      data: {
        date: new Date(nextDate),
        startTime: nextStart,
        endTime: nextEnd,
        status: 'RESCHEDULED',
      },
      include: appointmentInclude,
    });
    return sendSuccess(res, formatAppointment(updated), 'Appointment rescheduled');
  } catch (err) {
    next(err);
  }
});

// DELETE /api/appointments/:id
router.delete('/:id', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const appt = await prisma.appointment.findUnique({ where: { id: req.params.id } });
    if (!appt || appt.gymId !== req.gymId) return sendError(res, 'Appointment not found', 404);

    await prisma.appointment.delete({ where: { id: appt.id } });
    return sendSuccess(res, null, 'Appointment deleted');
  } catch (err) {
    next(err);
  }
});

module.exports = router;

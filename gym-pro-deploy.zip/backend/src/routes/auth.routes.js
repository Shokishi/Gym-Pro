const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate, optionalAuth } = require('../middleware/auth');
const { upload, getUploadedFileUrl } = require('../middleware/upload');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError } = require('../utils/response');
const {
  sanitizeUser,
  generateReadableId,
  stringifyJson,
  parseJson,
  normalizeMobileCandidates,
  canonicalMobile,
  formatSubscriptionPlan,
} = require('../utils/json');
const { nowIST } = require('../utils/date');
const { createAuditLog, getClientIp } = require('../utils/audit');
const { createNotification } = require('../utils/notification');
const { syncGymSubscriptionLifecycle } = require('../middleware/gymAccess');
const { dispatchRealtimeOtp } = require('../utils/otpService');

const router = express.Router();

const mapRoleParam = (role) => {
  if (!role) return null;
  const upper = String(role).toUpperCase().trim();
  if (upper === 'ADMIN' || upper === 'SUPER_ADMIN' || upper === 'SUPERADMIN') return 'SUPER_ADMIN';
  if (upper === 'OWNER' || upper === 'GYM_OWNER') return 'GYM_OWNER';
  if (upper === 'TRAINER' || upper === 'COACH') return 'TRAINER';
  if (upper === 'CUSTOMER' || upper === 'MEMBER') return 'CUSTOMER';
  return upper;
};

const generateTokens = (user) => {
  const payload = { id: user.id, email: user.email, role: user.role };
  const accessToken = jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '1d',
  });
  const refreshToken = jwt.sign(payload, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '30d',
  });
  return { accessToken, refreshToken };
};

const issueOtpRecord = async (identifier, purpose = 'REGISTER', extraMeta = {}) => {
  const otp = String(Math.floor(100000 + Math.random() * 900000));
  const expiresAt = new Date(Date.now() + 15 * 60 * 1000);
  await prisma.oTPVerification.create({
    data: {
      mobile: String(identifier).trim(),
      otp,
      purpose,
      expiresAt,
    },
  });

  // Real-time OTP delivery to Mail and/or SMS
  const targetStr = String(identifier || '').trim();
  const email = extraMeta.email || (targetStr.includes('@') ? targetStr : null);
  const mobile = extraMeta.mobile || (!targetStr.includes('@') ? targetStr : null);
  const recipientName = extraMeta.fullName || extraMeta.name || null;

  dispatchRealtimeOtp({
    target: targetStr,
    email,
    mobile,
    otp,
    purpose,
    recipientName,
  }).catch((err) => {
    console.error('[OTP Dispatch Error]:', err.message);
  });

  return { otp, expiresAt };
};

const getUserContext = async (userId) => {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: {
      gymOwnerProfile: { include: { gym: true } },
      ownedGyms: true,
      trainerProfile: { include: { gym: true, branch: true } },
      customerProfile: {
        include: {
          gym: true,
          branch: true,
          assignedTrainer: { include: { user: { select: { id: true, fullName: true, mobile: true, profilePhoto: true } } } },
        },
      },
    },
  });

  if (!user) return null;

  let gym = null;
  let profile = null;

  if (user.role === 'GYM_OWNER') {
    profile = user.gymOwnerProfile;
    gym = user.gymOwnerProfile?.gym || user.ownedGyms?.[0] || null;
  } else if (user.role === 'TRAINER') {
    profile = user.trainerProfile;
    gym = user.trainerProfile?.gym || null;
  } else if (user.role === 'CUSTOMER') {
    profile = user.customerProfile;
    gym = user.customerProfile?.gym || null;
  }

  let subscription = null;
  if (gym) {
    gym = await syncGymSubscriptionLifecycle(gym);
    subscription = await prisma.gymSubscription.findFirst({
      where: { gymId: gym.id },
      orderBy: { createdAt: 'desc' },
      include: { plan: true },
    });
    if (subscription?.plan) {
      subscription = { ...subscription, plan: formatSubscriptionPlan(subscription.plan) };
    }
  }

  const unreadNotifications = await prisma.notification.count({
    where: { userId: user.id, isRead: false },
  });

  const cleanUser = sanitizeUser(user);
  delete cleanUser.gymOwnerProfile;
  delete cleanUser.ownedGyms;
  delete cleanUser.trainerProfile;
  delete cleanUser.customerProfile;

  return {
    user: cleanUser,
    profile,
    gym,
    subscription,
    unreadNotifications,
  };
};

// GET /api/auth/plans (public live pricing & trial config for Landing & Registration)
router.get('/plans', async (req, res, next) => {
  try {
    const [plans, trialSettings] = await Promise.all([
      prisma.subscriptionPlan.findMany({
        where: { isActive: true },
        orderBy: { monthlyPrice: 'asc' },
      }),
      prisma.trialSettings.findFirst(),
    ]);
    return sendSuccess(
      res,
      {
        plans: plans.map(formatSubscriptionPlan),
        trialDays: trialSettings?.isEnabled ? trialSettings.durationDays : 0,
        trialEnabled: trialSettings ? trialSettings.isEnabled : true,
      },
      'Public subscription plans fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/auth/invite/:code
router.get('/invite/:code', async (req, res, next) => {
  try {
    const code = req.params.code.trim().toUpperCase();
    const invite = await prisma.trainerInvite.findUnique({
      where: { code },
      include: { gym: { select: { id: true, name: true, city: true, isActive: true } } },
    });

    if (invite && !invite.isUsed && (!invite.expiresAt || new Date(invite.expiresAt) > new Date())) {
      if (!invite.gym?.isActive) {
        return sendError(res, 'Associated gym is currently inactive', 403);
      }
      return sendSuccess(
        res,
        {
          code: invite.code,
          gymId: invite.gymId,
          branchId: invite.branchId,
          gymName: invite.gym.name,
          city: invite.gym.city,
        },
        'Invitation code is valid'
      );
    }

    // Also allow matching gymCode directly
    const gym = await prisma.gym.findFirst({
      where: { OR: [{ gymCode: code }, { id: req.params.code.trim() }], isActive: true },
      select: { id: true, name: true, city: true, gymCode: true },
    });

    if (!gym) {
      return sendError(res, 'Invalid or expired gym invitation code', 404);
    }

    return sendSuccess(
      res,
      { code: gym.gymCode || code, gymId: gym.id, gymName: gym.name, city: gym.city },
      'Gym code is valid'
    );
  } catch (err) {
    next(err);
  }
});

// POST /api/auth/register (Gym Owner default, or Trainer/Customer if gymId passed)
router.post(
  '/register',
  upload.single('logo'),
  [
    body('email').isEmail().withMessage('Valid email is required').normalizeEmail(),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const {
        email,
        password,
        fullName,
        name,
        mobile,
        role = 'GYM_OWNER',
        gymName,
        gymAddress,
        address,
        gymCity,
        city,
        gymState,
        state,
        gymPhone,
        gymId,
        branchId,
        specialization,
        experience,
        experienceYears,
        dateOfBirth,
        emergencyContact,
        emergencyPhone,
      } = req.body;

      const resolvedName = (fullName || name || '').trim();
      if (!resolvedName) {
        return sendError(res, 'Full name is required', 400);
      }

      const normalizedRole = mapRoleParam(role) || 'GYM_OWNER';
      const formattedMobile = canonicalMobile(mobile);

      if (!formattedMobile) {
        return sendError(res, 'Mobile number is compulsory', 400);
      }

      const mobileCandidates = normalizeMobileCandidates(mobile);
      const existingEmail = await prisma.user.findUnique({ where: { email } });
      if (existingEmail) {
        return sendError(res, 'An account with this email already exists', 409);
      }

      const existingMobile = await prisma.user.findFirst({
        where: { mobile: { in: mobileCandidates } },
      });
      if (existingMobile) {
        return sendError(res, 'An account with this mobile number already exists', 409);
      }

      // Check platform setting allowSelfRegistration
      const allowSelfReg = await prisma.platformSetting.findUnique({ where: { key: 'allowSelfRegistration' } });
      if (allowSelfReg && parseJson(allowSelfReg.value, true) === false && normalizedRole === 'GYM_OWNER') {
        return sendError(res, 'New gym self-registration is currently disabled by administrator', 403);
      }

      if ((normalizedRole === 'TRAINER' || normalizedRole === 'CUSTOMER') && !gymId) {
        return sendError(res, 'gymId is required when registering as trainer or customer', 400);
      }

      if (gymId) {
        const targetGym = await prisma.gym.findUnique({ where: { id: gymId } });
        if (!targetGym || !targetGym.isActive) {
          return sendError(res, 'Selected gym not found or is inactive', 404);
        }

        const activeSub = await prisma.gymSubscription.findFirst({
          where: { gymId, status: { in: ['ACTIVE', 'TRIAL', 'GRACE'] } },
          orderBy: { createdAt: 'desc' },
          include: { plan: true },
        });

        if (activeSub?.plan) {
          if (normalizedRole === 'CUSTOMER') {
            const count = await prisma.customerProfile.count({ where: { gymId, isActive: true } });
            if (count >= activeSub.plan.maxCustomers) {
              return sendError(res, 'Gym has reached maximum customer limit for its current plan', 403);
            }
          }
          if (normalizedRole === 'TRAINER') {
            const count = await prisma.trainerProfile.count({ where: { gymId, isActive: true } });
            if (count >= activeSub.plan.maxTrainers) {
              return sendError(res, 'Gym has reached maximum trainer limit for its current plan', 403);
            }
          }
        }
      }

      // Prevent repeated trial abuse for Gym Owners
      const trialSettings = await prisma.trialSettings.findFirst();
      let trialEligible = trialSettings ? trialSettings.isEnabled : true;
      if (normalizedRole === 'GYM_OWNER' && trialEligible && trialSettings?.allowOneTrialPerPhone !== false) {
        const priorTrialGym = await prisma.gym.findFirst({
          where: {
            OR: [{ phone: { in: mobileCandidates } }, { email }],
          },
        });
        if (priorTrialGym) {
          trialEligible = false;
        }
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const requireOtp = trialSettings ? trialSettings.requireOtpVerification !== false : true;
      const logoUrl = req.file ? getUploadedFileUrl(req.file) : req.body.logo || null;

      const created = await prisma.$transaction(async (tx) => {
        const user = await tx.user.create({
          data: {
            email,
            password: hashedPassword,
            fullName: resolvedName,
            mobile: formattedMobile,
            role: normalizedRole,
            isActive: true,
            isVerified: !requireOtp,
            mobileVerified: !requireOtp,
            lastLoginAt: new Date(),
          },
        });

        let createdGym = null;

        if (normalizedRole === 'GYM_OWNER') {
          const trialDays = trialEligible ? trialSettings?.durationDays || 7 : 0;
          const trialStart = nowIST().toDate();
          const trialEnd = nowIST().add(trialDays, 'day').toDate();
          const resolvedGymName = (gymName || `${resolvedName}'s Fitness Studio`).trim();
          const gymCode = generateReadableId('GYM').replace('-', '');

          createdGym = await tx.gym.create({
            data: {
              gymCode,
              name: resolvedGymName,
              logo: logoUrl,
              address: (gymAddress || address || '').trim() || null,
              city: (gymCity || city || '').trim() || null,
              state: (gymState || state || '').trim() || null,
              phone: canonicalMobile(gymPhone) || formattedMobile,
              email,
              ownerId: user.id,
              subscriptionStatus: trialEligible ? 'TRIAL' : 'EXPIRED',
              trialStartDate: trialEligible ? trialStart : null,
              trialEndDate: trialEligible ? trialEnd : null,
            },
          });

          await tx.gymOwnerProfile.create({
            data: {
              userId: user.id,
              gymId: createdGym.id,
              businessDetails: resolvedGymName,
              notificationPrefs: stringifyJson({ email: true, sms: true, whatsapp: true, push: true }),
            },
          });

          await tx.gymBranch.create({
            data: {
              gymId: createdGym.id,
              name: 'Main Branch',
              address: (gymAddress || address || '').trim() || null,
              city: (gymCity || city || '').trim() || null,
              phone: canonicalMobile(gymPhone) || formattedMobile,
              email,
              isMain: true,
            },
          });

          // PART 24: 7-day trial includes ALL features of the Premium plan
          const premiumPlan =
            (await tx.subscriptionPlan.findFirst({
              where: { isActive: true, name: 'Premium' },
            })) ||
            (await tx.subscriptionPlan.findFirst({
              where: { isActive: true },
              orderBy: { monthlyPrice: 'desc' },
            }));

          if (premiumPlan) {
            await tx.gymSubscription.create({
              data: {
                gymId: createdGym.id,
                planId: premiumPlan.id,
                billingPeriod: 'MONTHLY',
                startDate: trialStart,
                endDate: trialEnd,
                status: trialEligible ? 'TRIAL' : 'EXPIRED',
                amount: 0,
              },
            });
          }
        } else if (normalizedRole === 'TRAINER') {
          await tx.trainerProfile.create({
            data: {
              userId: user.id,
              gymId,
              branchId: branchId || null,
              trainerId: generateReadableId('TRN'),
              specialization: specialization || 'General Fitness',
              experience: Number(experience ?? experienceYears) || 0,
            },
          });
        } else if (normalizedRole === 'CUSTOMER') {
          await tx.customerProfile.create({
            data: {
              userId: user.id,
              gymId,
              branchId: branchId || null,
              customerId: generateReadableId('MEM'),
              dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : null,
              address: (address || '').trim() || null,
              emergencyContact: emergencyContact || null,
              emergencyPhone: emergencyPhone || null,
            },
          });
        }

        await tx.loginHistory.create({
          data: {
            userId: user.id,
            ipAddress: getClientIp(req),
            userAgent: req.headers['user-agent'] || null,
          },
        });

        return { user, createdGym };
      });

      const otpInfo = await issueOtpRecord(formattedMobile, 'REGISTER', {
        email: created.user.email,
        mobile: formattedMobile,
        fullName: resolvedName,
      });

      await createNotification({
        userId: created.user.id,
        gymId: created.createdGym?.id || gymId || null,
        type: 'WELCOME',
        title: 'Welcome to GYM PRO',
        message:
          normalizedRole === 'GYM_OWNER' && trialEligible
            ? `Hi ${resolvedName}, your 7-day Premium Free Trial for "${created.createdGym?.name}" is ready once OTP is verified!`
            : `Hi ${resolvedName}, please verify your mobile OTP to activate your account.`,
        io: req.app.get('io'),
      });

      await createAuditLog({
        userId: created.user.id,
        gymId: created.createdGym?.id || gymId || null,
        action: 'REGISTER',
        entity: 'User',
        entityId: created.user.id,
        details: { role: normalizedRole, trialEligible },
        req,
      });

      const context = await getUserContext(created.user.id);
      const responsePayload = {
        requiresOtpVerification: true,
        mobile: formattedMobile,
        purpose: 'REGISTER',
        trialEligible,
        ...context,
      };

      if (!requireOtp) {
        const tokens = generateTokens(created.user);
        Object.assign(responsePayload, tokens);
      }

      if (process.env.NODE_ENV !== 'production') {
        responsePayload.devOtp = otpInfo.otp;
      }

      return sendSuccess(
        res,
        responsePayload,
        'Registration created. Please verify mobile OTP to activate your account.',
        201
      );
    } catch (err) {
      next(err);
    }
  }
);

// POST /api/auth/register/trainer
router.post(
  '/register/trainer',
  [
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const {
        inviteCode,
        gymId: directGymId,
        name,
        fullName,
        mobile,
        email,
        password,
        specialization = 'Strength & Conditioning',
        experience,
        experienceYears = 0,
      } = req.body;

      const resolvedName = (fullName || name || '').trim();
      if (!resolvedName) return sendError(res, 'Full name is required', 400);

      const formattedMobile = canonicalMobile(mobile);
      if (!formattedMobile) return sendError(res, 'Mobile number is compulsory', 400);

      let gymId = directGymId;
      let branchId = req.body.branchId || null;
      let inviteRecord = null;

      if (inviteCode) {
        const code = inviteCode.trim().toUpperCase();
        inviteRecord = await prisma.trainerInvite.findUnique({ where: { code } });
        if (inviteRecord) {
          if (inviteRecord.isUsed) return sendError(res, 'This invitation code has already been used', 400);
          if (inviteRecord.expiresAt && new Date(inviteRecord.expiresAt) < new Date()) {
            return sendError(res, 'Invitation code has expired', 400);
          }
          gymId = inviteRecord.gymId;
          branchId = inviteRecord.branchId || branchId;
        } else {
          const gymByCode = await prisma.gym.findFirst({
            where: { OR: [{ gymCode: code }, { id: inviteCode.trim() }] },
          });
          if (!gymByCode) return sendError(res, 'Invalid gym invitation code', 404);
          gymId = gymByCode.id;
        }
      }

      if (!gymId) return sendError(res, 'Valid gym invitation code or gymId is required', 400);

      const gym = await prisma.gym.findUnique({ where: { id: gymId } });
      if (!gym || !gym.isActive) return sendError(res, 'Gym not found or inactive', 404);

      const activeSub = await prisma.gymSubscription.findFirst({
        where: { gymId, status: { in: ['ACTIVE', 'TRIAL', 'GRACE'] } },
        orderBy: { createdAt: 'desc' },
        include: { plan: true },
      });
      if (activeSub?.plan) {
        const trainerCount = await prisma.trainerProfile.count({ where: { gymId, isActive: true } });
        if (trainerCount >= activeSub.plan.maxTrainers) {
          return sendError(res, 'Gym has reached maximum trainer limit for its subscription plan', 403);
        }
      }

      const resolvedEmail = (email || `trainer.${formattedMobile.replace(/\D/g, '')}@gympro.local`).toLowerCase().trim();
      const mobileCandidates = normalizeMobileCandidates(mobile);
      const [dupEmail, dupMobile] = await Promise.all([
        prisma.user.findUnique({ where: { email: resolvedEmail } }),
        prisma.user.findFirst({ where: { mobile: { in: mobileCandidates } } }),
      ]);
      if (dupEmail) return sendError(res, 'Email already registered', 409);
      if (dupMobile) return sendError(res, 'Mobile number already registered', 409);

      const hashedPassword = await bcrypt.hash(password, 10);

      const created = await prisma.$transaction(async (tx) => {
        const user = await tx.user.create({
          data: {
            email: resolvedEmail,
            password: hashedPassword,
            fullName: resolvedName,
            mobile: formattedMobile,
            role: 'TRAINER',
            isActive: true,
            isVerified: false,
            mobileVerified: false,
          },
        });

        const trainer = await tx.trainerProfile.create({
          data: {
            userId: user.id,
            gymId,
            branchId,
            trainerId: generateReadableId('TRN'),
            specialization,
            experience: Number(experience ?? experienceYears) || 0,
          },
        });

        if (inviteRecord) {
          await tx.trainerInvite.update({
            where: { id: inviteRecord.id },
            data: { isUsed: true },
          });
        }

        return { user, trainer };
      });

      const otpInfo = await issueOtpRecord(formattedMobile, 'REGISTER', {
        email: created.user.email,
        mobile: formattedMobile,
        fullName: resolvedName,
      });

      await createNotification({
        userId: gym.ownerId,
        gymId,
        type: 'NEW_TRAINER',
        title: 'New Trainer Joined',
        message: `${resolvedName} registered as a trainer via invitation.`,
        io: req.app.get('io'),
      });

      const context = await getUserContext(created.user.id);
      const payload = {
        requiresOtpVerification: true,
        mobile: formattedMobile,
        purpose: 'REGISTER',
        ...context,
      };
      if (process.env.NODE_ENV !== 'production') {
        payload.devOtp = otpInfo.otp;
      }
      return sendSuccess(res, payload, 'Trainer account created. Please verify mobile OTP.', 201);
    } catch (err) {
      next(err);
    }
  }
);

// POST /api/auth/register/customer
router.post(
  '/register/customer',
  [
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const {
        gymCode,
        gymId: directGymId,
        branchId,
        name,
        fullName,
        mobile,
        email,
        gender,
        fitnessGoal,
        referralCode,
        password,
      } = req.body;

      const resolvedName = (fullName || name || '').trim();
      if (!resolvedName) return sendError(res, 'Full name is required', 400);

      const formattedMobile = canonicalMobile(mobile);
      if (!formattedMobile) return sendError(res, 'Mobile number is compulsory', 400);

      const lookupCode = (gymCode || directGymId || '').trim();
      if (!lookupCode) return sendError(res, 'Gym Code or Gym ID is required', 400);

      const gym = await prisma.gym.findFirst({
        where: {
          OR: [{ id: lookupCode }, { gymCode: lookupCode.toUpperCase() }, { gymCode: lookupCode }],
        },
      });
      if (!gym || !gym.isActive) return sendError(res, 'Gym not found or currently inactive', 404);

      const activeSub = await prisma.gymSubscription.findFirst({
        where: { gymId: gym.id, status: { in: ['ACTIVE', 'TRIAL', 'GRACE'] } },
        orderBy: { createdAt: 'desc' },
        include: { plan: true },
      });
      if (activeSub?.plan) {
        const count = await prisma.customerProfile.count({ where: { gymId: gym.id, isActive: true } });
        if (count >= activeSub.plan.maxCustomers) {
          return sendError(res, 'This gym has reached its active member limit', 403);
        }
      }

      const resolvedEmail = (email || `member.${formattedMobile.replace(/\D/g, '')}@gympro.local`).toLowerCase().trim();
      const mobileCandidates = normalizeMobileCandidates(mobile);
      const [dupEmail, dupMobile] = await Promise.all([
        prisma.user.findUnique({ where: { email: resolvedEmail } }),
        prisma.user.findFirst({ where: { mobile: { in: mobileCandidates } } }),
      ]);
      if (dupEmail) return sendError(res, 'Email already registered', 409);
      if (dupMobile) return sendError(res, 'Mobile number already registered', 409);

      const hashedPassword = await bcrypt.hash(password, 10);

      const created = await prisma.$transaction(async (tx) => {
        const user = await tx.user.create({
          data: {
            email: resolvedEmail,
            password: hashedPassword,
            fullName: resolvedName,
            mobile: formattedMobile,
            role: 'CUSTOMER',
            isActive: true,
            isVerified: false,
            mobileVerified: false,
          },
        });

        const customer = await tx.customerProfile.create({
          data: {
            userId: user.id,
            gymId: gym.id,
            branchId: branchId || null,
            customerId: generateReadableId('MEM'),
            gender: gender || null,
            fitnessGoal: fitnessGoal || null,
            referralCode: referralCode || null,
          },
        });

        if (referralCode) {
          const referrer = await tx.customerProfile.findFirst({
            where: {
              gymId: gym.id,
              OR: [{ customerId: referralCode.trim().toUpperCase() }, { id: referralCode.trim() }],
            },
          });
          if (referrer) {
            await tx.referral.create({
              data: {
                gymId: gym.id,
                referrerId: referrer.id,
                referredName: resolvedName,
                referredMobile: formattedMobile,
                status: 'JOINED',
                rewardType: 'DISCOUNT',
                rewardValue: 500,
              },
            });
          }
        }

        return { user, customer };
      });

      const otpInfo = await issueOtpRecord(formattedMobile, 'REGISTER', {
        email: created.user.email,
        mobile: formattedMobile,
        fullName: resolvedName,
      });

      await createNotification({
        userId: gym.ownerId,
        gymId: gym.id,
        type: 'NEW_CUSTOMER',
        title: 'New Member Registered',
        message: `${resolvedName} registered for ${gym.name}.`,
        io: req.app.get('io'),
      });

      const context = await getUserContext(created.user.id);
      const payload = {
        requiresOtpVerification: true,
        mobile: formattedMobile,
        purpose: 'REGISTER',
        ...context,
      };
      if (process.env.NODE_ENV !== 'production') {
        payload.devOtp = otpInfo.otp;
      }
      return sendSuccess(res, payload, 'Customer account created. Please verify mobile OTP.', 201);
    } catch (err) {
      next(err);
    }
  }
);

// POST /api/auth/login
router.post('/login', async (req, res, next) => {
  try {
    const { email, mobile, identifier, password, role, otp } = req.body;
    const loginId = (identifier || email || mobile || '').trim();

    if (!loginId) {
      return sendError(res, 'Email or mobile number is required', 400);
    }

    const mobileCandidates = normalizeMobileCandidates(loginId);
    const user = await prisma.user.findFirst({
      where: {
        OR: [{ email: loginId.toLowerCase() }, { mobile: { in: mobileCandidates } }],
      },
    });

    if (!user) {
      return sendError(res, 'Invalid credentials', 401);
    }

    if (role) {
      const expectedRole = mapRoleParam(role);
      if (expectedRole && user.role !== expectedRole) {
        return sendError(res, `Account exists under a different role (${user.role.replace('_', ' ')})`, 403);
      }
    }

    if (!user.isActive) {
      return sendError(res, 'Your account has been deactivated. Contact administrator.', 403);
    }

    // Customer OTP login path if otp is passed without password
    if (user.role === 'CUSTOMER' && otp && !password) {
      const otpRecord = await prisma.oTPVerification.findFirst({
        where: {
          mobile: { in: normalizeMobileCandidates(user.mobile || loginId) },
          otp: String(otp).trim(),
          verified: false,
          expiresAt: { gt: new Date() },
        },
        orderBy: { createdAt: 'desc' },
      });
      if (!otpRecord) {
        return sendError(res, 'Invalid or expired login OTP', 401);
      }
      await prisma.oTPVerification.update({ where: { id: otpRecord.id }, data: { verified: true } });
    } else {
      if (!password) {
        return sendError(res, 'Password is required', 400);
      }
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return sendError(res, 'Invalid credentials', 401);
      }
    }

    // Enforce mobile OTP verification before allowing non-admin login
    if (user.role !== 'SUPER_ADMIN' && !user.mobileVerified && user.mobile) {
      const otpInfo = await issueOtpRecord(user.mobile, 'REGISTER', {
        email: user.email,
        mobile: user.mobile,
        fullName: user.fullName,
      });
      return res.status(403).json({
        success: false,
        code: 'OTP_REQUIRED',
        error: 'Mobile number is not verified yet. Please verify OTP to activate your account.',
        data: {
          requiresOtpVerification: true,
          mobile: user.mobile,
          purpose: 'REGISTER',
          ...(process.env.NODE_ENV !== 'production' ? { devOtp: otpInfo.otp } : {}),
        },
      });
    }

    // Optional Two-Factor Authentication for Super Admin
    if (user.role === 'SUPER_ADMIN' && user.twoFactorEnabled) {
      if (!otp) {
        const otpInfo = await issueOtpRecord(user.email, 'LOGIN_2FA', {
          email: user.email,
          mobile: user.mobile,
          fullName: user.fullName,
        });
        return sendSuccess(
          res,
          {
            requires2FA: true,
            email: user.email,
            ...(process.env.NODE_ENV !== 'production' ? { devOtp: otpInfo.otp } : {}),
          },
          'Two-factor authentication code sent'
        );
      }
      const twoFaRecord = await prisma.oTPVerification.findFirst({
        where: {
          mobile: user.email,
          otp: String(otp).trim(),
          purpose: 'LOGIN_2FA',
          verified: false,
          expiresAt: { gt: new Date() },
        },
        orderBy: { createdAt: 'desc' },
      });
      if (!twoFaRecord) {
        return sendError(res, 'Invalid or expired two-factor authentication code', 401);
      }
      await prisma.oTPVerification.update({ where: { id: twoFaRecord.id }, data: { verified: true } });
    }

    await prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    await prisma.loginHistory.create({
      data: {
        userId: user.id,
        ipAddress: getClientIp(req),
        userAgent: req.headers['user-agent'] || null,
      },
    });

    const tokens = generateTokens(user);
    const context = await getUserContext(user.id);

    return sendSuccess(
      res,
      {
        ...tokens,
        ...context,
      },
      'Login successful'
    );
  } catch (err) {
    next(err);
  }
});

// POST /api/auth/admin/login
router.post(
  '/admin/login',
  [
    body('email').isEmail().withMessage('Valid admin email is required').normalizeEmail(),
    body('password').notEmpty().withMessage('Password is required'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { email, password, otp } = req.body;

      const user = await prisma.user.findUnique({ where: { email } });
      if (!user || user.role !== 'SUPER_ADMIN') {
        return sendError(res, 'Invalid super admin credentials', 401);
      }

      if (!user.isActive) {
        return sendError(res, 'Admin account is deactivated', 403);
      }

      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return sendError(res, 'Invalid super admin credentials', 401);
      }

      if (user.twoFactorEnabled) {
        if (!otp) {
          const otpInfo = await issueOtpRecord(user.email, 'LOGIN_2FA', {
            email: user.email,
            mobile: user.mobile,
            fullName: user.fullName,
          });
          return sendSuccess(
            res,
            {
              requires2FA: true,
              email: user.email,
              ...(process.env.NODE_ENV !== 'production' ? { devOtp: otpInfo.otp } : {}),
            },
            'Two-factor authentication code sent'
          );
        }
        const twoFaRecord = await prisma.oTPVerification.findFirst({
          where: {
            mobile: user.email,
            otp: String(otp).trim(),
            purpose: 'LOGIN_2FA',
            verified: false,
            expiresAt: { gt: new Date() },
          },
          orderBy: { createdAt: 'desc' },
        });
        if (!twoFaRecord) {
          return sendError(res, 'Invalid or expired two-factor authentication code', 401);
        }
        await prisma.oTPVerification.update({ where: { id: twoFaRecord.id }, data: { verified: true } });
      }

      await prisma.user.update({
        where: { id: user.id },
        data: { lastLoginAt: new Date() },
      });

      await prisma.loginHistory.create({
        data: {
          userId: user.id,
          ipAddress: getClientIp(req),
          userAgent: req.headers['user-agent'] || null,
        },
      });

      const tokens = generateTokens(user);
      const context = await getUserContext(user.id);

      await createAuditLog({
        userId: user.id,
        action: 'ADMIN_LOGIN',
        entity: 'User',
        entityId: user.id,
        req,
      });

      return sendSuccess(
        res,
        {
          ...tokens,
          ...context,
        },
        'Super Admin login successful'
      );
    } catch (err) {
      next(err);
    }
  }
);

// POST /api/auth/send-otp
router.post(
  '/send-otp',
  [body('mobile').trim().notEmpty().withMessage('Mobile number or identifier is required'), validate],
  async (req, res, next) => {
    try {
      const { mobile, purpose = 'REGISTER' } = req.body;
      const target = canonicalMobile(mobile) || mobile.trim();
      const existingUser = await prisma.user.findFirst({
        where: {
          OR: [
            { mobile: target },
            { email: target },
          ],
        },
      });
      const otpInfo = await issueOtpRecord(target, purpose, {
        email: existingUser?.email,
        mobile: existingUser?.mobile || (target.includes('@') ? null : target),
        fullName: existingUser?.fullName,
      });

      const responseData = {
        mobile: target,
        purpose,
        expiresAt: otpInfo.expiresAt,
      };
      if (process.env.NODE_ENV !== 'production') {
        responseData.otp = otpInfo.otp;
        responseData.devOtp = otpInfo.otp;
      }

      return sendSuccess(res, responseData, 'OTP sent successfully');
    } catch (err) {
      next(err);
    }
  }
);

// POST /api/auth/verify-otp
router.post(
  '/verify-otp',
  [
    body('mobile').trim().notEmpty().withMessage('Mobile number is required'),
    body('otp').trim().isLength({ min: 4, max: 8 }).withMessage('Valid OTP is required'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { mobile, otp, purpose = 'REGISTER' } = req.body;
      const candidates = normalizeMobileCandidates(mobile);
      const acceptedPurposes =
        purpose === 'RESET_PASSWORD' || purpose === 'PASSWORD_RESET'
          ? ['RESET_PASSWORD', 'PASSWORD_RESET']
          : [purpose, 'VERIFICATION', 'REGISTER'];

      const record = await prisma.oTPVerification.findFirst({
        where: {
          mobile: { in: candidates },
          otp: otp.trim(),
          purpose: { in: acceptedPurposes },
          verified: false,
          expiresAt: { gt: new Date() },
        },
        orderBy: { createdAt: 'desc' },
      });

      if (!record) {
        return sendError(res, 'Invalid or expired OTP', 400);
      }

      await prisma.oTPVerification.update({
        where: { id: record.id },
        data: { verified: true },
      });

      if (purpose === 'RESET_PASSWORD' || purpose === 'PASSWORD_RESET') {
        return sendSuccess(res, { verified: true, mobile: canonicalMobile(mobile) }, 'OTP verified for password reset');
      }

      const user = await prisma.user.findFirst({
        where: { mobile: { in: candidates } },
      });

      if (user) {
        await prisma.user.update({
          where: { id: user.id },
          data: { mobileVerified: true, isVerified: true, isActive: true },
        });
        const tokens = generateTokens(user);
        const context = await getUserContext(user.id);
        return sendSuccess(
          res,
          { verified: true, ...tokens, ...context },
          'Mobile OTP verified and account activated'
        );
      }

      return sendSuccess(res, { verified: true, mobile: canonicalMobile(mobile) }, 'OTP verified successfully');
    } catch (err) {
      next(err);
    }
  }
);

// POST /api/auth/forgot-password
router.post('/forgot-password', async (req, res, next) => {
  try {
    const { email, mobile, identifier } = req.body;
    const lookup = (identifier || email || mobile || '').trim();
    if (!lookup) {
      return sendError(res, 'Email or mobile is required', 400);
    }

    const mobileCandidates = normalizeMobileCandidates(lookup);
    const user = await prisma.user.findFirst({
      where: { OR: [{ email: lookup.toLowerCase() }, { mobile: { in: mobileCandidates } }] },
    });

    if (!user) {
      return sendError(res, 'No account found with provided email or mobile', 404);
    }

    const targetIdentifier = user.mobile || user.email;
    const otpInfo = await issueOtpRecord(targetIdentifier, 'RESET_PASSWORD', {
      email: user.email,
      mobile: user.mobile,
      fullName: user.fullName,
    });

    const data = {
      identifier: targetIdentifier,
      mobile: user.mobile,
      expiresAt: otpInfo.expiresAt,
    };
    if (process.env.NODE_ENV !== 'production') {
      data.otp = otpInfo.otp;
      data.devOtp = otpInfo.otp;
    }

    return sendSuccess(res, data, 'Password reset OTP generated');
  } catch (err) {
    next(err);
  }
});

// POST /api/auth/reset-password
router.post(
  '/reset-password',
  [
    body('otp').trim().notEmpty().withMessage('OTP is required'),
    body('newPassword').isLength({ min: 6 }).withMessage('New password must be at least 6 characters'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { email, mobile, identifier, otp, newPassword } = req.body;
      const lookup = (identifier || email || mobile || '').trim();
      if (!lookup) {
        return sendError(res, 'Email or mobile is required', 400);
      }

      const mobileCandidates = normalizeMobileCandidates(lookup);
      const user = await prisma.user.findFirst({
        where: { OR: [{ email: lookup.toLowerCase() }, { mobile: { in: mobileCandidates } }] },
      });
      if (!user) {
        return sendError(res, 'User not found', 404);
      }

      const possibleKeys = [
        ...mobileCandidates,
        ...normalizeMobileCandidates(user.mobile),
        user.email,
      ].filter(Boolean);

      const otpRecord = await prisma.oTPVerification.findFirst({
        where: {
          mobile: { in: possibleKeys },
          otp: otp.trim(),
          purpose: { in: ['RESET_PASSWORD', 'PASSWORD_RESET'] },
          expiresAt: { gt: new Date() },
        },
        orderBy: { createdAt: 'desc' },
      });

      if (!otpRecord) {
        return sendError(res, 'Invalid or expired reset OTP', 400);
      }

      const hashedPassword = await bcrypt.hash(newPassword, 10);

      await prisma.$transaction([
        prisma.oTPVerification.update({
          where: { id: otpRecord.id },
          data: { verified: true },
        }),
        prisma.user.update({
          where: { id: user.id },
          data: { password: hashedPassword },
        }),
      ]);

      await createAuditLog({
        userId: user.id,
        action: 'RESET_PASSWORD',
        entity: 'User',
        entityId: user.id,
        req,
      });

      return sendSuccess(res, null, 'Password reset successful');
    } catch (err) {
      next(err);
    }
  }
);

// POST /api/auth/refresh-token
router.post(
  '/refresh-token',
  [body('refreshToken').notEmpty().withMessage('Refresh token is required'), validate],
  async (req, res, next) => {
    try {
      const { refreshToken } = req.body;
      let decoded;
      try {
        decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
      } catch {
        return sendError(res, 'Invalid or expired refresh token', 401);
      }

      const user = await prisma.user.findUnique({ where: { id: decoded.id } });
      if (!user || !user.isActive) {
        return sendError(res, 'User not found or inactive', 401);
      }

      const tokens = generateTokens(user);
      return sendSuccess(res, tokens, 'Token refreshed successfully');
    } catch (err) {
      next(err);
    }
  }
);

// GET /api/auth/me
router.get('/me', authenticate, async (req, res, next) => {
  try {
    const context = await getUserContext(req.user.id);
    if (!context) {
      return sendError(res, 'User not found', 404);
    }
    return sendSuccess(res, context, 'User profile fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/auth/logout
router.post('/logout', optionalAuth, async (req, res, next) => {
  try {
    if (req.user) {
      await createAuditLog({
        userId: req.user.id,
        action: 'LOGOUT',
        entity: 'User',
        entityId: req.user.id,
        req,
      });
    }
    return sendSuccess(res, null, 'Logged out successfully');
  } catch (err) {
    next(err);
  }
});

module.exports = router;

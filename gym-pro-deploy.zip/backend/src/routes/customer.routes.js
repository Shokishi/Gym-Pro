const express = require('express');
const bcrypt = require('bcryptjs');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const {
  generateReadableId,
  parseJson,
  stringifyJson,
  formatCustomer,
  canonicalMobile,
  normalizeMobileCandidates,
  calculateBMI,
} = require('../utils/json');
const { getISTMonthRange, dayjs, IST_TZ } = require('../utils/date');
const { createAuditLog } = require('../utils/audit');
const { createNotification } = require('../utils/notification');
const { emitNewCustomer } = require('../socket');
const { generateMembershipCardPDF } = require('../utils/pdfGenerator');

const router = express.Router();

router.use(authenticate, requireGymAccess());

const ensureCustomerAccess = async (req, customerId) => {
  const customer = await prisma.customerProfile.findUnique({
    where: { id: customerId },
    include: {
      user: {
        select: {
          id: true,
          email: true,
          fullName: true,
          mobile: true,
          profilePhoto: true,
          isActive: true,
          isVerified: true,
          mobileVerified: true,
          emailVerified: true,
          lastLoginAt: true,
        },
      },
      branch: true,
      gym: true,
      assignedTrainer: {
        include: {
          user: { select: { id: true, fullName: true, mobile: true, email: true, profilePhoto: true } },
        },
      },
      memberships: {
        orderBy: { createdAt: 'desc' },
        include: { plan: true },
      },
    },
  });

  if (!customer) return { error: 'Customer not found', status: 404 };
  if (req.gymId && customer.gymId !== req.gymId) {
    return { error: 'Access denied: customer belongs to another gym', status: 403 };
  }
  if (req.user.role === 'CUSTOMER' && req.customerProfile?.id !== customer.id) {
    return { error: 'Access denied: you can only view your own records', status: 403 };
  }
  if (
    req.user.role === 'TRAINER' &&
    customer.assignedTrainerId &&
    customer.assignedTrainerId !== req.trainerProfile?.id
  ) {
    // Trainers only access their assigned customers (or unassigned within authorized gym)
    return { error: 'Access denied: customer is assigned to another trainer', status: 403 };
  }
  return { customer };
};

// Static portal route BEFORE /:id
// GET /api/customers/portal/home
router.get('/portal/home', authorize('CUSTOMER'), async (req, res, next) => {
  try {
    const customerId = req.customerProfile.id;
    const gymId = req.gymId;
    const monthRange = getISTMonthRange();
    const todayDay = dayjs().tz(IST_TZ).format('dddd').toUpperCase();

    const [activeMembership, latestMembership, monthlyCheckIns, workouts, dietPlan, latestProgress, appointments] =
      await Promise.all([
        prisma.customerMembership.findFirst({
          where: { customerId, status: 'ACTIVE' },
          orderBy: { endDate: 'desc' },
          include: { plan: true },
        }),
        prisma.customerMembership.findFirst({
          where: { customerId },
          orderBy: { createdAt: 'desc' },
          include: { plan: true },
        }),
        prisma.attendance.count({
          where: {
            customerId,
            status: 'PRESENT',
            date: { gte: monthRange.dateOnlyStart, lte: monthRange.dateOnlyEnd },
          },
        }),
        prisma.workoutPlan.findMany({
          where: { gymId, customerId },
          orderBy: { createdAt: 'desc' },
          include: { exercises: { orderBy: { orderIndex: 'asc' } } },
        }),
        prisma.dietPlan.findFirst({
          where: { gymId, customerId, isActive: true },
          orderBy: { createdAt: 'desc' },
          include: { meals: true },
        }),
        prisma.fitnessProgress.findFirst({
          where: { customerId },
          orderBy: { date: 'desc' },
        }),
        prisma.appointment.findMany({
          where: {
            gymId,
            date: { gte: dayjs().tz(IST_TZ).startOf('day').toDate() },
            OR: [{ customerId }, { bookings: { some: { customerId, status: 'CONFIRMED' } } }],
          },
          orderBy: { date: 'asc' },
          take: 5,
        }),
      ]);

    const todayWorkout =
      workouts.find((w) => String(w.dayOfWeek).toUpperCase() === todayDay) || workouts[0] || null;

    const totalCalories = dietPlan?.meals?.reduce((s, m) => s + (m.calories || 0), 0) || 0;
    const membership = activeMembership || latestMembership || null;

    return sendSuccess(
      res,
      {
        membership: membership
          ? {
              ...membership,
              planName: membership.plan?.name,
              plan: membership.plan
                ? { ...membership.plan, services: parseJson(membership.plan.services, []) }
                : null,
            }
          : null,
        activeMembership: membership,
        monthlyCheckIns,
        todayWorkout,
        workout: todayWorkout,
        dietPlan: dietPlan ? { ...dietPlan, totalCalories } : null,
        latestWeight: latestProgress?.weight || req.customerProfile.weightKg || null,
        latestProgress,
        upcomingAppointments: appointments,
      },
      'Customer home summary fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/customers
router.get('/', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId && req.user.role !== 'SUPER_ADMIN') {
      return sendError(res, 'gymId is required', 400);
    }

    const { page, limit, skip } = getPagination(req.query);
    const { search, branchId, assignedTrainerId, isActive, status, membershipStatus } = req.query;

    const where = {};
    if (gymId) where.gymId = gymId;
    if (branchId && branchId !== 'ALL') where.branchId = branchId;
    if (req.user.role === 'TRAINER') {
      where.assignedTrainerId = req.trainerProfile.id;
    } else if (assignedTrainerId) {
      where.assignedTrainerId = assignedTrainerId;
    }

    if (isActive !== undefined) where.isActive = isActive === 'true';
    else if (status === 'INACTIVE') where.isActive = false;

    const mStatus = membershipStatus || (status && ['ACTIVE', 'EXPIRED', 'FROZEN'].includes(status) ? status : null);
    if (mStatus) {
      where.memberships = { some: { status: mStatus } };
    } else if (status === 'EXPIRING') {
      const now = new Date();
      const sevenDays = dayjs().add(7, 'day').toDate();
      where.memberships = { some: { status: 'ACTIVE', endDate: { gte: now, lte: sevenDays } } };
    }

    if (search) {
      where.OR = [
        { customerId: { contains: search } },
        { user: { fullName: { contains: search } } },
        { user: { email: { contains: search } } },
        { user: { mobile: { contains: search } } },
      ];
    }

    const [customers, total] = await Promise.all([
      prisma.customerProfile.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          user: {
            select: {
              id: true,
              email: true,
              fullName: true,
              mobile: true,
              profilePhoto: true,
              isActive: true,
            },
          },
          branch: { select: { id: true, name: true } },
          assignedTrainer: {
            include: { user: { select: { id: true, fullName: true, mobile: true, profilePhoto: true } } },
          },
          memberships: {
            take: 3,
            orderBy: { createdAt: 'desc' },
            include: { plan: true },
          },
        },
      }),
      prisma.customerProfile.count({ where }),
    ]);

    return sendSuccess(res, formatPaginatedData(customers.map(formatCustomer), total, page, limit), 'Customers fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/customers
router.post(
  '/',
  authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'),
  [validate],
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const {
        email,
        password,
        fullName,
        name,
        mobile,
        branchId,
        gender,
        dateOfBirth,
        dob,
        heightCm,
        weightKg,
        fitnessGoal,
        medicalNotes,
        address,
        emergencyContact,
        emergencyPhone,
        assignedTrainerId,
        trainerId,
        planId,
        amountPaid,
        paymentMethod = 'CASH',
        joiningDate,
      } = req.body;

      const resolvedName = (fullName || name || '').trim();
      if (!resolvedName) return sendError(res, 'Full name is required', 400);

      const formattedMobile = canonicalMobile(mobile);
      if (!formattedMobile) return sendError(res, 'Mobile number is compulsory', 400);

      // Subscription limit check
      const activeSub = await prisma.gymSubscription.findFirst({
        where: { gymId, status: { in: ['ACTIVE', 'TRIAL', 'GRACE'] } },
        orderBy: { createdAt: 'desc' },
        include: { plan: true },
      });
      if (activeSub?.plan) {
        const count = await prisma.customerProfile.count({ where: { gymId, isActive: true } });
        if (count >= activeSub.plan.maxCustomers) {
          return sendError(
            res,
            `Customer limit (${activeSub.plan.maxCustomers}) reached for your current subscription plan`,
            403
          );
        }
      }

      const resolvedEmail = (
        email || `member.${formattedMobile.replace(/\D/g, '')}.${Date.now().toString().slice(-4)}@gympro.local`
      )
        .toLowerCase()
        .trim();

      const mobileCandidates = normalizeMobileCandidates(mobile);
      const [existingEmail, existingMobile] = await Promise.all([
        prisma.user.findUnique({ where: { email: resolvedEmail } }),
        prisma.user.findFirst({ where: { mobile: { in: mobileCandidates } } }),
      ]);
      if (existingEmail) return sendError(res, 'Email already registered', 409);
      if (existingMobile) return sendError(res, 'Mobile already registered', 409);

      const rawPassword = password || 'Welcome@123';
      const hashedPassword = await bcrypt.hash(rawPassword, 10);
      const resolvedTrainer = assignedTrainerId || trainerId || null;
      const resolvedDob = dateOfBirth || dob || null;

      const created = await prisma.$transaction(async (tx) => {
        const user = await tx.user.create({
          data: {
            email: resolvedEmail,
            password: hashedPassword,
            fullName: resolvedName,
            mobile: formattedMobile,
            role: 'CUSTOMER',
            isActive: true,
            isVerified: true,
            mobileVerified: true,
          },
        });

        const customer = await tx.customerProfile.create({
          data: {
            userId: user.id,
            gymId,
            branchId: branchId || null,
            customerId: generateReadableId('MEM'),
            gender: gender || null,
            dateOfBirth: resolvedDob ? new Date(resolvedDob) : null,
            heightCm: heightCm ? Number(heightCm) : null,
            weightKg: weightKg ? Number(weightKg) : null,
            fitnessGoal: fitnessGoal || null,
            medicalNotes: medicalNotes || null,
            address: address || null,
            emergencyContact: emergencyContact || null,
            emergencyPhone: emergencyPhone || null,
            assignedTrainerId: resolvedTrainer,
            joiningDate: joiningDate ? new Date(joiningDate) : new Date(),
          },
          include: {
            user: {
              select: { id: true, email: true, fullName: true, mobile: true, profilePhoto: true, isActive: true },
            },
            branch: true,
            assignedTrainer: { include: { user: { select: { id: true, fullName: true } } } },
          },
        });

        if (weightKg || heightCm) {
          const w = weightKg ? Number(weightKg) : null;
          const h = heightCm ? Number(heightCm) : null;
          await tx.fitnessProgress.create({
            data: {
              customerId: customer.id,
              gymId,
              weight: w,
              height: h,
              bmi: calculateBMI(w, h),
              notes: 'Initial baseline measurement',
              measuredBy: req.user.id,
            },
          });
        }

        if (planId) {
          const plan = await tx.membershipPlan.findUnique({ where: { id: planId } });
          if (plan && plan.gymId === gymId) {
            const start = dayjs().tz(IST_TZ);
            const end = start.add(plan.durationDays, 'day');
            const total = Math.max(0, Number(plan.price) + Number(plan.joiningFee || 0) - Number(plan.discount || 0));
            const paid = Math.min(total, Number(amountPaid ?? total) || 0);

            const membership = await tx.customerMembership.create({
              data: {
                customerId: customer.id,
                planId: plan.id,
                gymId,
                startDate: start.toDate(),
                endDate: end.toDate(),
                status: 'ACTIVE',
                purchasePrice: Number(plan.price),
                joiningFee: Number(plan.joiningFee || 0),
                discount: Number(plan.discount || 0),
                tax: 0,
                totalPaid: paid,
              },
            });

            await tx.invoice.create({
              data: {
                gymId,
                customerId: customer.id,
                invoiceNumber: generateReadableId('INV'),
                membershipId: membership.id,
                items: stringifyJson([{ description: plan.name, quantity: 1, unitPrice: plan.price, total: plan.price }]),
                subtotal: plan.price,
                discount: plan.discount || 0,
                tax: 0,
                total,
                status: paid >= total ? 'PAID' : paid > 0 ? 'PARTIALLY_PAID' : 'UNPAID',
                paidAmount: paid,
                dueDate: end.toDate(),
              },
            });

            if (paid > 0) {
              await tx.payment.create({
                data: {
                  gymId,
                  customerId: customer.id,
                  membershipId: membership.id,
                  amount: paid,
                  paymentMethod,
                  status: 'APPROVED',
                  approvedBy: req.user.id,
                  approvedAt: new Date(),
                  notes: `Initial membership: ${plan.name}`,
                },
              });
            }
          }
        }

        return customer;
      });

      const io = req.app.get('io');
      emitNewCustomer(io, gymId, {
        customerId: created.id,
        readableId: created.customerId,
        fullName: created.user.fullName,
        createdAt: created.createdAt,
      });

      await createNotification({
        userId: created.userId,
        gymId,
        type: 'WELCOME',
        title: 'Welcome to the Gym!',
        message: `Your member profile (${created.customerId}) has been created.`,
        io,
      });

      await createAuditLog({
        userId: req.user.id,
        gymId,
        action: 'CREATE_CUSTOMER',
        entity: 'CustomerProfile',
        entityId: created.id,
        details: { customerId: created.customerId, email: resolvedEmail },
        req,
      });

      return sendSuccess(res, formatCustomer(created), 'Customer created successfully', 201);
    } catch (err) {
      next(err);
    }
  }
);

// GET /api/customers/:id
router.get('/:id', async (req, res, next) => {
  try {
    const check = await ensureCustomerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    return sendSuccess(res, formatCustomer(check.customer), 'Customer retrieved');
  } catch (err) {
    next(err);
  }
});

// PUT /api/customers/:id
router.put('/:id', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const check = await ensureCustomerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const {
      fullName,
      name,
      email,
      mobile,
      branchId,
      gender,
      dateOfBirth,
      dob,
      heightCm,
      weightKg,
      fitnessGoal,
      medicalNotes,
      address,
      emergencyContact,
      emergencyPhone,
      assignedTrainerId,
      trainerId,
      isActive,
    } = req.body;

    const resolvedName = fullName !== undefined ? fullName : name;
    const resolvedDob = dateOfBirth !== undefined ? dateOfBirth : dob;
    const resolvedTrainer = assignedTrainerId !== undefined ? assignedTrainerId : trainerId;

    const updated = await prisma.$transaction(async (tx) => {
      if (resolvedName !== undefined || mobile !== undefined || email !== undefined || isActive !== undefined) {
        await tx.user.update({
          where: { id: check.customer.userId },
          data: {
            ...(resolvedName !== undefined && { fullName: resolvedName }),
            ...(mobile !== undefined && { mobile: canonicalMobile(mobile) || null }),
            ...(email !== undefined && { email: email.toLowerCase().trim() }),
            ...(isActive !== undefined && { isActive: Boolean(isActive) }),
          },
        });
      }

      return tx.customerProfile.update({
        where: { id: check.customer.id },
        data: {
          ...(branchId !== undefined && { branchId: branchId || null }),
          ...(gender !== undefined && { gender }),
          ...(resolvedDob !== undefined && { dateOfBirth: resolvedDob ? new Date(resolvedDob) : null }),
          ...(heightCm !== undefined && { heightCm: heightCm ? Number(heightCm) : null }),
          ...(weightKg !== undefined && { weightKg: weightKg ? Number(weightKg) : null }),
          ...(fitnessGoal !== undefined && { fitnessGoal }),
          ...(medicalNotes !== undefined && { medicalNotes }),
          ...(address !== undefined && { address }),
          ...(emergencyContact !== undefined && { emergencyContact }),
          ...(emergencyPhone !== undefined && { emergencyPhone }),
          ...(resolvedTrainer !== undefined && { assignedTrainerId: resolvedTrainer || null }),
          ...(isActive !== undefined && { isActive: Boolean(isActive) }),
        },
        include: {
          user: {
            select: { id: true, email: true, fullName: true, mobile: true, profilePhoto: true, isActive: true },
          },
          branch: true,
          assignedTrainer: { include: { user: { select: { id: true, fullName: true } } } },
          memberships: { take: 2, orderBy: { createdAt: 'desc' }, include: { plan: true } },
        },
      });
    });

    await createAuditLog({
      userId: req.user.id,
      gymId: check.customer.gymId,
      action: 'UPDATE_CUSTOMER',
      entity: 'CustomerProfile',
      entityId: updated.id,
      req,
    });

    return sendSuccess(res, formatCustomer(updated), 'Customer updated successfully');
  } catch (err) {
    next(err);
  }
});

// PATCH /api/customers/:id/assign-trainer
router.patch('/:id/assign-trainer', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const check = await ensureCustomerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const { trainerId } = req.body;
    const updated = await prisma.customerProfile.update({
      where: { id: check.customer.id },
      data: { assignedTrainerId: trainerId || null },
      include: {
        user: { select: { id: true, email: true, fullName: true, mobile: true, profilePhoto: true, isActive: true } },
        assignedTrainer: { include: { user: { select: { id: true, fullName: true } } } },
      },
    });

    return sendSuccess(res, formatCustomer(updated), 'Trainer assigned successfully');
  } catch (err) {
    next(err);
  }
});

// PATCH /api/customers/:id/status
router.patch('/:id/status', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const check = await ensureCustomerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const active =
      req.body.isActive !== undefined
        ? Boolean(req.body.isActive)
        : req.body.status
        ? String(req.body.status).toUpperCase() === 'ACTIVE'
        : !check.customer.isActive;

    await prisma.$transaction([
      prisma.customerProfile.update({ where: { id: check.customer.id }, data: { isActive: active } }),
      prisma.user.update({ where: { id: check.customer.userId }, data: { isActive: active } }),
    ]);

    return sendSuccess(res, { isActive: active }, `Customer ${active ? 'activated' : 'deactivated'}`);
  } catch (err) {
    next(err);
  }
});

// DELETE /api/customers/:id (Soft delete)
router.delete('/:id', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const check = await ensureCustomerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    await prisma.$transaction([
      prisma.customerProfile.update({
        where: { id: check.customer.id },
        data: { isActive: false },
      }),
      prisma.user.update({
        where: { id: check.customer.userId },
        data: { isActive: false },
      }),
    ]);

    await createAuditLog({
      userId: req.user.id,
      gymId: check.customer.gymId,
      action: 'DEACTIVATE_CUSTOMER',
      entity: 'CustomerProfile',
      entityId: check.customer.id,
      req,
    });

    return sendSuccess(res, null, 'Customer deactivated successfully');
  } catch (err) {
    next(err);
  }
});

// GET /api/customers/:id/profile
router.get('/:id/profile', async (req, res, next) => {
  try {
    const check = await ensureCustomerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const [activeMembership, attendanceCount, totalPaidAgg, latestProgress] = await Promise.all([
      prisma.customerMembership.findFirst({
        where: { customerId: check.customer.id, status: 'ACTIVE' },
        orderBy: { endDate: 'desc' },
        include: { plan: true },
      }),
      prisma.attendance.count({
        where: { customerId: check.customer.id, status: 'PRESENT' },
      }),
      prisma.payment.aggregate({
        where: { customerId: check.customer.id, status: 'APPROVED' },
        _sum: { amount: true },
      }),
      prisma.fitnessProgress.findFirst({
        where: { customerId: check.customer.id },
        orderBy: { date: 'desc' },
      }),
    ]);

    return sendSuccess(
      res,
      {
        customer: formatCustomer(check.customer),
        activeMembership: activeMembership
          ? {
              ...activeMembership,
              plan: activeMembership.plan
                ? { ...activeMembership.plan, services: parseJson(activeMembership.plan.services, []) }
                : null,
            }
          : null,
        stats: {
          totalCheckIns: attendanceCount,
          totalPaid: totalPaidAgg._sum.amount || 0,
        },
        latestProgress,
      },
      'Customer profile retrieved'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/customers/:id/attendance
router.get('/:id/attendance', async (req, res, next) => {
  try {
    const check = await ensureCustomerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const { page, limit, skip } = getPagination(req.query);
    const where = { customerId: check.customer.id };

    if (req.query.month && req.query.year) {
      const range = getISTMonthRange(req.query.month, req.query.year);
      where.date = { gte: range.dateOnlyStart, lte: range.dateOnlyEnd };
    }

    const [records, total] = await Promise.all([
      prisma.attendance.findMany({
        where,
        skip,
        take: limit,
        orderBy: { date: 'desc' },
      }),
      prisma.attendance.count({ where }),
    ]);

    return sendSuccess(res, formatPaginatedData(records, total, page, limit), 'Customer attendance fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/customers/:id/payments
router.get('/:id/payments', async (req, res, next) => {
  try {
    const check = await ensureCustomerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const { page, limit, skip } = getPagination(req.query);
    const [payments, total] = await Promise.all([
      prisma.payment.findMany({
        where: { customerId: check.customer.id },
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          membership: { include: { plan: { select: { id: true, name: true } } } },
        },
      }),
      prisma.payment.count({ where: { customerId: check.customer.id } }),
    ]);

    return sendSuccess(res, formatPaginatedData(payments, total, page, limit), 'Customer payments fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/customers/:id/membership
router.get('/:id/membership', async (req, res, next) => {
  try {
    const check = await ensureCustomerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const memberships = await prisma.customerMembership.findMany({
      where: { customerId: check.customer.id },
      orderBy: { createdAt: 'desc' },
      include: { plan: true },
    });

    const formatted = memberships.map((m) => ({
      ...m,
      plan: m.plan ? { ...m.plan, services: parseJson(m.plan.services, []) } : null,
    }));

    const activeMembership = formatted.find((m) => m.status === 'ACTIVE') || null;

    return sendSuccess(res, { activeMembership, history: formatted }, 'Customer membership fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/customers/:id/workouts
router.get('/:id/workouts', async (req, res, next) => {
  try {
    const check = await ensureCustomerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const workouts = await prisma.workoutPlan.findMany({
      where: { customerId: check.customer.id },
      orderBy: { createdAt: 'desc' },
      include: {
        trainer: { include: { user: { select: { fullName: true } } } },
        exercises: { orderBy: { orderIndex: 'asc' } },
      },
    });

    return sendSuccess(res, workouts, 'Customer workout plans fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/customers/:id/diet
router.get('/:id/diet', async (req, res, next) => {
  try {
    const check = await ensureCustomerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const dietPlans = await prisma.dietPlan.findMany({
      where: { customerId: check.customer.id },
      orderBy: { createdAt: 'desc' },
      include: {
        trainer: { include: { user: { select: { fullName: true } } } },
        meals: true,
      },
    });

    return sendSuccess(res, dietPlans, 'Customer diet plans fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/customers/:id/progress
router.get('/:id/progress', async (req, res, next) => {
  try {
    const check = await ensureCustomerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const progress = await prisma.fitnessProgress.findMany({
      where: { customerId: check.customer.id },
      orderBy: { date: 'desc' },
    });

    return sendSuccess(res, progress, 'Customer fitness progress fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/customers/:id/membership-card
router.post('/:id/membership-card', async (req, res, next) => {
  try {
    const check = await ensureCustomerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const activeMembership = await prisma.customerMembership.findFirst({
      where: { customerId: check.customer.id, status: { in: ['ACTIVE', 'FROZEN'] } },
      orderBy: { endDate: 'desc' },
      include: { plan: true },
    });

    if (req.query.format === 'pdf' || req.body?.format === 'pdf') {
      const pdfBuffer = generateMembershipCardPDF(check.customer, check.customer.gym, activeMembership);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="membership-card-${check.customer.customerId}.pdf"`
      );
      return res.send(pdfBuffer);
    }

    const qrPayload = JSON.stringify({
      type: 'GYM_PRO_CHECKIN',
      gymId: check.customer.gymId,
      customerId: check.customer.id,
      readableId: check.customer.customerId,
    });

    return sendSuccess(
      res,
      {
        cardNumber: check.customer.customerId,
        memberName: check.customer.user.fullName,
        mobile: check.customer.user.mobile,
        profilePhoto: check.customer.user.profilePhoto,
        gymName: check.customer.gym?.name,
        gymLogo: check.customer.gym?.logo,
        branchName: check.customer.branch?.name || 'Main Branch',
        membership: activeMembership
          ? {
              planName: activeMembership.plan?.name,
              status: activeMembership.status,
              startDate: activeMembership.startDate,
              endDate: activeMembership.endDate,
            }
          : null,
        qrPayload,
      },
      'Membership card generated'
    );
  } catch (err) {
    next(err);
  }
});

module.exports = router;

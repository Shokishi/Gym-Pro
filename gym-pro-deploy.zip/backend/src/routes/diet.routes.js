const express = require('express');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const { formatCustomer, formatTrainer } = require('../utils/json');
const { createNotification } = require('../utils/notification');
const { createAuditLog } = require('../utils/audit');

const router = express.Router();

router.use(authenticate, requireGymAccess());

const VALID_MEAL_TYPES = new Set([
  'BREAKFAST',
  'LUNCH',
  'DINNER',
  'SNACK',
  'PRE_WORKOUT',
  'POST_WORKOUT',
]);

const normalizeMealType = (val) => {
  const upper = String(val || 'BREAKFAST').trim().toUpperCase().replace(/[\s-]+/g, '_');
  if (upper === 'EVENING_SNACK' || upper === 'MID_MORNING_SNACK' || upper === 'SNACKS') return 'SNACK';
  return VALID_MEAL_TYPES.has(upper) ? upper : 'SNACK';
};

const buildMealsInput = (meals = []) =>
  (Array.isArray(meals) ? meals : []).map((m, idx) => ({
    mealType: normalizeMealType(m.mealType || m.mealTime),
    name: m.name || m.items || `Meal ${idx + 1}`,
    description: m.description || m.items || null,
    time: m.time || null,
    calories: parseInt(m.calories, 10) || 0,
    protein: parseFloat(m.protein) || 0,
    carbs: parseFloat(m.carbs) || 0,
    fats: parseFloat(m.fats) || 0,
    instructions: m.instructions || null,
    completed: Boolean(m.completed),
  }));

const formatDietPlan = (plan) => {
  const meals = (plan.meals || []).map((m) => ({
    ...m,
    mealTime: m.mealType,
    items: m.description || m.name,
    time: m.time || '',
    completed: Boolean(m.completed),
  }));

  const totals = meals.reduce(
    (acc, m) => ({
      totalCalories: acc.totalCalories + (Number(m.calories) || 0),
      totalProtein: acc.totalProtein + (Number(m.protein) || 0),
      totalCarbs: acc.totalCarbs + (Number(m.carbs) || 0),
      totalFats: acc.totalFats + (Number(m.fats) || 0),
    }),
    { totalCalories: 0, totalProtein: 0, totalCarbs: 0, totalFats: 0 }
  );

  return {
    ...plan,
    title: plan.name,
    name: plan.name,
    goal: plan.goal || 'GENERAL_HEALTH',
    dietType: plan.dietType || 'BALANCED',
    notes: plan.notes || '',
    ...totals,
    customer: plan.customer ? formatCustomer(plan.customer) : null,
    customerName: plan.customer?.user?.fullName || null,
    trainer: plan.trainer ? formatTrainer(plan.trainer) : null,
    trainerName: plan.trainer?.user?.fullName || null,
    meals,
  };
};

const dietPlanInclude = {
  customer: { include: { user: true } },
  trainer: { include: { user: true } },
  meals: { orderBy: { createdAt: 'asc' } },
};

// GET /api/diets/me (Customer)
router.get('/me', authorize('CUSTOMER'), async (req, res, next) => {
  try {
    const customer = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
    if (!customer) return sendError(res, 'Customer profile not found', 404);

    const plans = await prisma.dietPlan.findMany({
      where: { gymId: customer.gymId, customerId: customer.id },
      include: dietPlanInclude,
      orderBy: [{ isActive: 'desc' }, { createdAt: 'desc' }],
    });

    return sendSuccess(res, plans.map(formatDietPlan), 'My diet plans fetched');
  } catch (err) {
    next(err);
  }
});

// PATCH /api/diets/me/:planId/meals/:mealId
router.patch('/me/:planId/meals/:mealId', authorize('CUSTOMER'), async (req, res, next) => {
  try {
    const customer = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
    if (!customer) return sendError(res, 'Customer profile not found', 404);

    const plan = await prisma.dietPlan.findFirst({
      where: { id: req.params.planId, customerId: customer.id, gymId: customer.gymId },
      include: { meals: true },
    });
    if (!plan) return sendError(res, 'Diet plan not found', 404);

    const meal = plan.meals.find((m) => m.id === req.params.mealId);
    if (!meal) return sendError(res, 'Meal not found in plan', 404);

    const completed = req.body.completed !== undefined ? Boolean(req.body.completed) : !meal.completed;
    const updated = await prisma.dietMeal.update({
      where: { id: meal.id },
      data: { completed },
    });

    return sendSuccess(
      res,
      {
        ...updated,
        mealTime: updated.mealType,
        items: updated.description || updated.name,
      },
      'Meal adherence updated'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/diets/customer/:id
router.get('/customer/:id', async (req, res, next) => {
  try {
    const customer = await prisma.customerProfile.findUnique({ where: { id: req.params.id } });
    if (!customer || customer.gymId !== req.gymId) return sendError(res, 'Customer not found', 404);

    if (req.user.role === 'CUSTOMER' && customer.userId !== req.user.id) {
      return sendError(res, 'Access denied', 403);
    }

    const plans = await prisma.dietPlan.findMany({
      where: { gymId: req.gymId, customerId: customer.id },
      include: dietPlanInclude,
      orderBy: [{ isActive: 'desc' }, { createdAt: 'desc' }],
    });

    return sendSuccess(res, plans.map(formatDietPlan), 'Customer diet plans fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/diets
router.get('/', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { page, limit, skip } = getPagination(req.query);
    const { customerId, trainerId, isActive, goal, dietType, search } = req.query;

    const where = { gymId };
    if (customerId) where.customerId = customerId;
    if (trainerId) where.trainerId = trainerId;
    if (isActive !== undefined) where.isActive = isActive === 'true';
    if (goal) where.goal = goal;
    if (dietType) where.dietType = dietType;
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { notes: { contains: search } },
      ];
    }

    if (req.user.role === 'CUSTOMER') {
      const cust = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
      if (!cust) return sendSuccess(res, formatPaginatedData([], 0, page, limit));
      where.customerId = cust.id;
    } else if (req.user.role === 'TRAINER') {
      const tr = await prisma.trainerProfile.findUnique({ where: { userId: req.user.id } });
      if (tr) {
        where.OR = [
          { trainerId: tr.id },
          { customer: { assignedTrainerId: tr.id } },
        ];
      }
    }

    const [plans, total] = await Promise.all([
      prisma.dietPlan.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: dietPlanInclude,
      }),
      prisma.dietPlan.count({ where }),
    ]);

    return sendSuccess(
      res,
      formatPaginatedData(plans.map(formatDietPlan), total, page, limit),
      'Diet plans fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/diets/:id
router.get('/:id', async (req, res, next) => {
  try {
    const plan = await prisma.dietPlan.findUnique({
      where: { id: req.params.id },
      include: dietPlanInclude,
    });
    if (!plan || plan.gymId !== req.gymId) return sendError(res, 'Diet plan not found', 404);

    if (req.user.role === 'CUSTOMER') {
      const cust = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
      if (!cust || plan.customerId !== cust.id) return sendError(res, 'Access denied', 403);
    }

    return sendSuccess(res, formatDietPlan(plan), 'Diet plan fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/diets
router.post(
  '/',
  authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'),
  [
    body().custom((val) => {
      if (!val.name && !val.title) throw new Error('Diet plan name or title is required');
      return true;
    }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const {
        name,
        title,
        customerId,
        trainerId,
        isActive = true,
        goal,
        dietType,
        notes,
        meals = [],
      } = req.body;

      let resolvedTrainerId = trainerId || null;
      if (req.user.role === 'TRAINER') {
        const tr = await prisma.trainerProfile.findUnique({ where: { userId: req.user.id } });
        if (tr) resolvedTrainerId = tr.id;
      }

      if (customerId) {
        const customer = await prisma.customerProfile.findUnique({ where: { id: customerId } });
        if (!customer || customer.gymId !== gymId) return sendError(res, 'Customer not found in gym', 404);
      }

      const plan = await prisma.dietPlan.create({
        data: {
          gymId,
          trainerId: resolvedTrainerId,
          customerId: customerId || null,
          name: (name || title).trim(),
          isActive: Boolean(isActive),
          goal: goal || null,
          dietType: dietType || null,
          notes: notes || null,
          meals: {
            create: buildMealsInput(meals),
          },
        },
        include: dietPlanInclude,
      });

      if (plan.customerId && plan.customer?.userId) {
        await createNotification({
          userId: plan.customer.userId,
          gymId,
          type: 'DIET_ASSIGNED',
          title: 'New Diet Plan Assigned',
          message: `Diet plan "${plan.name}" has been assigned to you.`,
          data: { dietPlanId: plan.id },
        });
      }

      await createAuditLog({
        userId: req.user.id,
        gymId,
        action: 'DIET_PLAN_CREATED',
        entity: 'DietPlan',
        entityId: plan.id,
        details: { name: plan.name, customerId: plan.customerId },
        ipAddress: req.ip,
      });

      return sendSuccess(res, formatDietPlan(plan), 'Diet plan created', 201);
    } catch (err) {
      next(err);
    }
  }
);

// PUT /api/diets/:id
router.put('/:id', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.dietPlan.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Diet plan not found', 404);

    const { name, title, isActive, goal, dietType, notes, customerId, trainerId, meals } = req.body;

    const updated = await prisma.$transaction(async (tx) => {
      if (Array.isArray(meals)) {
        await tx.dietMeal.deleteMany({ where: { dietPlanId: existing.id } });
      }
      return tx.dietPlan.update({
        where: { id: existing.id },
        data: {
          ...(name || title ? { name: (name || title).trim() } : {}),
          ...(isActive !== undefined ? { isActive: Boolean(isActive) } : {}),
          ...(goal !== undefined ? { goal } : {}),
          ...(dietType !== undefined ? { dietType } : {}),
          ...(notes !== undefined ? { notes } : {}),
          ...(customerId !== undefined ? { customerId: customerId || null } : {}),
          ...(trainerId !== undefined ? { trainerId: trainerId || null } : {}),
          ...(Array.isArray(meals) ? { meals: { create: buildMealsInput(meals) } } : {}),
        },
        include: dietPlanInclude,
      });
    });

    return sendSuccess(res, formatDietPlan(updated), 'Diet plan updated');
  } catch (err) {
    next(err);
  }
});

// POST /api/diets/:id/assign
router.post('/:id/assign', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const { customerId } = req.body;
    if (!customerId) return sendError(res, 'customerId is required', 400);

    const [plan, customer] = await Promise.all([
      prisma.dietPlan.findUnique({ where: { id: req.params.id }, include: { meals: true } }),
      prisma.customerProfile.findUnique({ where: { id: customerId }, include: { user: true } }),
    ]);

    if (!plan || plan.gymId !== req.gymId) return sendError(res, 'Diet plan not found', 404);
    if (!customer || customer.gymId !== req.gymId) return sendError(res, 'Customer not found', 404);

    let assigned;
    if (!plan.customerId || plan.customerId === customer.id) {
      assigned = await prisma.dietPlan.update({
        where: { id: plan.id },
        data: { customerId: customer.id, isActive: true },
        include: dietPlanInclude,
      });
    } else {
      assigned = await prisma.dietPlan.create({
        data: {
          gymId: plan.gymId,
          trainerId: plan.trainerId,
          customerId: customer.id,
          name: plan.name,
          isActive: true,
          goal: plan.goal,
          dietType: plan.dietType,
          notes: plan.notes,
          meals: {
            create: plan.meals.map((m) => ({
              mealType: m.mealType,
              name: m.name,
              description: m.description,
              time: m.time,
              calories: m.calories,
              protein: m.protein,
              carbs: m.carbs,
              fats: m.fats,
              instructions: m.instructions,
              completed: false,
            })),
          },
        },
        include: dietPlanInclude,
      });
    }

    await createNotification({
      userId: customer.userId,
      gymId: req.gymId,
      type: 'DIET_ASSIGNED',
      title: 'Diet Plan Assigned',
      message: `Diet plan "${assigned.name}" has been assigned to you.`,
      data: { dietPlanId: assigned.id },
    });

    return sendSuccess(res, formatDietPlan(assigned), 'Diet plan assigned to customer');
  } catch (err) {
    next(err);
  }
});

// DELETE /api/diets/:id
router.delete('/:id', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.dietPlan.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Diet plan not found', 404);

    await prisma.dietPlan.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'Diet plan deleted');
  } catch (err) {
    next(err);
  }
});

// POST /api/diets/:id/meals
router.post('/:id/meals', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const plan = await prisma.dietPlan.findUnique({ where: { id: req.params.id } });
    if (!plan || plan.gymId !== req.gymId) return sendError(res, 'Diet plan not found', 404);

    const mealInput = buildMealsInput([req.body])[0];
    const meal = await prisma.dietMeal.create({
      data: { ...mealInput, dietPlanId: plan.id },
    });

    return sendSuccess(
      res,
      { ...meal, mealTime: meal.mealType, items: meal.description || meal.name },
      'Meal added',
      201
    );
  } catch (err) {
    next(err);
  }
});

// PUT /api/diets/meals/:mealId
router.put('/meals/:mealId', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.dietMeal.findUnique({
      where: { id: req.params.mealId },
      include: { dietPlan: true },
    });
    if (!existing || existing.dietPlan.gymId !== req.gymId) return sendError(res, 'Meal not found', 404);

    const updated = await prisma.dietMeal.update({
      where: { id: existing.id },
      data: {
        mealType: req.body.mealType || req.body.mealTime
          ? normalizeMealType(req.body.mealType || req.body.mealTime)
          : existing.mealType,
        name: req.body.name ?? existing.name,
        description: req.body.description ?? req.body.items ?? existing.description,
        time: req.body.time ?? existing.time,
        calories: req.body.calories != null ? parseInt(req.body.calories, 10) : existing.calories,
        protein: req.body.protein != null ? parseFloat(req.body.protein) : existing.protein,
        carbs: req.body.carbs != null ? parseFloat(req.body.carbs) : existing.carbs,
        fats: req.body.fats != null ? parseFloat(req.body.fats) : existing.fats,
        instructions: req.body.instructions ?? existing.instructions,
        completed: req.body.completed !== undefined ? Boolean(req.body.completed) : existing.completed,
      },
    });

    return sendSuccess(res, updated, 'Meal updated');
  } catch (err) {
    next(err);
  }
});

// DELETE /api/diets/meals/:mealId
router.delete('/meals/:mealId', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.dietMeal.findUnique({
      where: { id: req.params.mealId },
      include: { dietPlan: true },
    });
    if (!existing || existing.dietPlan.gymId !== req.gymId) return sendError(res, 'Meal not found', 404);

    await prisma.dietMeal.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'Meal deleted');
  } catch (err) {
    next(err);
  }
});

module.exports = router;

const express = require('express');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const { formatCustomer, formatTrainer } = require('../utils/json');
const { getISTDayRange } = require('../utils/date');
const { createNotification } = require('../utils/notification');
const { createAuditLog } = require('../utils/audit');

const router = express.Router();

router.use(authenticate, requireGymAccess());

const VALID_MUSCLE_GROUPS = new Set([
  'CHEST',
  'BACK',
  'SHOULDERS',
  'BICEPS',
  'TRICEPS',
  'LEGS',
  'ABS',
  'CARDIO',
  'FULL_BODY',
]);

const normalizeMuscleGroup = (val) => {
  const upper = String(val || 'FULL_BODY').trim().toUpperCase().replace(/\s+/g, '_');
  return VALID_MUSCLE_GROUPS.has(upper) ? upper : 'FULL_BODY';
};

const buildExercisesInput = (exercises = [], fallbackDay = null) =>
  (Array.isArray(exercises) ? exercises : []).map((ex, idx) => ({
    name: ex.name || `Exercise ${idx + 1}`,
    day: ex.day || fallbackDay || 'Monday',
    muscleGroup: normalizeMuscleGroup(ex.muscleGroup || ex.category),
    sets: parseInt(ex.sets, 10) || 3,
    reps: String(ex.reps ?? '10-12'),
    weight: ex.weight != null && ex.weight !== '' ? String(ex.weight) : null,
    restTime: parseInt(ex.restTime ?? ex.restSeconds, 10) || 60,
    instructions: ex.instructions || null,
    imageUrl: ex.imageUrl || null,
    videoUrl: ex.videoUrl || null,
    orderIndex: ex.orderIndex != null ? parseInt(ex.orderIndex, 10) : idx,
  }));

const formatWorkoutPlan = (plan, completedExerciseIds = new Set()) => {
  const exercises = (plan.exercises || []).map((ex) => ({
    ...ex,
    day: ex.day || plan.dayOfWeek || 'Monday',
    restSeconds: ex.restTime || 60,
    completed: completedExerciseIds.has(ex.id),
  }));

  return {
    ...plan,
    title: plan.name,
    name: plan.name,
    goal: plan.goal || 'GENERAL_FITNESS',
    difficulty: plan.difficulty || 'INTERMEDIATE',
    durationWeeks: plan.durationWeeks || 4,
    description: plan.description || '',
    customer: plan.customer ? formatCustomer(plan.customer) : null,
    customerName: plan.customer?.user?.fullName || null,
    trainer: plan.trainer ? formatTrainer(plan.trainer) : null,
    trainerName: plan.trainer?.user?.fullName || null,
    exercises,
  };
};

const workoutPlanInclude = {
  customer: { include: { user: true } },
  trainer: { include: { user: true } },
  exercises: { orderBy: { orderIndex: 'asc' } },
};

const getTodayCompletedExerciseIds = async (customerId) => {
  if (!customerId) return new Set();
  const { start, end } = getISTDayRange();
  const logs = await prisma.exerciseLog.findMany({
    where: {
      customerId,
      completed: true,
      date: { gte: start, lte: end },
    },
    select: { exerciseId: true },
  });
  return new Set(logs.map((l) => l.exerciseId));
};

// GET /api/workouts/me (Customer)
router.get('/me', authorize('CUSTOMER'), async (req, res, next) => {
  try {
    const customer = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
    if (!customer) return sendError(res, 'Customer profile not found', 404);

    const [plans, completedIds] = await Promise.all([
      prisma.workoutPlan.findMany({
        where: { gymId: customer.gymId, customerId: customer.id },
        include: workoutPlanInclude,
        orderBy: { createdAt: 'desc' },
      }),
      getTodayCompletedExerciseIds(customer.id),
    ]);

    return sendSuccess(
      res,
      plans.map((p) => formatWorkoutPlan(p, completedIds)),
      'My workout plans fetched'
    );
  } catch (err) {
    next(err);
  }
});

// PATCH /api/workouts/me/:planId/exercises/:exerciseId
router.patch('/me/:planId/exercises/:exerciseId', authorize('CUSTOMER'), async (req, res, next) => {
  try {
    const customer = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
    if (!customer) return sendError(res, 'Customer profile not found', 404);

    const plan = await prisma.workoutPlan.findFirst({
      where: { id: req.params.planId, customerId: customer.id, gymId: customer.gymId },
      include: { exercises: true },
    });
    if (!plan) return sendError(res, 'Workout plan not found', 404);

    const exercise = plan.exercises.find((e) => e.id === req.params.exerciseId);
    if (!exercise) return sendError(res, 'Exercise not found in this plan', 404);

    const { start, end } = getISTDayRange();
    const completed = req.body.completed !== undefined ? Boolean(req.body.completed) : true;

    const existing = await prisma.exerciseLog.findFirst({
      where: {
        exerciseId: exercise.id,
        customerId: customer.id,
        date: { gte: start, lte: end },
      },
    });

    const log = existing
      ? await prisma.exerciseLog.update({
          where: { id: existing.id },
          data: {
            completed,
            actualSets: req.body.actualSets != null ? parseInt(req.body.actualSets, 10) : existing.actualSets,
            actualReps: req.body.actualReps ?? existing.actualReps,
            actualWeight: req.body.actualWeight ?? existing.actualWeight,
            notes: req.body.notes ?? existing.notes,
          },
        })
      : await prisma.exerciseLog.create({
          data: {
            exerciseId: exercise.id,
            customerId: customer.id,
            date: new Date(),
            completed,
            actualSets: req.body.actualSets != null ? parseInt(req.body.actualSets, 10) : exercise.sets,
            actualReps: req.body.actualReps ?? exercise.reps,
            actualWeight: req.body.actualWeight ?? exercise.weight,
            notes: req.body.notes || null,
          },
        });

    return sendSuccess(res, { ...log, exerciseId: exercise.id, completed }, 'Exercise status updated');
  } catch (err) {
    next(err);
  }
});

// POST /api/workouts/me/:planId/complete
router.post('/me/:planId/complete', authorize('CUSTOMER'), async (req, res, next) => {
  try {
    const customer = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
    if (!customer) return sendError(res, 'Customer profile not found', 404);

    const plan = await prisma.workoutPlan.findFirst({
      where: { id: req.params.planId, customerId: customer.id, gymId: customer.gymId },
      include: { exercises: true },
    });
    if (!plan) return sendError(res, 'Workout plan not found', 404);

    const { day } = req.body;
    const targetExercises = day
      ? plan.exercises.filter((e) => (e.day || plan.dayOfWeek || '').toLowerCase() === String(day).toLowerCase())
      : plan.exercises;

    const listToLog = targetExercises.length > 0 ? targetExercises : plan.exercises;
    const { start, end } = getISTDayRange();
    const existingLogs = await prisma.exerciseLog.findMany({
      where: {
        customerId: customer.id,
        exerciseId: { in: listToLog.map((e) => e.id) },
        date: { gte: start, lte: end },
      },
    });
    const existingMap = new Map(existingLogs.map((l) => [l.exerciseId, l]));

    for (const ex of listToLog) {
      const prev = existingMap.get(ex.id);
      if (prev) {
        await prisma.exerciseLog.update({ where: { id: prev.id }, data: { completed: true } });
      } else {
        await prisma.exerciseLog.create({
          data: {
            exerciseId: ex.id,
            customerId: customer.id,
            date: new Date(),
            completed: true,
            actualSets: ex.sets,
            actualReps: ex.reps,
            actualWeight: ex.weight,
          },
        });
      }
    }

    return sendSuccess(res, { completedCount: listToLog.length, day: day || 'ALL' }, 'Workout day marked completed');
  } catch (err) {
    next(err);
  }
});

// POST /api/workouts/exercises/:id/log
router.post('/exercises/:id/log', authorize('CUSTOMER', 'TRAINER', 'GYM_OWNER'), async (req, res, next) => {
  try {
    const exercise = await prisma.exercise.findUnique({
      where: { id: req.params.id },
      include: { workoutPlan: true },
    });
    if (!exercise || exercise.workoutPlan.gymId !== req.gymId) {
      return sendError(res, 'Exercise not found', 404);
    }

    let customerId = req.body.customerId || exercise.workoutPlan.customerId;
    if (req.user.role === 'CUSTOMER') {
      const cust = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
      if (!cust) return sendError(res, 'Customer profile not found', 404);
      customerId = cust.id;
    }
    if (!customerId) return sendError(res, 'customerId is required', 400);

    const log = await prisma.exerciseLog.create({
      data: {
        exerciseId: exercise.id,
        customerId,
        date: new Date(),
        completed: req.body.completed !== undefined ? Boolean(req.body.completed) : true,
        actualSets: req.body.actualSets != null ? parseInt(req.body.actualSets, 10) : exercise.sets,
        actualReps: req.body.actualReps != null ? String(req.body.actualReps) : exercise.reps,
        actualWeight: req.body.actualWeight != null ? String(req.body.actualWeight) : exercise.weight,
        notes: req.body.notes || null,
      },
    });

    return sendSuccess(res, log, 'Exercise logged', 201);
  } catch (err) {
    next(err);
  }
});

// GET /api/workouts/customer/:id
router.get('/customer/:id', async (req, res, next) => {
  try {
    const customer = await prisma.customerProfile.findUnique({ where: { id: req.params.id } });
    if (!customer || customer.gymId !== req.gymId) {
      return sendError(res, 'Customer not found', 404);
    }
    if (req.user.role === 'CUSTOMER' && customer.userId !== req.user.id) {
      return sendError(res, 'Access denied', 403);
    }

    const [plans, completedIds] = await Promise.all([
      prisma.workoutPlan.findMany({
        where: { gymId: req.gymId, customerId: customer.id },
        include: workoutPlanInclude,
        orderBy: { createdAt: 'desc' },
      }),
      getTodayCompletedExerciseIds(customer.id),
    ]);

    return sendSuccess(
      res,
      plans.map((p) => formatWorkoutPlan(p, completedIds)),
      'Customer workout plans fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/workouts
router.get('/', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { page, limit, skip } = getPagination(req.query);
    const { customerId, trainerId, dayOfWeek, goal, difficulty, search } = req.query;

    const where = { gymId };
    if (customerId) where.customerId = customerId;
    if (trainerId) where.trainerId = trainerId;
    if (dayOfWeek) where.dayOfWeek = dayOfWeek;
    if (goal) where.goal = goal;
    if (difficulty) where.difficulty = difficulty;
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { description: { contains: search } },
      ];
    }

    if (req.user.role === 'CUSTOMER') {
      const cust = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
      if (!cust) return sendSuccess(res, formatPaginatedData([], 0, page, limit));
      where.customerId = cust.id;
    } else if (req.user.role === 'TRAINER') {
      const tr = await prisma.trainerProfile.findUnique({ where: { userId: req.user.id } });
      if (tr) {
        where.OR = [
          { trainerId: tr.id },
          { customer: { assignedTrainerId: tr.id } },
        ];
      }
    }

    const [plans, total] = await Promise.all([
      prisma.workoutPlan.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: workoutPlanInclude,
      }),
      prisma.workoutPlan.count({ where }),
    ]);

    return sendSuccess(
      res,
      formatPaginatedData(plans.map((p) => formatWorkoutPlan(p)), total, page, limit),
      'Workout plans fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/workouts/:id
router.get('/:id', async (req, res, next) => {
  try {
    const plan = await prisma.workoutPlan.findUnique({
      where: { id: req.params.id },
      include: workoutPlanInclude,
    });
    if (!plan || plan.gymId !== req.gymId) return sendError(res, 'Workout plan not found', 404);

    if (req.user.role === 'CUSTOMER') {
      const cust = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
      if (!cust || plan.customerId !== cust.id) return sendError(res, 'Access denied', 403);
    }

    const completedIds = await getTodayCompletedExerciseIds(plan.customerId);
    return sendSuccess(res, formatWorkoutPlan(plan, completedIds), 'Workout plan fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/workouts
router.post(
  '/',
  authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'),
  [
    body().custom((val) => {
      if (!val.name && !val.title) throw new Error('Plan name or title is required');
      return true;
    }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const {
        name,
        title,
        customerId,
        trainerId,
        dayOfWeek,
        goal,
        difficulty,
        durationWeeks,
        description,
        exercises = [],
      } = req.body;

      let resolvedTrainerId = trainerId || null;
      if (req.user.role === 'TRAINER') {
        const tr = await prisma.trainerProfile.findUnique({ where: { userId: req.user.id } });
        if (tr) resolvedTrainerId = tr.id;
      }

      if (customerId) {
        const customer = await prisma.customerProfile.findUnique({ where: { id: customerId } });
        if (!customer || customer.gymId !== gymId) return sendError(res, 'Customer not found in gym', 404);
      }

      const plan = await prisma.workoutPlan.create({
        data: {
          gymId,
          trainerId: resolvedTrainerId,
          customerId: customerId || null,
          name: (name || title).trim(),
          dayOfWeek: dayOfWeek || null,
          goal: goal || null,
          difficulty: difficulty || null,
          durationWeeks: durationWeeks != null ? parseInt(durationWeeks, 10) || 4 : null,
          description: description || null,
          exercises: {
            create: buildExercisesInput(exercises, dayOfWeek),
          },
        },
        include: workoutPlanInclude,
      });

      if (plan.customerId && plan.customer?.userId) {
        await createNotification({
          userId: plan.customer.userId,
          gymId,
          type: 'WORKOUT_ASSIGNED',
          title: 'New Workout Plan Assigned',
          message: `Workout plan "${plan.name}" has been assigned to you.`,
          data: { workoutPlanId: plan.id },
        });
      }

      await createAuditLog({
        userId: req.user.id,
        gymId,
        action: 'WORKOUT_PLAN_CREATED',
        entity: 'WorkoutPlan',
        entityId: plan.id,
        details: { name: plan.name, customerId: plan.customerId },
        ipAddress: req.ip,
      });

      return sendSuccess(res, formatWorkoutPlan(plan), 'Workout plan created', 201);
    } catch (err) {
      next(err);
    }
  }
);

// PUT /api/workouts/:id
router.put('/:id', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.workoutPlan.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Workout plan not found', 404);

    const {
      name,
      title,
      dayOfWeek,
      goal,
      difficulty,
      durationWeeks,
      description,
      customerId,
      trainerId,
      exercises,
    } = req.body;

    const updated = await prisma.$transaction(async (tx) => {
      if (Array.isArray(exercises)) {
        await tx.exercise.deleteMany({ where: { workoutPlanId: existing.id } });
      }
      return tx.workoutPlan.update({
        where: { id: existing.id },
        data: {
          ...(name || title ? { name: (name || title).trim() } : {}),
          ...(dayOfWeek !== undefined ? { dayOfWeek } : {}),
          ...(goal !== undefined ? { goal } : {}),
          ...(difficulty !== undefined ? { difficulty } : {}),
          ...(durationWeeks !== undefined ? { durationWeeks: parseInt(durationWeeks, 10) || null } : {}),
          ...(description !== undefined ? { description } : {}),
          ...(customerId !== undefined ? { customerId: customerId || null } : {}),
          ...(trainerId !== undefined ? { trainerId: trainerId || null } : {}),
          ...(Array.isArray(exercises)
            ? { exercises: { create: buildExercisesInput(exercises, dayOfWeek ?? existing.dayOfWeek) } }
            : {}),
        },
        include: workoutPlanInclude,
      });
    });

    return sendSuccess(res, formatWorkoutPlan(updated), 'Workout plan updated');
  } catch (err) {
    next(err);
  }
});

// POST /api/workouts/:id/assign
router.post('/:id/assign', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const { customerId } = req.body;
    if (!customerId) return sendError(res, 'customerId is required', 400);

    const [plan, customer] = await Promise.all([
      prisma.workoutPlan.findUnique({
        where: { id: req.params.id },
        include: { exercises: { orderBy: { orderIndex: 'asc' } } },
      }),
      prisma.customerProfile.findUnique({ where: { id: customerId }, include: { user: true } }),
    ]);

    if (!plan || plan.gymId !== req.gymId) return sendError(res, 'Workout plan not found', 404);
    if (!customer || customer.gymId !== req.gymId) return sendError(res, 'Customer not found', 404);

    let assigned;
    if (!plan.customerId || plan.customerId === customer.id) {
      assigned = await prisma.workoutPlan.update({
        where: { id: plan.id },
        data: { customerId: customer.id },
        include: workoutPlanInclude,
      });
    } else {
      assigned = await prisma.workoutPlan.create({
        data: {
          gymId: plan.gymId,
          trainerId: plan.trainerId,
          customerId: customer.id,
          name: plan.name,
          dayOfWeek: plan.dayOfWeek,
          goal: plan.goal,
          difficulty: plan.difficulty,
          durationWeeks: plan.durationWeeks,
          description: plan.description,
          exercises: {
            create: plan.exercises.map((ex, idx) => ({
              name: ex.name,
              day: ex.day,
              muscleGroup: ex.muscleGroup,
              sets: ex.sets,
              reps: ex.reps,
              weight: ex.weight,
              restTime: ex.restTime,
              instructions: ex.instructions,
              imageUrl: ex.imageUrl,
              videoUrl: ex.videoUrl,
              orderIndex: idx,
            })),
          },
        },
        include: workoutPlanInclude,
      });
    }

    await createNotification({
      userId: customer.userId,
      gymId: req.gymId,
      type: 'WORKOUT_ASSIGNED',
      title: 'Workout Plan Assigned',
      message: `Workout plan "${assigned.name}" has been assigned to you.`,
      data: { workoutPlanId: assigned.id },
    });

    return sendSuccess(res, formatWorkoutPlan(assigned), 'Workout plan assigned to customer');
  } catch (err) {
    next(err);
  }
});

// DELETE /api/workouts/:id
router.delete('/:id', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.workoutPlan.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Workout plan not found', 404);

    await prisma.workoutPlan.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'Workout plan deleted');
  } catch (err) {
    next(err);
  }
});

// POST /api/workouts/:id/exercises
router.post('/:id/exercises', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const plan = await prisma.workoutPlan.findUnique({
      where: { id: req.params.id },
      include: { exercises: true },
    });
    if (!plan || plan.gymId !== req.gymId) return sendError(res, 'Workout plan not found', 404);

    const exInput = buildExercisesInput([req.body], plan.dayOfWeek)[0];
    exInput.orderIndex = req.body.orderIndex != null ? parseInt(req.body.orderIndex, 10) : plan.exercises.length;

    const exercise = await prisma.exercise.create({
      data: {
        ...exInput,
        workoutPlanId: plan.id,
      },
    });

    return sendSuccess(res, exercise, 'Exercise added', 201);
  } catch (err) {
    next(err);
  }
});

// PUT /api/workouts/exercises/:exerciseId
router.put('/exercises/:exerciseId', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.exercise.findUnique({
      where: { id: req.params.exerciseId },
      include: { workoutPlan: true },
    });
    if (!existing || existing.workoutPlan.gymId !== req.gymId) return sendError(res, 'Exercise not found', 404);

    const updated = await prisma.exercise.update({
      where: { id: existing.id },
      data: {
        name: req.body.name ?? existing.name,
        day: req.body.day ?? existing.day,
        muscleGroup: req.body.muscleGroup ? normalizeMuscleGroup(req.body.muscleGroup) : existing.muscleGroup,
        sets: req.body.sets != null ? parseInt(req.body.sets, 10) : existing.sets,
        reps: req.body.reps != null ? String(req.body.reps) : existing.reps,
        weight: req.body.weight !== undefined ? String(req.body.weight) : existing.weight,
        restTime: req.body.restTime != null || req.body.restSeconds != null
          ? parseInt(req.body.restTime ?? req.body.restSeconds, 10)
          : existing.restTime,
        instructions: req.body.instructions !== undefined ? req.body.instructions : existing.instructions,
        imageUrl: req.body.imageUrl !== undefined ? req.body.imageUrl : existing.imageUrl,
        videoUrl: req.body.videoUrl !== undefined ? req.body.videoUrl : existing.videoUrl,
        orderIndex: req.body.orderIndex != null ? parseInt(req.body.orderIndex, 10) : existing.orderIndex,
      },
    });

    return sendSuccess(res, updated, 'Exercise updated');
  } catch (err) {
    next(err);
  }
});

// DELETE /api/workouts/exercises/:exerciseId
router.delete('/exercises/:exerciseId', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.exercise.findUnique({
      where: { id: req.params.exerciseId },
      include: { workoutPlan: true },
    });
    if (!existing || existing.workoutPlan.gymId !== req.gymId) return sendError(res, 'Exercise not found', 404);

    await prisma.exercise.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'Exercise deleted');
  } catch (err) {
    next(err);
  }
});

module.exports = router;

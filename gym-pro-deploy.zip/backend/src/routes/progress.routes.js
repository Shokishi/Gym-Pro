const express = require('express');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { upload, getUploadedFileUrl } = require('../middleware/upload');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const { calculateBMI, formatCustomer } = require('../utils/json');
const { createAuditLog } = require('../utils/audit');

const router = express.Router();

router.use(authenticate, requireGymAccess());

const formatProgress = (p) => ({
  ...p,
  muscleMass: p.muscleMass ?? null,
  chestCm: p.chest ?? null,
  waistCm: p.waist ?? null,
  hipsCm: p.hips ?? null,
  bicepsCm: p.biceps ?? null,
  thighsCm: p.thighs ?? null,
  recordedAt: p.date,
  customer: p.customer ? formatCustomer(p.customer) : null,
});

// GET /api/progress/me (Customer)
router.get('/me', authorize('CUSTOMER'), async (req, res, next) => {
  try {
    const customer = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
    if (!customer) return sendError(res, 'Customer profile not found', 404);

    const { limit = 50 } = req.query;
    const records = await prisma.fitnessProgress.findMany({
      where: { gymId: customer.gymId, customerId: customer.id },
      orderBy: { date: 'desc' },
      take: parseInt(limit, 10) || 50,
    });

    return sendSuccess(res, records.map(formatProgress), 'My fitness progress fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/progress/customer/:id
router.get('/customer/:id', async (req, res, next) => {
  try {
    const customer = await prisma.customerProfile.findUnique({ where: { id: req.params.id } });
    if (!customer || customer.gymId !== req.gymId) return sendError(res, 'Customer not found', 404);

    if (req.user.role === 'CUSTOMER' && customer.userId !== req.user.id) {
      return sendError(res, 'Access denied', 403);
    }

    const { page, limit, skip } = getPagination(req.query);
    const [records, total] = await Promise.all([
      prisma.fitnessProgress.findMany({
        where: { gymId: req.gymId, customerId: customer.id },
        orderBy: { date: 'desc' },
        skip,
        take: limit,
      }),
      prisma.fitnessProgress.count({ where: { gymId: req.gymId, customerId: customer.id } }),
    ]);

    return sendSuccess(
      res,
      formatPaginatedData(records.map(formatProgress), total, page, limit),
      'Customer fitness progress fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/progress/chart/:id
router.get('/chart/:id', async (req, res, next) => {
  try {
    const customer = await prisma.customerProfile.findUnique({ where: { id: req.params.id } });
    if (!customer || customer.gymId !== req.gymId) return sendError(res, 'Customer not found', 404);

    if (req.user.role === 'CUSTOMER' && customer.userId !== req.user.id) {
      return sendError(res, 'Access denied', 403);
    }

    const records = await prisma.fitnessProgress.findMany({
      where: { gymId: req.gymId, customerId: customer.id },
      orderBy: { date: 'asc' },
      take: 30,
    });

    return sendSuccess(res, records.map(formatProgress), 'Progress chart data fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/progress
router.get('/', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { page, limit, skip } = getPagination(req.query);
    const where = { gymId };

    if (req.user.role === 'CUSTOMER') {
      const cust = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
      if (!cust) return sendSuccess(res, formatPaginatedData([], 0, page, limit));
      where.customerId = cust.id;
    } else if (req.query.customerId) {
      where.customerId = req.query.customerId;
    }

    const [records, total] = await Promise.all([
      prisma.fitnessProgress.findMany({
        where,
        skip,
        take: limit,
        orderBy: { date: 'desc' },
        include: { customer: { include: { user: true } } },
      }),
      prisma.fitnessProgress.count({ where }),
    ]);

    return sendSuccess(
      res,
      formatPaginatedData(records.map(formatProgress), total, page, limit),
      'Progress records fetched'
    );
  } catch (err) {
    next(err);
  }
});

// POST /api/progress
router.post('/', upload.single('progressPhoto'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    let customerId = req.body.customerId;
    if (req.user.role === 'CUSTOMER') {
      const cust = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
      if (!cust) return sendError(res, 'Customer profile not found', 404);
      customerId = cust.id;
    }
    if (!customerId) return sendError(res, 'customerId is required', 400);

    const customer = await prisma.customerProfile.findUnique({ where: { id: customerId } });
    if (!customer || customer.gymId !== gymId) return sendError(res, 'Customer not found in gym', 404);

    const toNum = (v) => (v !== undefined && v !== null && v !== '' ? parseFloat(v) : null);
    const weight = toNum(req.body.weight);
    const height = toNum(req.body.height) ?? customer.heightCm ?? null;
    const bmi = toNum(req.body.bmi) ?? (weight && height ? calculateBMI(weight, height) : null);

    const progressPhoto = req.file
      ? getUploadedFileUrl(req.file)
      : req.body.progressPhoto || null;

    const record = await prisma.fitnessProgress.create({
      data: {
        customerId: customer.id,
        gymId,
        date: req.body.date || req.body.recordedAt ? new Date(req.body.date || req.body.recordedAt) : new Date(),
        weight,
        height,
        bmi,
        bodyFat: toNum(req.body.bodyFat),
        muscleMass: toNum(req.body.muscleMass),
        chest: toNum(req.body.chest ?? req.body.chestCm),
        waist: toNum(req.body.waist ?? req.body.waistCm),
        hips: toNum(req.body.hips ?? req.body.hipsCm),
        biceps: toNum(req.body.biceps ?? req.body.bicepsCm),
        thighs: toNum(req.body.thighs ?? req.body.thighsCm),
        progressPhoto,
        notes: req.body.notes || null,
        measuredBy: req.user.id,
      },
      include: { customer: { include: { user: true } } },
    });

    if (weight != null || height != null) {
      await prisma.customerProfile.update({
        where: { id: customer.id },
        data: {
          ...(weight != null ? { weightKg: weight } : {}),
          ...(height != null ? { heightCm: height } : {}),
        },
      });
    }

    await createAuditLog({
      userId: req.user.id,
      gymId,
      action: 'PROGRESS_RECORDED',
      entity: 'FitnessProgress',
      entityId: record.id,
      details: { customerId: customer.id, weight, bmi },
      ipAddress: req.ip,
    });

    return sendSuccess(res, formatProgress(record), 'Fitness progress recorded', 201);
  } catch (err) {
    next(err);
  }
});

// PUT /api/progress/:id
router.put('/:id', authorize('GYM_OWNER', 'TRAINER', 'CUSTOMER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.fitnessProgress.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Progress record not found', 404);

    if (req.user.role === 'CUSTOMER') {
      const cust = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
      if (!cust || existing.customerId !== cust.id) return sendError(res, 'Access denied', 403);
    }

    const toNum = (v, fallback) =>
      v !== undefined ? (v !== null && v !== '' ? parseFloat(v) : null) : fallback;

    const weight = toNum(req.body.weight, existing.weight);
    const height = toNum(req.body.height, existing.height);
    const bmi =
      req.body.bmi !== undefined
        ? toNum(req.body.bmi, existing.bmi)
        : weight && height
        ? calculateBMI(weight, height)
        : existing.bmi;

    const updated = await prisma.fitnessProgress.update({
      where: { id: existing.id },
      data: {
        date: req.body.date || req.body.recordedAt ? new Date(req.body.date || req.body.recordedAt) : existing.date,
        weight,
        height,
        bmi,
        bodyFat: toNum(req.body.bodyFat, existing.bodyFat),
        muscleMass: toNum(req.body.muscleMass, existing.muscleMass),
        chest: toNum(req.body.chest ?? req.body.chestCm, existing.chest),
        waist: toNum(req.body.waist ?? req.body.waistCm, existing.waist),
        hips: toNum(req.body.hips ?? req.body.hipsCm, existing.hips),
        biceps: toNum(req.body.biceps ?? req.body.bicepsCm, existing.biceps),
        thighs: toNum(req.body.thighs ?? req.body.thighsCm, existing.thighs),
        notes: req.body.notes !== undefined ? req.body.notes : existing.notes,
      },
      include: { customer: { include: { user: true } } },
    });

    return sendSuccess(res, formatProgress(updated), 'Fitness progress updated');
  } catch (err) {
    next(err);
  }
});

// DELETE /api/progress/:id
router.delete('/:id', authorize('GYM_OWNER', 'TRAINER', 'CUSTOMER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.fitnessProgress.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Progress record not found', 404);

    if (req.user.role === 'CUSTOMER') {
      const cust = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
      if (!cust || existing.customerId !== cust.id) return sendError(res, 'Access denied', 403);
    }

    await prisma.fitnessProgress.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'Progress record deleted');
  } catch (err) {
    next(err);
  }
});

module.exports = router;

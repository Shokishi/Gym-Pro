const express = require('express');
const bcrypt = require('bcryptjs');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const { formatTrainer } = require('../utils/json');
const { createAuditLog } = require('../utils/audit');
const { createNotification } = require('../utils/notification');

const router = express.Router();

router.use(authenticate, requireGymAccess());

const parseMonthYear = (monthVal, yearVal) => {
  const now = new Date();
  if (typeof monthVal === 'string' && monthVal.includes('-')) {
    const [yStr, mStr] = monthVal.split('-');
    const y = parseInt(yStr, 10);
    const m = parseInt(mStr, 10);
    if (Number.isFinite(y) && Number.isFinite(m) && m >= 1 && m <= 12) {
      return { month: m, year: y };
    }
  }
  const month = parseInt(monthVal, 10) || now.getMonth() + 1;
  const year = parseInt(yearVal, 10) || now.getFullYear();
  return { month, year };
};

const formatSalary = (s) => ({
  ...s,
  monthLabel: `${s.year}-${String(s.month).padStart(2, '0')}`,
  netAmount: s.totalAmount,
  trainer: s.trainer ? formatTrainer(s.trainer) : null,
  trainerName: s.trainer?.user?.fullName || null,
});

// GET /api/salaries/report
router.get('/report', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { year, month } = parseMonthYear(req.query.month, req.query.year || new Date().getFullYear());
    const where = { gymId, year };
    if (req.query.month) where.month = month;

    const salaries = await prisma.salary.findMany({
      where,
      include: { trainer: { include: { user: true } } },
      orderBy: [{ month: 'asc' }],
    });

    const summary = salaries.reduce(
      (acc, s) => {
        acc.totalPayroll += s.totalAmount;
        if (s.status === 'PAID') acc.totalPaid += s.totalAmount;
        else acc.totalPending += s.totalAmount;
        return acc;
      },
      { totalPayroll: 0, totalPaid: 0, totalPending: 0 }
    );

    return sendSuccess(res, { summary, records: salaries.map(formatSalary) }, 'Salary report fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/salaries
router.get('/', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { page, limit, skip } = getPagination(req.query);
    const where = { gymId };

    if (req.user.role === 'TRAINER') {
      const tr = await prisma.trainerProfile.findUnique({ where: { userId: req.user.id } });
      if (!tr) return sendSuccess(res, formatPaginatedData([], 0, page, limit));
      where.trainerId = tr.id;
    } else if (req.query.trainerId) {
      where.trainerId = req.query.trainerId;
    }

    if (req.query.status) where.status = String(req.query.status).toUpperCase();
    if (req.query.month) {
      const parsed = parseMonthYear(req.query.month, req.query.year);
      where.month = parsed.month;
      if (typeof req.query.month === 'string' && req.query.month.includes('-')) {
        where.year = parsed.year;
      }
    }
    if (req.query.year && !where.year) where.year = parseInt(req.query.year, 10);

    const [salaries, total] = await Promise.all([
      prisma.salary.findMany({
        where,
        skip,
        take: limit,
        orderBy: [{ year: 'desc' }, { month: 'desc' }, { createdAt: 'desc' }],
        include: { trainer: { include: { user: true } } },
      }),
      prisma.salary.count({ where }),
    ]);

    return sendSuccess(
      res,
      formatPaginatedData(salaries.map(formatSalary), total, page, limit),
      'Salaries fetched'
    );
  } catch (err) {
    next(err);
  }
});

// POST /api/salaries/generate
router.post('/generate', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { month, year } = parseMonthYear(req.body.month, req.body.year);

    const trainers = await prisma.trainerProfile.findMany({
      where: { gymId, isActive: true },
      include: { user: true },
    });

    const existing = await prisma.salary.findMany({
      where: { gymId, month, year },
      select: { trainerId: true },
    });
    const existingSet = new Set(existing.map((e) => e.trainerId));

    const created = [];
    for (const trainer of trainers) {
      if (existingSet.has(trainer.id)) continue;
      const baseSalary = Number(trainer.salary || 0);
      const commission = 0;
      const bonus = 0;
      const deductions = 0;
      const totalAmount = Math.max(0, baseSalary + commission + bonus - deductions);

      const rec = await prisma.salary.create({
        data: {
          gymId,
          trainerId: trainer.id,
          month,
          year,
          baseSalary,
          commission,
          bonus,
          deductions,
          totalAmount,
          status: 'PENDING',
          notes: req.body.notes || `Auto-generated payroll for ${year}-${String(month).padStart(2, '0')}`,
        },
        include: { trainer: { include: { user: true } } },
      });
      created.push(formatSalary(rec));
    }

    await createAuditLog({
      userId: req.user.id,
      gymId,
      action: 'PAYROLL_GENERATED',
      entity: 'Salary',
      details: { month, year, generatedCount: created.length },
      ipAddress: req.ip,
    });

    return sendSuccess(res, { generatedCount: created.length, records: created }, 'Payroll generated', 201);
  } catch (err) {
    next(err);
  }
});

// POST /api/salaries
router.post(
  '/',
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  [
    body('trainerId').notEmpty().withMessage('trainerId is required'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const trainer = await prisma.trainerProfile.findUnique({ where: { id: req.body.trainerId } });
      if (!trainer || trainer.gymId !== gymId) return sendError(res, 'Trainer not found in gym', 404);

      const { month, year } = parseMonthYear(req.body.month, req.body.year);
      const baseSalary = parseFloat(req.body.baseSalary ?? trainer.salary ?? 0) || 0;
      const commission = parseFloat(req.body.commission ?? 0) || 0;
      const bonus = parseFloat(req.body.bonus ?? 0) || 0;
      const deductions = parseFloat(req.body.deductions ?? 0) || 0;
      const totalAmount =
        req.body.netAmount != null || req.body.totalAmount != null
          ? parseFloat(req.body.netAmount ?? req.body.totalAmount)
          : Math.max(0, baseSalary + commission + bonus - deductions);

      const salary = await prisma.salary.create({
        data: {
          gymId,
          trainerId: trainer.id,
          month,
          year,
          baseSalary,
          commission,
          bonus,
          deductions,
          totalAmount,
          status: req.body.status === 'PAID' ? 'PAID' : 'PENDING',
          paidAt: req.body.status === 'PAID' ? new Date() : null,
          notes: req.body.notes || null,
        },
        include: { trainer: { include: { user: true } } },
      });

      return sendSuccess(res, formatSalary(salary), 'Salary record created', 201);
    } catch (err) {
      next(err);
    }
  }
);

// PUT /api/salaries/:id
router.put('/:id', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.salary.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Salary record not found', 404);

    const baseSalary = req.body.baseSalary != null ? parseFloat(req.body.baseSalary) : existing.baseSalary;
    const commission = req.body.commission != null ? parseFloat(req.body.commission) : existing.commission;
    const bonus = req.body.bonus != null ? parseFloat(req.body.bonus) : existing.bonus;
    const deductions = req.body.deductions != null ? parseFloat(req.body.deductions) : existing.deductions;
    const totalAmount =
      req.body.netAmount != null || req.body.totalAmount != null
        ? parseFloat(req.body.netAmount ?? req.body.totalAmount)
        : Math.max(0, baseSalary + commission + bonus - deductions);

    const updated = await prisma.salary.update({
      where: { id: existing.id },
      data: {
        baseSalary,
        commission,
        bonus,
        deductions,
        totalAmount,
        notes: req.body.notes !== undefined ? req.body.notes : existing.notes,
      },
      include: { trainer: { include: { user: true } } },
    });

    return sendSuccess(res, formatSalary(updated), 'Salary record updated');
  } catch (err) {
    next(err);
  }
});

const markSalaryPaidHandler = async (req, res, next) => {
  try {
    const existing = await prisma.salary.findUnique({
      where: { id: req.params.id },
      include: { trainer: { include: { user: true } } },
    });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Salary record not found', 404);

    const updated = await prisma.salary.update({
      where: { id: existing.id },
      data: {
        status: 'PAID',
        paidAt: new Date(),
        notes: req.body.notes || existing.notes,
      },
      include: { trainer: { include: { user: true } } },
    });

    if (existing.trainer?.userId) {
      await createNotification({
        userId: existing.trainer.userId,
        gymId: req.gymId,
        type: 'SALARY_PAID',
        title: 'Salary Paid',
        message: `Your salary of ₹${updated.totalAmount.toLocaleString('en-IN')} for ${updated.year}-${String(updated.month).padStart(2, '0')} has been paid.`,
        data: { salaryId: updated.id },
      });
    }

    await createAuditLog({
      userId: req.user.id,
      gymId: req.gymId,
      action: 'SALARY_PAID',
      entity: 'Salary',
      entityId: updated.id,
      details: { amount: updated.totalAmount, trainerId: updated.trainerId },
      ipAddress: req.ip,
    });

    return sendSuccess(res, formatSalary(updated), 'Salary marked as paid');
  } catch (err) {
    next(err);
  }
};

router.patch('/:id/pay', authorize('GYM_OWNER', 'SUPER_ADMIN'), markSalaryPaidHandler);
router.put('/:id/pay', authorize('GYM_OWNER', 'SUPER_ADMIN'), markSalaryPaidHandler);

// DELETE /api/salaries/:id
router.delete('/:id', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.salary.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Salary record not found', 404);

    await prisma.salary.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'Salary record deleted');
  } catch (err) {
    next(err);
  }
});

module.exports = router;

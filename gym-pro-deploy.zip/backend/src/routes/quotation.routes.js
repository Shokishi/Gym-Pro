const express = require('express');
const bcrypt = require('bcryptjs');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const {
  generateReadableId,
  parseJson,
  stringifyJson,
  canonicalMobile,
  normalizeMobileCandidates,
  formatCustomer,
} = require('../utils/json');
const { createAuditLog } = require('../utils/audit');
const { generateQuotationPDF } = require('../utils/pdfGenerator');

const router = express.Router();

router.use(authenticate, requireGymAccess(), authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'));

const VALID_STATUSES = new Set(['DRAFT', 'SENT', 'ACCEPTED', 'REJECTED', 'EXPIRED']);

const formatQuotation = (q) => ({
  ...q,
  items: parseJson(q.items, []),
  customerName: q.customerName || q.customer?.user?.fullName || '',
  customerPhone: q.customerPhone || q.customer?.user?.mobile || '',
  customerEmail: q.customerEmail || q.customer?.user?.email || '',
  validUntil: q.expiryDate,
  notes: q.termsAndConditions || '',
  totalAmount: q.total,
  customer: q.customer ? formatCustomer(q.customer) : null,
});

const quotationInclude = {
  customer: { include: { user: true } },
  gym: true,
};

// GET /api/quotations
router.get('/', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { page, limit, skip } = getPagination(req.query);
    const { status, search } = req.query;

    const where = { gymId };
    if (status) where.status = String(status).toUpperCase();
    if (search) {
      where.OR = [
        { quotationNumber: { contains: search } },
        { customerName: { contains: search } },
        { customerPhone: { contains: search } },
        { customer: { user: { fullName: { contains: search } } } },
      ];
    }

    const [quotations, total] = await Promise.all([
      prisma.quotation.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: { customer: { include: { user: true } } },
      }),
      prisma.quotation.count({ where }),
    ]);

    return sendSuccess(
      res,
      formatPaginatedData(quotations.map(formatQuotation), total, page, limit),
      'Quotations fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/quotations/:id/pdf
router.get('/:id/pdf', async (req, res, next) => {
  try {
    const quotation = await prisma.quotation.findUnique({
      where: { id: req.params.id },
      include: quotationInclude,
    });
    if (!quotation || quotation.gymId !== req.gymId) return sendError(res, 'Quotation not found', 404);

    const fakeCustomer = quotation.customer || {
      user: {
        fullName: quotation.customerName || 'Prospective Member',
        mobile: quotation.customerPhone || '',
        email: quotation.customerEmail || '',
      },
    };

    const pdfBuffer = generateQuotationPDF(
      { ...quotation, items: parseJson(quotation.items, []) },
      quotation.gym,
      fakeCustomer
    );

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="Quotation-${quotation.quotationNumber}.pdf"`);
    return res.send(pdfBuffer);
  } catch (err) {
    next(err);
  }
});

// GET /api/quotations/:id
router.get('/:id', async (req, res, next) => {
  try {
    const quotation = await prisma.quotation.findUnique({
      where: { id: req.params.id },
      include: quotationInclude,
    });
    if (!quotation || quotation.gymId !== req.gymId) return sendError(res, 'Quotation not found', 404);

    return sendSuccess(res, formatQuotation(quotation), 'Quotation fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/quotations
router.post('/', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const {
      customerId,
      customerName,
      customerPhone,
      customerEmail,
      items = [],
      subtotal,
      discount = 0,
      tax = 0,
      total,
      totalAmount,
      status = 'DRAFT',
      termsAndConditions,
      notes,
      expiryDate,
      validUntil,
    } = req.body;

    let resolvedCustomer = null;
    if (customerId) {
      resolvedCustomer = await prisma.customerProfile.findUnique({
        where: { id: customerId },
        include: { user: true },
      });
      if (!resolvedCustomer || resolvedCustomer.gymId !== gymId) {
        return sendError(res, 'Customer not found in gym', 404);
      }
    }

    const parsedItems = Array.isArray(items) ? items : [];
    const computedSubtotal =
      subtotal != null
        ? parseFloat(subtotal)
        : parsedItems.reduce(
            (sum, it) => sum + (parseFloat(it.amount ?? it.price ?? 0) * (parseInt(it.quantity ?? 1, 10) || 1)),
            0
          );
    const numDiscount = parseFloat(discount) || 0;
    const numTax = parseFloat(tax) || 0;
    const computedTotal =
      total != null || totalAmount != null
        ? parseFloat(total ?? totalAmount)
        : Math.max(0, computedSubtotal - numDiscount + numTax);

    const quotation = await prisma.quotation.create({
      data: {
        gymId,
        customerId: resolvedCustomer?.id || null,
        customerName: customerName || resolvedCustomer?.user?.fullName || null,
        customerPhone: customerPhone || resolvedCustomer?.user?.mobile || null,
        customerEmail: customerEmail || resolvedCustomer?.user?.email || null,
        quotationNumber: generateReadableId('QT'),
        items: stringifyJson(parsedItems),
        subtotal: computedSubtotal || computedTotal,
        discount: numDiscount,
        tax: numTax,
        total: computedTotal,
        status: VALID_STATUSES.has(String(status).toUpperCase()) ? String(status).toUpperCase() : 'DRAFT',
        termsAndConditions: termsAndConditions || notes || null,
        expiryDate: expiryDate || validUntil ? new Date(expiryDate || validUntil) : new Date(Date.now() + 14 * 86400000),
      },
      include: quotationInclude,
    });

    await createAuditLog({
      userId: req.user.id,
      gymId,
      action: 'QUOTATION_CREATED',
      entity: 'Quotation',
      entityId: quotation.id,
      details: { quotationNumber: quotation.quotationNumber, total: quotation.total },
      ipAddress: req.ip,
    });

    return sendSuccess(res, formatQuotation(quotation), 'Quotation created', 201);
  } catch (err) {
    next(err);
  }
});

// PUT /api/quotations/:id
router.put('/:id', async (req, res, next) => {
  try {
    const existing = await prisma.quotation.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Quotation not found', 404);

    const items = Array.isArray(req.body.items) ? req.body.items : parseJson(existing.items, []);
    const subtotal = req.body.subtotal != null ? parseFloat(req.body.subtotal) : existing.subtotal;
    const discount = req.body.discount != null ? parseFloat(req.body.discount) : existing.discount;
    const tax = req.body.tax != null ? parseFloat(req.body.tax) : existing.tax;
    const total =
      req.body.total != null || req.body.totalAmount != null
        ? parseFloat(req.body.total ?? req.body.totalAmount)
        : Math.max(0, subtotal - discount + tax);

    const updated = await prisma.quotation.update({
      where: { id: existing.id },
      data: {
        customerId: req.body.customerId !== undefined ? req.body.customerId || null : existing.customerId,
        customerName: req.body.customerName !== undefined ? req.body.customerName : existing.customerName,
        customerPhone: req.body.customerPhone !== undefined ? req.body.customerPhone : existing.customerPhone,
        customerEmail: req.body.customerEmail !== undefined ? req.body.customerEmail : existing.customerEmail,
        items: stringifyJson(items),
        subtotal,
        discount,
        tax,
        total,
        status:
          req.body.status && VALID_STATUSES.has(String(req.body.status).toUpperCase())
            ? String(req.body.status).toUpperCase()
            : existing.status,
        termsAndConditions:
          req.body.termsAndConditions !== undefined || req.body.notes !== undefined
            ? req.body.termsAndConditions ?? req.body.notes
            : existing.termsAndConditions,
        expiryDate:
          req.body.expiryDate || req.body.validUntil
            ? new Date(req.body.expiryDate || req.body.validUntil)
            : existing.expiryDate,
      },
      include: quotationInclude,
    });

    return sendSuccess(res, formatQuotation(updated), 'Quotation updated');
  } catch (err) {
    next(err);
  }
});

// PATCH /api/quotations/:id/status
router.patch('/:id/status', async (req, res, next) => {
  try {
    const existing = await prisma.quotation.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Quotation not found', 404);

    const nextStatus = String(req.body.status || '').toUpperCase();
    if (!VALID_STATUSES.has(nextStatus)) {
      return sendError(res, 'Invalid quotation status', 400);
    }

    const updated = await prisma.quotation.update({
      where: { id: existing.id },
      data: { status: nextStatus },
      include: quotationInclude,
    });

    return sendSuccess(res, formatQuotation(updated), 'Quotation status updated');
  } catch (err) {
    next(err);
  }
});

const convertQuotationHandler = async (req, res, next) => {
  try {
    const quotation = await prisma.quotation.findUnique({
      where: { id: req.params.id },
      include: { customer: { include: { user: true } } },
    });
    if (!quotation || quotation.gymId !== req.gymId) return sendError(res, 'Quotation not found', 404);

    const result = await prisma.$transaction(async (tx) => {
      let customerId = req.body.customerId || quotation.customerId;

      if (!customerId && quotation.customerPhone) {
        const mob = canonicalMobile(quotation.customerPhone);
        const existingUser = await tx.user.findFirst({
          where: { mobile: { in: normalizeMobileCandidates(mob) } },
          include: { customerProfile: true },
        });
        if (existingUser?.customerProfile && existingUser.customerProfile.gymId === quotation.gymId) {
          customerId = existingUser.customerProfile.id;
        } else if (!existingUser) {
          const passwordHash = await bcrypt.hash('Password@123', 10);
          const newUser = await tx.user.create({
            data: {
              fullName: quotation.customerName || 'Walk-in Member',
              mobile: mob,
              email: quotation.customerEmail || null,
              password: passwordHash,
              role: 'CUSTOMER',
              isActive: true,
              isVerified: true,
              mobileVerified: true,
            },
          });
          const newCust = await tx.customerProfile.create({
            data: {
              userId: newUser.id,
              gymId: quotation.gymId,
              customerId: generateReadableId('CUST'),
              isActive: true,
            },
          });
          customerId = newCust.id;
        }
      }

      if (!customerId) {
        const firstCustomer = await tx.customerProfile.findFirst({
          where: { gymId: quotation.gymId },
          orderBy: { createdAt: 'asc' },
        });
        if (!firstCustomer) {
          throw new Error('Cannot convert quotation without a linked customer or phone number');
        }
        customerId = firstCustomer.id;
      }

      let membership = null;
      if (req.body.planId) {
        const plan = await tx.membershipPlan.findUnique({ where: { id: req.body.planId } });
        if (plan && plan.gymId === quotation.gymId) {
          const start = new Date();
          const end = new Date(start.getTime() + plan.durationDays * 86400000);
          membership = await tx.customerMembership.create({
            data: {
              customerId,
              planId: plan.id,
              gymId: quotation.gymId,
              startDate: start,
              endDate: end,
              status: 'ACTIVE',
              purchasePrice: plan.price,
              joiningFee: plan.joiningFee || 0,
              discount: quotation.discount || 0,
              tax: quotation.tax || 0,
              totalPaid: 0,
            },
          });
        }
      }

      const invoice = await tx.invoice.create({
        data: {
          gymId: quotation.gymId,
          customerId,
          membershipId: membership?.id || null,
          invoiceNumber: generateReadableId('INV'),
          items: quotation.items,
          subtotal: quotation.subtotal,
          discount: quotation.discount,
          tax: quotation.tax,
          total: quotation.total,
          status: 'UNPAID',
          paidAmount: 0,
          dueDate: new Date(Date.now() + 7 * 86400000),
        },
        include: { customer: { include: { user: true } } },
      });

      const updatedQuotation = await tx.quotation.update({
        where: { id: quotation.id },
        data: { status: 'ACCEPTED', customerId },
        include: quotationInclude,
      });

      return { quotation: updatedQuotation, invoice, membership };
    });

    await createAuditLog({
      userId: req.user.id,
      gymId: req.gymId,
      action: 'QUOTATION_CONVERTED',
      entity: 'Quotation',
      entityId: quotation.id,
      details: { invoiceId: result.invoice.id, invoiceNumber: result.invoice.invoiceNumber },
      ipAddress: req.ip,
    });

    return sendSuccess(
      res,
      {
        quotation: formatQuotation(result.quotation),
        invoice: {
          ...result.invoice,
          items: parseJson(result.invoice.items, []),
          totalAmount: result.invoice.total,
        },
        membership: result.membership,
      },
      'Quotation converted to invoice',
      201
    );
  } catch (err) {
    if (err.message?.includes('Cannot convert quotation')) {
      return sendError(res, err.message, 400);
    }
    next(err);
  }
};

router.post('/:id/convert', convertQuotationHandler);
router.put('/:id/convert', convertQuotationHandler);

// DELETE /api/quotations/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const existing = await prisma.quotation.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Quotation not found', 404);

    await prisma.quotation.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'Quotation deleted');
  } catch (err) {
    next(err);
  }
});

module.exports = router;

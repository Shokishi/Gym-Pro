const express = require('express');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const { parseJson } = require('../utils/json');
const { createNotification } = require('../utils/notification');

const router = express.Router();

router.use(authenticate);

const normalizeTargetRole = (val) => {
  const upper = String(val || 'ALL').trim().toUpperCase();
  if (upper === 'CUSTOMERS' || upper === 'MEMBERS') return 'CUSTOMER';
  if (upper === 'TRAINERS') return 'TRAINER';
  if (upper === 'OWNERS' || upper === 'GYM_OWNERS') return 'GYM_OWNER';
  return upper;
};

const formatNotification = (n) => {
  const data = parseJson(n.data, {});
  return {
    ...n,
    data,
    read: Boolean(n.isRead),
    audience: data?.targetRole || 'USER',
  };
};

// Mark all as read (both PATCH and PUT)
const markAllReadHandler = async (req, res, next) => {
  try {
    const result = await prisma.notification.updateMany({
      where: { userId: req.user.id, isRead: false },
      data: { isRead: true },
    });

    return sendSuccess(res, { updatedCount: result.count }, 'All notifications marked as read');
  } catch (err) {
    next(err);
  }
};

router.patch('/read-all', markAllReadHandler);
router.put('/read-all', markAllReadHandler);

// Send notifications (both POST / and POST /send)
const sendNotificationHandler = async (req, res, next) => {
  try {
    const {
      userIds,
      targetRole,
      audience,
      targetAudience,
      gymId: bodyGymId,
      type = 'ANNOUNCEMENT',
      title,
      message,
      data = {},
    } = req.body;

    const normalizedRole = normalizeTargetRole(targetRole || audience || targetAudience);

    let resolvedGymId = bodyGymId || null;
    if (req.user.role === 'GYM_OWNER') {
      const gym = await prisma.gym.findFirst({ where: { ownerId: req.user.id } });
      if (!gym) return sendError(res, 'Gym not found for this owner', 404);
      resolvedGymId = gym.id;
    }

    let recipientIds = [];

    if (Array.isArray(userIds) && userIds.length > 0) {
      if (req.user.role === 'GYM_OWNER') {
        const [customers, trainers] = await Promise.all([
          prisma.customerProfile.findMany({
            where: { gymId: resolvedGymId, userId: { in: userIds } },
            select: { userId: true },
          }),
          prisma.trainerProfile.findMany({
            where: { gymId: resolvedGymId, userId: { in: userIds } },
            select: { userId: true },
          }),
        ]);
        recipientIds = [...new Set([...customers.map((c) => c.userId), ...trainers.map((t) => t.userId)])];
      } else {
        recipientIds = userIds;
      }
    } else if (resolvedGymId) {
      const includeCustomers = normalizedRole === 'ALL' || normalizedRole === 'CUSTOMER';
      const includeTrainers = normalizedRole === 'ALL' || normalizedRole === 'TRAINER';

      const [customers, trainers] = await Promise.all([
        includeCustomers
          ? prisma.customerProfile.findMany({
              where: { gymId: resolvedGymId, isActive: true },
              select: { userId: true },
            })
          : [],
        includeTrainers
          ? prisma.trainerProfile.findMany({
              where: { gymId: resolvedGymId, isActive: true },
              select: { userId: true },
            })
          : [],
      ]);
      recipientIds = [...new Set([...customers.map((c) => c.userId), ...trainers.map((t) => t.userId)])];
    } else if (req.user.role === 'SUPER_ADMIN') {
      const where = { isActive: true };
      if (normalizedRole && normalizedRole !== 'ALL') where.role = normalizedRole;
      const users = await prisma.user.findMany({ where, select: { id: true } });
      recipientIds = users.map((u) => u.id);
    }

    if (recipientIds.length === 0) {
      return sendError(res, 'No eligible recipients found', 400);
    }

    const io = req.app.get('io');
    const created = [];
    for (const uid of recipientIds) {
      const n = await createNotification({
        userId: uid,
        gymId: resolvedGymId,
        type,
        title,
        message,
        data: { ...data, targetRole: normalizedRole, sentBy: req.user.id },
        io,
      });
      if (n) created.push(formatNotification(n));
    }

    return sendSuccess(
      res,
      { sentCount: created.length, notifications: created },
      `Notification sent to ${created.length} recipient(s)`,
      201
    );
  } catch (err) {
    next(err);
  }
};

const sendValidators = [
  body('title').trim().notEmpty().withMessage('Title is required'),
  body('message').trim().notEmpty().withMessage('Message is required'),
  validate,
];

router.post('/', authorize('SUPER_ADMIN', 'GYM_OWNER'), sendValidators, sendNotificationHandler);
router.post('/send', authorize('SUPER_ADMIN', 'GYM_OWNER'), sendValidators, sendNotificationHandler);

// GET /api/notifications
router.get('/', async (req, res, next) => {
  try {
    const { page, limit, skip } = getPagination(req.query);
    const where = { userId: req.user.id };
    if (req.query.isRead !== undefined) {
      where.isRead = req.query.isRead === 'true';
    }

    const [notifications, total, unreadCount] = await Promise.all([
      prisma.notification.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      prisma.notification.count({ where }),
      prisma.notification.count({ where: { userId: req.user.id, isRead: false } }),
    ]);

    return sendSuccess(
      res,
      {
        unreadCount,
        ...formatPaginatedData(notifications.map(formatNotification), total, page, limit),
      },
      'Notifications fetched'
    );
  } catch (err) {
    next(err);
  }
});

// Mark single read (PATCH & PUT)
const markReadHandler = async (req, res, next) => {
  try {
    const existing = await prisma.notification.findUnique({ where: { id: req.params.id } });
    if (!existing || (existing.userId !== req.user.id && req.user.role !== 'SUPER_ADMIN')) {
      return sendError(res, 'Notification not found', 404);
    }

    const updated = await prisma.notification.update({
      where: { id: existing.id },
      data: { isRead: true },
    });

    return sendSuccess(res, formatNotification(updated), 'Notification marked as read');
  } catch (err) {
    next(err);
  }
};

router.patch('/:id/read', markReadHandler);
router.put('/:id/read', markReadHandler);

// DELETE /api/notifications/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const existing = await prisma.notification.findUnique({ where: { id: req.params.id } });
    if (!existing || (existing.userId !== req.user.id && req.user.role !== 'SUPER_ADMIN' && req.user.role !== 'GYM_OWNER')) {
      return sendError(res, 'Notification not found', 404);
    }

    await prisma.notification.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'Notification deleted');
  } catch (err) {
    next(err);
  }
});

module.exports = router;

const express = require('express');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const { parseJson, stringifyJson, generateReadableId, formatCustomer } = require('../utils/json');
const { dayjs, IST_TZ } = require('../utils/date');
const { createAuditLog } = require('../utils/audit');
const { createNotification } = require('../utils/notification');
const { emitMembershipStatusChange } = require('../socket');

const router = express.Router();

router.use(authenticate, requireGymAccess());

const formatPlan = (p) => {
  const features = parseJson(p.services, []);
  return {
    ...p,
    setupFee: p.joiningFee,
    features,
    services: features,
    amount: p.price,
  };
};

const formatMembership = (m) => ({
  ...m,
  customer: m.customer ? formatCustomer(m.customer) : null,
  customerName: m.customer?.user?.fullName || '',
  plan: m.plan ? formatPlan(m.plan) : null,
  planName: m.plan?.name || '',
  amount: m.purchasePrice,
});

// ========================
// Membership Plans CRUD
// ========================

// GET /api/memberships/plans
router.get('/plans', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const where = { gymId };
    if (req.query.isActive !== undefined) {
      where.isActive = req.query.isActive === 'true';
    }

    const plans = await prisma.membershipPlan.findMany({
      where,
      orderBy: { price: 'asc' },
      include: { _count: { select: { customerMemberships: true } } },
    });

    return sendSuccess(res, plans.map(formatPlan), 'Membership plans fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/memberships/plans
router.post(
  '/plans',
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  [
    body('name').trim().notEmpty().withMessage('Plan name is required'),
    body('durationDays').isInt({ min: 1 }).withMessage('durationDays must be at least 1'),
    body('price').isFloat({ min: 0 }).withMessage('Valid price is required'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const {
        name,
        description,
        durationDays,
        price,
        joiningFee,
        setupFee = 0,
        discount = 0,
        tax = 0,
        services,
        features = [],
        planType = 'STANDARD',
        isActive = true,
      } = req.body;

      const resolvedJoining = joiningFee !== undefined ? joiningFee : setupFee;
      const resolvedFeatures = services !== undefined ? services : features;

      const plan = await prisma.membershipPlan.create({
        data: {
          gymId,
          name,
          description: description || null,
          durationDays: parseInt(durationDays, 10),
          price: Number(price),
          joiningFee: Number(resolvedJoining) || 0,
          discount: Number(discount) || 0,
          tax: Number(tax) || 0,
          services: stringifyJson(resolvedFeatures, '[]'),
          planType,
          isActive: Boolean(isActive),
        },
      });

      await createAuditLog({
        userId: req.user.id,
        gymId,
        action: 'CREATE_MEMBERSHIP_PLAN',
        entity: 'MembershipPlan',
        entityId: plan.id,
        details: { name, price },
        req,
      });

      return sendSuccess(res, formatPlan(plan), 'Membership plan created', 201);
    } catch (err) {
      next(err);
    }
  }
);

// PUT /api/memberships/plans/:id
router.put('/plans/:id', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    const existing = await prisma.membershipPlan.findUnique({ where: { id: req.params.id } });
    if (!existing || (gymId && existing.gymId !== gymId)) {
      return sendError(res, 'Membership plan not found', 404);
    }

    const {
      name,
      description,
      durationDays,
      price,
      joiningFee,
      setupFee,
      discount,
      tax,
      services,
      features,
      planType,
      isActive,
    } = req.body;

    const resolvedJoining = joiningFee !== undefined ? joiningFee : setupFee;
    const resolvedFeatures = services !== undefined ? services : features;

    // Historical CustomerMembership records preserve their purchasePrice snapshot
    const updated = await prisma.membershipPlan.update({
      where: { id: existing.id },
      data: {
        ...(name !== undefined && { name }),
        ...(description !== undefined && { description }),
        ...(durationDays !== undefined && { durationDays: parseInt(durationDays, 10) }),
        ...(price !== undefined && { price: Number(price) }),
        ...(resolvedJoining !== undefined && { joiningFee: Number(resolvedJoining) }),
        ...(discount !== undefined && { discount: Number(discount) }),
        ...(tax !== undefined && { tax: Number(tax) }),
        ...(resolvedFeatures !== undefined && { services: stringifyJson(resolvedFeatures, '[]') }),
        ...(planType !== undefined && { planType }),
        ...(isActive !== undefined && { isActive: Boolean(isActive) }),
      },
    });

    return sendSuccess(res, formatPlan(updated), 'Membership plan updated');
  } catch (err) {
    next(err);
  }
});

// DELETE /api/memberships/plans/:id
router.delete('/plans/:id', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    const existing = await prisma.membershipPlan.findUnique({ where: { id: req.params.id } });
    if (!existing || (gymId && existing.gymId !== gymId)) {
      return sendError(res, 'Membership plan not found', 404);
    }

    await prisma.membershipPlan.update({
      where: { id: existing.id },
      data: { isActive: false },
    });

    return sendSuccess(res, null, 'Membership plan deactivated');
  } catch (err) {
    next(err);
  }
});

// ========================
// Customer Self Routes BEFORE /:id
// ========================

// GET /api/memberships/me
router.get('/me', authorize('CUSTOMER'), async (req, res, next) => {
  try {
    const memberships = await prisma.customerMembership.findMany({
      where: { customerId: req.customerProfile.id },
      orderBy: { createdAt: 'desc' },
      include: { plan: true },
    });
    const formatted = memberships.map(formatMembership);
    return sendSuccess(res, formatted, 'My memberships fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/memberships/me/renew
router.post('/me/renew', authorize('CUSTOMER'), async (req, res, next) => {
  try {
    return sendError(
      res,
      'Please submit your membership payment via QR / UPI first. Your membership activates after verification.',
      400
    );
  } catch (err) {
    next(err);
  }
});

// ========================
// Customer Memberships
// ========================

// GET /api/memberships
router.get('/', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN', 'CUSTOMER'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { page, limit, skip } = getPagination(req.query);
    const { status, customerId, search } = req.query;

    const where = { gymId };
    if (status && status !== 'ALL') {
      if (status === 'EXPIRING') {
        where.status = 'ACTIVE';
        where.endDate = { gte: new Date(), lte: dayjs().add(7, 'day').toDate() };
      } else {
        where.status = status;
      }
    }
    if (req.user.role === 'CUSTOMER') {
      where.customerId = req.customerProfile.id;
    } else if (customerId) {
      where.customerId = customerId;
    }
    if (search) {
      where.OR = [
        { customer: { user: { fullName: { contains: search } } } },
        { customer: { user: { mobile: { contains: search } } } },
        { plan: { name: { contains: search } } },
      ];
    }

    const [memberships, total] = await Promise.all([
      prisma.customerMembership.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          customer: {
            include: { user: { select: { id: true, fullName: true, mobile: true, email: true, profilePhoto: true } } },
          },
          plan: true,
        },
      }),
      prisma.customerMembership.count({ where }),
    ]);

    return sendSuccess(
      res,
      formatPaginatedData(memberships.map(formatMembership), total, page, limit),
      'Memberships fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/memberships/:id
router.get('/:id', async (req, res, next) => {
  try {
    const membership = await prisma.customerMembership.findUnique({
      where: { id: req.params.id },
      include: {
        customer: { include: { user: { select: { id: true, fullName: true, mobile: true, email: true } } } },
        plan: true,
      },
    });
    if (!membership || (req.gymId && membership.gymId !== req.gymId)) {
      return sendError(res, 'Membership not found', 404);
    }
    if (req.user.role === 'CUSTOMER' && membership.customerId !== req.customerProfile.id) {
      return sendError(res, 'Access denied', 403);
    }
    return sendSuccess(res, formatMembership(membership), 'Membership retrieved');
  } catch (err) {
    next(err);
  }
});

// POST /api/memberships AND /api/memberships/assign
const assignMembershipHandler = async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const {
      customerId,
      planId,
      startDate,
      couponCode,
      paidAmount,
      amountPaid = 0,
      paymentMethod = 'CASH',
      transactionRef,
      createInvoice = true,
    } = req.body;

    const resolvedPaid = paidAmount !== undefined ? paidAmount : amountPaid;

    const [customer, plan] = await Promise.all([
      prisma.customerProfile.findUnique({
        where: { id: customerId },
        include: { user: true },
      }),
      prisma.membershipPlan.findUnique({ where: { id: planId } }),
    ]);

    if (!customer || customer.gymId !== gymId) {
      return sendError(res, 'Customer not found in this gym', 404);
    }
    if (!plan || plan.gymId !== gymId || !plan.isActive) {
      return sendError(res, 'Membership plan not found or inactive', 404);
    }

    const basePrice = Number(plan.price);
    const joiningFee = Number(plan.joiningFee || 0);
    let discount = Number(plan.discount || 0);
    let appliedCoupon = null;

    if (couponCode) {
      const coupon = await prisma.coupon.findUnique({
        where: { gymId_code: { gymId, code: couponCode.trim().toUpperCase() } },
      });
      if (!coupon || !coupon.isActive) {
        return sendError(res, 'Invalid or inactive coupon code', 400);
      }
      if (coupon.expiryDate && new Date(coupon.expiryDate) < new Date()) {
        return sendError(res, 'Coupon code has expired', 400);
      }
      if (coupon.maxUses && coupon.currentUses >= coupon.maxUses) {
        return sendError(res, 'Coupon usage limit reached', 400);
      }
      const applicable = parseJson(coupon.applicablePlans, []);
      if (applicable.length > 0 && !applicable.includes(plan.id)) {
        return sendError(res, 'Coupon is not valid for this plan', 400);
      }
      const orderAmount = basePrice + joiningFee;
      if (coupon.minOrderAmount && orderAmount < coupon.minOrderAmount) {
        return sendError(res, `Minimum order amount ₹${coupon.minOrderAmount} required for this coupon`, 400);
      }

      const couponDiscount =
        coupon.discountType === 'PERCENTAGE'
          ? (orderAmount * coupon.discountValue) / 100
          : coupon.discountValue;
      discount += couponDiscount;
      appliedCoupon = coupon;
    }

    const subtotal = basePrice + joiningFee;
    const taxableAmount = Math.max(0, subtotal - discount);
    const taxAmount = Number(((taxableAmount * Number(plan.tax || 0)) / 100).toFixed(2));
    const grandTotal = Number((taxableAmount + taxAmount).toFixed(2));
    const actualPaid = Math.min(grandTotal, Number(resolvedPaid) || 0);

    const start = startDate ? dayjs(startDate).tz(IST_TZ) : dayjs().tz(IST_TZ);
    const end = start.add(plan.durationDays, 'day');

    const result = await prisma.$transaction(async (tx) => {
      const membership = await tx.customerMembership.create({
        data: {
          customerId: customer.id,
          planId: plan.id,
          gymId,
          startDate: start.toDate(),
          endDate: end.toDate(),
          status: 'ACTIVE',
          purchasePrice: basePrice,
          joiningFee,
          discount,
          tax: taxAmount,
          totalPaid: actualPaid,
        },
        include: { plan: true },
      });

      let invoice = null;
      if (createInvoice) {
        const invoiceStatus =
          actualPaid >= grandTotal ? 'PAID' : actualPaid > 0 ? 'PARTIALLY_PAID' : 'UNPAID';
        const items = [
          { description: `${plan.name} (${plan.durationDays} days)`, quantity: 1, unitPrice: basePrice, total: basePrice },
        ];
        if (joiningFee > 0) {
          items.push({ description: 'Joining Fee', quantity: 1, unitPrice: joiningFee, total: joiningFee });
        }

        invoice = await tx.invoice.create({
          data: {
            gymId,
            customerId: customer.id,
            invoiceNumber: generateReadableId('INV'),
            membershipId: membership.id,
            items: stringifyJson(items, '[]'),
            subtotal,
            discount,
            tax: taxAmount,
            total: grandTotal,
            status: invoiceStatus,
            paidAmount: actualPaid,
            dueDate: end.toDate(),
          },
        });
      }

      let payment = null;
      if (actualPaid > 0) {
        payment = await tx.payment.create({
          data: {
            gymId,
            customerId: customer.id,
            membershipId: membership.id,
            amount: actualPaid,
            paymentMethod,
            transactionRef: transactionRef || null,
            status: 'APPROVED',
            approvedBy: req.user.id,
            approvedAt: new Date(),
            notes: `Membership assigned: ${plan.name}`,
          },
        });
      }

      if (appliedCoupon) {
        await tx.coupon.update({
          where: { id: appliedCoupon.id },
          data: { currentUses: { increment: 1 } },
        });
      }

      return { membership, invoice, payment };
    });

    const io = req.app.get('io');
    emitMembershipStatusChange(io, gymId, customer.userId, {
      membershipId: result.membership.id,
      customerId: customer.id,
      status: 'ACTIVE',
      planName: plan.name,
    });

    await createNotification({
      userId: customer.userId,
      gymId,
      type: 'MEMBERSHIP',
      title: 'Membership Activated',
      message: `Your "${plan.name}" membership is active until ${end.format('DD MMM YYYY')}.`,
      data: { membershipId: result.membership.id },
      io,
    });

    await createAuditLog({
      userId: req.user.id,
      gymId,
      action: 'ASSIGN_MEMBERSHIP',
      entity: 'CustomerMembership',
      entityId: result.membership.id,
      details: { customerId: customer.id, planId: plan.id, grandTotal, actualPaid },
      req,
    });

    return sendSuccess(res, result, 'Membership assigned successfully', 201);
  } catch (err) {
    next(err);
  }
};

const assignValidators = [
  body('customerId').notEmpty().withMessage('customerId is required'),
  body('planId').notEmpty().withMessage('planId is required'),
  validate,
];
router.post('/assign', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), assignValidators, assignMembershipHandler);
router.post('/', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), assignValidators, assignMembershipHandler);

// PUT / POST /api/memberships/:id/renew
const renewHandler = async (req, res, next) => {
  try {
    const gymId = req.gymId;
    const existing = await prisma.customerMembership.findUnique({
      where: { id: req.params.id },
      include: { plan: true, customer: { include: { user: true } } },
    });
    if (!existing || (gymId && existing.gymId !== gymId)) {
      return sendError(res, 'Membership not found', 404);
    }

    const planId = req.body.planId || existing.planId;
    const plan = await prisma.membershipPlan.findUnique({ where: { id: planId } });
    if (!plan || plan.gymId !== existing.gymId) {
      return sendError(res, 'Membership plan not found', 404);
    }

    const now = dayjs().tz(IST_TZ);
    const currentEnd = dayjs(existing.endDate).tz(IST_TZ);
    const start = currentEnd.isAfter(now) ? currentEnd : now;
    const newEnd = start.add(plan.durationDays, 'day');

    const basePrice = Number(plan.price);
    const discount = Number(req.body.discount !== undefined ? req.body.discount : plan.discount || 0);
    const taxable = Math.max(0, basePrice - discount);
    const taxAmount = Number(((taxable * Number(plan.tax || 0)) / 100).toFixed(2));
    const totalAmount = Number((taxable + taxAmount).toFixed(2));
    const paidAmount = Math.min(totalAmount, Number(req.body.paidAmount ?? req.body.amountPaid ?? 0));

    const renewed = await prisma.$transaction(async (tx) => {
      const membership = await tx.customerMembership.create({
        data: {
          customerId: existing.customerId,
          planId: plan.id,
          gymId: existing.gymId,
          startDate: start.toDate(),
          endDate: newEnd.toDate(),
          status: 'ACTIVE',
          purchasePrice: basePrice,
          joiningFee: 0,
          discount,
          tax: taxAmount,
          totalPaid: paidAmount,
        },
        include: { plan: true },
      });

      const invoice = await tx.invoice.create({
        data: {
          gymId: existing.gymId,
          customerId: existing.customerId,
          invoiceNumber: generateReadableId('INV'),
          membershipId: membership.id,
          items: stringifyJson([
            {
              description: `Renewal: ${plan.name} (${plan.durationDays} days)`,
              quantity: 1,
              unitPrice: basePrice,
              total: basePrice,
            },
          ]),
          subtotal: basePrice,
          discount,
          tax: taxAmount,
          total: totalAmount,
          status: paidAmount >= totalAmount ? 'PAID' : paidAmount > 0 ? 'PARTIALLY_PAID' : 'UNPAID',
          paidAmount,
          dueDate: newEnd.toDate(),
        },
      });

      if (paidAmount > 0) {
        await tx.payment.create({
          data: {
            gymId: existing.gymId,
            customerId: existing.customerId,
            membershipId: membership.id,
            amount: paidAmount,
            paymentMethod: req.body.paymentMethod || 'CASH',
            transactionRef: req.body.transactionRef || null,
            status: 'APPROVED',
            approvedBy: req.user.id,
            approvedAt: new Date(),
            notes: `Membership renewal: ${plan.name}`,
          },
        });
      }

      return { membership, invoice };
    });

    const io = req.app.get('io');
    emitMembershipStatusChange(io, existing.gymId, existing.customer.userId, {
      membershipId: renewed.membership.id,
      customerId: existing.customerId,
      status: 'ACTIVE',
      action: 'RENEWED',
    });

    return sendSuccess(res, renewed, 'Membership renewed successfully');
  } catch (err) {
    next(err);
  }
};
router.put('/:id/renew', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), renewHandler);
router.post('/:id/renew', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), renewHandler);

// PUT / PATCH /api/memberships/:id/freeze
const freezeHandler = async (req, res, next) => {
  try {
    const gymId = req.gymId;
    const existing = await prisma.customerMembership.findUnique({
      where: { id: req.params.id },
      include: { customer: true },
    });
    if (!existing || (gymId && existing.gymId !== gymId)) {
      return sendError(res, 'Membership not found', 404);
    }

    const { unfreeze, freeze, frozenUntil } = req.body;
    const shouldUnfreeze = unfreeze !== undefined ? Boolean(unfreeze) : freeze === false || existing.isFrozen;
    let updated;

    if (shouldUnfreeze) {
      if (!existing.isFrozen) {
        return sendError(res, 'Membership is not currently frozen', 400);
      }
      const frozenDays = existing.frozenAt ? Math.max(0, dayjs().diff(dayjs(existing.frozenAt), 'day')) : 0;
      const extendedEnd = dayjs(existing.endDate).add(frozenDays, 'day').toDate();

      updated = await prisma.customerMembership.update({
        where: { id: existing.id },
        data: {
          status: 'ACTIVE',
          isFrozen: false,
          frozenAt: null,
          frozenUntil: null,
          endDate: extendedEnd,
        },
      });
    } else {
      if (existing.status === 'CANCELLED' || existing.status === 'EXPIRED') {
        return sendError(res, `Cannot freeze a ${existing.status.toLowerCase()} membership`, 400);
      }
      updated = await prisma.customerMembership.update({
        where: { id: existing.id },
        data: {
          status: 'FROZEN',
          isFrozen: true,
          frozenAt: new Date(),
          frozenUntil: frozenUntil ? new Date(frozenUntil) : null,
        },
      });
    }

    emitMembershipStatusChange(req.app.get('io'), existing.gymId, existing.customer.userId, {
      membershipId: updated.id,
      customerId: existing.customerId,
      status: updated.status,
      isFrozen: updated.isFrozen,
    });

    return sendSuccess(res, updated, shouldUnfreeze ? 'Membership unfrozen' : 'Membership frozen');
  } catch (err) {
    next(err);
  }
};
router.put('/:id/freeze', authorize('GYM_OWNER', 'SUPER_ADMIN'), freezeHandler);
router.patch('/:id/freeze', authorize('GYM_OWNER', 'SUPER_ADMIN'), freezeHandler);

// PUT / PATCH /api/memberships/:id/cancel
const cancelHandler = async (req, res, next) => {
  try {
    const gymId = req.gymId;
    const existing = await prisma.customerMembership.findUnique({
      where: { id: req.params.id },
      include: { customer: true },
    });
    if (!existing || (gymId && existing.gymId !== gymId)) {
      return sendError(res, 'Membership not found', 404);
    }

    const updated = await prisma.customerMembership.update({
      where: { id: existing.id },
      data: { status: 'CANCELLED', isFrozen: false },
    });

    emitMembershipStatusChange(req.app.get('io'), existing.gymId, existing.customer.userId, {
      membershipId: updated.id,
      customerId: existing.customerId,
      status: 'CANCELLED',
    });

    await createAuditLog({
      userId: req.user.id,
      gymId: existing.gymId,
      action: 'CANCEL_MEMBERSHIP',
      entity: 'CustomerMembership',
      entityId: updated.id,
      req,
    });

    return sendSuccess(res, updated, 'Membership cancelled');
  } catch (err) {
    next(err);
  }
};
router.put('/:id/cancel', authorize('GYM_OWNER', 'SUPER_ADMIN'), cancelHandler);
router.patch('/:id/cancel', authorize('GYM_OWNER', 'SUPER_ADMIN'), cancelHandler);

// PUT /api/memberships/:id/extend
router.put(
  '/:id/extend',
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  [body('days').isInt({ min: 1 }).withMessage('days must be a positive integer'), validate],
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      const existing = await prisma.customerMembership.findUnique({
        where: { id: req.params.id },
        include: { customer: true },
      });
      if (!existing || (gymId && existing.gymId !== gymId)) {
        return sendError(res, 'Membership not found', 404);
      }

      const days = parseInt(req.body.days, 10);
      const baseEnd =
        dayjs(existing.endDate).isBefore(dayjs()) && existing.status === 'EXPIRED'
          ? dayjs()
          : dayjs(existing.endDate);
      const newEndDate = baseEnd.add(days, 'day').toDate();

      const updated = await prisma.customerMembership.update({
        where: { id: existing.id },
        data: {
          endDate: newEndDate,
          status: existing.status === 'EXPIRED' ? 'ACTIVE' : existing.status,
        },
      });

      emitMembershipStatusChange(req.app.get('io'), existing.gymId, existing.customer.userId, {
        membershipId: updated.id,
        customerId: existing.customerId,
        status: updated.status,
        extendedDays: days,
        endDate: newEndDate,
      });

      await createAuditLog({
        userId: req.user.id,
        gymId: existing.gymId,
        action: 'EXTEND_MEMBERSHIP',
        entity: 'CustomerMembership',
        entityId: updated.id,
        details: { days, newEndDate },
        req,
      });

      return sendSuccess(res, updated, `Membership extended by ${days} days`);
    } catch (err) {
      next(err);
    }
  }
);

module.exports = router;

const express = require('express');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { upload, getUploadedFileUrl } = require('../middleware/upload');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const {
  parseJson,
  stringifyJson,
  sanitizeUser,
  formatCustomer,
  formatTrainer,
  formatPayment,
  formatSubscriptionPlan,
  generateReadableId,
} = require('../utils/json');
const { nowIST, getISTDayRange, getISTMonthRange, dayjs, IST_TZ } = require('../utils/date');
const { createAuditLog } = require('../utils/audit');
const { createNotification } = require('../utils/notification');

const router = express.Router();

// Authentication required on all /gym routes; subscription expiry still permits billing/profile/settings reads
router.use(authenticate);

// GET /api/gym/dashboard
router.get(
  '/dashboard',
  requireGymAccess({ allowWhenExpired: true }),
  authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'),
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const branchId = req.query.branchId && req.query.branchId !== 'ALL' ? req.query.branchId : undefined;
      const startDate = req.query.startDate
        ? dayjs(req.query.startDate).tz(IST_TZ).startOf('day').toDate()
        : nowIST().subtract(29, 'day').startOf('day').toDate();
      const endDate = req.query.endDate
        ? dayjs(req.query.endDate).tz(IST_TZ).endOf('day').toDate()
        : nowIST().endOf('day').toDate();

      const todayRange = getISTDayRange();
      const monthRange = getISTMonthRange();
      const sevenDaysLater = nowIST().add(7, 'day').toDate();
      const now = nowIST().toDate();

      const customerWhere = { gymId, ...(branchId && { branchId }) };
      const trainerWhere = { gymId, isActive: true, ...(branchId && { branchId }) };
      const expenseWhere = { gymId, ...(branchId && { branchId }) };

      const [
        totalCustomers,
        activeCustomers,
        inactiveCustomers,
        newMembersCount,
        totalTrainers,
        totalBranches,
        activeMemberships,
        expiredMemberships,
        expiringMemberships,
        todayPresentCount,
        todayAbsentCount,
        pendingPayments,
        todayRevenueAgg,
        periodRevenueAgg,
        periodExpenseAgg,
        monthlyRevenueAgg,
        monthlyExpenseAgg,
        todayCheckIns,
        recentPayments,
        periodPayments,
        periodExpenses,
        periodAttendance,
        membershipsByPlan,
        plans,
      ] = await Promise.all([
        prisma.customerProfile.count({ where: customerWhere }),
        prisma.customerProfile.count({ where: { ...customerWhere, isActive: true } }),
        prisma.customerProfile.count({ where: { ...customerWhere, isActive: false } }),
        prisma.customerProfile.count({
          where: { ...customerWhere, joiningDate: { gte: startDate, lte: endDate } },
        }),
        prisma.trainerProfile.count({ where: trainerWhere }),
        prisma.gymBranch.count({ where: { gymId, isActive: true } }),
        prisma.customerMembership.count({ where: { gymId, status: 'ACTIVE' } }),
        prisma.customerMembership.count({ where: { gymId, status: 'EXPIRED' } }),
        prisma.customerMembership.findMany({
          where: { gymId, status: 'ACTIVE', endDate: { gte: now, lte: sevenDaysLater } },
          take: 10,
          orderBy: { endDate: 'asc' },
          include: {
            customer: { include: { user: { select: { id: true, fullName: true, mobile: true, profilePhoto: true } } } },
            plan: true,
          },
        }),
        prisma.attendance.count({
          where: { gymId, status: 'PRESENT', date: { gte: todayRange.start, lte: todayRange.end } },
        }),
        prisma.attendance.count({
          where: { gymId, status: 'ABSENT', date: { gte: todayRange.start, lte: todayRange.end } },
        }),
        prisma.payment.findMany({
          where: { gymId, status: { in: ['PENDING', 'UNDER_REVIEW'] } },
          take: 10,
          orderBy: { createdAt: 'desc' },
          include: {
            customer: { include: { user: { select: { id: true, fullName: true, mobile: true } } } },
            membership: { include: { plan: true } },
          },
        }),
        prisma.payment.aggregate({
          where: { gymId, status: 'APPROVED', createdAt: { gte: todayRange.start, lte: todayRange.end } },
          _sum: { amount: true },
        }),
        prisma.payment.aggregate({
          where: { gymId, status: 'APPROVED', createdAt: { gte: startDate, lte: endDate } },
          _sum: { amount: true },
        }),
        prisma.expense.aggregate({
          where: { ...expenseWhere, date: { gte: startDate, lte: endDate } },
          _sum: { amount: true },
        }),
        prisma.payment.aggregate({
          where: { gymId, status: 'APPROVED', createdAt: { gte: monthRange.start, lte: monthRange.end } },
          _sum: { amount: true },
        }),
        prisma.expense.aggregate({
          where: { ...expenseWhere, date: { gte: monthRange.start, lte: monthRange.end } },
          _sum: { amount: true },
        }),
        prisma.attendance.findMany({
          where: { gymId, date: { gte: todayRange.start, lte: todayRange.end } },
          take: 10,
          orderBy: { checkInTime: 'desc' },
          include: {
            customer: { include: { user: { select: { id: true, fullName: true, profilePhoto: true, mobile: true } } } },
          },
        }),
        prisma.payment.findMany({
          where: { gymId },
          take: 5,
          orderBy: { createdAt: 'desc' },
          include: {
            customer: { include: { user: { select: { id: true, fullName: true, mobile: true } } } },
          },
        }),
        prisma.payment.findMany({
          where: {
            gymId,
            status: 'APPROVED',
            createdAt: { gte: nowIST().subtract(5, 'month').startOf('month').toDate() },
          },
          select: { amount: true, createdAt: true },
        }),
        prisma.expense.findMany({
          where: {
            ...expenseWhere,
            date: { gte: nowIST().subtract(5, 'month').startOf('month').toDate() },
          },
          select: { amount: true, date: true },
        }),
        prisma.attendance.findMany({
          where: {
            gymId,
            date: { gte: nowIST().subtract(6, 'day').startOf('day').toDate() },
          },
          select: { date: true, status: true },
        }),
        prisma.customerMembership.groupBy({
          by: ['planId'],
          where: { gymId, status: 'ACTIVE' },
          _count: { id: true },
        }),
        prisma.membershipPlan.findMany({ where: { gymId }, select: { id: true, name: true } }),
      ]);

      const monthlyMap = {};
      for (let i = 5; i >= 0; i--) {
        const d = dayjs().tz(IST_TZ).subtract(i, 'month');
        const key = d.format('YYYY-MM');
        monthlyMap[key] = { month: key, label: d.format('MMM YY'), revenue: 0, expenses: 0 };
      }
      periodPayments.forEach((p) => {
        const key = dayjs(p.createdAt).tz(IST_TZ).format('YYYY-MM');
        if (monthlyMap[key]) monthlyMap[key].revenue += Number(p.amount || 0);
      });
      periodExpenses.forEach((e) => {
        const key = dayjs(e.date).tz(IST_TZ).format('YYYY-MM');
        if (monthlyMap[key]) monthlyMap[key].expenses += Number(e.amount || 0);
      });

      const attMap = {};
      for (let i = 6; i >= 0; i--) {
        const d = dayjs().tz(IST_TZ).subtract(i, 'day');
        const key = d.format('YYYY-MM-DD');
        attMap[key] = { label: d.format('DD MMM'), present: 0, absent: 0 };
      }
      periodAttendance.forEach((a) => {
        const key = dayjs(a.date).format('YYYY-MM-DD');
        if (attMap[key]) {
          if (a.status === 'PRESENT') attMap[key].present += 1;
          else attMap[key].absent += 1;
        }
      });

      const planMap = Object.fromEntries(plans.map((p) => [p.id, p.name]));
      const membershipDistribution = membershipsByPlan.map((m) => ({
        name: planMap[m.planId] || 'Other',
        value: m._count.id,
      }));

      const totalRevenue = periodRevenueAgg._sum.amount || 0;
      const totalExpenses = periodExpenseAgg._sum.amount || 0;
      const monthlyRevenue = monthlyRevenueAgg._sum.amount || 0;
      const monthlyExpenses = monthlyExpenseAgg._sum.amount || 0;
      const attendanceValues = Object.values(attMap);
      const avgDailyAttendance =
        attendanceValues.length > 0
          ? Math.round(attendanceValues.reduce((s, d) => s + d.present, 0) / attendanceValues.length)
          : 0;

      return sendSuccess(
        res,
        {
          stats: {
            totalCustomers,
            activeCustomers,
            activeMembers: activeCustomers,
            inactiveCustomers,
            expiredMemberships,
            newRegistrations: newMembersCount,
            newMembers: newMembersCount,
            totalTrainers,
            totalBranches,
            activeMemberships,
            expiringSoonCount: expiringMemberships.length,
            expiringSoon: expiringMemberships.length,
            todayAttendanceCount: todayPresentCount,
            todayAttendance: todayPresentCount,
            todayPresent: todayPresentCount,
            todayAbsent: todayAbsentCount,
            avgDailyAttendance,
            pendingPaymentsCount: pendingPayments.length,
            todayRevenue: todayRevenueAgg._sum.amount || 0,
            totalRevenue,
            monthlyRevenue,
            monthlyExpenses,
            estimatedProfit: monthlyRevenue - monthlyExpenses,
            netProfit: totalRevenue - totalExpenses,
          },
          revenueChart: Object.values(monthlyMap),
          revenueTrend: Object.values(monthlyMap),
          attendanceChart: attendanceValues,
          membershipDistribution,
          expiringMemberships: expiringMemberships.map((m) => ({
            ...m,
            customer: formatCustomer(m.customer),
            customerName: m.customer?.user?.fullName || '',
            planName: m.plan?.name || '',
          })),
          pendingPayments: pendingPayments.map(formatPayment),
          todayCheckIns: todayCheckIns.map((a) => ({
            ...a,
            customer: formatCustomer(a.customer),
            customerName: a.customer?.user?.fullName || '',
          })),
          recentCheckIns: todayCheckIns.map((a) => ({
            ...a,
            customer: formatCustomer(a.customer),
            customerName: a.customer?.user?.fullName || '',
          })),
          recentPayments: recentPayments.map(formatPayment),
        },
        'Gym dashboard fetched'
      );
    } catch (err) {
      next(err);
    }
  }
);

// GET /api/gym/profile
router.get('/profile', requireGymAccess({ allowWhenExpired: true }), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const gym = await prisma.gym.findUnique({
      where: { id: gymId },
      include: {
        owner: { select: { id: true, fullName: true, email: true, mobile: true, profilePhoto: true } },
        branches: { where: { isActive: true } },
        ownerProfiles: { select: { businessDetails: true, notificationPrefs: true } },
      },
    });

    if (!gym) return sendError(res, 'Gym not found', 404);

    return sendSuccess(
      res,
      {
        ...gym,
        settings: parseJson(gym.settings, {}),
        owner: sanitizeUser(gym.owner),
        ownerProfiles: gym.ownerProfiles.map((op) => ({
          ...op,
          notificationPrefs: parseJson(op.notificationPrefs, {}),
        })),
      },
      'Gym profile retrieved'
    );
  } catch (err) {
    next(err);
  }
});

// PUT /api/gym/profile
router.put(
  '/profile',
  requireGymAccess({ allowWhenExpired: true }),
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  upload.single('logo'),
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const { name, address, city, state, phone, email, businessDetails, notificationPrefs } = req.body;
      const logoUrl = req.file ? getUploadedFileUrl(req.file) : req.body.logo;

      const updated = await prisma.gym.update({
        where: { id: gymId },
        data: {
          ...(name !== undefined && { name }),
          ...(address !== undefined && { address }),
          ...(city !== undefined && { city }),
          ...(state !== undefined && { state }),
          ...(phone !== undefined && { phone }),
          ...(email !== undefined && { email }),
          ...(logoUrl !== undefined && { logo: logoUrl }),
        },
      });

      if (businessDetails !== undefined || notificationPrefs !== undefined) {
        await prisma.gymOwnerProfile.updateMany({
          where: { gymId, userId: updated.ownerId },
          data: {
            ...(businessDetails !== undefined && { businessDetails }),
            ...(notificationPrefs !== undefined && {
              notificationPrefs:
                typeof notificationPrefs === 'string'
                  ? notificationPrefs
                  : JSON.stringify(notificationPrefs),
            }),
          },
        });
      }

      await createAuditLog({
        userId: req.user.id,
        gymId,
        action: 'UPDATE_GYM_PROFILE',
        entity: 'Gym',
        entityId: gymId,
        req,
      });

      return sendSuccess(res, updated, 'Gym profile updated successfully');
    } catch (err) {
      next(err);
    }
  }
);

// GET / PUT /api/gym/settings
router.get('/settings', requireGymAccess({ allowWhenExpired: true }), async (req, res, next) => {
  try {
    const gym = await prisma.gym.findUnique({ where: { id: req.gymId } });
    if (!gym) return sendError(res, 'Gym not found', 404);
    const parsed = parseJson(gym.settings, {});
    return sendSuccess(
      res,
      {
        gstNumber: parsed.gstNumber ?? '',
        invoicePrefix: parsed.invoicePrefix ?? 'INV-',
        defaultTaxRate: parsed.defaultTaxRate ?? 18,
        currency: parsed.currency ?? 'INR',
        openingTime: parsed.openingTime ?? '05:30',
        closingTime: parsed.closingTime ?? '22:00',
        enableQrAttendance: parsed.enableQrAttendance ?? true,
        enableExpiryReminders: parsed.enableExpiryReminders ?? true,
        allowMemberSelfPayment: parsed.allowMemberSelfPayment ?? true,
        ...parsed,
      },
      'Gym settings retrieved'
    );
  } catch (err) {
    next(err);
  }
});

router.put(
  '/settings',
  requireGymAccess({ allowWhenExpired: true }),
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  async (req, res, next) => {
    try {
      const gym = await prisma.gym.findUnique({ where: { id: req.gymId } });
      if (!gym) return sendError(res, 'Gym not found', 404);

      const current = parseJson(gym.settings, {});
      const merged = { ...current, ...req.body };

      await prisma.gym.update({
        where: { id: gym.id },
        data: { settings: JSON.stringify(merged) },
      });

      await createAuditLog({
        userId: req.user.id,
        gymId: gym.id,
        action: 'UPDATE_GYM_SETTINGS',
        entity: 'Gym',
        entityId: gym.id,
        req,
      });

      return sendSuccess(res, merged, 'Gym settings saved successfully');
    } catch (err) {
      next(err);
    }
  }
);

// GET /api/gym/permissions & PUT /api/gym/permissions/:userId
router.get(
  '/permissions',
  requireGymAccess(),
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  async (req, res, next) => {
    try {
      const trainers = await prisma.trainerProfile.findMany({
        where: { gymId: req.gymId, isActive: true },
        include: {
          user: { select: { id: true, fullName: true, mobile: true, email: true, profilePhoto: true, role: true } },
        },
        orderBy: { createdAt: 'asc' },
      });

      const formatted = trainers.map((t) => ({
        id: t.id,
        userId: t.userId,
        name: t.user.fullName,
        mobile: t.user.mobile,
        email: t.user.email,
        avatar: t.user.profilePhoto,
        role: t.user.role,
        permissions: parseJson(t.permissions, {
          canMarkAttendance: true,
          canManageWorkouts: true,
          canManageDiets: true,
          canViewPayments: false,
          canManageCustomers: false,
          canViewReports: false,
        }),
      }));

      return sendSuccess(res, formatted, 'Staff permissions fetched');
    } catch (err) {
      next(err);
    }
  }
);

router.put(
  '/permissions/:userId',
  requireGymAccess(),
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  async (req, res, next) => {
    try {
      const trainer = await prisma.trainerProfile.findFirst({
        where: {
          gymId: req.gymId,
          OR: [{ userId: req.params.userId }, { id: req.params.userId }],
        },
      });
      if (!trainer) return sendError(res, 'Staff/trainer record not found in this gym', 404);

      const permissions = req.body.permissions || req.body;
      const updated = await prisma.trainerProfile.update({
        where: { id: trainer.id },
        data: { permissions: stringifyJson(permissions, '{}') },
      });

      await createAuditLog({
        userId: req.user.id,
        gymId: req.gymId,
        action: 'UPDATE_PERMISSIONS',
        entity: 'TrainerProfile',
        entityId: trainer.id,
        details: permissions,
        req,
      });

      return sendSuccess(
        res,
        { ...updated, permissions: parseJson(updated.permissions, {}) },
        'Permissions updated successfully'
      );
    } catch (err) {
      next(err);
    }
  }
);

// GET /api/gym/audit-logs
router.get(
  '/audit-logs',
  requireGymAccess({ allowWhenExpired: true }),
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  async (req, res, next) => {
    try {
      const { page, limit, skip } = getPagination(req.query);
      const { search } = req.query;
      const where = { gymId: req.gymId };
      if (search) {
        where.OR = [
          { action: { contains: search } },
          { entity: { contains: search } },
          { user: { fullName: { contains: search } } },
        ];
      }

      const [logs, total] = await Promise.all([
        prisma.auditLog.findMany({
          where,
          skip,
          take: limit,
          orderBy: { createdAt: 'desc' },
          include: { user: { select: { id: true, fullName: true, role: true } } },
        }),
        prisma.auditLog.count({ where }),
      ]);

      const formatted = logs.map((l) => {
        const parsed = parseJson(l.details, {});
        return {
          ...l,
          user: l.user ? sanitizeUser(l.user) : null,
          details: typeof parsed === 'object' ? JSON.stringify(parsed) : String(parsed),
        };
      });

      return sendSuccess(res, formatPaginatedData(formatted, total, page, limit), 'Gym audit logs fetched');
    } catch (err) {
      next(err);
    }
  }
);

// CRUD /api/gym/branches
router.get('/branches', requireGymAccess({ allowWhenExpired: true }), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const branches = await prisma.gymBranch.findMany({
      where: { gymId },
      orderBy: { createdAt: 'asc' },
      include: {
        _count: { select: { customers: true, trainers: true, equipment: true } },
      },
    });

    return sendSuccess(res, branches, 'Branches retrieved');
  } catch (err) {
    next(err);
  }
});

router.post(
  '/branches',
  requireGymAccess(),
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  upload.fields([
    { name: 'qrCodeImage', maxCount: 1 },
    { name: 'upiQrCode', maxCount: 1 },
  ]),
  [body('name').trim().notEmpty().withMessage('Branch name is required'), validate],
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const activeSub = await prisma.gymSubscription.findFirst({
        where: { gymId, status: { in: ['ACTIVE', 'TRIAL', 'GRACE'] } },
        orderBy: { createdAt: 'desc' },
        include: { plan: true },
      });

      if (activeSub?.plan) {
        const currentBranchCount = await prisma.gymBranch.count({ where: { gymId, isActive: true } });
        if (currentBranchCount >= activeSub.plan.maxBranches) {
          return sendError(
            res,
            `Branch limit (${activeSub.plan.maxBranches}) reached for your current subscription plan`,
            403
          );
        }
      }

      const {
        name,
        address,
        city,
        phone,
        email,
        managerName,
        isMain = false,
        isActive = true,
        upiId,
        accountHolderName,
        paymentInstructions,
      } = req.body;

      const qrCodeImage = req.files?.qrCodeImage?.[0]
        ? getUploadedFileUrl(req.files.qrCodeImage[0])
        : req.body.qrCodeImage || null;
      const upiQrCode = req.files?.upiQrCode?.[0]
        ? getUploadedFileUrl(req.files.upiQrCode[0])
        : req.body.upiQrCode || null;

      const branch = await prisma.gymBranch.create({
        data: {
          gymId,
          name,
          address: address || null,
          city: city || null,
          phone: phone || null,
          email: email || null,
          managerName: managerName || null,
          isMain: Boolean(isMain),
          isActive: Boolean(isActive),
          upiId: upiId || null,
          accountHolderName: accountHolderName || null,
          paymentInstructions: paymentInstructions || null,
          qrCodeImage,
          upiQrCode,
        },
      });

      return sendSuccess(res, branch, 'Branch created successfully', 201);
    } catch (err) {
      next(err);
    }
  }
);

router.put(
  '/branches/:id',
  requireGymAccess(),
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  upload.fields([
    { name: 'qrCodeImage', maxCount: 1 },
    { name: 'upiQrCode', maxCount: 1 },
  ]),
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      const existing = await prisma.gymBranch.findUnique({ where: { id: req.params.id } });
      if (!existing || (gymId && existing.gymId !== gymId)) {
        return sendError(res, 'Branch not found', 404);
      }

      const {
        name,
        address,
        city,
        phone,
        email,
        managerName,
        isMain,
        isActive,
        upiId,
        accountHolderName,
        paymentInstructions,
      } = req.body;
      const qrCodeImage = req.files?.qrCodeImage?.[0]
        ? getUploadedFileUrl(req.files.qrCodeImage[0])
        : req.body.qrCodeImage;
      const upiQrCode = req.files?.upiQrCode?.[0]
        ? getUploadedFileUrl(req.files.upiQrCode[0])
        : req.body.upiQrCode;

      const updated = await prisma.gymBranch.update({
        where: { id: existing.id },
        data: {
          ...(name !== undefined && { name }),
          ...(address !== undefined && { address }),
          ...(city !== undefined && { city }),
          ...(phone !== undefined && { phone }),
          ...(email !== undefined && { email }),
          ...(managerName !== undefined && { managerName }),
          ...(isMain !== undefined && { isMain: isMain === true || isMain === 'true' }),
          ...(isActive !== undefined && { isActive: isActive === true || isActive === 'true' }),
          ...(upiId !== undefined && { upiId }),
          ...(accountHolderName !== undefined && { accountHolderName }),
          ...(paymentInstructions !== undefined && { paymentInstructions }),
          ...(qrCodeImage !== undefined && { qrCodeImage }),
          ...(upiQrCode !== undefined && { upiQrCode }),
        },
      });

      return sendSuccess(res, updated, 'Branch updated successfully');
    } catch (err) {
      next(err);
    }
  }
);

router.delete(
  '/branches/:id',
  requireGymAccess(),
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      const existing = await prisma.gymBranch.findUnique({ where: { id: req.params.id } });
      if (!existing || (gymId && existing.gymId !== gymId)) {
        return sendError(res, 'Branch not found', 404);
      }

      await prisma.gymBranch.update({
        where: { id: existing.id },
        data: { isActive: false },
      });

      return sendSuccess(res, null, 'Branch deactivated successfully');
    } catch (err) {
      next(err);
    }
  }
);

// GET /api/gym/subscription
router.get(
  '/subscription',
  requireGymAccess({ allowWhenExpired: true }),
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const [currentSubscription, availablePlans, customerCount, trainerCount, branchCount] = await Promise.all([
        prisma.gymSubscription.findFirst({
          where: { gymId },
          orderBy: { createdAt: 'desc' },
          include: {
            plan: true,
            payments: { orderBy: { createdAt: 'desc' }, take: 5 },
          },
        }),
        prisma.subscriptionPlan.findMany({
          where: { isActive: true },
          orderBy: { monthlyPrice: 'asc' },
        }),
        prisma.customerProfile.count({ where: { gymId, isActive: true } }),
        prisma.trainerProfile.count({ where: { gymId, isActive: true } }),
        prisma.gymBranch.count({ where: { gymId, isActive: true } }),
      ]);

      const formattedPlan = currentSubscription?.plan
        ? formatSubscriptionPlan(currentSubscription.plan)
        : null;
      const daysRemaining = currentSubscription?.endDate
        ? Math.max(0, dayjs(currentSubscription.endDate).diff(dayjs(), 'day'))
        : 0;

      return sendSuccess(
        res,
        {
          gymStatus: req.gym?.subscriptionStatus,
          status: currentSubscription?.status || req.gym?.subscriptionStatus || 'TRIAL',
          trialStartDate: req.gym?.trialStartDate,
          trialEndDate: req.gym?.trialEndDate,
          endDate: currentSubscription?.endDate || req.gym?.trialEndDate,
          daysRemaining,
          plan: formattedPlan,
          planName: formattedPlan?.name || 'Trial',
          currentSubscription: currentSubscription
            ? {
                ...currentSubscription,
                plan: formattedPlan,
              }
            : null,
          usage: {
            members: customerCount,
            customers: customerCount,
            trainers: trainerCount,
            branches: branchCount,
          },
          availablePlans: availablePlans.map(formatSubscriptionPlan),
        },
        'Subscription details retrieved'
      );
    } catch (err) {
      next(err);
    }
  }
);

// GET /api/gym/subscription/plans
router.get(
  '/subscription/plans',
  requireGymAccess({ allowWhenExpired: true }),
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  async (req, res, next) => {
    try {
      const plans = await prisma.subscriptionPlan.findMany({
        where: { isActive: true },
        orderBy: { monthlyPrice: 'asc' },
      });
      return sendSuccess(res, plans.map(formatSubscriptionPlan), 'Subscription plans fetched');
    } catch (err) {
      next(err);
    }
  }
);

// POST /api/gym/subscription/purchase AND /api/gym/subscription/upgrade
const purchaseSubscriptionHandler = async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const {
      planId,
      billingPeriod,
      billingCycle,
      paymentMethod = 'UPI',
      transactionId,
      couponCode,
    } = req.body;
    const resolvedPeriod = (billingPeriod || billingCycle || 'MONTHLY').toUpperCase();

    const plan = await prisma.subscriptionPlan.findUnique({ where: { id: planId } });
    if (!plan || !plan.isActive) {
      return sendError(res, 'Selected subscription plan is unavailable', 404);
    }

    if (transactionId) {
      const dupTx = await prisma.subscriptionPayment.findFirst({
        where: { transactionId: transactionId.trim(), status: { not: 'REJECTED' } },
      });
      if (dupTx) {
        return sendError(res, 'Duplicate subscription transaction ID already submitted', 409);
      }
    }

    let amount = resolvedPeriod === 'YEARLY' ? plan.yearlyPrice : plan.monthlyPrice;
    let appliedCoupon = null;

    if (couponCode) {
      const coupon = await prisma.platformCoupon.findUnique({
        where: { code: couponCode.trim().toUpperCase() },
      });
      if (!coupon || !coupon.isActive) {
        return sendError(res, 'Invalid or inactive platform coupon', 400);
      }
      if (coupon.expiryDate && new Date(coupon.expiryDate) < new Date()) {
        return sendError(res, 'Platform coupon has expired', 400);
      }
      if (coupon.maxUses && coupon.currentUses >= coupon.maxUses) {
        return sendError(res, 'Platform coupon usage limit exceeded', 400);
      }
      const applicable = parseJson(coupon.applicablePlans, []);
      if (applicable.length > 0 && !applicable.includes(plan.id)) {
        return sendError(res, 'Coupon is not applicable for this subscription plan', 400);
      }

      if (coupon.discountType === 'PERCENTAGE') {
        amount = Math.max(0, amount - (amount * coupon.discountValue) / 100);
      } else {
        amount = Math.max(0, amount - coupon.discountValue);
      }
      appliedCoupon = coupon;
    }

    const durationDays = resolvedPeriod === 'YEARLY' ? 365 : 30;
    const startDate = nowIST().toDate();
    const endDate = nowIST().add(durationDays, 'day').toDate();
    const receiptUrl = req.file ? getUploadedFileUrl(req.file) : req.body.receiptUrl || null;

    // Note: Do NOT activate subscription just from screenshot upload; Super Admin verifies payment (PART 26)
    const result = await prisma.$transaction(async (tx) => {
      const subscription = await tx.gymSubscription.create({
        data: {
          gymId,
          planId: plan.id,
          billingPeriod: resolvedPeriod,
          startDate,
          endDate,
          status: 'PENDING',
          amount,
        },
        include: { plan: true },
      });

      const payment = await tx.subscriptionPayment.create({
        data: {
          gymSubscriptionId: subscription.id,
          gymId,
          amount,
          paymentMethod,
          transactionId: transactionId ? transactionId.trim() : null,
          status: 'PENDING',
          receiptUrl,
        },
      });

      if (appliedCoupon) {
        await tx.platformCoupon.update({
          where: { id: appliedCoupon.id },
          data: { currentUses: { increment: 1 } },
        });
      }

      return { subscription, payment };
    });

    const admins = await prisma.user.findMany({ where: { role: 'SUPER_ADMIN', isActive: true } });
    for (const admin of admins) {
      await createNotification({
        userId: admin.id,
        gymId,
        type: 'SUBSCRIPTION_PURCHASE',
        title: 'New Subscription Payment Submitted',
        message: `Gym submitted ₹${amount} for ${plan.name} (${resolvedPeriod}) plan.`,
        data: { paymentId: result.payment.id, subscriptionId: result.subscription.id },
        io: req.app.get('io'),
      });
    }

    await createAuditLog({
      userId: req.user.id,
      gymId,
      action: 'PURCHASE_SUBSCRIPTION',
      entity: 'GymSubscription',
      entityId: result.subscription.id,
      details: { planId: plan.id, billingPeriod: resolvedPeriod, amount },
      req,
    });

    return sendSuccess(res, result, 'Subscription payment submitted for verification', 201);
  } catch (err) {
    next(err);
  }
};

router.post(
  '/subscription/purchase',
  requireGymAccess({ allowWhenExpired: true }),
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  upload.single('receipt'),
  [body('planId').notEmpty().withMessage('planId is required'), validate],
  purchaseSubscriptionHandler
);

router.post(
  '/subscription/upgrade',
  requireGymAccess({ allowWhenExpired: true }),
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  upload.single('receipt'),
  [body('planId').notEmpty().withMessage('planId is required'), validate],
  purchaseSubscriptionHandler
);

// POST /api/gym/subscription/cancel
router.post(
  '/subscription/cancel',
  requireGymAccess({ allowWhenExpired: true }),
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  async (req, res, next) => {
    try {
      const latest = await prisma.gymSubscription.findFirst({
        where: { gymId: req.gymId },
        orderBy: { createdAt: 'desc' },
      });
      if (!latest) return sendError(res, 'No active subscription found', 404);

      await prisma.$transaction([
        prisma.gymSubscription.update({
          where: { id: latest.id },
          data: { status: 'CANCELLED' },
        }),
        prisma.gym.update({
          where: { id: req.gymId },
          data: { subscriptionStatus: 'CANCELLED' },
        }),
      ]);

      return sendSuccess(res, null, 'Subscription cancelled');
    } catch (err) {
      next(err);
    }
  }
);

// GET /api/gym/subscription/payments
router.get(
  '/subscription/payments',
  requireGymAccess({ allowWhenExpired: true }),
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const { page, limit, skip } = getPagination(req.query);
      const [payments, total] = await Promise.all([
        prisma.subscriptionPayment.findMany({
          where: { gymId },
          skip,
          take: limit,
          orderBy: { createdAt: 'desc' },
          include: { gymSubscription: { include: { plan: true } } },
        }),
        prisma.subscriptionPayment.count({ where: { gymId } }),
      ]);

      return sendSuccess(res, formatPaginatedData(payments, total, page, limit), 'Subscription payment history fetched');
    } catch (err) {
      next(err);
    }
  }
);

// Owner Support Tickets & Domain Requests
router.post(
  '/support-tickets',
  requireGymAccess({ allowWhenExpired: true }),
  authorize('GYM_OWNER'),
  [body('subject').trim().notEmpty(), body('message').trim().notEmpty(), validate],
  async (req, res, next) => {
    try {
      const ticket = await prisma.supportTicket.create({
        data: {
          userId: req.user.id,
          gymId: req.gymId,
          subject: req.body.subject.trim(),
          message: req.body.message.trim(),
          priority: req.body.priority || 'MEDIUM',
        },
      });
      return sendSuccess(res, ticket, 'Support ticket created', 201);
    } catch (err) {
      next(err);
    }
  }
);

router.post(
  '/domains',
  requireGymAccess(),
  authorize('GYM_OWNER'),
  [body('domainName').trim().notEmpty(), validate],
  async (req, res, next) => {
    try {
      const domain = await prisma.domain.create({
        data: {
          gymId: req.gymId,
          domainName: req.body.domainName.trim().toLowerCase(),
          verificationStatus: 'PENDING',
          verificationToken: `gympro-verify=${generateReadableId('DNS').toLowerCase()}`,
          cnameTarget: 'cname.gympro.app',
          dnsConfigured: false,
          sslStatus: 'PENDING',
        },
      });
      return sendSuccess(res, domain, 'Custom domain request submitted for DNS verification', 201);
    } catch (err) {
      next(err);
    }
  }
);

module.exports = router;

const express = require('express');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { validate } = require('../middleware/validate');
const { upload, getUploadedFileUrl } = require('../middleware/upload');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const { createAuditLog } = require('../utils/audit');

const router = express.Router();

router.use(authenticate, requireGymAccess(), authorize('GYM_OWNER', 'SUPER_ADMIN'));

const normalizeCategory = (cat) => {
  const upper = String(cat || 'OTHER').trim().toUpperCase();
  if (upper === 'UTILITIES') return 'ELECTRICITY';
  if (upper === 'MAINTENANCE') return 'REPAIRS';
  if (upper === 'SALARY' || upper === 'SALARIES') return 'STAFF';
  return upper;
};

const formatExpense = (e) => ({
  ...e,
  title: e.title || e.description || 'Expense',
  description: e.description || e.title || '',
  paymentMethod: e.paymentMethod || 'CASH',
  notes: e.notes || '',
});

const buildSummary = async (gymId, query = {}) => {
  const { startDate, endDate, branchId } = query;
  const where = { gymId };
  if (branchId) where.branchId = branchId;
  if (startDate || endDate) {
    where.date = {
      ...(startDate ? { gte: new Date(startDate) } : {}),
      ...(endDate ? { lte: new Date(endDate) } : {}),
    };
  }

  const expenses = await prisma.expense.findMany({ where });
  const categoryMap = {};
  let totalAmount = 0;

  for (const e of expenses) {
    const amt = Number(e.amount || 0);
    totalAmount += amt;
    categoryMap[e.category] = (categoryMap[e.category] || 0) + amt;
  }

  const byCategory = Object.entries(categoryMap).map(([category, amount]) => ({
    category,
    amount,
    percentage: totalAmount > 0 ? Math.round((amount / totalAmount) * 1000) / 10 : 0,
  }));

  return {
    totalAmount,
    total: totalAmount,
    count: expenses.length,
    byCategory,
    categoryBreakdown: categoryMap,
  };
};

// GET /api/expenses/summary
router.get('/summary', async (req, res, next) => {
  try {
    if (!req.gymId) return sendError(res, 'gymId is required', 400);
    const summary = await buildSummary(req.gymId, req.query);
    return sendSuccess(res, summary, 'Expense summary fetched');
  } catch (err) {
    next(err);
  }
});

router.get('/categories', async (req, res, next) => {
  try {
    if (!req.gymId) return sendError(res, 'gymId is required', 400);
    const summary = await buildSummary(req.gymId, req.query);
    return sendSuccess(res, summary, 'Expense categories fetched');
  } catch (err) {
    next(err);
  }
});

router.get('/report', async (req, res, next) => {
  try {
    if (!req.gymId) return sendError(res, 'gymId is required', 400);
    const summary = await buildSummary(req.gymId, req.query);
    return sendSuccess(res, summary, 'Expense report fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/expenses
router.get('/', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { page, limit, skip } = getPagination(req.query);
    const { category, branchId, startDate, endDate, search } = req.query;

    const where = { gymId };
    if (category) where.category = normalizeCategory(category);
    if (branchId) where.branchId = branchId;
    if (startDate || endDate) {
      where.date = {
        ...(startDate ? { gte: new Date(startDate) } : {}),
        ...(endDate ? { lte: new Date(endDate) } : {}),
      };
    }
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
        { notes: { contains: search } },
      ];
    }

    const [expenses, total] = await Promise.all([
      prisma.expense.findMany({
        where,
        skip,
        take: limit,
        orderBy: { date: 'desc' },
      }),
      prisma.expense.count({ where }),
    ]);

    return sendSuccess(
      res,
      formatPaginatedData(expenses.map(formatExpense), total, page, limit),
      'Expenses fetched'
    );
  } catch (err) {
    next(err);
  }
});

// POST /api/expenses
router.post(
  '/',
  upload.single('receipt'),
  [
    body('amount').isFloat({ min: 0.01 }).withMessage('Valid amount is required'),
    body().custom((val) => {
      if (!val.title && !val.description) throw new Error('Expense title or description is required');
      return true;
    }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const {
        title,
        description,
        category = 'OTHER',
        amount,
        date,
        paymentMethod = 'CASH',
        notes,
        branchId,
      } = req.body;

      const receiptUrl = req.file ? getUploadedFileUrl(req.file) : req.body.receiptUrl || null;
      const effectiveTitle = (title || description).trim();
      const effectiveDesc = (description || title || '').trim();

      const expense = await prisma.expense.create({
        data: {
          gymId,
          branchId: branchId || null,
          category: normalizeCategory(category),
          title: effectiveTitle,
          description: effectiveDesc,
          amount: parseFloat(amount),
          date: date ? new Date(date) : new Date(),
          paymentMethod: String(paymentMethod || 'CASH').toUpperCase(),
          notes: notes || null,
          receiptUrl,
        },
      });

      await createAuditLog({
        userId: req.user.id,
        gymId,
        action: 'EXPENSE_CREATED',
        entity: 'Expense',
        entityId: expense.id,
        details: { title: expense.title, category: expense.category, amount: expense.amount },
        ipAddress: req.ip,
      });

      return sendSuccess(res, formatExpense(expense), 'Expense recorded', 201);
    } catch (err) {
      next(err);
    }
  }
);

// PUT /api/expenses/:id
router.put('/:id', upload.single('receipt'), async (req, res, next) => {
  try {
    const existing = await prisma.expense.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Expense not found', 404);

    const receiptUrl = req.file ? getUploadedFileUrl(req.file) : req.body.receiptUrl ?? existing.receiptUrl;
    const nextTitle = req.body.title !== undefined ? req.body.title : existing.title;
    const nextDesc =
      req.body.description !== undefined
        ? req.body.description
        : req.body.title !== undefined && !existing.description
        ? req.body.title
        : existing.description;

    const updated = await prisma.expense.update({
      where: { id: existing.id },
      data: {
        title: nextTitle,
        description: nextDesc,
        category: req.body.category ? normalizeCategory(req.body.category) : existing.category,
        amount: req.body.amount != null ? parseFloat(req.body.amount) : existing.amount,
        date: req.body.date ? new Date(req.body.date) : existing.date,
        paymentMethod: req.body.paymentMethod ? String(req.body.paymentMethod).toUpperCase() : existing.paymentMethod,
        notes: req.body.notes !== undefined ? req.body.notes : existing.notes,
        branchId: req.body.branchId !== undefined ? req.body.branchId || null : existing.branchId,
        receiptUrl,
      },
    });

    return sendSuccess(res, formatExpense(updated), 'Expense updated');
  } catch (err) {
    next(err);
  }
});

// DELETE /api/expenses/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const existing = await prisma.expense.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Expense not found', 404);

    await prisma.expense.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'Expense deleted');
  } catch (err) {
    next(err);
  }
});

module.exports = router;

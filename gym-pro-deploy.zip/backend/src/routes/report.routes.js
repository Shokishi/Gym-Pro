const express = require('express');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { sendSuccess, sendError } = require('../utils/response');
const { dayjs, IST_TZ, formatIST } = require('../utils/date');
const { generateReportPDF } = require('../utils/pdfGenerator');

const router = express.Router();

router.use(authenticate, requireGymAccess());

const resolveRange = (query = {}) => {
  const now = dayjs().tz(IST_TZ);
  const period = String(query.period || query.range || '30d').toLowerCase();

  let start = query.startDate ? dayjs(query.startDate).tz(IST_TZ).startOf('day') : null;
  let end = query.endDate ? dayjs(query.endDate).tz(IST_TZ).endOf('day') : now.endOf('day');

  if (!start) {
    if (period === 'today') {
      start = now.startOf('day');
    } else if (period === 'yesterday') {
      start = now.subtract(1, 'day').startOf('day');
      end = now.subtract(1, 'day').endOf('day');
    } else if (period === '7d' || period === 'last_7_days') {
      start = now.subtract(6, 'day').startOf('day');
    } else if (period === 'this_month') {
      start = now.startOf('month');
    } else if (period === 'last_month') {
      start = now.subtract(1, 'month').startOf('month');
      end = now.subtract(1, 'month').endOf('month');
    } else {
      start = now.subtract(29, 'day').startOf('day');
    }
  }

  return { start: start.toDate(), end: end.toDate(), startDay: start, endDay: end };
};

const toCsv = (headers, rows) => {
  const esc = (v) => {
    const str = String(v ?? '');
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };
  return [headers.map(esc).join(','), ...rows.map((r) => r.map(esc).join(','))].join('\n');
};

// GET /api/reports/owner
router.get('/owner', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { start, end, startDay, endDay } = resolveRange(req.query);

    const [
      approvedPayments,
      pendingPaymentsList,
      expenses,
      salaries,
      memberships,
      attendance,
      activeMembersCount,
    ] = await Promise.all([
      prisma.payment.findMany({
        where: { gymId, status: 'APPROVED', createdAt: { gte: start, lte: end } },
        orderBy: { createdAt: 'asc' },
      }),
      prisma.payment.findMany({
        where: { gymId, status: { in: ['PENDING', 'UNDER_REVIEW'] } },
      }),
      prisma.expense.findMany({
        where: { gymId, date: { gte: start, lte: end } },
        orderBy: { date: 'asc' },
      }),
      prisma.salary.findMany({
        where: { gymId, status: 'PAID', paidAt: { gte: start, lte: end } },
      }),
      prisma.customerMembership.findMany({
        where: { gymId, createdAt: { gte: start, lte: end } },
        include: { plan: true },
      }),
      prisma.attendance.findMany({
        where: { gymId, date: { gte: start, lte: end } },
      }),
      prisma.customerMembership.count({ where: { gymId, status: 'ACTIVE' } }),
    ]);

    const totalRevenue = approvedPayments.reduce((s, p) => s + Number(p.amount || 0), 0);
    const totalOpsExpenses = expenses.reduce((s, e) => s + Number(e.amount || 0), 0);
    const totalPayroll = salaries.reduce((s, x) => s + Number(x.totalAmount || 0), 0);
    const totalExpenses = totalOpsExpenses + totalPayroll;
    const netProfit = totalRevenue - totalExpenses;
    const pendingPayments = pendingPaymentsList.reduce((s, p) => s + Number(p.amount || 0), 0);
    const totalAttendance = attendance.filter((a) => a.status === 'PRESENT').length;

    // Build daily series across window (up to 31 buckets)
    const bucketMap = new Map();
    const diffDays = Math.min(31, Math.max(1, endDay.diff(startDay, 'day') + 1));
    for (let i = 0; i < diffDays; i++) {
      const d = startDay.add(i, 'day');
      const key = d.format('YYYY-MM-DD');
      bucketMap.set(key, {
        date: key,
        label: d.format('DD MMM'),
        revenue: 0,
        expenses: 0,
        profit: 0,
        present: 0,
        absent: 0,
      });
    }

    for (const p of approvedPayments) {
      const k = dayjs(p.createdAt).tz(IST_TZ).format('YYYY-MM-DD');
      if (bucketMap.has(k)) bucketMap.get(k).revenue += Number(p.amount || 0);
    }
    for (const e of expenses) {
      const k = dayjs(e.date).tz(IST_TZ).format('YYYY-MM-DD');
      if (bucketMap.has(k)) bucketMap.get(k).expenses += Number(e.amount || 0);
    }
    for (const a of attendance) {
      const k = dayjs(a.date).utc().format('YYYY-MM-DD');
      if (bucketMap.has(k)) {
        if (a.status === 'PRESENT') bucketMap.get(k).present += 1;
        else bucketMap.get(k).absent += 1;
      }
    }

    const series = Array.from(bucketMap.values()).map((row) => ({
      ...row,
      profit: row.revenue - row.expenses,
    }));

    const planMap = {};
    for (const m of memberships) {
      const planName = m.plan?.name || 'Other';
      if (!planMap[planName]) planMap[planName] = { name: planName, count: 0, revenue: 0 };
      planMap[planName].count += 1;
      planMap[planName].revenue += Number(m.purchasePrice || 0);
    }

    const expCatMap = {};
    for (const e of expenses) {
      expCatMap[e.category] = (expCatMap[e.category] || 0) + Number(e.amount || 0);
    }

    return sendSuccess(
      res,
      {
        summary: {
          totalRevenue,
          totalExpenses,
          netProfit,
          newMemberships: memberships.length,
          totalAttendance,
          pendingPayments,
          activeMembers: activeMembersCount,
        },
        revenueSeries: series,
        attendanceSeries: series.map(({ date, label, present, absent }) => ({ date, label, present, absent })),
        membershipDistribution: Object.values(planMap),
        expenseBreakdown: Object.entries(expCatMap).map(([category, amount]) => ({ category, amount })),
      },
      'Owner report fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/reports/admin (Super Admin)
router.get('/admin', authorize('SUPER_ADMIN'), async (req, res, next) => {
  try {
    const { start, end } = resolveRange(req.query);

    const [gyms, subPayments] = await Promise.all([
      prisma.gym.findMany({
        include: {
          owner: { select: { id: true, fullName: true, mobile: true, email: true } },
          subscriptions: {
            include: { plan: true },
            orderBy: { createdAt: 'desc' },
            take: 1,
          },
          _count: { select: { customers: true, trainers: true } },
          subscriptionPayments: { where: { createdAt: { gte: start, lte: end } } },
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.subscriptionPayment.findMany({
        where: { createdAt: { gte: start, lte: end } },
      }),
    ]);

    const verifiedPayments = subPayments
      .filter((p) => p.status === 'VERIFIED')
      .reduce((s, p) => s + Number(p.amount || 0), 0);
    const pendingPayments = subPayments
      .filter((p) => p.status === 'PENDING')
      .reduce((s, p) => s + Number(p.amount || 0), 0);

    const activeGyms = gyms.filter((g) => g.isActive && g.subscriptionStatus === 'ACTIVE').length;
    const trialGyms = gyms.filter((g) => g.subscriptionStatus === 'TRIAL').length;
    const conversionRate =
      activeGyms + trialGyms > 0 ? Math.round((activeGyms / (activeGyms + trialGyms)) * 1000) / 10 : 0;

    const rows = gyms.map((g) => {
      const latestSub = g.subscriptions[0];
      const revenue = g.subscriptionPayments
        .filter((p) => p.status === 'VERIFIED')
        .reduce((s, p) => s + Number(p.amount || 0), 0);
      return {
        gymId: g.id,
        gymName: g.name,
        ownerName: g.owner?.fullName || '',
        ownerMobile: g.owner?.mobile || '',
        planName: latestSub?.plan?.name || (g.subscriptionStatus === 'TRIAL' ? '7-Day Free Trial' : 'N/A'),
        status: g.subscriptionStatus,
        isActive: g.isActive,
        revenue,
        customers: g._count.customers,
        trainers: g._count.trainers,
        joinedAt: g.createdAt,
      };
    });

    return sendSuccess(
      res,
      {
        summary: {
          totalRevenue: verifiedPayments,
          verifiedPayments,
          pendingPayments,
          totalGyms: gyms.length,
          activeGyms,
          trialGyms,
          conversionRate,
        },
        rows,
      },
      'Admin report fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/reports/revenue
router.get('/revenue', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);
    const { start, end } = resolveRange(req.query);

    const payments = await prisma.payment.findMany({
      where: { gymId, status: 'APPROVED', createdAt: { gte: start, lte: end } },
      include: { customer: { include: { user: true } } },
      orderBy: { createdAt: 'desc' },
    });

    const total = payments.reduce((s, p) => s + Number(p.amount || 0), 0);
    const byMethod = {};
    for (const p of payments) {
      byMethod[p.paymentMethod] = (byMethod[p.paymentMethod] || 0) + Number(p.amount || 0);
    }

    return sendSuccess(res, { total, count: payments.length, byMethod, payments }, 'Revenue report fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/reports/attendance
router.get('/attendance', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);
    const { start, end } = resolveRange(req.query);

    const records = await prisma.attendance.findMany({
      where: { gymId, date: { gte: start, lte: end } },
      include: { customer: { include: { user: true } } },
      orderBy: { date: 'desc' },
    });

    const presentCount = records.filter((r) => r.status === 'PRESENT').length;
    const absentCount = records.filter((r) => r.status === 'ABSENT').length;

    return sendSuccess(
      res,
      { total: records.length, presentCount, absentCount, records },
      'Attendance report fetched'
    );
  } catch (err) {
    next(err);
  }
});

const membershipReportHandler = async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const memberships = await prisma.customerMembership.findMany({
      where: { gymId },
      include: { plan: true, customer: { include: { user: true } } },
    });

    const statusCounts = { ACTIVE: 0, EXPIRED: 0, FROZEN: 0, CANCELLED: 0 };
    const planRevenue = {};

    for (const m of memberships) {
      statusCounts[m.status] = (statusCounts[m.status] || 0) + 1;
      const pname = m.plan?.name || 'Custom';
      if (!planRevenue[pname]) planRevenue[pname] = { plan: pname, count: 0, revenue: 0 };
      planRevenue[pname].count += 1;
      planRevenue[pname].revenue += Number(m.totalPaid || 0);
    }

    return sendSuccess(
      res,
      { total: memberships.length, statusCounts, byPlan: Object.values(planRevenue) },
      'Membership report fetched'
    );
  } catch (err) {
    next(err);
  }
};

router.get('/memberships', authorize('GYM_OWNER', 'SUPER_ADMIN'), membershipReportHandler);
router.get('/membership', authorize('GYM_OWNER', 'SUPER_ADMIN'), membershipReportHandler);

// GET /api/reports/financial
router.get('/financial', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);
    const { start, end } = resolveRange(req.query);

    const [payments, expenses, salaries] = await Promise.all([
      prisma.payment.findMany({ where: { gymId, status: 'APPROVED', createdAt: { gte: start, lte: end } } }),
      prisma.expense.findMany({ where: { gymId, date: { gte: start, lte: end } } }),
      prisma.salary.findMany({ where: { gymId, status: 'PAID', paidAt: { gte: start, lte: end } } }),
    ]);

    const revenue = payments.reduce((s, p) => s + Number(p.amount || 0), 0);
    const expenseTotal = expenses.reduce((s, e) => s + Number(e.amount || 0), 0);
    const salaryTotal = salaries.reduce((s, x) => s + Number(x.totalAmount || 0), 0);

    return sendSuccess(
      res,
      {
        revenue,
        operatingExpenses: expenseTotal,
        payrollExpenses: salaryTotal,
        totalExpenses: expenseTotal + salaryTotal,
        netProfit: revenue - (expenseTotal + salaryTotal),
      },
      'Financial report fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/reports/trainer-performance
router.get('/trainer-performance', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const trainers = await prisma.trainerProfile.findMany({
      where: { gymId },
      include: {
        user: true,
        _count: {
          select: { assignedCustomers: true, workoutPlans: true, dietPlans: true, appointments: true },
        },
      },
    });

    return sendSuccess(
      res,
      trainers.map((t) => ({
        id: t.id,
        trainerId: t.trainerId,
        name: t.user?.fullName || '',
        specialization: t.specialization,
        customersCount: t._count.assignedCustomers,
        workoutPlansCount: t._count.workoutPlans,
        dietPlansCount: t._count.dietPlans,
        appointmentsCount: t._count.appointments,
      })),
      'Trainer performance report fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/reports/retention
router.get('/retention', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const [totalCustomers, activeMemberships, expiredMemberships] = await Promise.all([
      prisma.customerProfile.count({ where: { gymId } }),
      prisma.customerMembership.count({ where: { gymId, status: 'ACTIVE' } }),
      prisma.customerMembership.count({ where: { gymId, status: 'EXPIRED' } }),
    ]);

    const retentionRate =
      activeMemberships + expiredMemberships > 0
        ? Math.round((activeMemberships / (activeMemberships + expiredMemberships)) * 1000) / 10
        : 100;

    return sendSuccess(
      res,
      { totalCustomers, activeMemberships, expiredMemberships, retentionRate },
      'Retention report fetched'
    );
  } catch (err) {
    next(err);
  }
});

const exportHandler = async (req, res, next) => {
  try {
    const type = String(req.params.type || req.query.type || 'revenue').toLowerCase();
    const format = String(req.query.format || (type === 'pdf' ? 'pdf' : 'csv')).toLowerCase();
    const { start, end } = resolveRange(req.query);

    let title = 'GYM PRO Report';
    let headers = [];
    let rows = [];

    if (req.user.role === 'SUPER_ADMIN' && (type === 'admin' || !req.gymId)) {
      const gyms = await prisma.gym.findMany({
        include: { owner: true, _count: { select: { customers: true } } },
        orderBy: { createdAt: 'desc' },
      });
      title = 'GYM PRO Platform Report';
      headers = ['Gym Name', 'Owner', 'Mobile', 'Status', 'Customers', 'Joined'];
      rows = gyms.map((g) => [
        g.name,
        g.owner?.fullName || '',
        g.owner?.mobile || '',
        g.subscriptionStatus,
        g._count.customers,
        formatIST(g.createdAt, 'DD MMM YYYY'),
      ]);
    } else {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      if (type === 'attendance') {
        const list = await prisma.attendance.findMany({
          where: { gymId, date: { gte: start, lte: end } },
          include: { customer: { include: { user: true } } },
          orderBy: { date: 'desc' },
        });
        title = 'Attendance Report';
        headers = ['Date', 'Customer ID', 'Member Name', 'Status', 'Method', 'Check In'];
        rows = list.map((a) => [
          formatIST(a.date, 'DD MMM YYYY'),
          a.customer?.customerId || '',
          a.customer?.user?.fullName || '',
          a.status,
          a.method,
          a.checkInTime ? formatIST(a.checkInTime, 'hh:mm A') : '-',
        ]);
      } else if (type === 'expenses') {
        const list = await prisma.expense.findMany({
          where: { gymId, date: { gte: start, lte: end } },
          orderBy: { date: 'desc' },
        });
        title = 'Expenses Report';
        headers = ['Date', 'Title', 'Category', 'Method', 'Amount (INR)'];
        rows = list.map((e) => [
          formatIST(e.date, 'DD MMM YYYY'),
          e.title || e.description,
          e.category,
          e.paymentMethod || 'CASH',
          e.amount,
        ]);
      } else if (type === 'memberships' || type === 'customers') {
        const list = await prisma.customerMembership.findMany({
          where: { gymId },
          include: { customer: { include: { user: true } }, plan: true },
          orderBy: { createdAt: 'desc' },
        });
        title = 'Memberships Report';
        headers = ['Member ID', 'Member Name', 'Plan', 'Status', 'Valid Until', 'Paid (INR)'];
        rows = list.map((m) => [
          m.customer?.customerId || '',
          m.customer?.user?.fullName || '',
          m.plan?.name || '',
          m.status,
          formatIST(m.endDate, 'DD MMM YYYY'),
          m.totalPaid,
        ]);
      } else {
        const list = await prisma.payment.findMany({
          where: { gymId, createdAt: { gte: start, lte: end } },
          include: { customer: { include: { user: true } } },
          orderBy: { createdAt: 'desc' },
        });
        title = 'Revenue & Payments Report';
        headers = ['Date', 'Member Name', 'Method', 'Reference', 'Status', 'Amount (INR)'];
        rows = list.map((p) => [
          formatIST(p.createdAt, 'DD MMM YYYY'),
          p.customer?.user?.fullName || '',
          p.paymentMethod,
          p.transactionRef || '-',
          p.status,
          p.amount,
        ]);
      }
    }

    if (format === 'pdf') {
      const pdf = generateReportPDF(title, `Exported ${formatIST(new Date())}`, headers, rows);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${type}-report.pdf"`);
      return res.send(pdf);
    }

    const csv = toCsv(headers, rows);
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${type}-report.csv"`);
    return res.send(csv);
  } catch (err) {
    next(err);
  }
};

router.get('/export/:type', authorize('GYM_OWNER', 'SUPER_ADMIN'), exportHandler);
router.get('/export', authorize('GYM_OWNER', 'SUPER_ADMIN'), exportHandler);

module.exports = router;

const express = require('express');
const bcrypt = require('bcryptjs');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const {
  generateReadableId,
  formatTrainer,
  formatCustomer,
  canonicalMobile,
  normalizeMobileCandidates,
} = require('../utils/json');
const { getISTDateOnly, getISTMonthRange, getISTDayRange } = require('../utils/date');
const { createAuditLog } = require('../utils/audit');

const router = express.Router();

router.use(authenticate, requireGymAccess());

const ensureTrainerAccess = async (req, trainerId) => {
  const trainer = await prisma.trainerProfile.findUnique({
    where: { id: trainerId },
    include: {
      user: {
        select: {
          id: true,
          email: true,
          fullName: true,
          mobile: true,
          profilePhoto: true,
          isActive: true,
          lastLoginAt: true,
        },
      },
      branch: true,
      assignedCustomers: {
        where: { isActive: true },
        include: {
          user: { select: { id: true, fullName: true, mobile: true, email: true, profilePhoto: true } },
        },
      },
      appointments: {
        orderBy: { date: 'desc' },
        take: 15,
        include: {
          customer: { include: { user: { select: { id: true, fullName: true } } } },
        },
      },
      _count: { select: { assignedCustomers: true, workoutPlans: true, dietPlans: true, appointments: true } },
    },
  });

  if (!trainer) return { error: 'Trainer not found', status: 404 };
  if (req.gymId && trainer.gymId !== req.gymId) {
    return { error: 'Access denied: trainer belongs to another gym', status: 403 };
  }
  if (req.user.role === 'TRAINER' && req.trainerProfile?.id !== trainer.id) {
    return { error: 'Access denied: trainers can only access their own data', status: 403 };
  }
  return { trainer };
};

// Static portal & invite routes BEFORE /:id

// GET /api/trainers/portal/dashboard
router.get('/portal/dashboard', authorize('TRAINER'), async (req, res, next) => {
  try {
    const trainerId = req.trainerProfile.id;
    const gymId = req.gymId;
    const todayRange = getISTDayRange();

    const [assignedCustomers, todaySchedule, todayCheckIns] = await Promise.all([
      prisma.customerProfile.findMany({
        where: { gymId, assignedTrainerId: trainerId, isActive: true },
        include: {
          user: { select: { id: true, fullName: true, mobile: true, email: true, profilePhoto: true } },
          memberships: { take: 1, orderBy: { createdAt: 'desc' }, include: { plan: true } },
        },
      }),
      prisma.appointment.findMany({
        where: {
          gymId,
          trainerId,
          date: { gte: todayRange.start, lte: todayRange.end },
          status: { not: 'CANCELLED' },
        },
        orderBy: { startTime: 'asc' },
        include: {
          customer: { include: { user: { select: { id: true, fullName: true, mobile: true } } } },
        },
      }),
      prisma.attendance.count({
        where: {
          gymId,
          status: 'PRESENT',
          date: { gte: todayRange.start, lte: todayRange.end },
          customer: { assignedTrainerId: trainerId },
        },
      }),
    ]);

    return sendSuccess(
      res,
      {
        stats: {
          assignedCustomers: assignedCustomers.length,
          todaySessions: todaySchedule.length,
          todayCheckIns,
        },
        todaySchedule: todaySchedule.map((s) => ({
          ...s,
          time: s.startTime,
          customer: s.customer ? formatCustomer(s.customer) : null,
          customerName: s.customer?.user?.fullName || null,
        })),
        customers: assignedCustomers.map(formatCustomer),
      },
      'Trainer dashboard fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/trainers/portal/customers
router.get('/portal/customers', authorize('TRAINER'), async (req, res, next) => {
  try {
    const trainerId = req.trainerProfile.id;
    const gymId = req.gymId;
    const { search } = req.query;

    const where = { gymId, assignedTrainerId: trainerId, isActive: true };
    if (search) {
      where.OR = [
        { customerId: { contains: search } },
        { user: { fullName: { contains: search } } },
        { user: { mobile: { contains: search } } },
      ];
    }

    const customers = await prisma.customerProfile.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: {
        user: { select: { id: true, fullName: true, email: true, mobile: true, profilePhoto: true, isActive: true } },
        memberships: { take: 1, orderBy: { createdAt: 'desc' }, include: { plan: true } },
      },
    });

    return sendSuccess(res, customers.map(formatCustomer), 'Trainer assigned customers fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/trainers/portal/schedule
router.get('/portal/schedule', authorize('TRAINER'), async (req, res, next) => {
  try {
    const appointments = await prisma.appointment.findMany({
      where: { gymId: req.gymId, trainerId: req.trainerProfile.id },
      orderBy: [{ date: 'asc' }, { startTime: 'asc' }],
      include: {
        customer: { include: { user: { select: { id: true, fullName: true, mobile: true } } } },
        bookings: {
          where: { status: 'CONFIRMED' },
          include: { customer: { include: { user: { select: { id: true, fullName: true } } } } },
        },
      },
    });

    const formatted = appointments.map((a) => ({
      ...a,
      time: a.startTime,
      customer: a.customer ? formatCustomer(a.customer) : null,
      customerName: a.customer?.user?.fullName || null,
    }));

    return sendSuccess(res, formatted, 'Trainer schedule fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/trainers/invite
router.post('/invite', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const code = `GYM-TRN-${Math.floor(1000 + Math.random() * 9000)}`;
    const invite = await prisma.trainerInvite.create({
      data: {
        gymId,
        branchId: req.body.branchId || null,
        code,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });

    return sendSuccess(res, { ...invite, inviteCode: invite.code }, 'Trainer invitation generated', 201);
  } catch (err) {
    next(err);
  }
});

// GET /api/trainers
router.get('/', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN', 'CUSTOMER'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId && req.user.role !== 'SUPER_ADMIN') {
      return sendError(res, 'gymId is required', 400);
    }

    const { page, limit, skip } = getPagination(req.query);
    const { search, branchId, isActive } = req.query;

    const where = {};
    if (gymId) where.gymId = gymId;
    if (branchId && branchId !== 'ALL') where.branchId = branchId;
    if (isActive !== undefined) where.isActive = isActive === 'true';
    if (search) {
      where.OR = [
        { trainerId: { contains: search } },
        { specialization: { contains: search } },
        { user: { fullName: { contains: search } } },
        { user: { email: { contains: search } } },
        { user: { mobile: { contains: search } } },
      ];
    }

    const [trainers, total] = await Promise.all([
      prisma.trainerProfile.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          user: {
            select: { id: true, email: true, fullName: true, mobile: true, profilePhoto: true, isActive: true },
          },
          branch: { select: { id: true, name: true } },
          _count: { select: { assignedCustomers: true } },
        },
      }),
      prisma.trainerProfile.count({ where }),
    ]);

    return sendSuccess(res, formatPaginatedData(trainers.map(formatTrainer), total, page, limit), 'Trainers fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/trainers
router.post('/', authorize('GYM_OWNER', 'SUPER_ADMIN'), [validate], async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const {
      email,
      password,
      fullName,
      name,
      mobile,
      branchId,
      specialization,
      experience,
      experienceYears = 0,
      joiningDate,
      salary,
      baseSalary = 0,
      commission,
      commissionPercent = 0,
      certifications,
      shiftTiming,
      bio,
    } = req.body;

    const resolvedName = (fullName || name || '').trim();
    if (!resolvedName) return sendError(res, 'Full name is required', 400);

    const formattedMobile = canonicalMobile(mobile);
    if (!formattedMobile) return sendError(res, 'Mobile number is compulsory', 400);

    const activeSub = await prisma.gymSubscription.findFirst({
      where: { gymId, status: { in: ['ACTIVE', 'TRIAL', 'GRACE'] } },
      orderBy: { createdAt: 'desc' },
      include: { plan: true },
    });

    if (activeSub?.plan) {
      const count = await prisma.trainerProfile.count({ where: { gymId, isActive: true } });
      if (count >= activeSub.plan.maxTrainers) {
        return sendError(
          res,
          `Trainer limit (${activeSub.plan.maxTrainers}) reached for your current subscription plan`,
          403
        );
      }
    }

    const resolvedEmail = (
      email || `trainer.${formattedMobile.replace(/\D/g, '')}.${Date.now().toString().slice(-4)}@gympro.local`
    )
      .toLowerCase()
      .trim();

    const mobileCandidates = normalizeMobileCandidates(mobile);
    const [existingEmail, existingMobile] = await Promise.all([
      prisma.user.findUnique({ where: { email: resolvedEmail } }),
      prisma.user.findFirst({ where: { mobile: { in: mobileCandidates } } }),
    ]);
    if (existingEmail) return sendError(res, 'Email already registered', 409);
    if (existingMobile) return sendError(res, 'Mobile already registered', 409);

    const hashedPassword = await bcrypt.hash(password || 'Trainer@123', 10);

    const created = await prisma.$transaction(async (tx) => {
      const user = await tx.user.create({
        data: {
          email: resolvedEmail,
          password: hashedPassword,
          fullName: resolvedName,
          mobile: formattedMobile,
          role: 'TRAINER',
          isActive: true,
          isVerified: true,
          mobileVerified: true,
        },
      });

      return tx.trainerProfile.create({
        data: {
          userId: user.id,
          gymId,
          branchId: branchId || null,
          trainerId: generateReadableId('TRN'),
          specialization: specialization || 'General Fitness',
          experience: parseInt(experience ?? experienceYears ?? 0, 10) || 0,
          joiningDate: joiningDate ? new Date(joiningDate) : new Date(),
          salary: Number(salary ?? baseSalary ?? 0) || 0,
          commission: Number(commission ?? commissionPercent ?? 0) || 0,
          certifications: certifications || null,
          shiftTiming: shiftTiming || null,
          bio: bio || null,
        },
        include: {
          user: {
            select: { id: true, email: true, fullName: true, mobile: true, profilePhoto: true, isActive: true },
          },
          branch: true,
        },
      });
    });

    await createAuditLog({
      userId: req.user.id,
      gymId,
      action: 'CREATE_TRAINER',
      entity: 'TrainerProfile',
      entityId: created.id,
      details: { trainerId: created.trainerId, email: resolvedEmail },
      req,
    });

    return sendSuccess(res, formatTrainer(created), 'Trainer created successfully', 201);
  } catch (err) {
    next(err);
  }
});

// GET /api/trainers/:id
router.get('/:id', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const check = await ensureTrainerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const formatted = formatTrainer(check.trainer);
    formatted.appointments = (check.trainer.appointments || []).map((a) => ({
      ...a,
      customer: a.customer ? formatCustomer(a.customer) : null,
    }));
    return sendSuccess(res, formatted, 'Trainer retrieved');
  } catch (err) {
    next(err);
  }
});

// PUT /api/trainers/:id
router.put('/:id', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const check = await ensureTrainerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const {
      fullName,
      name,
      mobile,
      branchId,
      specialization,
      experience,
      experienceYears,
      salary,
      baseSalary,
      commission,
      commissionPercent,
      certifications,
      shiftTiming,
      bio,
      isActive,
    } = req.body;

    const resolvedName = fullName !== undefined ? fullName : name;
    const resolvedExp = experience !== undefined ? experience : experienceYears;
    const resolvedSalary = salary !== undefined ? salary : baseSalary;
    const resolvedCommission = commission !== undefined ? commission : commissionPercent;

    const updated = await prisma.$transaction(async (tx) => {
      if (resolvedName !== undefined || mobile !== undefined || isActive !== undefined) {
        await tx.user.update({
          where: { id: check.trainer.userId },
          data: {
            ...(resolvedName !== undefined && { fullName: resolvedName }),
            ...(mobile !== undefined && { mobile: canonicalMobile(mobile) || null }),
            ...(isActive !== undefined && { isActive: Boolean(isActive) }),
          },
        });
      }

      return tx.trainerProfile.update({
        where: { id: check.trainer.id },
        data: {
          ...(branchId !== undefined && { branchId: branchId || null }),
          ...(specialization !== undefined && { specialization }),
          ...(resolvedExp !== undefined && { experience: parseInt(resolvedExp, 10) || 0 }),
          ...(resolvedSalary !== undefined && { salary: Number(resolvedSalary) || 0 }),
          ...(resolvedCommission !== undefined && { commission: Number(resolvedCommission) || 0 }),
          ...(certifications !== undefined && { certifications }),
          ...(shiftTiming !== undefined && { shiftTiming }),
          ...(bio !== undefined && { bio }),
          ...(isActive !== undefined && { isActive: Boolean(isActive) }),
        },
        include: {
          user: {
            select: { id: true, email: true, fullName: true, mobile: true, profilePhoto: true, isActive: true },
          },
          branch: true,
        },
      });
    });

    await createAuditLog({
      userId: req.user.id,
      gymId: check.trainer.gymId,
      action: 'UPDATE_TRAINER',
      entity: 'TrainerProfile',
      entityId: updated.id,
      req,
    });

    return sendSuccess(res, formatTrainer(updated), 'Trainer updated successfully');
  } catch (err) {
    next(err);
  }
});

// DELETE /api/trainers/:id
router.delete('/:id', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const check = await ensureTrainerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    await prisma.$transaction([
      prisma.trainerProfile.update({
        where: { id: check.trainer.id },
        data: { isActive: false },
      }),
      prisma.user.update({
        where: { id: check.trainer.userId },
        data: { isActive: false },
      }),
    ]);

    return sendSuccess(res, null, 'Trainer deactivated successfully');
  } catch (err) {
    next(err);
  }
});

// GET /api/trainers/:id/customers
router.get('/:id/customers', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const check = await ensureTrainerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const { page, limit, skip } = getPagination(req.query);
    const where = { assignedTrainerId: check.trainer.id, isActive: true };

    const [customers, total] = await Promise.all([
      prisma.customerProfile.findMany({
        where,
        skip,
        take: limit,
        include: {
          user: { select: { id: true, fullName: true, email: true, mobile: true, profilePhoto: true } },
          memberships: { take: 1, orderBy: { createdAt: 'desc' }, include: { plan: true } },
        },
      }),
      prisma.customerProfile.count({ where }),
    ]);

    return sendSuccess(
      res,
      formatPaginatedData(customers.map(formatCustomer), total, page, limit),
      'Assigned customers fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/trainers/:id/schedule
router.get('/:id/schedule', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const check = await ensureTrainerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const where = { trainerId: check.trainer.id };
    if (req.query.startDate && req.query.endDate) {
      where.date = {
        gte: new Date(req.query.startDate),
        lte: new Date(req.query.endDate),
      };
    }

    const appointments = await prisma.appointment.findMany({
      where,
      orderBy: [{ date: 'asc' }, { startTime: 'asc' }],
      include: {
        customer: { include: { user: { select: { fullName: true, mobile: true } } } },
        bookings: {
          include: { customer: { include: { user: { select: { fullName: true } } } } },
        },
      },
    });

    return sendSuccess(res, appointments, 'Trainer schedule fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/trainers/:id/attendance
router.get('/:id/attendance', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const check = await ensureTrainerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const { page, limit, skip } = getPagination(req.query);
    const where = { trainerId: check.trainer.id };
    if (req.query.month && req.query.year) {
      const range = getISTMonthRange(req.query.month, req.query.year);
      where.date = { gte: range.dateOnlyStart, lte: range.dateOnlyEnd };
    }

    const [attendance, total] = await Promise.all([
      prisma.trainerAttendance.findMany({
        where,
        skip,
        take: limit,
        orderBy: { date: 'desc' },
      }),
      prisma.trainerAttendance.count({ where }),
    ]);

    return sendSuccess(res, formatPaginatedData(attendance, total, page, limit), 'Trainer attendance fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/trainers/:id/attendance
router.post('/:id/attendance', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const check = await ensureTrainerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const { date, status = 'PRESENT', action } = req.body;
    const targetDate = getISTDateOnly(date);
    const now = new Date();

    const record = await prisma.trainerAttendance.upsert({
      where: {
        gymId_trainerId_date: {
          gymId: check.trainer.gymId,
          trainerId: check.trainer.id,
          date: targetDate,
        },
      },
      update: {
        status,
        ...(action === 'CHECK_OUT' ? { checkOutTime: now } : { checkInTime: now }),
      },
      create: {
        gymId: check.trainer.gymId,
        trainerId: check.trainer.id,
        date: targetDate,
        status,
        checkInTime: status === 'PRESENT' || status === 'HALF_DAY' ? now : null,
      },
    });

    return sendSuccess(res, record, 'Trainer attendance recorded');
  } catch (err) {
    next(err);
  }
});

// GET /api/trainers/:id/salary
router.get('/:id/salary', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const check = await ensureTrainerAccess(req, req.params.id);
    if (check.error) return sendError(res, check.error, check.status);

    const salaries = await prisma.salary.findMany({
      where: { trainerId: check.trainer.id },
      orderBy: [{ year: 'desc' }, { month: 'desc' }],
    });

    return sendSuccess(
      res,
      {
        baseSalary: check.trainer.salary,
        commissionRate: check.trainer.commission,
        history: salaries,
      },
      'Trainer salary info fetched'
    );
  } catch (err) {
    next(err);
  }
});

module.exports = router;

const express = require('express');
const bcrypt = require('bcryptjs');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const { generateReadableId, canonicalMobile, normalizeMobileCandidates, formatCustomer } = require('../utils/json');
const { createAuditLog } = require('../utils/audit');
const { createNotification } = require('../utils/notification');

const router = express.Router();

router.use(authenticate, requireGymAccess(), authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'));

const formatEnquiry = (e) => ({
  ...e,
  phone: e.mobile,
  interestedPlan: e.interestedPlan || null,
});

// GET /api/enquiries/stats
router.get('/stats', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const enquiries = await prisma.enquiry.findMany({ where: { gymId } });
    const byStatus = { NEW: 0, CONTACTED: 0, FOLLOW_UP: 0, CONVERTED: 0, LOST: 0 };
    for (const e of enquiries) {
      byStatus[e.status] = (byStatus[e.status] || 0) + 1;
    }

    const total = enquiries.length;
    const conversionRate = total > 0 ? Math.round((byStatus.CONVERTED / total) * 1000) / 10 : 0;

    return sendSuccess(res, { total, conversionRate, byStatus }, 'Enquiry stats fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/enquiries
router.get('/', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { page, limit, skip } = getPagination(req.query);
    const { status, source, search } = req.query;

    const where = { gymId };
    if (status) where.status = String(status).toUpperCase();
    if (source) where.source = source;
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { mobile: { contains: search } },
        { email: { contains: search } },
      ];
    }

    const [enquiries, total] = await Promise.all([
      prisma.enquiry.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      prisma.enquiry.count({ where }),
    ]);

    return sendSuccess(
      res,
      formatPaginatedData(enquiries.map(formatEnquiry), total, page, limit),
      'Enquiries fetched'
    );
  } catch (err) {
    next(err);
  }
});

// POST /api/enquiries
router.post(
  '/',
  [
    body('name').trim().notEmpty().withMessage('Name is required'),
    body().custom((val) => {
      if (!val.mobile && !val.phone) throw new Error('Mobile number is required');
      return true;
    }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const {
        name,
        mobile,
        phone,
        email,
        source = 'WALK_IN',
        status = 'NEW',
        interestedPlan,
        notes,
        followUpDate,
        assignedTo,
      } = req.body;

      const normalizedMobile = canonicalMobile(mobile || phone);

      const enquiry = await prisma.enquiry.create({
        data: {
          gymId,
          name: name.trim(),
          mobile: normalizedMobile,
          email: email?.trim() || null,
          source,
          status: String(status).toUpperCase(),
          interestedPlan: interestedPlan || null,
          notes: notes || null,
          followUpDate: followUpDate ? new Date(followUpDate) : null,
          assignedTo: assignedTo || null,
        },
      });

      return sendSuccess(res, formatEnquiry(enquiry), 'Enquiry created', 201);
    } catch (err) {
      next(err);
    }
  }
);

// PUT /api/enquiries/:id
router.put('/:id', async (req, res, next) => {
  try {
    const existing = await prisma.enquiry.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Enquiry not found', 404);

    const updated = await prisma.enquiry.update({
      where: { id: existing.id },
      data: {
        name: req.body.name ?? existing.name,
        mobile: req.body.mobile || req.body.phone ? canonicalMobile(req.body.mobile || req.body.phone) : existing.mobile,
        email: req.body.email !== undefined ? req.body.email || null : existing.email,
        source: req.body.source ?? existing.source,
        status: req.body.status ? String(req.body.status).toUpperCase() : existing.status,
        interestedPlan: req.body.interestedPlan !== undefined ? req.body.interestedPlan : existing.interestedPlan,
        notes: req.body.notes !== undefined ? req.body.notes : existing.notes,
        followUpDate: req.body.followUpDate ? new Date(req.body.followUpDate) : existing.followUpDate,
        assignedTo: req.body.assignedTo !== undefined ? req.body.assignedTo : existing.assignedTo,
      },
    });

    return sendSuccess(res, formatEnquiry(updated), 'Enquiry updated');
  } catch (err) {
    next(err);
  }
});

// PATCH /api/enquiries/:id/status
router.patch('/:id/status', async (req, res, next) => {
  try {
    const existing = await prisma.enquiry.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Enquiry not found', 404);
    if (!req.body.status) return sendError(res, 'status is required', 400);

    const updated = await prisma.enquiry.update({
      where: { id: existing.id },
      data: {
        status: String(req.body.status).toUpperCase(),
        ...(req.body.notes !== undefined ? { notes: req.body.notes } : {}),
      },
    });

    return sendSuccess(res, formatEnquiry(updated), 'Enquiry status updated');
  } catch (err) {
    next(err);
  }
});

const convertEnquiryHandler = async (req, res, next) => {
  try {
    const enquiry = await prisma.enquiry.findUnique({ where: { id: req.params.id } });
    if (!enquiry || enquiry.gymId !== req.gymId) return sendError(res, 'Enquiry not found', 404);
    if (enquiry.status === 'CONVERTED') {
      return sendError(res, 'Enquiry has already been converted', 400);
    }

    const mobile = canonicalMobile(enquiry.mobile);
    const existingUser = await prisma.user.findFirst({
      where: { mobile: { in: normalizeMobileCandidates(mobile) } },
    });
    if (existingUser) {
      return sendError(res, 'A user with this mobile number already exists in the platform', 409);
    }

    const passwordHash = await bcrypt.hash(req.body.password || 'Password@123', 10);
    const customerCode = generateReadableId('CUST');

    const createdCustomer = await prisma.$transaction(async (tx) => {
      const user = await tx.user.create({
        data: {
          fullName: enquiry.name,
          mobile,
          email: enquiry.email || null,
          password: passwordHash,
          role: 'CUSTOMER',
          isActive: true,
          isVerified: true,
          mobileVerified: true,
        },
      });

      const customer = await tx.customerProfile.create({
        data: {
          userId: user.id,
          gymId: enquiry.gymId,
          branchId: req.body.branchId || null,
          customerId: customerCode,
          isActive: true,
        },
        include: { user: true },
      });

      await tx.enquiry.update({
        where: { id: enquiry.id },
        data: { status: 'CONVERTED' },
      });

      return customer;
    });

    await createNotification({
      userId: createdCustomer.userId,
      gymId: enquiry.gymId,
      type: 'WELCOME',
      title: 'Welcome to the Gym!',
      message: `Your enquiry was converted into an active customer profile (${customerCode}).`,
    });

    await createAuditLog({
      userId: req.user.id,
      gymId: enquiry.gymId,
      action: 'ENQUIRY_CONVERTED',
      entity: 'Enquiry',
      entityId: enquiry.id,
      details: { customerId: createdCustomer.id, customerCode },
      ipAddress: req.ip,
    });

    return sendSuccess(
      res,
      { enquiryId: enquiry.id, customer: formatCustomer(createdCustomer) },
      'Enquiry converted to customer',
      201
    );
  } catch (err) {
    next(err);
  }
};

router.post('/:id/convert', convertEnquiryHandler);
router.put('/:id/convert', convertEnquiryHandler);

// DELETE /api/enquiries/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const existing = await prisma.enquiry.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Enquiry not found', 404);

    await prisma.enquiry.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'Enquiry deleted');
  } catch (err) {
    next(err);
  }
});

module.exports = router;

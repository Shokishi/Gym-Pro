const express = require('express');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const { createAuditLog } = require('../utils/audit');

const router = express.Router();

router.use(authenticate, requireGymAccess(), authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'));

const formatEquipment = (e) => ({
  ...e,
  brand: e.supplier || '',
  purchaseCost: e.cost ?? 0,
  status: e.condition || 'GOOD',
});

// GET /api/equipment/maintenance-due
router.get('/maintenance-due', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const upcomingDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    const items = await prisma.equipment.findMany({
      where: {
        gymId,
        OR: [
          { nextMaintenanceDate: { lte: upcomingDate } },
          { condition: { in: ['NEEDS_REPAIR', 'UNDER_MAINTENANCE', 'OUT_OF_ORDER', 'DAMAGED', 'MAINTENANCE'] } },
        ],
      },
      orderBy: { nextMaintenanceDate: 'asc' },
    });

    return sendSuccess(res, items.map(formatEquipment), 'Maintenance due equipment fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/equipment
router.get('/', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { page, limit, skip } = getPagination(req.query);
    const { category, condition, status, branchId, search } = req.query;

    const where = { gymId };
    if (category) where.category = category;
    if (condition || status) where.condition = String(condition || status).toUpperCase();
    if (branchId) where.branchId = branchId;
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { category: { contains: search } },
        { supplier: { contains: search } },
      ];
    }

    const [items, total] = await Promise.all([
      prisma.equipment.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
      }),
      prisma.equipment.count({ where }),
    ]);

    return sendSuccess(
      res,
      formatPaginatedData(items.map(formatEquipment), total, page, limit),
      'Equipment fetched'
    );
  } catch (err) {
    next(err);
  }
});

// POST /api/equipment
router.post(
  '/',
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  [
    body('name').trim().notEmpty().withMessage('Equipment name is required'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const {
        name,
        category = 'GENERAL',
        quantity = 1,
        purchaseDate,
        cost,
        purchaseCost,
        condition,
        status,
        supplier,
        brand,
        warrantyExpiry,
        lastMaintenanceDate,
        nextMaintenanceDate,
        notes,
        branchId,
      } = req.body;

      const equipment = await prisma.equipment.create({
        data: {
          gymId,
          branchId: branchId || null,
          name: name.trim(),
          category,
          quantity: parseInt(quantity, 10) || 1,
          purchaseDate: purchaseDate ? new Date(purchaseDate) : null,
          cost: cost != null || purchaseCost != null ? parseFloat(cost ?? purchaseCost) : null,
          condition: String(condition || status || 'OPERATIONAL').toUpperCase(),
          supplier: supplier || brand || null,
          warrantyExpiry: warrantyExpiry ? new Date(warrantyExpiry) : null,
          lastMaintenanceDate: lastMaintenanceDate ? new Date(lastMaintenanceDate) : null,
          nextMaintenanceDate: nextMaintenanceDate ? new Date(nextMaintenanceDate) : null,
          notes: notes || null,
        },
      });

      await createAuditLog({
        userId: req.user.id,
        gymId,
        action: 'EQUIPMENT_CREATED',
        entity: 'Equipment',
        entityId: equipment.id,
        details: { name: equipment.name, quantity: equipment.quantity },
        ipAddress: req.ip,
      });

      return sendSuccess(res, formatEquipment(equipment), 'Equipment added', 201);
    } catch (err) {
      next(err);
    }
  }
);

// PUT /api/equipment/:id
router.put('/:id', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.equipment.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Equipment not found', 404);

    const updated = await prisma.equipment.update({
      where: { id: existing.id },
      data: {
        name: req.body.name ?? existing.name,
        category: req.body.category ?? existing.category,
        quantity: req.body.quantity != null ? parseInt(req.body.quantity, 10) : existing.quantity,
        purchaseDate: req.body.purchaseDate ? new Date(req.body.purchaseDate) : existing.purchaseDate,
        cost:
          req.body.cost !== undefined || req.body.purchaseCost !== undefined
            ? parseFloat(req.body.cost ?? req.body.purchaseCost) || 0
            : existing.cost,
        condition: req.body.condition || req.body.status
          ? String(req.body.condition || req.body.status).toUpperCase()
          : existing.condition,
        supplier: req.body.supplier !== undefined || req.body.brand !== undefined
          ? req.body.supplier ?? req.body.brand
          : existing.supplier,
        warrantyExpiry: req.body.warrantyExpiry ? new Date(req.body.warrantyExpiry) : existing.warrantyExpiry,
        lastMaintenanceDate: req.body.lastMaintenanceDate
          ? new Date(req.body.lastMaintenanceDate)
          : existing.lastMaintenanceDate,
        nextMaintenanceDate: req.body.nextMaintenanceDate
          ? new Date(req.body.nextMaintenanceDate)
          : existing.nextMaintenanceDate,
        notes: req.body.notes !== undefined ? req.body.notes : existing.notes,
        branchId: req.body.branchId !== undefined ? req.body.branchId || null : existing.branchId,
      },
    });

    return sendSuccess(res, formatEquipment(updated), 'Equipment updated');
  } catch (err) {
    next(err);
  }
});

// POST /api/equipment/:id/maintenance
router.post('/:id/maintenance', async (req, res, next) => {
  try {
    const existing = await prisma.equipment.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Equipment not found', 404);

    const maintenanceDate = req.body.date || req.body.lastMaintenanceDate
      ? new Date(req.body.date || req.body.lastMaintenanceDate)
      : new Date();
    const nextDate = req.body.nextMaintenanceDate
      ? new Date(req.body.nextMaintenanceDate)
      : new Date(maintenanceDate.getTime() + 90 * 24 * 60 * 60 * 1000);

    const maintenanceNotes = req.body.notes
      ? `${existing.notes ? `${existing.notes}\n` : ''}[${maintenanceDate.toISOString().slice(0, 10)}] ${req.body.notes}`
      : existing.notes;

    const updated = await prisma.equipment.update({
      where: { id: existing.id },
      data: {
        lastMaintenanceDate: maintenanceDate,
        nextMaintenanceDate: nextDate,
        condition: req.body.condition || req.body.status
          ? String(req.body.condition || req.body.status).toUpperCase()
          : 'OPERATIONAL',
        notes: maintenanceNotes,
      },
    });

    const maintenanceCost = parseFloat(req.body.cost || 0);
    if (maintenanceCost > 0) {
      await prisma.expense.create({
        data: {
          gymId: req.gymId,
          branchId: existing.branchId || null,
          category: 'REPAIRS',
          title: `Equipment Maintenance: ${existing.name}`,
          description: req.body.notes || `Maintenance for ${existing.name}`,
          amount: maintenanceCost,
          date: maintenanceDate,
          paymentMethod: 'CASH',
        },
      });
    }

    await createAuditLog({
      userId: req.user.id,
      gymId: req.gymId,
      action: 'EQUIPMENT_MAINTENANCE_LOGGED',
      entity: 'Equipment',
      entityId: existing.id,
      details: { notes: req.body.notes, cost: maintenanceCost, nextMaintenanceDate: nextDate },
      ipAddress: req.ip,
    });

    return sendSuccess(res, formatEquipment(updated), 'Maintenance logged');
  } catch (err) {
    next(err);
  }
});

// DELETE /api/equipment/:id
router.delete('/:id', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.equipment.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Equipment not found', 404);

    await prisma.equipment.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'Equipment deleted');
  } catch (err) {
    next(err);
  }
});

module.exports = router;

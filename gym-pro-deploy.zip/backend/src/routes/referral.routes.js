const express = require('express');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const { createNotification } = require('../utils/notification');
const { createAuditLog } = require('../utils/audit');

const router = express.Router();

router.use(authenticate, requireGymAccess());

const formatReferral = (r) => ({
  ...r,
  rewardAmount: r.rewardValue || 0,
  referrerName: r.referrer?.user?.fullName || '',
  referrerMobile: r.referrer?.user?.mobile || '',
  referrerCode: r.referrer?.customerId || '',
});

// GET /api/referrals/stats
router.get('/stats', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const referrals = await prisma.referral.findMany({
      where: { gymId },
      include: {
        referrer: {
          include: { user: { select: { id: true, fullName: true } } },
        },
      },
    });

    const total = referrals.length;
    const joined = referrals.filter((r) => r.status === 'JOINED' || r.status === 'CONVERTED').length;
    const rewardsIssued = referrals.filter((r) => r.rewardIssued).length;
    const totalRewardValue = referrals
      .filter((r) => r.rewardIssued)
      .reduce((sum, r) => sum + (r.rewardValue || 0), 0);

    const referrerMap = {};
    referrals.forEach((r) => {
      if (!referrerMap[r.referrerId]) {
        referrerMap[r.referrerId] = {
          referrerId: r.referrerId,
          customerId: r.referrer?.customerId,
          name: r.referrer?.user?.fullName || 'Unknown',
          totalReferred: 0,
          joinedCount: 0,
        };
      }
      referrerMap[r.referrerId].totalReferred += 1;
      if (r.status === 'JOINED' || r.status === 'CONVERTED') {
        referrerMap[r.referrerId].joinedCount += 1;
      }
    });

    const topReferrers = Object.values(referrerMap)
      .sort((a, b) => b.joinedCount - a.joinedCount || b.totalReferred - a.totalReferred)
      .slice(0, 10);

    return sendSuccess(
      res,
      {
        summary: {
          total,
          joined,
          pending: referrals.filter((r) => r.status === 'PENDING').length,
          rewardsIssued,
          totalRewardValue,
        },
        topReferrers,
      },
      'Referral stats fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/referrals
router.get('/', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { page, limit, skip } = getPagination(req.query);
    const { status, referrerId } = req.query;

    const where = { gymId };
    if (req.user.role === 'CUSTOMER') {
      const cust = req.customerProfile || (await prisma.customerProfile.findUnique({ where: { userId: req.user.id } }));
      if (!cust) return sendSuccess(res, formatPaginatedData([], 0, page, limit));
      where.referrerId = cust.id;
    } else if (referrerId) {
      where.referrerId = referrerId;
    }
    if (status) where.status = String(status).toUpperCase();

    const [referrals, total] = await Promise.all([
      prisma.referral.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          referrer: {
            include: { user: { select: { id: true, fullName: true, mobile: true } } },
          },
        },
      }),
      prisma.referral.count({ where }),
    ]);

    return sendSuccess(res, formatPaginatedData(referrals.map(formatReferral), total, page, limit), 'Referrals fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/referrals
router.post(
  '/',
  [
    body('referredName').trim().notEmpty().withMessage('Referred person name is required'),
    body().custom((val) => {
      if (!val.referredMobile && !val.referredPhone) throw new Error('Referred mobile number is required');
      return true;
    }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      let {
        referrerId,
        referredName,
        referredMobile,
        referredPhone,
        status = 'PENDING',
        rewardType = 'DISCOUNT',
        rewardValue,
        rewardAmount,
      } = req.body;

      if (req.user.role === 'CUSTOMER') {
        const cust = req.customerProfile || (await prisma.customerProfile.findUnique({ where: { userId: req.user.id } }));
        if (!cust) return sendError(res, 'Customer profile not found', 404);
        referrerId = cust.id;
        status = 'PENDING';
      }
      if (!referrerId) return sendError(res, 'referrerId is required', 400);

      const referrer = await prisma.customerProfile.findUnique({ where: { id: referrerId } });
      if (!referrer || referrer.gymId !== gymId) {
        return sendError(res, 'Referrer customer not found in this gym', 404);
      }

      const referral = await prisma.referral.create({
        data: {
          gymId,
          referrerId,
          referredName: referredName.trim(),
          referredMobile: (referredMobile || referredPhone).trim(),
          status: String(status).toUpperCase(),
          rewardType,
          rewardValue: Number(rewardValue ?? rewardAmount ?? 0) || 0,
        },
        include: {
          referrer: { include: { user: { select: { id: true, fullName: true, mobile: true } } } },
        },
      });

      return sendSuccess(res, formatReferral(referral), 'Referral created successfully', 201);
    } catch (err) {
      next(err);
    }
  }
);

// PATCH /api/referrals/:id/status
router.patch('/:id/status', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.referral.findUnique({ where: { id: req.params.id } });
    if (!existing || (req.gymId && existing.gymId !== req.gymId)) {
      return sendError(res, 'Referral not found', 404);
    }

    const updated = await prisma.referral.update({
      where: { id: existing.id },
      data: {
        ...(req.body.status ? { status: String(req.body.status).toUpperCase() } : {}),
        ...(req.body.rewardAmount != null || req.body.rewardValue != null
          ? { rewardValue: Number(req.body.rewardAmount ?? req.body.rewardValue) || 0 }
          : {}),
      },
      include: {
        referrer: { include: { user: { select: { id: true, fullName: true, mobile: true } } } },
      },
    });

    return sendSuccess(res, formatReferral(updated), 'Referral status updated');
  } catch (err) {
    next(err);
  }
});

// PATCH /api/referrals/:id/reward
router.patch('/:id/reward', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.referral.findUnique({
      where: { id: req.params.id },
      include: { referrer: { include: { user: true } } },
    });
    if (!existing || (req.gymId && existing.gymId !== req.gymId)) {
      return sendError(res, 'Referral not found', 404);
    }

    const updated = await prisma.referral.update({
      where: { id: existing.id },
      data: {
        rewardIssued: true,
        rewardType: req.body.rewardType || existing.rewardType,
        rewardValue:
          req.body.rewardAmount != null || req.body.rewardValue != null
            ? Number(req.body.rewardAmount ?? req.body.rewardValue) || 0
            : existing.rewardValue,
      },
      include: {
        referrer: { include: { user: { select: { id: true, fullName: true, mobile: true } } } },
      },
    });

    if (existing.referrer?.userId) {
      await createNotification({
        userId: existing.referrer.userId,
        gymId: existing.gymId,
        type: 'REFERRAL_REWARD',
        title: 'Referral Reward Issued!',
        message: `You received a ₹${updated.rewardValue} referral reward for referring ${existing.referredName}.`,
      });
    }

    await createAuditLog({
      userId: req.user.id,
      gymId: existing.gymId,
      action: 'REFERRAL_REWARD_ISSUED',
      entity: 'Referral',
      entityId: existing.id,
      details: { rewardValue: updated.rewardValue, rewardType: updated.rewardType },
      ipAddress: req.ip,
    });

    return sendSuccess(res, formatReferral(updated), 'Referral reward issued');
  } catch (err) {
    next(err);
  }
});

// PUT /api/referrals/:id
router.put('/:id', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.referral.findUnique({ where: { id: req.params.id } });
    if (!existing || (req.gymId && existing.gymId !== req.gymId)) {
      return sendError(res, 'Referral not found', 404);
    }

    const { referredName, referredMobile, status, rewardType, rewardValue, rewardAmount, rewardIssued } = req.body;
    const updated = await prisma.referral.update({
      where: { id: existing.id },
      data: {
        ...(referredName !== undefined && { referredName }),
        ...(referredMobile !== undefined && { referredMobile }),
        ...(status !== undefined && { status: String(status).toUpperCase() }),
        ...(rewardType !== undefined && { rewardType }),
        ...(rewardValue !== undefined || rewardAmount !== undefined
          ? { rewardValue: Number(rewardValue ?? rewardAmount) || 0 }
          : {}),
        ...(rewardIssued !== undefined && { rewardIssued: Boolean(rewardIssued) }),
      },
      include: {
        referrer: { include: { user: { select: { id: true, fullName: true, mobile: true } } } },
      },
    });

    return sendSuccess(res, formatReferral(updated), 'Referral updated');
  } catch (err) {
    next(err);
  }
});

// DELETE /api/referrals/:id
router.delete('/:id', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.referral.findUnique({ where: { id: req.params.id } });
    if (!existing || (req.gymId && existing.gymId !== req.gymId)) {
      return sendError(res, 'Referral not found', 404);
    }

    await prisma.referral.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'Referral deleted');
  } catch (err) {
    next(err);
  }
});

module.exports = router;

const express = require('express');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { upload, getUploadedFileUrl } = require('../middleware/upload');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const { formatPayment, generateReadableId, stringifyJson } = require('../utils/json');
const { dayjs, IST_TZ } = require('../utils/date');
const { createAuditLog } = require('../utils/audit');
const { createNotification } = require('../utils/notification');
const { emitPaymentNotification, emitMembershipStatusChange } = require('../socket');

const router = express.Router();

router.use(authenticate, requireGymAccess());

const formatQrSetting = (s) => {
  if (!s) return null;
  return {
    ...s,
    merchantName: s.accountHolderName || '',
    instructions: s.paymentInstructions || '',
    qrImageUrl: s.upiQrCodeImage || null,
  };
};

// ========================
// QR Payment Settings (placed before /:id routes)
// ========================

// GET /api/payments/qr-settings
router.get('/qr-settings', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const where = { gymId };
    if (req.query.branchId && req.query.branchId !== 'ALL') where.branchId = req.query.branchId;
    if (req.user.role === 'CUSTOMER') where.isActive = true;

    const settings = await prisma.qRPaymentSetting.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: { branch: { select: { id: true, name: true } } },
    });

    const formattedList = settings.map(formatQrSetting);
    const primary = formattedList.find((s) => s.isActive) || formattedList[0] || {
      upiId: '',
      merchantName: req.gym?.name || '',
      instructions: 'Scan QR and share your UTR reference.',
      qrImageUrl: null,
    };

    // Return primary QR fields directly PLUS settings array so both single-object & multi-branch consumers work seamlessly
    return sendSuccess(
      res,
      {
        ...primary,
        settings: formattedList,
      },
      'QR payment settings fetched'
    );
  } catch (err) {
    next(err);
  }
});

// PUT /api/payments/qr-settings (Upsert primary QR setting without requiring :id)
router.put(
  '/qr-settings',
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  upload.fields([
    { name: 'qrImage', maxCount: 1 },
    { name: 'upiQrCodeImage', maxCount: 1 },
  ]),
  [body('upiId').trim().notEmpty().withMessage('UPI ID is required'), validate],
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const {
        id,
        branchId,
        upiId,
        accountHolderName,
        merchantName,
        paymentInstructions,
        instructions,
        isActive = true,
      } = req.body;

      const uploadedFile = req.files?.qrImage?.[0] || req.files?.upiQrCodeImage?.[0];
      const upiQrCodeImage = uploadedFile
        ? getUploadedFileUrl(uploadedFile)
        : req.body.upiQrCodeImage || req.body.qrImageUrl || undefined;

      const resolvedHolder = accountHolderName !== undefined ? accountHolderName : merchantName;
      const resolvedInstructions =
        paymentInstructions !== undefined ? paymentInstructions : instructions;

      const existing = id
        ? await prisma.qRPaymentSetting.findUnique({ where: { id } })
        : await prisma.qRPaymentSetting.findFirst({
            where: { gymId, ...(branchId ? { branchId } : {}) },
            orderBy: { createdAt: 'desc' },
          });

      const saved = existing
        ? await prisma.qRPaymentSetting.update({
            where: { id: existing.id },
            data: {
              ...(branchId !== undefined && { branchId: branchId || null }),
              upiId: upiId.trim(),
              ...(resolvedHolder !== undefined && { accountHolderName: resolvedHolder }),
              ...(resolvedInstructions !== undefined && { paymentInstructions: resolvedInstructions }),
              ...(upiQrCodeImage !== undefined && { upiQrCodeImage }),
              isActive: isActive === true || isActive === 'true',
            },
          })
        : await prisma.qRPaymentSetting.create({
            data: {
              gymId,
              branchId: branchId || null,
              upiId: upiId.trim(),
              accountHolderName: resolvedHolder || null,
              paymentInstructions: resolvedInstructions || null,
              upiQrCodeImage: upiQrCodeImage || null,
              isActive: isActive === true || isActive === 'true',
            },
          });

      return sendSuccess(res, formatQrSetting(saved), 'QR payment settings saved');
    } catch (err) {
      next(err);
    }
  }
);

// POST /api/payments/qr-settings
router.post(
  '/qr-settings',
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  upload.single('upiQrCodeImage'),
  [body('upiId').trim().notEmpty().withMessage('UPI ID is required'), validate],
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const { branchId, upiId, accountHolderName, merchantName, paymentInstructions, instructions, isActive = true } =
        req.body;
      const upiQrCodeImage = req.file ? getUploadedFileUrl(req.file) : req.body.upiQrCodeImage || null;

      const setting = await prisma.qRPaymentSetting.create({
        data: {
          gymId,
          branchId: branchId || null,
          upiId: upiId.trim(),
          upiQrCodeImage,
          accountHolderName: accountHolderName || merchantName || null,
          paymentInstructions: paymentInstructions || instructions || null,
          isActive: isActive === true || isActive === 'true',
        },
      });

      return sendSuccess(res, formatQrSetting(setting), 'QR payment setting created', 201);
    } catch (err) {
      next(err);
    }
  }
);

// PUT /api/payments/qr-settings/:id
router.put(
  '/qr-settings/:id',
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  upload.single('upiQrCodeImage'),
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      const existing = await prisma.qRPaymentSetting.findUnique({ where: { id: req.params.id } });
      if (!existing || (gymId && existing.gymId !== gymId)) {
        return sendError(res, 'QR payment setting not found', 404);
      }

      const { branchId, upiId, accountHolderName, merchantName, paymentInstructions, instructions, isActive } =
        req.body;
      const upiQrCodeImage = req.file ? getUploadedFileUrl(req.file) : req.body.upiQrCodeImage;
      const resolvedHolder = accountHolderName !== undefined ? accountHolderName : merchantName;
      const resolvedInstructions =
        paymentInstructions !== undefined ? paymentInstructions : instructions;

      const updated = await prisma.qRPaymentSetting.update({
        where: { id: existing.id },
        data: {
          ...(branchId !== undefined && { branchId: branchId || null }),
          ...(upiId !== undefined && { upiId: upiId.trim() }),
          ...(resolvedHolder !== undefined && { accountHolderName: resolvedHolder }),
          ...(resolvedInstructions !== undefined && { paymentInstructions: resolvedInstructions }),
          ...(upiQrCodeImage !== undefined && { upiQrCodeImage }),
          ...(isActive !== undefined && { isActive: isActive === true || isActive === 'true' }),
        },
      });

      return sendSuccess(res, formatQrSetting(updated), 'QR payment setting updated');
    } catch (err) {
      next(err);
    }
  }
);

// DELETE /api/payments/qr-settings/:id
router.delete('/qr-settings/:id', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    const existing = await prisma.qRPaymentSetting.findUnique({ where: { id: req.params.id } });
    if (!existing || (gymId && existing.gymId !== gymId)) {
      return sendError(res, 'QR payment setting not found', 404);
    }

    await prisma.qRPaymentSetting.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'QR payment setting deleted');
  } catch (err) {
    next(err);
  }
});

// ========================
// Customer Self & Static Routes BEFORE /:id
// ========================

// GET /api/payments/me
router.get('/me', authorize('CUSTOMER'), async (req, res, next) => {
  try {
    const { page, limit, skip } = getPagination(req.query);
    const where = { customerId: req.customerProfile.id };
    const [payments, total] = await Promise.all([
      prisma.payment.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          customer: { include: { user: { select: { id: true, fullName: true, mobile: true } } } },
          membership: { include: { plan: { select: { id: true, name: true } } } },
        },
      }),
      prisma.payment.count({ where }),
    ]);

    return sendSuccess(res, formatPaginatedData(payments.map(formatPayment), total, page, limit), 'My payments fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/payments/outstanding
router.get('/outstanding', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN', 'CUSTOMER'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const where = {
      gymId,
      status: { in: ['UNPAID', 'PARTIALLY_PAID'] },
    };
    if (req.user.role === 'CUSTOMER') {
      where.customerId = req.customerProfile.id;
    }

    const invoices = await prisma.invoice.findMany({
      where,
      orderBy: { dueDate: 'asc' },
      include: {
        customer: {
          include: { user: { select: { id: true, fullName: true, mobile: true, email: true } } },
        },
        membership: { include: { plan: { select: { name: true } } } },
      },
    });

    const dues = invoices.map((inv) => ({
      invoiceId: inv.id,
      invoiceNumber: inv.invoiceNumber,
      customer: inv.customer,
      membershipPlan: inv.membership?.plan?.name || null,
      total: inv.total,
      paidAmount: inv.paidAmount,
      outstandingAmount: Number(Math.max(0, inv.total - inv.paidAmount).toFixed(2)),
      status: inv.status,
      dueDate: inv.dueDate,
    }));

    const totalOutstanding = dues.reduce((sum, d) => sum + d.outstandingAmount, 0);

    return sendSuccess(res, { totalOutstanding, dues }, 'Outstanding dues fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/payments/refund
router.post(
  '/refund',
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  [body('paymentId').notEmpty().withMessage('paymentId is required'), validate],
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      const { paymentId, notes } = req.body;

      const payment = await prisma.payment.findUnique({
        where: { id: paymentId },
        include: { customer: true },
      });

      if (!payment || (gymId && payment.gymId !== gymId)) {
        return sendError(res, 'Payment not found', 404);
      }

      if (payment.status !== 'APPROVED') {
        return sendError(res, 'Only approved payments can be refunded', 400);
      }

      const refunded = await prisma.$transaction(async (tx) => {
        const updatedPayment = await tx.payment.update({
          where: { id: payment.id },
          data: {
            status: 'REFUNDED',
            notes: notes ? `${payment.notes ? payment.notes + ' | ' : ''}Refund: ${notes}` : payment.notes,
          },
        });

        if (payment.membershipId) {
          const mem = await tx.customerMembership.findUnique({ where: { id: payment.membershipId } });
          if (mem) {
            await tx.customerMembership.update({
              where: { id: mem.id },
              data: { totalPaid: Math.max(0, mem.totalPaid - payment.amount) },
            });
          }

          const inv = await tx.invoice.findFirst({ where: { membershipId: payment.membershipId } });
          if (inv) {
            const newPaid = Math.max(0, inv.paidAmount - payment.amount);
            await tx.invoice.update({
              where: { id: inv.id },
              data: {
                paidAmount: newPaid,
                status: newPaid === 0 ? 'UNPAID' : newPaid < inv.total ? 'PARTIALLY_PAID' : 'PAID',
              },
            });
          }
        }

        return updatedPayment;
      });

      const io = req.app.get('io');
      await createNotification({
        userId: payment.customer.userId,
        gymId: payment.gymId,
        type: 'PAYMENT_REFUND',
        title: 'Payment Refunded',
        message: `Your payment of ₹${payment.amount} has been refunded.`,
        data: { paymentId: payment.id },
        io,
      });

      emitPaymentNotification(io, payment.gymId, payment.customer.userId, {
        type: 'REFUNDED',
        payment: refunded,
      });

      await createAuditLog({
        userId: req.user.id,
        gymId: payment.gymId,
        action: 'REFUND_PAYMENT',
        entity: 'Payment',
        entityId: payment.id,
        details: { amount: payment.amount, notes },
        req,
      });

      return sendSuccess(res, refunded, 'Payment refunded successfully');
    } catch (err) {
      next(err);
    }
  }
);

// ========================
// Submit Payments (/submit, /me/submit, /)
// ========================

const submitPaymentHandler = async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    let {
      customerId,
      membershipId,
      planId,
      amount,
      paymentMethod = 'UPI',
      transactionRef,
      transactionId,
      notes,
      description,
      autoApprove = false,
      status: requestedStatus,
    } = req.body;

    const resolvedRef = (transactionRef || transactionId || '').trim() || null;
    const resolvedNotes = notes !== undefined ? notes : description;

    if (req.user.role === 'CUSTOMER') {
      customerId = req.customerProfile.id;
      autoApprove = false;
    }

    if (!customerId) return sendError(res, 'customerId is required', 400);

    // PART 9: Prevent duplicate transaction references
    if (resolvedRef) {
      const duplicate = await prisma.payment.findFirst({
        where: {
          gymId,
          transactionRef: resolvedRef,
          status: { not: 'REJECTED' },
        },
      });
      if (duplicate) {
        return sendError(res, `Duplicate transaction reference "${resolvedRef}" already exists`, 409);
      }
    }

    const customer = await prisma.customerProfile.findUnique({
      where: { id: customerId },
      include: { user: true },
    });
    if (!customer || customer.gymId !== gymId) {
      return sendError(res, 'Customer not found in this gym', 404);
    }

    const screenshotUrl = req.file ? getUploadedFileUrl(req.file) : req.body.screenshotUrl || null;
    const isAdminOrOwner = req.user.role === 'GYM_OWNER' || req.user.role === 'SUPER_ADMIN';
    const canAutoApprove =
      isAdminOrOwner &&
      (autoApprove === true || autoApprove === 'true' || requestedStatus === 'VERIFIED' || requestedStatus === 'APPROVED');

    // PART 9: Never treat a screenshot upload as confirmed payment
    const initialStatus = canAutoApprove ? 'APPROVED' : screenshotUrl ? 'UNDER_REVIEW' : 'PENDING';
    const parsedAmount = Number(amount);

    const payment = await prisma.$transaction(async (tx) => {
      let targetMembershipId = membershipId || null;

      // If customer selected a planId while paying, create a PENDING membership that only becomes ACTIVE upon owner approval
      if (planId && !targetMembershipId) {
        const plan = await tx.membershipPlan.findUnique({ where: { id: planId } });
        if (plan && plan.gymId === gymId) {
          const start = dayjs().tz(IST_TZ);
          const end = start.add(plan.durationDays, 'day');
          const createdMem = await tx.customerMembership.create({
            data: {
              customerId,
              planId: plan.id,
              gymId,
              startDate: start.toDate(),
              endDate: end.toDate(),
              status: canAutoApprove ? 'ACTIVE' : 'PENDING',
              purchasePrice: Number(plan.price),
              joiningFee: Number(plan.joiningFee || 0),
              discount: Number(plan.discount || 0),
              tax: 0,
              totalPaid: canAutoApprove ? parsedAmount : 0,
            },
          });
          targetMembershipId = createdMem.id;
        }
      }

      const created = await tx.payment.create({
        data: {
          gymId,
          customerId,
          membershipId: targetMembershipId,
          amount: parsedAmount,
          paymentMethod,
          transactionRef: resolvedRef,
          screenshotUrl,
          status: initialStatus,
          approvedBy: canAutoApprove ? req.user.id : null,
          approvedAt: canAutoApprove ? new Date() : null,
          notes: resolvedNotes || null,
        },
        include: {
          customer: { include: { user: { select: { id: true, fullName: true, mobile: true } } } },
          membership: { include: { plan: true } },
        },
      });

      if (canAutoApprove && targetMembershipId) {
        await tx.customerMembership.update({
          where: { id: targetMembershipId },
          data: { totalPaid: { increment: parsedAmount }, status: 'ACTIVE' },
        });

        const invoice = await tx.invoice.findFirst({ where: { membershipId: targetMembershipId } });
        if (invoice) {
          const newPaid = invoice.paidAmount + parsedAmount;
          await tx.invoice.update({
            where: { id: invoice.id },
            data: {
              paidAmount: newPaid,
              status: newPaid >= invoice.total ? 'PAID' : 'PARTIALLY_PAID',
            },
          });
        }
      }

      return created;
    });

    const formatted = formatPayment(payment);
    const io = req.app.get('io');
    emitPaymentNotification(io, gymId, customer.userId, {
      type: initialStatus,
      payment: formatted,
    });

    if (!canAutoApprove && req.gym?.ownerId) {
      await createNotification({
        userId: req.gym.ownerId,
        gymId,
        type: 'PAYMENT_SUBMITTED',
        title: 'New Payment Submitted',
        message: `${customer.user.fullName} submitted a payment of ₹${parsedAmount} via ${paymentMethod}.`,
        data: { paymentId: payment.id },
        io,
      });
    }

    return sendSuccess(res, formatted, 'Payment submitted successfully', 201);
  } catch (err) {
    next(err);
  }
};

const submitValidators = [body('amount').isFloat({ gt: 0 }).withMessage('Amount must be greater than 0'), validate];
router.post('/submit', upload.single('screenshot'), submitValidators, submitPaymentHandler);
router.post('/me/submit', upload.single('screenshot'), submitValidators, submitPaymentHandler);
router.post('/', upload.single('screenshot'), submitValidators, submitPaymentHandler);

// ========================
// List & Detail
// ========================

// GET /api/payments
router.get('/', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { page, limit, skip } = getPagination(req.query);
    const { status, paymentMethod, customerId, search, startDate, endDate } = req.query;

    const where = { gymId };
    if (req.user.role === 'CUSTOMER') {
      where.customerId = req.customerProfile.id;
    } else if (customerId) {
      where.customerId = customerId;
    }
    if (status && status !== 'ALL') {
      const upper = String(status).toUpperCase();
      if (upper === 'VERIFIED') where.status = 'APPROVED';
      else if (upper === 'PENDING') where.status = { in: ['PENDING', 'UNDER_REVIEW'] };
      else where.status = upper;
    }
    if (paymentMethod && paymentMethod !== 'ALL') where.paymentMethod = paymentMethod;
    if (search) {
      where.OR = [
        { transactionRef: { contains: search } },
        { notes: { contains: search } },
        { customer: { user: { fullName: { contains: search } } } },
        { customer: { user: { mobile: { contains: search } } } },
      ];
    }
    if (startDate || endDate) {
      where.createdAt = {
        ...(startDate && { gte: new Date(startDate) }),
        ...(endDate && { lte: new Date(endDate) }),
      };
    }

    const [payments, total] = await Promise.all([
      prisma.payment.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          customer: {
            include: { user: { select: { id: true, fullName: true, mobile: true, email: true } } },
          },
          membership: { include: { plan: { select: { id: true, name: true } } } },
          approver: { select: { id: true, fullName: true } },
        },
      }),
      prisma.payment.count({ where }),
    ]);

    return sendSuccess(res, formatPaginatedData(payments.map(formatPayment), total, page, limit), 'Payments fetched');
  } catch (err) {
    next(err);
  }
});

// GET /api/payments/:id
router.get('/:id', async (req, res, next) => {
  try {
    const payment = await prisma.payment.findUnique({
      where: { id: req.params.id },
      include: {
        customer: {
          include: { user: { select: { id: true, fullName: true, mobile: true, email: true } } },
        },
        membership: { include: { plan: true } },
        approver: { select: { id: true, fullName: true } },
      },
    });

    if (!payment || (req.gymId && payment.gymId !== req.gymId)) {
      return sendError(res, 'Payment not found', 404);
    }
    if (req.user.role === 'CUSTOMER' && payment.customerId !== req.customerProfile.id) {
      return sendError(res, 'Access denied', 403);
    }

    return sendSuccess(res, formatPayment(payment), 'Payment details fetched');
  } catch (err) {
    next(err);
  }
});

// PUT / PATCH /api/payments/:id/approve OR /verify
const approvePaymentHandler = async (req, res, next) => {
  try {
    const gymId = req.gymId;
    const payment = await prisma.payment.findUnique({
      where: { id: req.params.id },
      include: { customer: true, membership: { include: { plan: true } } },
    });

    if (!payment || (gymId && payment.gymId !== gymId)) {
      return sendError(res, 'Payment not found', 404);
    }

    if (payment.status === 'APPROVED') {
      return sendError(res, 'Payment is already approved', 400);
    }

    const updated = await prisma.$transaction(async (tx) => {
      const p = await tx.payment.update({
        where: { id: payment.id },
        data: {
          status: 'APPROVED',
          approvedBy: req.user.id,
          approvedAt: new Date(),
          notes: req.body.notes !== undefined ? req.body.notes : payment.notes,
        },
      });

      // Only verified payments activate memberships & generate/update invoices
      if (payment.membershipId) {
        const mem = await tx.customerMembership.update({
          where: { id: payment.membershipId },
          data: {
            totalPaid: { increment: payment.amount },
            status: 'ACTIVE',
          },
          include: { plan: true },
        });

        let invoice = await tx.invoice.findFirst({ where: { membershipId: payment.membershipId } });
        if (invoice) {
          const newPaid = invoice.paidAmount + payment.amount;
          await tx.invoice.update({
            where: { id: invoice.id },
            data: {
              paidAmount: newPaid,
              status: newPaid >= invoice.total ? 'PAID' : 'PARTIALLY_PAID',
            },
          });
        } else {
          await tx.invoice.create({
            data: {
              gymId: payment.gymId,
              customerId: payment.customerId,
              invoiceNumber: generateReadableId('INV'),
              membershipId: payment.membershipId,
              items: stringifyJson([
                {
                  description: mem.plan?.name || 'Gym Membership',
                  quantity: 1,
                  unitPrice: mem.purchasePrice,
                  total: mem.purchasePrice,
                },
              ]),
              subtotal: mem.purchasePrice,
              discount: mem.discount,
              tax: mem.tax,
              total: mem.purchasePrice - mem.discount + mem.tax,
              paidAmount: mem.totalPaid,
              status: mem.totalPaid >= mem.purchasePrice - mem.discount + mem.tax ? 'PAID' : 'PARTIALLY_PAID',
              dueDate: mem.endDate,
            },
          });
        }
      }

      return p;
    });

    const io = req.app.get('io');
    await createNotification({
      userId: payment.customer.userId,
      gymId: payment.gymId,
      type: 'PAYMENT_APPROVED',
      title: 'Payment Approved',
      message: `Your payment of ₹${payment.amount} has been approved.`,
      data: { paymentId: payment.id },
      io,
    });

    emitPaymentNotification(io, payment.gymId, payment.customer.userId, {
      type: 'APPROVED',
      payment: updated,
    });

    if (payment.membershipId) {
      emitMembershipStatusChange(io, payment.gymId, payment.customer.userId, {
        membershipId: payment.membershipId,
        customerId: payment.customerId,
        status: 'ACTIVE',
      });
    }

    await createAuditLog({
      userId: req.user.id,
      gymId: payment.gymId,
      action: 'APPROVE_PAYMENT',
      entity: 'Payment',
      entityId: payment.id,
      details: { amount: payment.amount },
      req,
    });

    return sendSuccess(res, formatPayment(updated), 'Payment approved successfully');
  } catch (err) {
    next(err);
  }
};

router.put('/:id/approve', authorize('GYM_OWNER', 'SUPER_ADMIN'), approvePaymentHandler);
router.patch('/:id/verify', authorize('GYM_OWNER', 'SUPER_ADMIN'), approvePaymentHandler);

// PUT / PATCH /api/payments/:id/reject
const rejectPaymentHandler = async (req, res, next) => {
  try {
    const gymId = req.gymId;
    const payment = await prisma.payment.findUnique({
      where: { id: req.params.id },
      include: { customer: true },
    });

    if (!payment || (gymId && payment.gymId !== gymId)) {
      return sendError(res, 'Payment not found', 404);
    }

    if (payment.status === 'APPROVED') {
      return sendError(res, 'Cannot reject an already approved payment. Use refund instead.', 400);
    }

    const reason = req.body.reason || req.body.notes || 'Payment rejected';
    const updated = await prisma.$transaction(async (tx) => {
      const p = await tx.payment.update({
        where: { id: payment.id },
        data: {
          status: 'REJECTED',
          approvedBy: req.user.id,
          approvedAt: new Date(),
          notes: reason,
        },
      });
      if (payment.membershipId) {
        const mem = await tx.customerMembership.findUnique({ where: { id: payment.membershipId } });
        if (mem && mem.status === 'PENDING') {
          await tx.customerMembership.update({
            where: { id: mem.id },
            data: { status: 'CANCELLED' },
          });
        }
      }
      return p;
    });

    const io = req.app.get('io');
    await createNotification({
      userId: payment.customer.userId,
      gymId: payment.gymId,
      type: 'PAYMENT_REJECTED',
      title: 'Payment Rejected',
      message: `Your payment of ₹${payment.amount} was rejected. Reason: ${updated.notes}`,
      data: { paymentId: payment.id },
      io,
    });

    emitPaymentNotification(io, payment.gymId, payment.customer.userId, {
      type: 'REJECTED',
      payment: updated,
    });

    await createAuditLog({
      userId: req.user.id,
      gymId: payment.gymId,
      action: 'REJECT_PAYMENT',
      entity: 'Payment',
      entityId: payment.id,
      details: { notes: updated.notes },
      req,
    });

    return sendSuccess(res, formatPayment(updated), 'Payment rejected');
  } catch (err) {
    next(err);
  }
};

router.put('/:id/reject', authorize('GYM_OWNER', 'SUPER_ADMIN'), rejectPaymentHandler);
router.patch('/:id/reject', authorize('GYM_OWNER', 'SUPER_ADMIN'), rejectPaymentHandler);

module.exports = router;

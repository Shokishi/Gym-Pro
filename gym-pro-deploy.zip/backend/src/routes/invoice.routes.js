const express = require('express');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const { generateReadableId, parseJson, stringifyJson, formatCustomer } = require('../utils/json');
const { createAuditLog } = require('../utils/audit');
const { createNotification } = require('../utils/notification');
const { generateInvoicePDF } = require('../utils/pdfGenerator');

const router = express.Router();

router.use(authenticate, requireGymAccess());

const normalizeInvoiceStatus = (val) => {
  const upper = String(val || 'UNPAID').trim().toUpperCase();
  if (upper === 'PENDING') return 'UNPAID';
  if (upper === 'PARTIAL') return 'PARTIALLY_PAID';
  if (['UNPAID', 'PAID', 'PARTIALLY_PAID', 'CANCELLED'].includes(upper)) return upper;
  return 'UNPAID';
};

const formatInvoice = (inv) => ({
  ...inv,
  items: parseJson(inv.items, []),
  totalAmount: inv.total,
  customer: inv.customer ? formatCustomer(inv.customer) : null,
  customerName: inv.customer?.user?.fullName || null,
});

const invoiceInclude = {
  customer: { include: { user: true } },
  gym: true,
};

// GET /api/invoices
router.get('/', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { page, limit, skip } = getPagination(req.query);
    const { status, customerId, search } = req.query;

    const where = { gymId };
    if (status) where.status = normalizeInvoiceStatus(status);
    if (customerId) where.customerId = customerId;
    if (search) {
      where.OR = [
        { invoiceNumber: { contains: search } },
        { customer: { user: { fullName: { contains: search } } } },
        { customer: { user: { mobile: { contains: search } } } },
      ];
    }

    if (req.user.role === 'CUSTOMER') {
      const cust = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
      if (!cust) return sendSuccess(res, formatPaginatedData([], 0, page, limit));
      where.customerId = cust.id;
    }

    const [invoices, total] = await Promise.all([
      prisma.invoice.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: { customer: { include: { user: true } } },
      }),
      prisma.invoice.count({ where }),
    ]);

    return sendSuccess(
      res,
      formatPaginatedData(invoices.map(formatInvoice), total, page, limit),
      'Invoices fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/invoices/:id/pdf
router.get('/:id/pdf', async (req, res, next) => {
  try {
    const invoice = await prisma.invoice.findUnique({
      where: { id: req.params.id },
      include: invoiceInclude,
    });
    if (!invoice || invoice.gymId !== req.gymId) return sendError(res, 'Invoice not found', 404);

    if (req.user.role === 'CUSTOMER') {
      const cust = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
      if (!cust || invoice.customerId !== cust.id) return sendError(res, 'Access denied', 403);
    }

    const pdfBuffer = generateInvoicePDF(
      { ...invoice, items: parseJson(invoice.items, []) },
      invoice.gym,
      invoice.customer
    );

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="Invoice-${invoice.invoiceNumber}.pdf"`);
    return res.send(pdfBuffer);
  } catch (err) {
    next(err);
  }
});

// GET /api/invoices/:id
router.get('/:id', async (req, res, next) => {
  try {
    const invoice = await prisma.invoice.findUnique({
      where: { id: req.params.id },
      include: invoiceInclude,
    });
    if (!invoice || invoice.gymId !== req.gymId) return sendError(res, 'Invoice not found', 404);

    if (req.user.role === 'CUSTOMER') {
      const cust = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
      if (!cust || invoice.customerId !== cust.id) return sendError(res, 'Access denied', 403);
    }

    return sendSuccess(res, formatInvoice(invoice), 'Invoice fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/invoices
router.post(
  '/',
  authorize('GYM_OWNER', 'SUPER_ADMIN'),
  [
    body('customerId').notEmpty().withMessage('customerId is required'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const gymId = req.gymId;
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const customer = await prisma.customerProfile.findUnique({
        where: { id: req.body.customerId },
        include: { user: true },
      });
      if (!customer || customer.gymId !== gymId) return sendError(res, 'Customer not found in gym', 404);

      const rawItems = Array.isArray(req.body.items) ? req.body.items : [];
      const computedSubtotal =
        req.body.subtotal != null
          ? parseFloat(req.body.subtotal)
          : rawItems.reduce(
              (sum, it) => sum + (parseFloat(it.amount ?? it.price ?? 0) * (parseInt(it.quantity ?? 1, 10) || 1)),
              0
            );
      const discount = parseFloat(req.body.discount || 0) || 0;
      const tax = parseFloat(req.body.tax || 0) || 0;
      const total =
        req.body.total != null || req.body.totalAmount != null
          ? parseFloat(req.body.total ?? req.body.totalAmount)
          : Math.max(0, computedSubtotal - discount + tax);

      const status = normalizeInvoiceStatus(req.body.status);
      const paidAmount =
        status === 'PAID'
          ? parseFloat(req.body.paidAmount ?? total)
          : parseFloat(req.body.paidAmount || 0) || 0;

      const invoice = await prisma.invoice.create({
        data: {
          gymId,
          customerId: customer.id,
          membershipId: req.body.membershipId || null,
          invoiceNumber: generateReadableId('INV'),
          items: stringifyJson(rawItems),
          subtotal: computedSubtotal || total,
          discount,
          tax,
          total,
          status,
          paidAmount,
          dueDate: req.body.dueDate ? new Date(req.body.dueDate) : new Date(Date.now() + 7 * 86400000),
        },
        include: invoiceInclude,
      });

      if (customer.userId) {
        await createNotification({
          userId: customer.userId,
          gymId,
          type: 'INVOICE_GENERATED',
          title: `Invoice ${invoice.invoiceNumber}`,
          message: `An invoice for ₹${invoice.total.toLocaleString('en-IN')} has been generated.`,
          data: { invoiceId: invoice.id },
        });
      }

      await createAuditLog({
        userId: req.user.id,
        gymId,
        action: 'INVOICE_CREATED',
        entity: 'Invoice',
        entityId: invoice.id,
        details: { invoiceNumber: invoice.invoiceNumber, total: invoice.total },
        ipAddress: req.ip,
      });

      return sendSuccess(res, formatInvoice(invoice), 'Invoice created', 201);
    } catch (err) {
      next(err);
    }
  }
);

// PUT /api/invoices/:id
router.put('/:id', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.invoice.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Invoice not found', 404);

    const items = Array.isArray(req.body.items) ? req.body.items : parseJson(existing.items, []);
    const subtotal = req.body.subtotal != null ? parseFloat(req.body.subtotal) : existing.subtotal;
    const discount = req.body.discount != null ? parseFloat(req.body.discount) : existing.discount;
    const tax = req.body.tax != null ? parseFloat(req.body.tax) : existing.tax;
    const total =
      req.body.total != null || req.body.totalAmount != null
        ? parseFloat(req.body.total ?? req.body.totalAmount)
        : Math.max(0, subtotal - discount + tax);

    const updated = await prisma.invoice.update({
      where: { id: existing.id },
      data: {
        items: stringifyJson(items),
        subtotal,
        discount,
        tax,
        total,
        status: req.body.status ? normalizeInvoiceStatus(req.body.status) : existing.status,
        paidAmount: req.body.paidAmount != null ? parseFloat(req.body.paidAmount) : existing.paidAmount,
        dueDate: req.body.dueDate ? new Date(req.body.dueDate) : existing.dueDate,
      },
      include: invoiceInclude,
    });

    return sendSuccess(res, formatInvoice(updated), 'Invoice updated');
  } catch (err) {
    next(err);
  }
});

// PATCH /api/invoices/:id/pay
router.patch('/:id/pay', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.invoice.findUnique({
      where: { id: req.params.id },
      include: { customer: { include: { user: true } } },
    });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Invoice not found', 404);

    const payAmount =
      req.body.amount != null
        ? parseFloat(req.body.amount)
        : Math.max(0, existing.total - (existing.paidAmount || 0));
    const nextPaid = Math.min(existing.total, (existing.paidAmount || 0) + payAmount);
    const nextStatus = nextPaid >= existing.total - 0.01 ? 'PAID' : 'PARTIALLY_PAID';

    const updated = await prisma.$transaction(async (tx) => {
      const inv = await tx.invoice.update({
        where: { id: existing.id },
        data: {
          paidAmount: nextPaid,
          status: nextStatus,
        },
        include: invoiceInclude,
      });

      if (payAmount > 0 && req.body.recordPayment !== false) {
        await tx.payment.create({
          data: {
            gymId: req.gymId,
            customerId: existing.customerId,
            membershipId: existing.membershipId || null,
            amount: payAmount,
            paymentMethod: String(req.body.paymentMethod || 'CASH').toUpperCase(),
            transactionRef: req.body.transactionRef || null,
            status: 'APPROVED',
            approvedBy: req.user.id,
            approvedAt: new Date(),
            notes: `Invoice ${existing.invoiceNumber} settlement`,
          },
        });
      }

      return inv;
    });

    await createAuditLog({
      userId: req.user.id,
      gymId: req.gymId,
      action: 'INVOICE_PAID',
      entity: 'Invoice',
      entityId: existing.id,
      details: { payAmount, totalPaid: nextPaid, status: nextStatus },
      ipAddress: req.ip,
    });

    return sendSuccess(res, formatInvoice(updated), 'Invoice payment recorded');
  } catch (err) {
    next(err);
  }
});

// POST /api/invoices/:id/send
router.post('/:id/send', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const invoice = await prisma.invoice.findUnique({
      where: { id: req.params.id },
      include: { customer: { include: { user: true } }, gym: true },
    });
    if (!invoice || invoice.gymId !== req.gymId) return sendError(res, 'Invoice not found', 404);

    if (invoice.customer?.userId) {
      await createNotification({
        userId: invoice.customer.userId,
        gymId: req.gymId,
        type: 'INVOICE_SENT',
        title: `Invoice ${invoice.invoiceNumber}`,
        message: `${invoice.gym?.name || 'Your gym'} shared invoice ${invoice.invoiceNumber} for ₹${invoice.total.toLocaleString('en-IN')}.`,
        data: { invoiceId: invoice.id },
      });
    }

    await createAuditLog({
      userId: req.user.id,
      gymId: req.gymId,
      action: 'INVOICE_SENT',
      entity: 'Invoice',
      entityId: invoice.id,
      details: { email: invoice.customer?.user?.email, mobile: invoice.customer?.user?.mobile },
      ipAddress: req.ip,
    });

    return sendSuccess(
      res,
      { invoiceId: invoice.id, sentAt: new Date().toISOString() },
      'Invoice notification dispatched to customer'
    );
  } catch (err) {
    next(err);
  }
});

// DELETE /api/invoices/:id
router.delete('/:id', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const existing = await prisma.invoice.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.gymId !== req.gymId) return sendError(res, 'Invoice not found', 404);

    await prisma.invoice.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'Invoice deleted');
  } catch (err) {
    next(err);
  }
});

module.exports = router;

const express = require('express');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { validate } = require('../middleware/validate');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const { parseJson, stringifyJson } = require('../utils/json');
const { createAuditLog } = require('../utils/audit');

const router = express.Router();

router.use(authenticate);

const normalizeDiscountType = (val) => {
  const upper = String(val || 'PERCENTAGE').trim().toUpperCase();
  if (upper === 'FLAT' || upper === 'FIXED_AMOUNT') return 'FIXED';
  if (upper === 'PERCENT' || upper === 'PERCENTAGE') return 'PERCENTAGE';
  return upper;
};

const formatCoupon = (c, scope = 'GYM') => ({
  ...c,
  scope,
  applicablePlans: parseJson(c.applicablePlans, []),
  usedCount: c.currentUses || 0,
  expiresAt: c.expiryDate,
});

const resolveUserGymId = async (req) => {
  if (req.user.gymId) return req.user.gymId;
  if (req.headers['x-gym-id']) return req.headers['x-gym-id'];
  if (req.query.gymId) return req.query.gymId;

  if (req.user.role === 'CUSTOMER') {
    const cust = await prisma.customerProfile.findUnique({ where: { userId: req.user.id } });
    return cust?.gymId || null;
  }
  if (req.user.role === 'TRAINER') {
    const tr = await prisma.trainerProfile.findUnique({ where: { userId: req.user.id } });
    return tr?.gymId || null;
  }
  if (req.user.role === 'GYM_OWNER') {
    const g = await prisma.gym.findFirst({ where: { ownerId: req.user.id } });
    return g?.id || null;
  }
  return null;
};

// GET /api/coupons
router.get('/', async (req, res, next) => {
  try {
    const { page, limit, skip } = getPagination(req.query);
    const { isActive, search } = req.query;

    if (req.user.role === 'SUPER_ADMIN' && !req.query.gymId) {
      const where = {};
      if (isActive !== undefined) where.isActive = isActive === 'true';
      if (search) where.code = { contains: String(search).toUpperCase() };

      const [coupons, total] = await Promise.all([
        prisma.platformCoupon.findMany({ where, skip, take: limit, orderBy: { createdAt: 'desc' } }),
        prisma.platformCoupon.count({ where }),
      ]);

      return sendSuccess(
        res,
        formatPaginatedData(coupons.map((c) => formatCoupon(c, 'PLATFORM')), total, page, limit),
        'Platform coupons fetched'
      );
    }

    const gymId = await resolveUserGymId(req);
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const where = { gymId };
    if (isActive !== undefined) where.isActive = isActive === 'true';
    if (search) where.code = { contains: String(search).toUpperCase() };

    const [coupons, total] = await Promise.all([
      prisma.coupon.findMany({ where, skip, take: limit, orderBy: { createdAt: 'desc' } }),
      prisma.coupon.count({ where }),
    ]);

    return sendSuccess(
      res,
      formatPaginatedData(coupons.map((c) => formatCoupon(c, 'GYM')), total, page, limit),
      'Coupons fetched'
    );
  } catch (err) {
    next(err);
  }
});

// POST /api/coupons
router.post(
  '/',
  authorize('SUPER_ADMIN', 'GYM_OWNER'),
  [
    body('code').trim().notEmpty().withMessage('Coupon code is required'),
    body('discountValue').isFloat({ min: 0.01 }).withMessage('Valid discount value is required'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const code = String(req.body.code).trim().toUpperCase();
      const discountType = normalizeDiscountType(req.body.discountType);
      const discountValue = parseFloat(req.body.discountValue);
      const maxUses = parseInt(req.body.maxUses || 100, 10) || 100;
      const expiryDate = req.body.expiryDate || req.body.expiresAt
        ? new Date(req.body.expiryDate || req.body.expiresAt)
        : null;
      const applicablePlans = stringifyJson(req.body.applicablePlans || []);
      const isActive = req.body.isActive !== undefined ? Boolean(req.body.isActive) : true;

      if (req.user.role === 'SUPER_ADMIN' && !req.body.gymId) {
        const exists = await prisma.platformCoupon.findUnique({ where: { code } });
        if (exists) return sendError(res, 'Platform coupon code already exists', 409);

        const created = await prisma.platformCoupon.create({
          data: { code, discountType, discountValue, maxUses, expiryDate, applicablePlans, isActive },
        });
        return sendSuccess(res, formatCoupon(created, 'PLATFORM'), 'Platform coupon created', 201);
      }

      const gymId = req.body.gymId || (await resolveUserGymId(req));
      if (!gymId) return sendError(res, 'gymId is required', 400);

      const exists = await prisma.coupon.findFirst({ where: { gymId, code } });
      if (exists) return sendError(res, 'Coupon code already exists for this gym', 409);

      const created = await prisma.coupon.create({
        data: {
          gymId,
          code,
          discountType,
          discountValue,
          maxUses,
          minOrderAmount: parseFloat(req.body.minOrderAmount || 0) || 0,
          expiryDate,
          applicablePlans,
          isActive,
        },
      });

      await createAuditLog({
        userId: req.user.id,
        gymId,
        action: 'COUPON_CREATED',
        entity: 'Coupon',
        entityId: created.id,
        details: { code: created.code, discountType, discountValue },
        ipAddress: req.ip,
      });

      return sendSuccess(res, formatCoupon(created, 'GYM'), 'Coupon created', 201);
    } catch (err) {
      next(err);
    }
  }
);

// PUT /api/coupons/:id
router.put('/:id', authorize('SUPER_ADMIN', 'GYM_OWNER'), async (req, res, next) => {
  try {
    if (req.user.role === 'SUPER_ADMIN') {
      const existingPlatform = await prisma.platformCoupon.findUnique({ where: { id: req.params.id } });
      if (existingPlatform) {
        const updated = await prisma.platformCoupon.update({
          where: { id: existingPlatform.id },
          data: {
            code: req.body.code ? String(req.body.code).trim().toUpperCase() : existingPlatform.code,
            discountType: req.body.discountType
              ? normalizeDiscountType(req.body.discountType)
              : existingPlatform.discountType,
            discountValue:
              req.body.discountValue != null ? parseFloat(req.body.discountValue) : existingPlatform.discountValue,
            maxUses: req.body.maxUses != null ? parseInt(req.body.maxUses, 10) : existingPlatform.maxUses,
            expiryDate:
              req.body.expiryDate || req.body.expiresAt
                ? new Date(req.body.expiryDate || req.body.expiresAt)
                : existingPlatform.expiryDate,
            isActive: req.body.isActive !== undefined ? Boolean(req.body.isActive) : existingPlatform.isActive,
          },
        });
        return sendSuccess(res, formatCoupon(updated, 'PLATFORM'), 'Platform coupon updated');
      }
    }

    const gymId = await resolveUserGymId(req);
    const existing = await prisma.coupon.findUnique({ where: { id: req.params.id } });
    if (!existing || (req.user.role !== 'SUPER_ADMIN' && existing.gymId !== gymId)) {
      return sendError(res, 'Coupon not found', 404);
    }

    const updated = await prisma.coupon.update({
      where: { id: existing.id },
      data: {
        code: req.body.code ? String(req.body.code).trim().toUpperCase() : existing.code,
        discountType: req.body.discountType ? normalizeDiscountType(req.body.discountType) : existing.discountType,
        discountValue: req.body.discountValue != null ? parseFloat(req.body.discountValue) : existing.discountValue,
        maxUses: req.body.maxUses != null ? parseInt(req.body.maxUses, 10) : existing.maxUses,
        minOrderAmount:
          req.body.minOrderAmount != null ? parseFloat(req.body.minOrderAmount) : existing.minOrderAmount,
        expiryDate:
          req.body.expiryDate || req.body.expiresAt
            ? new Date(req.body.expiryDate || req.body.expiresAt)
            : existing.expiryDate,
        isActive: req.body.isActive !== undefined ? Boolean(req.body.isActive) : existing.isActive,
      },
    });

    return sendSuccess(res, formatCoupon(updated, 'GYM'), 'Coupon updated');
  } catch (err) {
    next(err);
  }
});

// PATCH /api/coupons/:id/status
router.patch('/:id/status', authorize('SUPER_ADMIN', 'GYM_OWNER'), async (req, res, next) => {
  try {
    const nextActive = req.body.active !== undefined ? Boolean(req.body.active) : req.body.isActive;

    if (req.user.role === 'SUPER_ADMIN') {
      const existingPlatform = await prisma.platformCoupon.findUnique({ where: { id: req.params.id } });
      if (existingPlatform) {
        const updated = await prisma.platformCoupon.update({
          where: { id: existingPlatform.id },
          data: { isActive: nextActive !== undefined ? Boolean(nextActive) : !existingPlatform.isActive },
        });
        return sendSuccess(res, formatCoupon(updated, 'PLATFORM'), 'Platform coupon status updated');
      }
    }

    const gymId = await resolveUserGymId(req);
    const existing = await prisma.coupon.findUnique({ where: { id: req.params.id } });
    if (!existing || (req.user.role !== 'SUPER_ADMIN' && existing.gymId !== gymId)) {
      return sendError(res, 'Coupon not found', 404);
    }

    const updated = await prisma.coupon.update({
      where: { id: existing.id },
      data: { isActive: nextActive !== undefined ? Boolean(nextActive) : !existing.isActive },
    });
    return sendSuccess(res, formatCoupon(updated, 'GYM'), 'Coupon status updated');
  } catch (err) {
    next(err);
  }
});

// POST /api/coupons/validate
router.post('/validate', async (req, res, next) => {
  try {
    const code = String(req.body.code || '').trim().toUpperCase();
    if (!code) return sendError(res, 'Coupon code is required', 400);

    const amount = parseFloat(req.body.amount || req.body.orderAmount || 0) || 0;
    const scope = String(req.body.scope || '').toUpperCase();
    const gymId = await resolveUserGymId(req);

    let coupon = null;
    let couponScope = 'GYM';

    // Owners redeeming SaaS subscription coupons check PlatformCoupon first when scope=PLATFORM or fallback
    if (scope === 'PLATFORM') {
      coupon = await prisma.platformCoupon.findUnique({ where: { code } });
      couponScope = 'PLATFORM';
    } else if (gymId) {
      coupon = await prisma.coupon.findFirst({ where: { gymId, code } });
      if (!coupon && req.user.role === 'GYM_OWNER') {
        coupon = await prisma.platformCoupon.findUnique({ where: { code } });
        couponScope = 'PLATFORM';
      }
    } else {
      coupon = await prisma.platformCoupon.findUnique({ where: { code } });
      couponScope = 'PLATFORM';
    }

    if (!coupon) return sendError(res, 'Invalid coupon code', 404);
    if (!coupon.isActive) return sendError(res, 'Coupon is inactive', 400);
    if (coupon.expiryDate && new Date(coupon.expiryDate) < new Date()) {
      return sendError(res, 'Coupon has expired', 400);
    }
    if (coupon.currentUses >= coupon.maxUses) {
      return sendError(res, 'Coupon usage limit exceeded', 400);
    }
    if (coupon.minOrderAmount && amount > 0 && amount < coupon.minOrderAmount) {
      return sendError(res, `Minimum order amount of ₹${coupon.minOrderAmount} required`, 400);
    }

    const discount =
      coupon.discountType === 'PERCENTAGE'
        ? Math.round(((amount * coupon.discountValue) / 100) * 100) / 100
        : Math.min(amount || coupon.discountValue, coupon.discountValue);

    const finalAmount = Math.max(0, Math.round((amount - discount) * 100) / 100);

    return sendSuccess(
      res,
      {
        valid: true,
        discount,
        finalAmount,
        coupon: formatCoupon(coupon, couponScope),
      },
      'Coupon applied successfully'
    );
  } catch (err) {
    next(err);
  }
});

// DELETE /api/coupons/:id
router.delete('/:id', authorize('SUPER_ADMIN', 'GYM_OWNER'), async (req, res, next) => {
  try {
    if (req.user.role === 'SUPER_ADMIN') {
      const existingPlatform = await prisma.platformCoupon.findUnique({ where: { id: req.params.id } });
      if (existingPlatform) {
        await prisma.platformCoupon.delete({ where: { id: existingPlatform.id } });
        return sendSuccess(res, null, 'Platform coupon deleted');
      }
    }

    const gymId = await resolveUserGymId(req);
    const existing = await prisma.coupon.findUnique({ where: { id: req.params.id } });
    if (!existing || (req.user.role !== 'SUPER_ADMIN' && existing.gymId !== gymId)) {
      return sendError(res, 'Coupon not found', 404);
    }

    await prisma.coupon.delete({ where: { id: existing.id } });
    return sendSuccess(res, null, 'Coupon deleted');
  } catch (err) {
    next(err);
  }
});

module.exports = router;

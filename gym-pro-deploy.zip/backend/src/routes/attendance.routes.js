const express = require('express');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');
const { requireGymAccess } = require('../middleware/gymAccess');
const { sendSuccess, sendError, getPagination, formatPaginatedData } = require('../utils/response');
const { getISTDateOnly, getISTMonthRange, dayjs, IST_TZ } = require('../utils/date');
const { formatCustomer } = require('../utils/json');
const { createAuditLog } = require('../utils/audit');
const { emitAttendanceUpdate } = require('../socket');

const router = express.Router();

/**
 * Automatically marks unmarked active members as ABSENT for yesterday (after full day ends).
 */
const runAutoAbsentForCompletedDay = async (gymId = null, targetDateInput = null) => {
  const targetDate = targetDateInput
    ? getISTDateOnly(targetDateInput)
    : getISTDateOnly(dayjs().tz(IST_TZ).subtract(1, 'day').toDate());

  const gymFilter = gymId ? { id: gymId } : { isActive: true };
  const gyms = await prisma.gym.findMany({ where: gymFilter, select: { id: true, ownerId: true } });

  let totalCreated = 0;
  for (const gym of gyms) {
    const [activeCustomers, existingRecords] = await Promise.all([
      prisma.customerProfile.findMany({
        where: {
          gymId: gym.id,
          isActive: true,
          memberships: { some: { status: 'ACTIVE', endDate: { gte: targetDate } } },
        },
        select: { id: true },
      }),
      prisma.attendance.findMany({
        where: { gymId: gym.id, date: targetDate },
        select: { customerId: true },
      }),
    ]);

    const markedSet = new Set(existingRecords.map((r) => r.customerId));
    const missing = activeCustomers.filter((c) => !markedSet.has(c.id));

    for (const c of missing) {
      await prisma.attendance.create({
        data: {
          gymId: gym.id,
          customerId: c.id,
          date: targetDate,
          status: 'ABSENT',
          method: 'AUTO',
          markedBy: gym.ownerId,
          notes: 'Auto-marked absent after end of day',
        },
      });
      totalCreated += 1;
    }
  }
  return totalCreated;
};

const formatAttendanceRecord = (r) => ({
  ...r,
  customer: r.customer ? formatCustomer(r.customer) : null,
  customerName: r.customer?.user?.fullName || '',
});

router.use(authenticate, requireGymAccess());

// GET /api/attendance/me (Customer's own attendance & streak)
router.get('/me', authorize('CUSTOMER'), async (req, res, next) => {
  try {
    const customerId = req.customerProfile.id;
    const records = await prisma.attendance.findMany({
      where: { customerId },
      orderBy: { date: 'desc' },
      take: 60,
    });

    const presentRecords = records.filter((r) => r.status === 'PRESENT');
    let streak = 0;
    const today = dayjs().tz(IST_TZ).startOf('day');
    const presentSet = new Set(presentRecords.map((r) => dayjs(r.date).format('YYYY-MM-DD')));

    let cursor = today;
    if (!presentSet.has(cursor.format('YYYY-MM-DD'))) {
      cursor = today.subtract(1, 'day');
    }
    while (presentSet.has(cursor.format('YYYY-MM-DD'))) {
      streak += 1;
      cursor = cursor.subtract(1, 'day');
    }

    return sendSuccess(
      res,
      {
        records,
        attendance: records,
        totalCheckIns: presentRecords.length,
        streak,
      },
      'My attendance fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/attendance/my-qr (Customer's unique QR pass)
router.get('/my-qr', authorize('CUSTOMER'), async (req, res, next) => {
  try {
    const qrPayload = JSON.stringify({
      type: 'GYM_PRO_CHECKIN',
      gymId: req.gymId,
      customerId: req.customerProfile.id,
      readableId: req.customerProfile.customerId,
    });

    return sendSuccess(
      res,
      {
        qrToken: qrPayload,
        token: qrPayload,
        code: req.customerProfile.customerId,
        customerId: req.customerProfile.id,
        gymId: req.gymId,
      },
      'QR token generated'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/attendance (Owner / Trainer daily or searchable list)
router.get('/', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { page, limit, skip } = getPagination(req.query);
    const { date, customerId, status, search } = req.query;

    const where = { gymId };
    if (date) where.date = getISTDateOnly(date);
    if (customerId) where.customerId = customerId;
    if (status && status !== 'ALL') where.status = status;
    if (search) {
      where.OR = [
        { customer: { customerId: { contains: search } } },
        { customer: { user: { fullName: { contains: search } } } },
        { customer: { user: { mobile: { contains: search } } } },
      ];
    }

    const [records, total] = await Promise.all([
      prisma.attendance.findMany({
        where,
        skip,
        take: limit,
        orderBy: { updatedAt: 'desc' },
        include: {
          customer: {
            include: {
              user: { select: { id: true, fullName: true, mobile: true, profilePhoto: true } },
              branch: { select: { id: true, name: true } },
            },
          },
          marker: { select: { id: true, fullName: true } },
        },
      }),
      prisma.attendance.count({ where }),
    ]);

    return sendSuccess(
      res,
      formatPaginatedData(records.map(formatAttendanceRecord), total, page, limit),
      'Attendance records fetched'
    );
  } catch (err) {
    next(err);
  }
});

// POST /api/attendance/mark
router.post('/mark', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const { customerId, trainerId, type = 'CUSTOMER', date, status = 'PRESENT', method = 'MANUAL', notes } = req.body;
    const targetDate = getISTDateOnly(date);
    const now = new Date();

    if (type === 'TRAINER' || trainerId) {
      if (!trainerId) return sendError(res, 'trainerId is required', 400);
      const trainer = await prisma.trainerProfile.findUnique({ where: { id: trainerId } });
      if (!trainer || trainer.gymId !== gymId) {
        return sendError(res, 'Trainer not found in this gym', 404);
      }

      const record = await prisma.trainerAttendance.upsert({
        where: { gymId_trainerId_date: { gymId, trainerId, date: targetDate } },
        update: {
          status,
          checkInTime: status === 'PRESENT' || status === 'HALF_DAY' ? now : undefined,
        },
        create: {
          gymId,
          trainerId,
          date: targetDate,
          status,
          checkInTime: status === 'PRESENT' || status === 'HALF_DAY' ? now : null,
        },
        include: {
          trainer: { include: { user: { select: { fullName: true } } } },
        },
      });

      emitAttendanceUpdate(req.app.get('io'), gymId, { type: 'TRAINER', record });
      return sendSuccess(res, record, 'Trainer attendance marked');
    }

    if (!customerId) return sendError(res, 'customerId is required', 400);

    const customer = await prisma.customerProfile.findUnique({ where: { id: customerId } });
    if (!customer || customer.gymId !== gymId) {
      return sendError(res, 'Customer not found in this gym', 404);
    }

    if (req.user.role === 'TRAINER' && customer.assignedTrainerId && customer.assignedTrainerId !== req.trainerProfile?.id) {
      return sendError(res, 'Access denied: customer is not assigned to you', 403);
    }

    const existing = await prisma.attendance.findUnique({
      where: { gymId_customerId_date: { gymId, customerId, date: targetDate } },
    });

    if (existing && existing.status !== status && !notes) {
      // Allow correction, track who modified it
    }

    const record = await prisma.attendance.upsert({
      where: { gymId_customerId_date: { gymId, customerId, date: targetDate } },
      update: {
        status,
        method: method || 'MANUAL',
        notes: notes !== undefined ? notes : existing ? `Corrected to ${status} by ${req.user.fullName}` : null,
        markedBy: req.user.id,
        checkInTime: status === 'PRESENT' ? existing?.checkInTime || now : null,
      },
      create: {
        gymId,
        customerId,
        date: targetDate,
        status,
        method: method || 'MANUAL',
        notes: notes || null,
        markedBy: req.user.id,
        checkInTime: status === 'PRESENT' ? now : null,
      },
      include: {
        customer: {
          include: { user: { select: { id: true, fullName: true, mobile: true, profilePhoto: true } } },
        },
      },
    });

    if (existing && existing.status !== status) {
      await createAuditLog({
        userId: req.user.id,
        gymId,
        action: 'ATTENDANCE_CORRECTION',
        entity: 'Attendance',
        entityId: record.id,
        details: { previousStatus: existing.status, newStatus: status, reason: notes || 'Manual correction' },
        req,
      });
    }

    const formatted = formatAttendanceRecord(record);
    emitAttendanceUpdate(req.app.get('io'), gymId, { type: 'CUSTOMER', record: formatted });
    return sendSuccess(res, formatted, 'Attendance marked successfully');
  } catch (err) {
    next(err);
  }
});

// POST /api/attendance/qr-checkin
router.post('/qr-checkin', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    let { customerId, qrData, qrCode, date, notes } = req.body;
    const rawQr = qrData || qrCode;

    if (rawQr) {
      try {
        const parsed = typeof rawQr === 'string' ? JSON.parse(rawQr) : rawQr;
        if (parsed.gymId && parsed.gymId !== gymId) {
          return sendError(res, 'QR code belongs to a different gym', 403);
        }
        if (parsed.customerId) customerId = parsed.customerId;
      } catch {
        if (!customerId && typeof rawQr === 'string') {
          const clean = rawQr.trim();
          const byReadable = await prisma.customerProfile.findFirst({
            where: { gymId, OR: [{ customerId: clean }, { id: clean }] },
          });
          if (byReadable) customerId = byReadable.id;
        }
      }
    }

    if (req.user.role === 'CUSTOMER') {
      customerId = req.customerProfile.id;
    }

    if (!customerId) {
      return sendError(res, 'Customer identifier or valid QR data is required', 400);
    }

    const customer = await prisma.customerProfile.findUnique({
      where: { id: customerId },
      include: {
        user: { select: { id: true, fullName: true, mobile: true, profilePhoto: true } },
        memberships: {
          where: { status: 'ACTIVE' },
          orderBy: { endDate: 'desc' },
          take: 1,
        },
      },
    });

    if (!customer || customer.gymId !== gymId || !customer.isActive) {
      return sendError(res, 'Active customer not found in this gym', 404);
    }

    const activeMembership = customer.memberships[0];
    if (!activeMembership || new Date(activeMembership.endDate) < new Date()) {
      return sendError(res, 'No active membership found for QR check-in. Please renew membership.', 403);
    }

    const today = getISTDateOnly(date);
    const now = new Date();

    // PART 7: Duplicate check-in prevention
    const existingToday = await prisma.attendance.findUnique({
      where: { gymId_customerId_date: { gymId, customerId, date: today } },
    });

    if (existingToday && existingToday.status === 'PRESENT') {
      return sendError(res, 'Duplicate check-in prevented: Member has already checked in today', 409);
    }

    const record = await prisma.attendance.upsert({
      where: { gymId_customerId_date: { gymId, customerId, date: today } },
      update: {
        status: 'PRESENT',
        method: 'QR',
        checkInTime: now,
        markedBy: req.user.id,
        notes: notes || 'QR Check-in',
      },
      create: {
        gymId,
        customerId,
        date: today,
        status: 'PRESENT',
        method: 'QR',
        checkInTime: now,
        markedBy: req.user.id,
        notes: notes || 'QR Check-in',
      },
      include: {
        customer: {
          include: { user: { select: { id: true, fullName: true, mobile: true, profilePhoto: true } } },
        },
      },
    });

    const formatted = formatAttendanceRecord(record);
    emitAttendanceUpdate(req.app.get('io'), gymId, { type: 'QR_CHECKIN', record: formatted });

    return sendSuccess(res, formatted, `Welcome ${customer.user.fullName}! QR check-in successful.`);
  } catch (err) {
    next(err);
  }
});

// PATCH /api/attendance/:id/checkout
router.patch('/:id/checkout', async (req, res, next) => {
  try {
    const existing = await prisma.attendance.findUnique({ where: { id: req.params.id } });
    if (!existing || (req.gymId && existing.gymId !== req.gymId)) {
      return sendError(res, 'Attendance record not found', 404);
    }
    const updated = await prisma.attendance.update({
      where: { id: existing.id },
      data: { checkOutTime: new Date() },
      include: {
        customer: { include: { user: { select: { id: true, fullName: true, mobile: true, profilePhoto: true } } } },
      },
    });
    const formatted = formatAttendanceRecord(updated);
    emitAttendanceUpdate(req.app.get('io'), existing.gymId, { type: 'CHECKOUT', record: formatted });
    return sendSuccess(res, formatted, 'Checked out successfully');
  } catch (err) {
    next(err);
  }
});

// POST /api/attendance/checkout
router.post('/checkout', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    let { customerId, trainerId, date } = req.body;
    const targetDate = getISTDateOnly(date);
    const now = new Date();

    if (req.user.role === 'CUSTOMER') {
      customerId = req.customerProfile.id;
    } else if (req.user.role === 'TRAINER' && !customerId) {
      trainerId = req.trainerProfile.id;
    }

    if (trainerId) {
      const existing = await prisma.trainerAttendance.findUnique({
        where: { gymId_trainerId_date: { gymId, trainerId, date: targetDate } },
      });
      if (!existing) return sendError(res, 'Check-in record not found for today', 404);

      const updated = await prisma.trainerAttendance.update({
        where: { id: existing.id },
        data: { checkOutTime: now },
      });
      emitAttendanceUpdate(req.app.get('io'), gymId, { type: 'TRAINER_CHECKOUT', record: updated });
      return sendSuccess(res, updated, 'Trainer checked out successfully');
    }

    if (!customerId) return sendError(res, 'customerId is required', 400);

    const existing = await prisma.attendance.findUnique({
      where: { gymId_customerId_date: { gymId, customerId, date: targetDate } },
    });
    if (!existing) return sendError(res, 'Check-in record not found for this date', 404);

    const updated = await prisma.attendance.update({
      where: { id: existing.id },
      data: { checkOutTime: now },
      include: {
        customer: { include: { user: { select: { id: true, fullName: true } } } },
      },
    });

    const formatted = formatAttendanceRecord(updated);
    emitAttendanceUpdate(req.app.get('io'), gymId, { type: 'CHECKOUT', record: formatted });
    return sendSuccess(res, formatted, 'Checked out successfully');
  } catch (err) {
    next(err);
  }
});

// GET /api/attendance/daily
router.get('/daily', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const targetDate = getISTDateOnly(req.query.date);
    const { page, limit, skip } = getPagination(req.query);
    const { status } = req.query;

    const where = { gymId, date: targetDate };
    if (status) where.status = status;

    const [records, total, presentCount, absentCount] = await Promise.all([
      prisma.attendance.findMany({
        where,
        skip,
        take: limit,
        orderBy: { updatedAt: 'desc' },
        include: {
          customer: {
            include: {
              user: { select: { id: true, fullName: true, mobile: true, profilePhoto: true } },
              branch: { select: { id: true, name: true } },
            },
          },
        },
      }),
      prisma.attendance.count({ where }),
      prisma.attendance.count({ where: { gymId, date: targetDate, status: 'PRESENT' } }),
      prisma.attendance.count({ where: { gymId, date: targetDate, status: 'ABSENT' } }),
    ]);

    return sendSuccess(
      res,
      {
        date: targetDate,
        summary: {
          present: presentCount,
          absent: absentCount,
          total: presentCount + absentCount,
        },
        ...formatPaginatedData(records.map(formatAttendanceRecord), total, page, limit),
      },
      'Daily attendance fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/attendance/monthly
router.get('/monthly', async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const range = getISTMonthRange(req.query.month, req.query.year);
    const where = {
      gymId,
      date: { gte: range.dateOnlyStart, lte: range.dateOnlyEnd },
    };

    if (req.user.role === 'CUSTOMER') {
      where.customerId = req.customerProfile.id;
    } else if (req.query.customerId) {
      where.customerId = req.query.customerId;
    }

    const records = await prisma.attendance.findMany({
      where,
      orderBy: { date: 'asc' },
      include: {
        customer: {
          include: { user: { select: { id: true, fullName: true, mobile: true, profilePhoto: true } } },
        },
      },
    });

    const presentDays = records.filter((r) => r.status === 'PRESENT').length;
    const absentDays = records.filter((r) => r.status === 'ABSENT').length;

    return sendSuccess(
      res,
      {
        month: range.month,
        year: range.year,
        summary: {
          presentDays,
          absentDays,
          totalRecords: records.length,
        },
        records: records.map(formatAttendanceRecord),
      },
      'Monthly attendance fetched'
    );
  } catch (err) {
    next(err);
  }
});

// GET /api/attendance/report
router.get('/report', authorize('GYM_OWNER', 'TRAINER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const endDate = getISTDateOnly(req.query.endDate);
    const startDate = req.query.startDate
      ? getISTDateOnly(req.query.startDate)
      : getISTDateOnly(dayjs().tz(IST_TZ).subtract(29, 'day').toDate());

    const records = await prisma.attendance.findMany({
      where: {
        gymId,
        date: { gte: startDate, lte: endDate },
      },
      include: {
        customer: {
          include: { user: { select: { id: true, fullName: true } } },
        },
      },
      orderBy: { date: 'asc' },
    });

    const dailyMap = {};
    const customerMap = {};

    records.forEach((r) => {
      const dateStr = dayjs(r.date).format('YYYY-MM-DD');
      if (!dailyMap[dateStr]) {
        dailyMap[dateStr] = { date: dateStr, label: dayjs(r.date).format('DD MMM'), present: 0, absent: 0 };
      }
      if (r.status === 'PRESENT') dailyMap[dateStr].present += 1;
      else dailyMap[dateStr].absent += 1;

      if (!customerMap[r.customerId]) {
        customerMap[r.customerId] = {
          customerId: r.customerId,
          readableId: r.customer?.customerId,
          name: r.customer?.user?.fullName || 'Unknown',
          present: 0,
          absent: 0,
        };
      }
      if (r.status === 'PRESENT') customerMap[r.customerId].present += 1;
      else customerMap[r.customerId].absent += 1;
    });

    const totalPresent = records.filter((r) => r.status === 'PRESENT').length;
    const totalRecords = records.length;

    return sendSuccess(
      res,
      {
        startDate,
        endDate,
        summary: {
          totalRecords,
          totalPresent,
          totalAbsent: totalRecords - totalPresent,
          attendanceRate: totalRecords > 0 ? Number(((totalPresent / totalRecords) * 100).toFixed(2)) : 0,
        },
        dailyBreakdown: Object.values(dailyMap),
        chart: Object.values(dailyMap),
        memberSummary: Object.values(customerMap).sort((a, b) => b.present - a.present),
      },
      'Attendance report generated'
    );
  } catch (err) {
    next(err);
  }
});

// POST /api/attendance/auto-absent
router.post('/auto-absent', authorize('GYM_OWNER', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    const gymId = req.gymId;
    if (!gymId) return sendError(res, 'gymId is required', 400);

    const targetDate = getISTDateOnly(req.body.date || dayjs().tz(IST_TZ).toDate());
    const createdCount = await runAutoAbsentForCompletedDay(gymId, targetDate);

    return sendSuccess(
      res,
      { date: targetDate, markedAbsentCount: createdCount },
      `Auto-marked ${createdCount} members as absent`
    );
  } catch (err) {
    next(err);
  }
});

module.exports = router;
module.exports.runAutoAbsentForCompletedDay = runAutoAbsentForCompletedDay;

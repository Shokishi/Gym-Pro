const express = require('express');
const bcrypt = require('bcryptjs');
const { body } = require('express-validator');
const prisma = require('../config/prisma');
const { authenticate } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { upload, getUploadedFileUrl } = require('../middleware/upload');
const { sendSuccess, sendError } = require('../utils/response');
const {
  sanitizeUser,
  parseJson,
  stringifyJson,
  canonicalMobile,
  normalizeMobileCandidates,
} = require('../utils/json');
const { createAuditLog } = require('../utils/audit');

const router = express.Router();

router.use(authenticate);

const generateOTPCode = () => String(Math.floor(100000 + Math.random() * 900000));

const buildFullProfile = async (userId) => {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: {
      ownedGyms: { include: { branches: true } },
      gymOwnerProfile: true,
      trainerProfile: {
        include: {
          gym: true,
          branch: true,
          _count: { select: { assignedCustomers: true } },
        },
      },
      customerProfile: {
        include: {
          gym: true,
          branch: true,
          assignedTrainer: { include: { user: true } },
          memberships: {
            include: { plan: true },
            orderBy: { createdAt: 'desc' },
            take: 1,
          },
        },
      },
      loginHistory: {
        orderBy: { loginAt: 'desc' },
        take: 15,
      },
    },
  });

  if (!user) return null;

  const base = sanitizeUser(user);
  const gym =
    user.ownedGyms?.[0] ||
    user.trainerProfile?.gym ||
    user.customerProfile?.gym ||
    null;

  return {
    ...base,
    name: user.fullName,
    avatar: user.profilePhoto || null,
    phone: user.mobile || '',
    gym,
    ownerProfile: user.gymOwnerProfile
      ? {
          ...user.gymOwnerProfile,
          businessDetails: parseJson(user.gymOwnerProfile.businessDetails, {}),
          notificationPrefs: parseJson(user.gymOwnerProfile.notificationPrefs, {}),
        }
      : null,
    trainerProfile: user.trainerProfile
      ? {
          ...user.trainerProfile,
          assignedCustomersCount: user.trainerProfile._count?.assignedCustomers || 0,
        }
      : null,
    customerProfile: user.customerProfile
      ? {
          ...user.customerProfile,
          latestMembership: user.customerProfile.memberships?.[0] || null,
          assignedTrainerName: user.customerProfile.assignedTrainer?.user?.fullName || null,
        }
      : null,
    bio: user.trainerProfile?.bio || '',
    specialization: user.trainerProfile?.specialization || '',
    experience: user.trainerProfile?.experience || '',
    address: user.customerProfile?.address || user.ownedGyms?.[0]?.address || '',
    dateOfBirth: user.customerProfile?.dateOfBirth || null,
    emergencyContact: user.customerProfile?.emergencyContact || '',
    emergencyPhone: user.customerProfile?.emergencyPhone || '',
    loginHistory: user.loginHistory || [],
  };
};

// GET /api/profile
router.get('/', async (req, res, next) => {
  try {
    const profile = await buildFullProfile(req.user.id);
    if (!profile) return sendError(res, 'User not found', 404);
    return sendSuccess(res, profile, 'Profile fetched');
  } catch (err) {
    next(err);
  }
});

// POST /api/profile/send-mobile-otp
router.post('/send-mobile-otp', async (req, res, next) => {
  try {
    const rawMobile = req.body.mobile || req.body.newMobile;
    if (!rawMobile) return sendError(res, 'Mobile number is required', 400);

    const mobile = canonicalMobile(rawMobile);
    const existing = await prisma.user.findFirst({
      where: {
        id: { not: req.user.id },
        mobile: { in: normalizeMobileCandidates(mobile) },
      },
    });
    if (existing) {
      return sendError(res, 'Mobile number is already linked to another account', 409);
    }

    const otp = generateOTPCode();
    await prisma.oTPVerification.create({
      data: {
        mobile,
        otp,
        purpose: 'MOBILE_CHANGE',
        expiresAt: new Date(Date.now() + 10 * 60 * 1000),
      },
    });

    const isProd = process.env.NODE_ENV === 'production';
    return sendSuccess(
      res,
      {
        mobile,
        expiresInMinutes: 10,
        ...(!isProd ? { devOtp: otp } : {}),
      },
      'OTP sent to mobile number'
    );
  } catch (err) {
    next(err);
  }
});

// PUT /api/profile
router.put('/', async (req, res, next) => {
  try {
    const current = await prisma.user.findUnique({
      where: { id: req.user.id },
      include: { gymOwnerProfile: true, trainerProfile: true, customerProfile: true },
    });
    if (!current) return sendError(res, 'User not found', 404);

    const nextFullName = req.body.fullName ?? req.body.name;
    const nextEmail = req.body.email !== undefined ? req.body.email?.trim() || null : current.email;
    const rawMobile = req.body.mobile !== undefined ? req.body.mobile : req.body.phone;

    let nextMobile = current.mobile;
    let nextMobileVerified = current.mobileVerified;

    if (rawMobile !== undefined) {
      if (current.role === 'SUPER_ADMIN' && (!rawMobile || String(rawMobile).trim() === '')) {
        nextMobile = null;
        nextMobileVerified = false;
      } else {
        const candidateMobile = canonicalMobile(rawMobile);
        if (candidateMobile && candidateMobile !== current.mobile) {
          const dup = await prisma.user.findFirst({
            where: {
              id: { not: current.id },
              mobile: { in: normalizeMobileCandidates(candidateMobile) },
            },
          });
          if (dup) return sendError(res, 'Mobile number already registered to another user', 409);

          if (current.role !== 'SUPER_ADMIN') {
            if (!req.body.otp) {
              return sendError(res, 'OTP verification is required to change mobile number', 400);
            }
            const otpRecord = await prisma.oTPVerification.findFirst({
              where: {
                mobile: { in: normalizeMobileCandidates(candidateMobile) },
                otp: String(req.body.otp).trim(),
                purpose: 'MOBILE_CHANGE',
                verified: false,
                expiresAt: { gt: new Date() },
              },
              orderBy: { createdAt: 'desc' },
            });
            if (!otpRecord) return sendError(res, 'Invalid or expired OTP for mobile change', 400);
            await prisma.oTPVerification.update({
              where: { id: otpRecord.id },
              data: { verified: true },
            });
            nextMobileVerified = true;
          }
          nextMobile = candidateMobile;
        }
      }
    }

    if (nextEmail && nextEmail !== current.email) {
      const emailDup = await prisma.user.findFirst({
        where: { id: { not: current.id }, email: nextEmail },
      });
      if (emailDup) return sendError(res, 'Email address already in use', 409);
    }

    await prisma.user.update({
      where: { id: current.id },
      data: {
        ...(nextFullName ? { fullName: nextFullName.trim() } : {}),
        email: nextEmail,
        mobile: nextMobile,
        mobileVerified: nextMobileVerified,
        ...(req.body.twoFactorEnabled !== undefined
          ? { twoFactorEnabled: Boolean(req.body.twoFactorEnabled) }
          : {}),
      },
    });

    if (current.role === 'TRAINER' && current.trainerProfile) {
      await prisma.trainerProfile.update({
        where: { id: current.trainerProfile.id },
        data: {
          ...(req.body.specialization !== undefined ? { specialization: req.body.specialization } : {}),
          ...(req.body.experience !== undefined ? { experience: req.body.experience } : {}),
          ...(req.body.certifications !== undefined ? { certifications: req.body.certifications } : {}),
          ...(req.body.bio !== undefined ? { bio: req.body.bio } : {}),
        },
      });
    } else if (current.role === 'CUSTOMER' && current.customerProfile) {
      await prisma.customerProfile.update({
        where: { id: current.customerProfile.id },
        data: {
          ...(req.body.dateOfBirth !== undefined
            ? { dateOfBirth: req.body.dateOfBirth ? new Date(req.body.dateOfBirth) : null }
            : {}),
          ...(req.body.address !== undefined ? { address: req.body.address } : {}),
          ...(req.body.emergencyContact !== undefined ? { emergencyContact: req.body.emergencyContact } : {}),
          ...(req.body.emergencyPhone !== undefined ? { emergencyPhone: req.body.emergencyPhone } : {}),
          ...(req.body.gender !== undefined ? { gender: req.body.gender } : {}),
          ...(req.body.heightCm !== undefined ? { heightCm: parseFloat(req.body.heightCm) || null } : {}),
          ...(req.body.weightKg !== undefined ? { weightKg: parseFloat(req.body.weightKg) || null } : {}),
          ...(req.body.fitnessGoal !== undefined ? { fitnessGoal: req.body.fitnessGoal } : {}),
          ...(req.body.medicalNotes !== undefined ? { medicalNotes: req.body.medicalNotes } : {}),
        },
      });
    } else if (current.role === 'GYM_OWNER' && current.gymOwnerProfile) {
      await prisma.gymOwnerProfile.update({
        where: { id: current.gymOwnerProfile.id },
        data: {
          ...(req.body.businessDetails !== undefined
            ? { businessDetails: stringifyJson(req.body.businessDetails) }
            : {}),
          ...(req.body.notificationPrefs !== undefined
            ? { notificationPrefs: stringifyJson(req.body.notificationPrefs) }
            : {}),
        },
      });
    }

    const updatedProfile = await buildFullProfile(req.user.id);
    return sendSuccess(res, updatedProfile, 'Profile updated successfully');
  } catch (err) {
    next(err);
  }
});

// PUT /api/profile/mobile
router.put('/mobile', async (req, res, next) => {
  try {
    const newMobileRaw = req.body.newMobile || req.body.mobile;
    const { otp } = req.body;
    if (!newMobileRaw) return sendError(res, 'Mobile number is required', 400);

    const newMobile = canonicalMobile(newMobileRaw);
    const dup = await prisma.user.findFirst({
      where: { id: { not: req.user.id }, mobile: { in: normalizeMobileCandidates(newMobile) } },
    });
    if (dup) return sendError(res, 'Mobile number already registered to another user', 409);

    if (req.user.role !== 'SUPER_ADMIN') {
      if (!otp) return sendError(res, 'OTP is required', 400);
      const otpRecord = await prisma.oTPVerification.findFirst({
        where: {
          mobile: { in: normalizeMobileCandidates(newMobile) },
          otp: String(otp).trim(),
          purpose: 'MOBILE_CHANGE',
          verified: false,
          expiresAt: { gt: new Date() },
        },
        orderBy: { createdAt: 'desc' },
      });
      if (!otpRecord) return sendError(res, 'Invalid or expired OTP', 400);
      await prisma.oTPVerification.update({ where: { id: otpRecord.id }, data: { verified: true } });
    }

    await prisma.user.update({
      where: { id: req.user.id },
      data: { mobile: newMobile, mobileVerified: true },
    });

    const updatedProfile = await buildFullProfile(req.user.id);
    return sendSuccess(res, updatedProfile, 'Mobile number updated');
  } catch (err) {
    next(err);
  }
});

const handleAvatarUpload = async (req, res, next) => {
  try {
    const photoUrl = req.file ? getUploadedFileUrl(req.file) : req.body.profilePhoto || req.body.avatar;
    if (!photoUrl) return sendError(res, 'Profile image file is required', 400);

    await prisma.user.update({
      where: { id: req.user.id },
      data: { profilePhoto: photoUrl },
    });

    const updatedProfile = await buildFullProfile(req.user.id);
    return sendSuccess(res, updatedProfile, 'Profile picture updated');
  } catch (err) {
    next(err);
  }
};

router.post('/avatar', upload.single('avatar'), handleAvatarUpload);
router.put('/photo', upload.single('photo'), handleAvatarUpload);

// PUT /api/profile/password
router.put(
  '/password',
  [
    body('currentPassword').notEmpty().withMessage('Current password is required'),
    body('newPassword').isLength({ min: 6 }).withMessage('New password must be at least 6 characters'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const user = await prisma.user.findUnique({ where: { id: req.user.id } });
      if (!user) return sendError(res, 'User not found', 404);

      const valid = await bcrypt.compare(req.body.currentPassword, user.password);
      if (!valid) return sendError(res, 'Current password is incorrect', 400);

      const hashed = await bcrypt.hash(req.body.newPassword, 10);
      await prisma.user.update({ where: { id: user.id }, data: { password: hashed } });

      await createAuditLog({
        userId: user.id,
        action: 'PASSWORD_CHANGED',
        entity: 'User',
        entityId: user.id,
        ipAddress: req.ip,
      });

      return sendSuccess(res, null, 'Password updated successfully');
    } catch (err) {
      next(err);
    }
  }
);

// GET /api/profile/login-history
router.get('/login-history', async (req, res, next) => {
  try {
    const history = await prisma.loginHistory.findMany({
      where: { userId: req.user.id },
      orderBy: { loginAt: 'desc' },
      take: 25,
    });
    return sendSuccess(res, history, 'Login history fetched');
  } catch (err) {
    next(err);
  }
});

module.exports = router;

const prisma = require('../config/prisma');
const { stringifyJson } = require('./json');

const getClientIp = (req) => {
  if (!req) return null;
  const forwarded = req.headers['x-forwarded-for'];
  if (forwarded) return forwarded.split(',')[0].trim();
  return req.ip || req.connection?.remoteAddress || null;
};

const createAuditLog = async ({
  userId = null,
  gymId = null,
  action,
  entity,
  entityId = null,
  details = {},
  req = null,
}) => {
  try {
    return await prisma.auditLog.create({
      data: {
        userId,
        gymId,
        action,
        entity,
        entityId,
        details: stringifyJson(details, '{}'),
        ipAddress: getClientIp(req),
      },
    });
  } catch (err) {
    console.error('AuditLog write error:', err.message);
    return null;
  }
};

module.exports = {
  createAuditLog,
  getClientIp,
};

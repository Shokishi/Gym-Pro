const parseJson = (val, fallback = null) => {
  if (val === null || val === undefined) return fallback;
  if (typeof val !== 'string') return val;
  try {
    return JSON.parse(val);
  } catch {
    return fallback;
  }
};

const stringifyJson = (val, fallback = '{}') => {
  if (val === null || val === undefined) return fallback;
  if (typeof val === 'string') {
    try {
      JSON.parse(val);
      return val;
    } catch {
      return JSON.stringify(val);
    }
  }
  return JSON.stringify(val);
};

const sanitizeUser = (user) => {
  if (!user) return null;
  const { password, ...rest } = user;
  return {
    ...rest,
    name: rest.fullName || rest.name || '',
    avatar: rest.profilePhoto || rest.avatar || null,
  };
};

const normalizeMobileCandidates = (input) => {
  if (!input) return [];
  const raw = String(input).trim().replace(/[\s\-()]/g, '');
  const digits = raw.replace(/\D/g, '');
  const candidates = new Set([String(input).trim(), raw]);
  if (digits.length === 10) {
    candidates.add(digits);
    candidates.add(`+91${digits}`);
    candidates.add(`91${digits}`);
  } else if (digits.length === 12 && digits.startsWith('91')) {
    const ten = digits.slice(2);
    candidates.add(ten);
    candidates.add(`+91${ten}`);
    candidates.add(digits);
  }
  return Array.from(candidates).filter(Boolean);
};

const canonicalMobile = (input) => {
  if (!input) return null;
  const digits = String(input).replace(/\D/g, '');
  if (digits.length === 10) return `+91${digits}`;
  if (digits.length === 12 && digits.startsWith('91')) return `+${digits}`;
  return String(input).trim();
};

const formatCustomer = (c) => {
  if (!c) return null;
  const user = c.user ? sanitizeUser(c.user) : null;
  const activeMembership =
    c.activeMembership ||
    (Array.isArray(c.memberships)
      ? c.memberships.find((m) => m.status === 'ACTIVE') || c.memberships[0] || null
      : null);

  const trainerName = c.assignedTrainer?.user?.fullName || c.assignedTrainer?.name || null;

  return {
    ...c,
    user,
    name: user?.fullName || c.name || '',
    email: user?.email || c.email || '',
    mobile: user?.mobile || c.mobile || '',
    avatar: user?.profilePhoto || null,
    dob: c.dateOfBirth || null,
    status: c.isActive === false ? 'INACTIVE' : 'ACTIVE',
    trainerId: c.assignedTrainerId || null,
    trainerName,
    trainer: c.assignedTrainer
      ? {
          id: c.assignedTrainer.id,
          trainerId: c.assignedTrainer.trainerId,
          name: trainerName,
          specialization: c.assignedTrainer.specialization,
          mobile: c.assignedTrainer.user?.mobile || null,
          avatar: c.assignedTrainer.user?.profilePhoto || null,
        }
      : null,
    activeMembership: activeMembership
      ? {
          ...activeMembership,
          plan: activeMembership.plan
            ? {
                ...activeMembership.plan,
                services: parseJson(activeMembership.plan.services, []),
                features: parseJson(activeMembership.plan.services, []),
              }
            : null,
        }
      : null,
    planName: activeMembership?.plan?.name || null,
  };
};

const formatTrainer = (t) => {
  if (!t) return null;
  const user = t.user ? sanitizeUser(t.user) : null;
  return {
    ...t,
    user,
    name: user?.fullName || t.name || '',
    email: user?.email || t.email || '',
    mobile: user?.mobile || t.mobile || '',
    avatar: user?.profilePhoto || null,
    status: t.isActive === false ? 'INACTIVE' : 'ACTIVE',
    baseSalary: t.salary ?? 0,
    commissionPercent: t.commission ?? 0,
    experienceYears: t.experience ?? 0,
    clientsCount: t._count?.assignedCustomers ?? (Array.isArray(t.assignedCustomers) ? t.assignedCustomers.length : 0),
    customers: Array.isArray(t.assignedCustomers) ? t.assignedCustomers.map(formatCustomer) : undefined,
    permissions: parseJson(t.permissions, {
      canMarkAttendance: true,
      canManageWorkouts: true,
      canManageDiets: true,
      canViewPayments: false,
      canManageCustomers: false,
      canViewReports: false,
    }),
  };
};

const formatPayment = (p) => {
  if (!p) return null;
  const customer = p.customer ? formatCustomer(p.customer) : null;
  return {
    ...p,
    customer,
    customerName: customer?.name || p.customerName || '',
    transactionId: p.transactionRef || p.transactionId || '',
    description: p.notes || p.description || '',
    receiptNumber: p.transactionRef || `PAY-${String(p.id).slice(0, 8).toUpperCase()}`,
  };
};

const formatSubscriptionPlan = (p) => {
  if (!p) return null;
  const features = parseJson(p.features, []);
  return {
    ...p,
    features,
    maxMembers: p.maxCustomers,
  };
};

const generateReadableId = (prefix = 'ID') => {
  const timestampPart = Date.now().toString().slice(-5);
  const randomPart = Math.floor(100 + Math.random() * 900);
  return `${prefix}-${timestampPart}${randomPart}`;
};

const calculateBMI = (weightKg, heightCm) => {
  if (!weightKg || !heightCm || heightCm <= 0) return null;
  const heightM = heightCm / 100;
  return Number((weightKg / (heightM * heightM)).toFixed(2));
};

module.exports = {
  parseJson,
  stringifyJson,
  sanitizeUser,
  normalizeMobileCandidates,
  canonicalMobile,
  formatCustomer,
  formatTrainer,
  formatPayment,
  formatSubscriptionPlan,
  generateReadableId,
  calculateBMI,
};

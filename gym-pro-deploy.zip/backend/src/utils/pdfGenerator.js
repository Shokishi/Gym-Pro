const { formatIST } = require('./date');

const sanitizePdfText = (input) => {
  if (input === null || input === undefined) return '';
  return String(input)
    .replace(/₹/g, 'Rs. ')
    .replace(/[^\x20-\x7E]/g, ' ')
    .replace(/\\/g, '\\\\')
    .replace(/\(/g, '\\(')
    .replace(/\)/g, '\\)');
};

class SimplePdfDocument {
  constructor() {
    this.pages = [];
    this.currentStream = [];
    this.y = 790;
    this.newPage();
  }

  newPage() {
    if (this.currentStream.length > 0) {
      this.pages.push(this.currentStream.join('\n'));
    }
    this.currentStream = [];
    this.y = 790;
  }

  ensureSpace(needed = 40) {
    if (this.y - needed < 50) {
      this.newPage();
    }
  }

  addText(text, x = 45, y = null, { font = 'F1', size = 10, color = [0.1, 0.1, 0.1] } = {}) {
    const targetY = y !== null ? y : this.y;
    const safe = sanitizePdfText(text);
    this.currentStream.push(
      `BT /${font} ${size} Tf ${color[0]} ${color[1]} ${color[2]} rg 1 0 0 1 ${x} ${targetY} Tm (${safe}) Tj ET`
    );
  }

  addLine(x1, y1, x2, y2, width = 0.75, color = [0.8, 0.8, 0.8]) {
    this.currentStream.push(
      `q ${width} w ${color[0]} ${color[1]} ${color[2]} RG ${x1} ${y1} m ${x2} ${y2} l S Q`
    );
  }

  addRect(x, y, w, h, fillColor = [0.95, 0.96, 0.98]) {
    this.currentStream.push(
      `q ${fillColor[0]} ${fillColor[1]} ${fillColor[2]} rg ${x} ${y} ${w} ${h} re f Q`
    );
  }

  moveDown(px = 16) {
    this.y -= px;
    this.ensureSpace(30);
  }

  build() {
    if (this.currentStream.length > 0) {
      this.pages.push(this.currentStream.join('\n'));
      this.currentStream = [];
    }

    const objects = [];
    const pageIds = [];

    // 1: Catalog, 2: Pages, 3: Helvetica, 4: Helvetica-Bold
    objects.push('<< /Type /Catalog /Pages 2 0 R >>');
    objects.push(''); // placeholder for Pages
    objects.push('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');
    objects.push('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>');

    for (const streamBody of this.pages) {
      const contentBytes = Buffer.byteLength(streamBody, 'latin1');
      const contentId = objects.length + 1;
      objects.push(`<< /Length ${contentBytes} >>\nstream\n${streamBody}\nendstream`);

      const pageId = objects.length + 1;
      pageIds.push(`${pageId} 0 R`);
      objects.push(
        `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${contentId} 0 R >>`
      );
    }

    objects[1] = `<< /Type /Pages /Kids [${pageIds.join(' ')}] /Count ${pageIds.length} >>`;

    const chunks = [];
    let offset = 0;
    const pushStr = (str) => {
      const buf = Buffer.from(str, 'latin1');
      chunks.push(buf);
      offset += buf.length;
    };

    pushStr('%PDF-1.4\n');
    const offsets = [0];

    for (let i = 0; i < objects.length; i++) {
      offsets.push(offset);
      pushStr(`${i + 1} 0 obj\n${objects[i]}\nendobj\n`);
    }

    const xrefOffset = offset;
    pushStr(`xref\n0 ${objects.length + 1}\n`);
    pushStr('0000000000 65535 f \n');
    for (let i = 1; i <= objects.length; i++) {
      pushStr(`${String(offsets[i]).padStart(10, '0')} 00000 n \n`);
    }

    pushStr(
      `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`
    );

    return Buffer.concat(chunks);
  }
}

const formatCurrency = (val) => `Rs. ${Number(val || 0).toFixed(2)}`;

const generateInvoicePDF = (invoice, gym, customer) => {
  const doc = new SimplePdfDocument();

  // Header banner
  doc.addRect(40, 745, 515, 65, [0.1, 0.16, 0.28]);
  doc.addText(gym?.name || 'GYM PRO FITNESS', 55, 782, { font: 'F2', size: 18, color: [1, 1, 1] });
  doc.addText(
    `${gym?.address || ''} ${gym?.city || ''} ${gym?.state || ''}`.trim() || 'Gym Pro SaaS Platform',
    55,
    764,
    { font: 'F1', size: 9, color: [0.85, 0.88, 0.95] }
  );
  doc.addText('TAX INVOICE', 450, 780, { font: 'F2', size: 16, color: [1, 1, 1] });
  doc.addText(`#${invoice.invoiceNumber}`, 450, 762, { font: 'F1', size: 10, color: [0.85, 0.88, 0.95] });

  doc.y = 720;
  doc.addText('Bill To:', 45, doc.y, { font: 'F2', size: 11 });
  doc.addText('Invoice Details:', 350, doc.y, { font: 'F2', size: 11 });
  doc.moveDown(16);

  doc.addText(customer?.user?.fullName || 'Valued Member', 45, doc.y, { font: 'F2', size: 10 });
  doc.addText(`Date: ${formatIST(invoice.createdAt, 'DD MMM YYYY')}`, 350, doc.y, { font: 'F1', size: 10 });
  doc.moveDown(14);

  doc.addText(`Member ID: ${customer?.customerId || 'N/A'}`, 45, doc.y, { font: 'F1', size: 9 });
  doc.addText(
    `Due Date: ${invoice.dueDate ? formatIST(invoice.dueDate, 'DD MMM YYYY') : 'Upon Receipt'}`,
    350,
    doc.y,
    { font: 'F1', size: 10 }
  );
  doc.moveDown(14);

  doc.addText(`Phone: ${customer?.user?.mobile || 'N/A'} | Email: ${customer?.user?.email || 'N/A'}`, 45, doc.y, {
    font: 'F1',
    size: 9,
  });
  doc.addText(`Status: ${invoice.status}`, 350, doc.y, { font: 'F2', size: 10 });
  doc.moveDown(24);

  // Table header
  doc.addRect(40, doc.y - 5, 515, 22, [0.92, 0.94, 0.97]);
  doc.addText('#', 48, doc.y + 2, { font: 'F2', size: 10 });
  doc.addText('Description', 75, doc.y + 2, { font: 'F2', size: 10 });
  doc.addText('Qty', 340, doc.y + 2, { font: 'F2', size: 10 });
  doc.addText('Unit Price', 390, doc.y + 2, { font: 'F2', size: 10 });
  doc.addText('Amount', 480, doc.y + 2, { font: 'F2', size: 10 });
  doc.moveDown(24);

  const items = Array.isArray(invoice.items) ? invoice.items : [];
  items.forEach((item, idx) => {
    doc.ensureSpace(25);
    const qty = Number(item.quantity || 1);
    const price = Number(item.unitPrice ?? item.price ?? item.amount ?? 0);
    const lineTotal = Number(item.total ?? qty * price);
    doc.addText(String(idx + 1), 48, doc.y, { font: 'F1', size: 9 });
    doc.addText(String(item.description || item.name || 'Gym Service').slice(0, 48), 75, doc.y, {
      font: 'F1',
      size: 9,
    });
    doc.addText(String(qty), 345, doc.y, { font: 'F1', size: 9 });
    doc.addText(formatCurrency(price), 390, doc.y, { font: 'F1', size: 9 });
    doc.addText(formatCurrency(lineTotal), 480, doc.y, { font: 'F1', size: 9 });
    doc.addLine(40, doc.y - 6, 555, doc.y - 6, 0.4, [0.9, 0.9, 0.9]);
    doc.moveDown(18);
  });

  doc.moveDown(10);
  doc.addLine(340, doc.y + 8, 555, doc.y + 8, 0.8, [0.7, 0.7, 0.7]);
  doc.addText('Subtotal:', 360, doc.y - 6, { font: 'F1', size: 10 });
  doc.addText(formatCurrency(invoice.subtotal), 475, doc.y - 6, { font: 'F1', size: 10 });
  doc.moveDown(16);

  doc.addText('Discount:', 360, doc.y - 6, { font: 'F1', size: 10 });
  doc.addText(`- ${formatCurrency(invoice.discount)}`, 475, doc.y - 6, { font: 'F1', size: 10 });
  doc.moveDown(16);

  doc.addText('Tax / GST:', 360, doc.y - 6, { font: 'F1', size: 10 });
  doc.addText(formatCurrency(invoice.tax), 475, doc.y - 6, { font: 'F1', size: 10 });
  doc.moveDown(18);

  doc.addRect(350, doc.y - 12, 205, 24, [0.92, 0.95, 0.99]);
  doc.addText('Total:', 360, doc.y - 4, { font: 'F2', size: 11 });
  doc.addText(formatCurrency(invoice.total), 475, doc.y - 4, { font: 'F2', size: 11 });
  doc.moveDown(22);

  doc.addText('Paid Amount:', 360, doc.y - 4, { font: 'F1', size: 10 });
  doc.addText(formatCurrency(invoice.paidAmount), 475, doc.y - 4, { font: 'F1', size: 10 });
  doc.moveDown(16);

  const balance = Math.max(0, Number(invoice.total || 0) - Number(invoice.paidAmount || 0));
  doc.addText('Balance Due:', 360, doc.y - 4, { font: 'F2', size: 10 });
  doc.addText(formatCurrency(balance), 475, doc.y - 4, { font: 'F2', size: 10 });

  doc.addText('Thank you for training with us! Generated by GYM PRO.', 45, 45, {
    font: 'F1',
    size: 8,
    color: [0.45, 0.45, 0.45],
  });

  return doc.build();
};

const generateQuotationPDF = (quotation, gym, customer) => {
  const doc = new SimplePdfDocument();

  doc.addRect(40, 745, 515, 65, [0.13, 0.25, 0.2]);
  doc.addText(gym?.name || 'GYM PRO FITNESS', 55, 782, { font: 'F2', size: 18, color: [1, 1, 1] });
  doc.addText(
    `${gym?.address || ''} ${gym?.city || ''}`.trim() || 'Gym Pro SaaS Platform',
    55,
    764,
    { font: 'F1', size: 9, color: [0.85, 0.92, 0.88] }
  );
  doc.addText('QUOTATION', 440, 780, { font: 'F2', size: 16, color: [1, 1, 1] });
  doc.addText(`#${quotation.quotationNumber}`, 440, 762, { font: 'F1', size: 10, color: [0.85, 0.92, 0.88] });

  doc.y = 720;
  doc.addText('Prepared For:', 45, doc.y, { font: 'F2', size: 11 });
  doc.addText('Quotation Details:', 350, doc.y, { font: 'F2', size: 11 });
  doc.moveDown(16);

  doc.addText(customer?.user?.fullName || 'Prospective Member', 45, doc.y, { font: 'F2', size: 10 });
  doc.addText(`Created: ${formatIST(quotation.createdAt, 'DD MMM YYYY')}`, 350, doc.y, { font: 'F1', size: 10 });
  doc.moveDown(14);

  doc.addText(`Phone: ${customer?.user?.mobile || 'N/A'}`, 45, doc.y, { font: 'F1', size: 9 });
  doc.addText(
    `Valid Until: ${quotation.expiryDate ? formatIST(quotation.expiryDate, 'DD MMM YYYY') : '15 Days'}`,
    350,
    doc.y,
    { font: 'F1', size: 10 }
  );
  doc.moveDown(14);

  doc.addText(`Email: ${customer?.user?.email || 'N/A'}`, 45, doc.y, { font: 'F1', size: 9 });
  doc.addText(`Status: ${quotation.status}`, 350, doc.y, { font: 'F2', size: 10 });
  doc.moveDown(24);

  doc.addRect(40, doc.y - 5, 515, 22, [0.92, 0.95, 0.93]);
  doc.addText('#', 48, doc.y + 2, { font: 'F2', size: 10 });
  doc.addText('Plan / Service', 75, doc.y + 2, { font: 'F2', size: 10 });
  doc.addText('Qty', 340, doc.y + 2, { font: 'F2', size: 10 });
  doc.addText('Rate', 390, doc.y + 2, { font: 'F2', size: 10 });
  doc.addText('Total', 480, doc.y + 2, { font: 'F2', size: 10 });
  doc.moveDown(24);

  const items = Array.isArray(quotation.items) ? quotation.items : [];
  items.forEach((item, idx) => {
    doc.ensureSpace(25);
    const qty = Number(item.quantity || 1);
    const price = Number(item.unitPrice ?? item.price ?? item.amount ?? 0);
    const lineTotal = Number(item.total ?? qty * price);
    doc.addText(String(idx + 1), 48, doc.y, { font: 'F1', size: 9 });
    doc.addText(String(item.description || item.name || 'Membership Plan').slice(0, 48), 75, doc.y, {
      font: 'F1',
      size: 9,
    });
    doc.addText(String(qty), 345, doc.y, { font: 'F1', size: 9 });
    doc.addText(formatCurrency(price), 390, doc.y, { font: 'F1', size: 9 });
    doc.addText(formatCurrency(lineTotal), 480, doc.y, { font: 'F1', size: 9 });
    doc.addLine(40, doc.y - 6, 555, doc.y - 6, 0.4, [0.9, 0.9, 0.9]);
    doc.moveDown(18);
  });

  doc.moveDown(10);
  doc.addText('Subtotal:', 360, doc.y, { font: 'F1', size: 10 });
  doc.addText(formatCurrency(quotation.subtotal), 475, doc.y, { font: 'F1', size: 10 });
  doc.moveDown(15);

  doc.addText('Discount:', 360, doc.y, { font: 'F1', size: 10 });
  doc.addText(`- ${formatCurrency(quotation.discount)}`, 475, doc.y, { font: 'F1', size: 10 });
  doc.moveDown(15);

  doc.addText('Tax / GST:', 360, doc.y, { font: 'F1', size: 10 });
  doc.addText(formatCurrency(quotation.tax), 475, doc.y, { font: 'F1', size: 10 });
  doc.moveDown(18);

  doc.addRect(350, doc.y - 6, 205, 22, [0.9, 0.95, 0.92]);
  doc.addText('Grand Total:', 360, doc.y + 1, { font: 'F2', size: 11 });
  doc.addText(formatCurrency(quotation.total), 475, doc.y + 1, { font: 'F2', size: 11 });
  doc.moveDown(28);

  if (quotation.termsAndConditions) {
    doc.addText('Terms & Conditions:', 45, doc.y, { font: 'F2', size: 10 });
    doc.moveDown(14);
    doc.addText(String(quotation.termsAndConditions).slice(0, 95), 45, doc.y, { font: 'F1', size: 9 });
  }

  doc.addText('Generated by GYM PRO SaaS Platform', 45, 45, {
    font: 'F1',
    size: 8,
    color: [0.45, 0.45, 0.45],
  });

  return doc.build();
};

const generateMembershipCardPDF = (customer, gym, membership) => {
  const doc = new SimplePdfDocument();

  doc.addRect(70, 520, 455, 250, [0.09, 0.13, 0.22]);
  doc.addRect(70, 725, 455, 45, [0.95, 0.45, 0.13]);

  doc.addText(gym?.name || 'GYM PRO FITNESS', 90, 742, { font: 'F2', size: 18, color: [1, 1, 1] });
  doc.addText('OFFICIAL MEMBER CARD', 370, 744, { font: 'F2', size: 11, color: [1, 1, 1] });

  doc.addText(customer?.user?.fullName || 'Member', 90, 685, { font: 'F2', size: 16, color: [1, 1, 1] });
  doc.addText(`Member ID: ${customer?.customerId || 'N/A'}`, 90, 660, {
    font: 'F1',
    size: 11,
    color: [0.85, 0.88, 0.94],
  });
  doc.addText(`Mobile: ${customer?.user?.mobile || 'N/A'}`, 90, 640, {
    font: 'F1',
    size: 10,
    color: [0.85, 0.88, 0.94],
  });
  doc.addText(`Branch: ${customer?.branch?.name || 'Main Branch'}`, 90, 620, {
    font: 'F1',
    size: 10,
    color: [0.85, 0.88, 0.94],
  });

  if (membership) {
    doc.addText(`Plan: ${membership.plan?.name || 'Membership'}`, 90, 585, {
      font: 'F2',
      size: 11,
      color: [0.98, 0.78, 0.35],
    });
    doc.addText(
      `Valid: ${formatIST(membership.startDate, 'DD MMM YYYY')} - ${formatIST(membership.endDate, 'DD MMM YYYY')}`,
      90,
      565,
      { font: 'F1', size: 10, color: [1, 1, 1] }
    );
    doc.addText(`Status: ${membership.status}`, 90, 545, {
      font: 'F2',
      size: 10,
      color: [0.4, 0.92, 0.6],
    });
  } else {
    doc.addText('No Active Membership', 90, 575, { font: 'F2', size: 11, color: [0.98, 0.5, 0.5] });
  }

  return doc.build();
};

const generateReportPDF = (title, subtitle, headers = [], rows = []) => {
  const doc = new SimplePdfDocument();

  doc.addRect(40, 760, 515, 50, [0.1, 0.16, 0.28]);
  doc.addText(title, 55, 790, { font: 'F2', size: 15, color: [1, 1, 1] });
  doc.addText(subtitle || `Generated on ${formatIST(new Date())}`, 55, 772, {
    font: 'F1',
    size: 9,
    color: [0.85, 0.88, 0.95],
  });

  doc.y = 735;
  const colWidth = Math.floor(500 / Math.max(1, headers.length));

  doc.addRect(40, doc.y - 4, 515, 20, [0.92, 0.94, 0.97]);
  headers.forEach((h, i) => {
    doc.addText(String(h).slice(0, 18), 46 + i * colWidth, doc.y + 2, { font: 'F2', size: 9 });
  });
  doc.moveDown(22);

  rows.forEach((row) => {
    doc.ensureSpace(24);
    row.forEach((cell, i) => {
      doc.addText(String(cell ?? '').slice(0, 22), 46 + i * colWidth, doc.y, { font: 'F1', size: 8 });
    });
    doc.addLine(40, doc.y - 5, 555, doc.y - 5, 0.3, [0.9, 0.9, 0.9]);
    doc.moveDown(16);
  });

  return doc.build();
};

module.exports = {
  generateInvoicePDF,
  generateQuotationPDF,
  generateMembershipCardPDF,
  generateReportPDF,
};

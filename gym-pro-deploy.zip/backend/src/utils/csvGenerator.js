const escapeCsvCell = (value) => {
  if (value === null || value === undefined) return '';
  const str = String(value);
  if (/[",\n\r]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
};

const generateCSV = (headers = [], rows = []) => {
  const headerLine = headers.map(escapeCsvCell).join(',');
  const dataLines = rows.map((row) => row.map(escapeCsvCell).join(','));
  // Prepend UTF-8 BOM so Excel renders INR symbol cleanly
  return '\uFEFF' + [headerLine, ...dataLines].join('\r\n');
};

module.exports = {
  generateCSV,
};

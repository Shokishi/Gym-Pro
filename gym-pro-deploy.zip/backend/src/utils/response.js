/**
 * Consistent API response helpers
 * Standard format: { success: boolean, data?: any, error?: string, message?: string }
 */

const sendSuccess = (res, data = null, message = 'Success', statusCode = 200) => {
  const payload = {
    success: true,
    message,
  };
  if (data !== undefined && data !== null) {
    payload.data = data;
  }
  return res.status(statusCode).json(payload);
};

const sendError = (res, error = 'Something went wrong', statusCode = 400, data = null) => {
  const payload = {
    success: false,
    error,
  };
  if (data !== undefined && data !== null) {
    payload.data = data;
  }
  return res.status(statusCode).json(payload);
};

const getPagination = (query = {}) => {
  const page = Math.max(1, parseInt(query.page, 10) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(query.limit, 10) || 20));
  const skip = (page - 1) * limit;
  return { page, limit, skip };
};

const formatPaginatedData = (items, total, page, limit) => {
  const totalPages = Math.ceil(total / limit) || 1;
  return {
    items,
    pagination: {
      total,
      page,
      limit,
      totalPages,
      hasNextPage: page < totalPages,
      hasPrevPage: page > 1,
    },
  };
};

module.exports = {
  sendSuccess,
  sendError,
  getPagination,
  formatPaginatedData,
};

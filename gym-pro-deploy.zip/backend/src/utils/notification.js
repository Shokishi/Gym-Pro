const prisma = require('../config/prisma');
const { stringifyJson, parseJson } = require('./json');

const createNotification = async ({
  userId,
  gymId = null,
  type = 'INFO',
  title,
  message,
  data = {},
  io = null,
}) => {
  try {
    const notification = await prisma.notification.create({
      data: {
        userId,
        gymId,
        type,
        title,
        message,
        data: stringifyJson(data, '{}'),
      },
    });

    const formatted = {
      ...notification,
      data: parseJson(notification.data, {}),
    };

    if (io) {
      io.to(`user:${userId}`).emit('notification', formatted);
      io.to(`user:${userId}`).emit('notification:new', formatted);
    }

    return formatted;
  } catch (err) {
    console.error('Notification creation error:', err.message);
    return null;
  }
};

module.exports = {
  createNotification,
};

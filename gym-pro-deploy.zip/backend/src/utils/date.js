const dayjs = require('dayjs');
const utc = require('dayjs/plugin/utc');
const timezone = require('dayjs/plugin/timezone');

dayjs.extend(utc);
dayjs.extend(timezone);

const IST_TZ = 'Asia/Kolkata';

const nowIST = () => dayjs().tz(IST_TZ);

const toIST = (date) => (date ? dayjs(date).tz(IST_TZ) : nowIST());

/**
 * Returns a Date normalized to midnight UTC representing the IST calendar date (YYYY-MM-DD),
 * ensuring consistent date-only comparisons and unique constraints in SQLite.
 */
const getISTDateOnly = (dateInput) => {
  const dateStr = (dateInput ? dayjs(dateInput) : dayjs()).tz(IST_TZ).format('YYYY-MM-DD');
  return new Date(`${dateStr}T00:00:00.000Z`);
};

const getISTDayRange = (dateInput) => {
  const d = (dateInput ? dayjs(dateInput) : dayjs()).tz(IST_TZ);
  return {
    start: d.startOf('day').toDate(),
    end: d.endOf('day').toDate(),
  };
};

const getISTMonthRange = (month, year) => {
  const now = nowIST();
  const m = parseInt(month, 10) || now.month() + 1;
  const y = parseInt(year, 10) || now.year();
  const start = dayjs.tz(`${y}-${String(m).padStart(2, '0')}-01`, IST_TZ).startOf('month');
  const end = start.endOf('month');
  return {
    month: m,
    year: y,
    start: start.toDate(),
    end: end.toDate(),
    dateOnlyStart: new Date(`${start.format('YYYY-MM-DD')}T00:00:00.000Z`),
    dateOnlyEnd: new Date(`${end.format('YYYY-MM-DD')}T23:59:59.999Z`),
  };
};

const formatIST = (date, format = 'DD MMM YYYY, hh:mm A') => {
  if (!date) return '';
  return dayjs(date).tz(IST_TZ).format(format);
};

module.exports = {
  dayjs,
  IST_TZ,
  nowIST,
  toIST,
  getISTDateOnly,
  getISTDayRange,
  getISTMonthRange,
  formatIST,
};

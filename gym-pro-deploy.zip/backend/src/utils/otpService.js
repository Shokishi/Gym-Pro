const nodemailer = require('nodemailer');
const https = require('https');

let transporter = null;

/**
 * Initialize or get reusable Nodemailer transporter
 */
const getEmailTransporter = () => {
  if (transporter) return transporter;

  const host = process.env.SMTP_HOST || 'smtp.gmail.com';
  const port = parseInt(process.env.SMTP_PORT, 10) || 587;
  const secure = process.env.SMTP_SECURE === 'true' || port === 465;
  const user = process.env.SMTP_USER || process.env.EMAIL_USER;
  const pass = process.env.SMTP_PASS || process.env.EMAIL_PASS;

  if (user && pass) {
    transporter = nodemailer.createTransport({
      host,
      port,
      secure,
      auth: { user, pass },
      pool: true,
      maxConnections: 5,
      maxMessages: 100,
    });
    console.log(`[OTP Service] Email transport configured using ${host}:${port} (${user})`);
  } else {
    transporter = null;
  }

  return transporter;
};

/**
 * Generate a responsive, professional HTML email template
 */
const generateEmailTemplate = ({ otp, purpose, recipientName }) => {
  const purposeLabels = {
    REGISTER: 'Account Registration & Verification',
    LOGIN_2FA: 'Two-Factor Authentication (2FA)',
    RESET_PASSWORD: 'Password Reset Request',
    VERIFY_MOBILE: 'Mobile Number Verification',
  };

  const label = purposeLabels[purpose] || 'Verification Code';

  return `
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GYM PRO - ${label}</title>
    <style>
      body { margin: 0; padding: 0; background-color: #0b0f19; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #f3f4f6; }
      .container { max-width: 560px; margin: 40px auto; background-color: #111827; border: 1px solid #1f2937; border-radius: 16px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.5); }
      .header { background: linear-gradient(135deg, #f97316 0%, #ea580c 100%); padding: 32px 24px; text-align: center; }
      .logo-title { font-size: 28px; font-weight: 800; color: #ffffff; letter-spacing: -0.5px; margin: 0; }
      .logo-sub { font-size: 13px; color: rgba(255,255,255,0.85); margin-top: 4px; text-transform: uppercase; letter-spacing: 1px; }
      .content { padding: 36px 32px; }
      .greeting { font-size: 18px; font-weight: 600; color: #ffffff; margin-bottom: 12px; }
      .message { font-size: 15px; color: #9ca3af; line-height: 1.6; margin-bottom: 24px; }
      .otp-box { background-color: #1f2937; border: 2px dashed #f97316; border-radius: 12px; padding: 20px; text-align: center; margin: 28px 0; }
      .otp-code { font-size: 38px; font-weight: 800; color: #f97316; letter-spacing: 10px; font-family: 'Courier New', Courier, monospace; margin: 0; }
      .otp-expiry { font-size: 13px; color: #9ca3af; margin-top: 8px; }
      .security-box { background-color: rgba(239, 68, 68, 0.1); border-left: 4px solid #ef4444; padding: 12px 16px; border-radius: 6px; font-size: 13px; color: #fca5a5; margin: 24px 0; }
      .footer { background-color: #0b0f19; padding: 24px; text-align: center; font-size: 12px; color: #6b7280; border-top: 1px solid #1f2937; }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="header">
        <h1 class="logo-title">GYM PRO</h1>
        <div class="logo-sub">Gym Management SaaS Platform</div>
      </div>
      <div class="content">
        <div class="greeting">Hello ${recipientName || 'there'},</div>
        <p class="message">
          You recently requested a one-time verification code for <strong>${label}</strong> on the GYM PRO platform.
        </p>
        <div class="otp-box">
          <div class="otp-code">${otp}</div>
          <div class="otp-expiry">This code is valid for <strong>15 minutes</strong></div>
        </div>
        <div class="security-box">
          <strong>Security Warning:</strong> Never share this OTP with anyone. GYM PRO staff or gym administrators will never ask for your code.
        </div>
        <p class="message" style="margin-bottom: 0;">
          If you did not make this request, you can safely ignore this email.
        </p>
      </div>
      <div class="footer">
        &copy; ${new Date().getFullYear()} GYM PRO Platform. All rights reserved.
      </div>
    </div>
  </body>
  </html>
  `;
};

/**
 * Send real-time OTP via Email
 */
const sendEmailOtp = async ({ to, otp, purpose, recipientName }) => {
  if (!to || !to.includes('@')) return { success: false, reason: 'Invalid email address' };

  const mailer = getEmailTransporter();
  const from = process.env.EMAIL_FROM || `"GYM PRO" <${process.env.SMTP_USER || 'no-reply@gympro.com'}>`;
  const subject = `GYM PRO - Your Verification Code is ${otp}`;
  const html = generateEmailTemplate({ otp, purpose, recipientName });

  if (mailer) {
    try {
      const info = await mailer.sendMail({
        from,
        to,
        subject,
        html,
        text: `Your GYM PRO verification code is: ${otp}. It is valid for 15 minutes. Do not share it with anyone.`,
      });
      console.log(`[OTP:EMAIL SUCCESS] Real-time email sent to ${to} (MessageId: ${info.messageId})`);
      return { success: true, messageId: info.messageId };
    } catch (err) {
      console.error(`[OTP:EMAIL ERROR] Failed to send email to ${to}:`, err.message);
      return { success: false, error: err.message };
    }
  } else {
    console.log(`\n======================================================`);
    console.log(`[OTP:EMAIL SIMULATION]`);
    console.log(`Recipient : ${to}`);
    console.log(`OTP Code  : >>> ${otp} <<<`);
    console.log(`Purpose   : ${purpose}`);
    console.log(`Note      : To deliver real emails directly to inboxes, add`);
    console.log(`            SMTP_USER and SMTP_PASS in backend/.env`);
    console.log(`======================================================\n`);
    return { success: true, simulated: true };
  }
};

/**
 * Send real-time OTP via SMS (supports Twilio & Fast2SMS)
 */
const sendSmsOtp = async ({ mobile, otp, purpose }) => {
  if (!mobile) return { success: false, reason: 'No mobile provided' };

  const cleanMobile = String(mobile).replace(/[^\d+]/g, '');

  // 1. Twilio Integration
  if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && process.env.TWILIO_PHONE_NUMBER) {
    try {
      const auth = Buffer.from(`${process.env.TWILIO_ACCOUNT_SID}:${process.env.TWILIO_AUTH_TOKEN}`).toString('base64');
      const postData = new URLSearchParams({
        To: cleanMobile.startsWith('+') ? cleanMobile : `+91${cleanMobile}`,
        From: process.env.TWILIO_PHONE_NUMBER,
        Body: `Your GYM PRO verification code is ${otp}. Valid for 15 mins. Do not share this OTP.`,
      }).toString();

      await new Promise((resolve, reject) => {
        const req = https.request(
          `https://api.twilio.com/2010-04-01/Accounts/${process.env.TWILIO_ACCOUNT_SID}/Messages.json`,
          {
            method: 'POST',
            headers: {
              Authorization: `Basic ${auth}`,
              'Content-Type': 'application/x-www-form-urlencoded',
              'Content-Length': Buffer.byteLength(postData),
            },
          },
          (res) => {
            let data = '';
            res.on('data', (chunk) => (data += chunk));
            res.on('end', () => (res.statusCode >= 200 && res.statusCode < 300 ? resolve(data) : reject(new Error(data))));
          }
        );
        req.on('error', reject);
        req.write(postData);
        req.end();
      });

      console.log(`[OTP:SMS SUCCESS] Real-time SMS dispatched via Twilio to ${cleanMobile}`);
      return { success: true, provider: 'twilio' };
    } catch (err) {
      console.error(`[OTP:SMS ERROR] Twilio failed for ${cleanMobile}:`, err.message);
    }
  }

  // 2. Fast2SMS Integration (popular in India)
  if (process.env.FAST2SMS_API_KEY) {
    try {
      const numbers = cleanMobile.replace(/^\+91/, '').slice(-10);
      const postData = JSON.stringify({
        variables_values: otp,
        route: 'otp',
        numbers,
      });

      await new Promise((resolve, reject) => {
        const req = https.request('https://www.fast2sms.com/dev/bulkV2', {
          method: 'POST',
          headers: {
            authorization: process.env.FAST2SMS_API_KEY,
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(postData),
          },
        }, (res) => {
          let data = '';
          res.on('data', (chunk) => (data += chunk));
          res.on('end', () => (res.statusCode === 200 ? resolve(data) : reject(new Error(data))));
        });
        req.on('error', reject);
        req.write(postData);
        req.end();
      });

      console.log(`[OTP:SMS SUCCESS] Real-time SMS dispatched via Fast2SMS to ${numbers}`);
      return { success: true, provider: 'fast2sms' };
    } catch (err) {
      console.error(`[OTP:SMS ERROR] Fast2SMS failed for ${cleanMobile}:`, err.message);
    }
  }

  // 3. Fallback / Console Output
  console.log(`\n======================================================`);
  console.log(`[OTP:SMS SIMULATION]`);
  console.log(`Mobile   : ${cleanMobile}`);
  console.log(`OTP Code : >>> ${otp} <<<`);
  console.log(`Message  : Your GYM PRO verification code is ${otp}. Valid for 15 mins.`);
  console.log(`Note     : Add TWILIO or FAST2SMS credentials in .env to deliver real SMS`);
  console.log(`======================================================\n`);
  return { success: true, simulated: true };
};

/**
 * Dispatch real-time OTP to Email, SMS, or Both
 */
const dispatchRealtimeOtp = async ({ target, email, mobile, otp, purpose, recipientName }) => {
  const tasks = [];

  const targetIsEmail = target && target.includes('@');
  const targetIsMobile = target && !targetIsEmail;

  const resolvedEmail = email || (targetIsEmail ? target : null);
  const resolvedMobile = mobile || (targetIsMobile ? target : null);

  if (resolvedEmail) {
    tasks.push(sendEmailOtp({ to: resolvedEmail, otp, purpose, recipientName }));
  }

  if (resolvedMobile) {
    tasks.push(sendSmsOtp({ mobile: resolvedMobile, otp, purpose }));
  }

  const results = await Promise.allSettled(tasks);
  return {
    otp,
    emailDispatched: Boolean(resolvedEmail),
    smsDispatched: Boolean(resolvedMobile),
    results,
  };
};

module.exports = {
  getEmailTransporter,
  sendEmailOtp,
  sendSmsOtp,
  dispatchRealtimeOtp,
};

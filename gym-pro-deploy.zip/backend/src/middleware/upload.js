const fs = require('fs');
const path = require('path');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');

const UPLOADS_ROOT = path.resolve(__dirname, '../../uploads');

const ensureDir = (dirPath) => {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
};

ensureDir(UPLOADS_ROOT);

const resolveSubFolder = (req, file) => {
  const field = file.fieldname || '';
  const url = req.originalUrl || '';

  if (field === 'profilePhoto' || url.includes('/profile/photo')) return 'profiles';
  if (field === 'logo' || url.includes('/gym/profile')) return 'gyms';
  if (field === 'screenshot' || field === 'screenshotUrl' || url.includes('/payments')) {
    if (field.toLowerCase().includes('qr') || url.includes('/qr-settings')) return 'qr';
    return 'payments';
  }
  if (field === 'receipt' || field === 'receiptUrl' || url.includes('/expenses') || url.includes('/subscription')) {
    return 'receipts';
  }
  if (field === 'progressPhoto' || url.includes('/progress')) return 'progress';
  if (field === 'qrCodeImage' || field === 'upiQrCode' || field === 'upiQrCodeImage') return 'qr';
  if (url.includes('/workouts')) return 'workouts';
  return 'misc';
};

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const subFolder = resolveSubFolder(req, file);
    const dest = path.join(UPLOADS_ROOT, subFolder);
    ensureDir(dest);
    cb(null, dest);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase();
    const safeExt = ext || '.bin';
    cb(null, `${uuidv4()}${safeExt}`);
  },
});

const allowedMimeTypes = new Set([
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp',
  'image/gif',
  'application/pdf',
  'video/mp4',
  'video/webm',
]);

const fileFilter = (req, file, cb) => {
  if (allowedMimeTypes.has(file.mimetype)) {
    cb(null, true);
  } else {
    const err = new Error(`Unsupported file type: ${file.mimetype}. Allowed: JPG, PNG, WEBP, GIF, PDF, MP4.`);
    err.statusCode = 400;
    cb(err, false);
  }
};

const maxFileSize = parseInt(process.env.MAX_FILE_SIZE, 10) || 5 * 1024 * 1024;

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: maxFileSize,
  },
});

const getUploadedFileUrl = (file) => {
  if (!file) return null;
  const rel = path.relative(UPLOADS_ROOT, file.path).replace(/\\/g, '/');
  return `/uploads/${rel}`;
};

module.exports = {
  upload,
  UPLOADS_ROOT,
  getUploadedFileUrl,
};

const prisma = require('../config/prisma');
const { sendError } = require('../utils/response');
const { parseJson } = require('../utils/json');
const { dayjs, IST_TZ } = require('../utils/date');
const { createNotification } = require('../utils/notification');

/**
 * Evaluates and syncs trial / paid subscription expiration & grace period for a gym,
 * and creates trial reminder notifications (days 5, 6, 7 or configured schedule).
 */
const syncGymSubscriptionLifecycle = async (gym, io = null) => {
  if (!gym) return gym;
  const now = dayjs().tz(IST_TZ);

  const latestSub = await prisma.gymSubscription.findFirst({
    where: { gymId: gym.id },
    orderBy: { createdAt: 'desc' },
    include: { plan: true },
  });

  // Check trial reminder schedule (e.g. days 5, 6, 7 of trial)
  if (gym.subscriptionStatus === 'TRIAL' && gym.trialStartDate && gym.trialEndDate) {
    const trialSettings = await prisma.trialSettings.findFirst();
    const reminderDays = parseJson(trialSettings?.reminderDays, [5, 6, 7]);
    const dayOfTrial = Math.max(1, now.startOf('day').diff(dayjs(gym.trialStartDate).tz(IST_TZ).startOf('day'), 'day') + 1);
    const daysRemaining = Math.max(0, dayjs(gym.trialEndDate).tz(IST_TZ).startOf('day').diff(now.startOf('day'), 'day'));

    if (Array.isArray(reminderDays) && reminderDays.includes(dayOfTrial)) {
      const existingReminder = await prisma.notification.findFirst({
        where: {
          userId: gym.ownerId,
          gymId: gym.id,
          type: `TRIAL_REMINDER_DAY_${dayOfTrial}`,
        },
      });
      if (!existingReminder) {
        await createNotification({
          userId: gym.ownerId,
          gymId: gym.id,
          type: `TRIAL_REMINDER_DAY_${dayOfTrial}`,
          title: `Free Trial Day ${dayOfTrial} Reminder`,
          message:
            daysRemaining === 0
              ? 'Your 7-day GYM PRO free trial expires today! Upgrade your subscription to keep uninterrupted access.'
              : `Your 7-day GYM PRO free trial has ${daysRemaining} day(s) remaining. Upgrade anytime to retain Premium features.`,
          data: { dayOfTrial, daysRemaining },
          io,
        });
      }
    }
  }

  // Check expiry for TRIAL or ACTIVE subscriptions
  if (latestSub && ['TRIAL', 'ACTIVE', 'GRACE'].includes(gym.subscriptionStatus)) {
    const expiryRef = gym.subscriptionStatus === 'TRIAL' ? gym.trialEndDate || latestSub.endDate : latestSub.endDate;
    if (expiryRef && now.isAfter(dayjs(expiryRef))) {
      const graceSettings = await prisma.gracePeriodSettings.findFirst();
      const graceEnabled = graceSettings ? graceSettings.isEnabled : true;
      const graceDays = graceEnabled ? graceSettings?.durationDays ?? 3 : 0;
      const graceEnd = dayjs(expiryRef).add(graceDays, 'day');

      if (graceEnabled && graceDays > 0 && now.isBefore(graceEnd)) {
        if (gym.subscriptionStatus !== 'GRACE') {
          const updated = await prisma.gym.update({
            where: { id: gym.id },
            data: { subscriptionStatus: 'GRACE' },
          });
          await prisma.gymSubscription.update({
            where: { id: latestSub.id },
            data: { status: 'GRACE' },
          });
          return updated;
        }
      } else {
        const updated = await prisma.gym.update({
          where: { id: gym.id },
          data: { subscriptionStatus: 'EXPIRED' },
        });
        await prisma.gymSubscription.update({
          where: { id: latestSub.id },
          data: { status: 'EXPIRED' },
        });
        return updated;
      }
    }
  }

  return gym;
};

/**
 * Multi-tenant gym isolation middleware.
 * Resolves req.gymId and req.gym (and role profile) for GYM_OWNER, TRAINER, CUSTOMER.
 * Ensures users can never access or mutate another gym's data.
 * Also enforces subscription expiry restrictions when allowWhenExpired is false.
 */
const requireGymAccess = ({ allowSuperAdminWithoutGym = false, allowWhenExpired = false } = {}) => {
  return async (req, res, next) => {
    try {
      if (!req.user) {
        return sendError(res, 'Authentication required', 401);
      }

      const requestedGymId =
        req.params.gymId ||
        req.query.gymId ||
        req.body?.gymId ||
        req.headers['x-gym-id'] ||
        null;

      if (req.user.role === 'SUPER_ADMIN') {
        if (requestedGymId) {
          const gym = await prisma.gym.findUnique({ where: { id: requestedGymId } });
          if (!gym) {
            return sendError(res, 'Gym not found', 404);
          }
          req.gymId = gym.id;
          req.gym = gym;
        } else if (!allowSuperAdminWithoutGym) {
          req.gymId = null;
        }
        return next();
      }

      let resolvedGymId = null;

      if (req.user.role === 'GYM_OWNER') {
        const ownerProfile = await prisma.gymOwnerProfile.findUnique({
          where: { userId: req.user.id },
          include: { gym: true },
        });

        let gym = ownerProfile?.gym || null;
        if (!gym) {
          gym = await prisma.gym.findFirst({ where: { ownerId: req.user.id } });
        }

        if (!gym) {
          return sendError(res, 'No gym associated with this owner account', 404);
        }

        gym = await syncGymSubscriptionLifecycle(gym, req.app?.get('io'));
        resolvedGymId = gym.id;
        req.gym = gym;
        req.ownerProfile = ownerProfile;
      } else if (req.user.role === 'TRAINER') {
        const trainerProfile = await prisma.trainerProfile.findUnique({
          where: { userId: req.user.id },
          include: { gym: true },
        });

        if (!trainerProfile) {
          return sendError(res, 'Trainer profile not found', 404);
        }

        const gym = await syncGymSubscriptionLifecycle(trainerProfile.gym, req.app?.get('io'));
        resolvedGymId = trainerProfile.gymId;
        req.gym = gym;
        req.trainerProfile = trainerProfile;
      } else if (req.user.role === 'CUSTOMER') {
        const customerProfile = await prisma.customerProfile.findUnique({
          where: { userId: req.user.id },
          include: { gym: true },
        });

        if (!customerProfile) {
          return sendError(res, 'Customer profile not found', 404);
        }

        const gym = await syncGymSubscriptionLifecycle(customerProfile.gym, req.app?.get('io'));
        resolvedGymId = customerProfile.gymId;
        req.gym = gym;
        req.customerProfile = customerProfile;
      }

      if (!resolvedGymId) {
        return sendError(res, 'Unable to resolve gym context', 403);
      }

      if (requestedGymId && requestedGymId !== resolvedGymId) {
        return sendError(res, 'Access denied: cross-tenant gym access is forbidden', 403);
      }

      if (req.gym && !req.gym.isActive) {
        return sendError(res, 'This gym account is currently suspended', 403);
      }

      if (!allowWhenExpired && req.gym && req.gym.subscriptionStatus === 'EXPIRED') {
        return res.status(402).json({
          success: false,
          code: 'SUBSCRIPTION_EXPIRED',
          error: 'Your GYM PRO subscription or free trial has expired. Please renew your subscription to restore access.',
        });
      }

      req.gymId = resolvedGymId;
      next();
    } catch (err) {
      next(err);
    }
  };
};

module.exports = {
  requireGymAccess,
  syncGymSubscriptionLifecycle,
};

require('dotenv').config();
process.env.TZ = process.env.TZ || 'Asia/Kolkata';
process.env.JWT_SECRET = process.env.JWT_SECRET || 'gympro_secure_production_jwt_secret_2026';
process.env.JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'gympro_secure_production_jwt_refresh_secret_2026';
process.env.DATABASE_URL = process.env.DATABASE_URL || 'file:./dev.db';

const http = require('http');
const fs = require('fs');
const path = require('path');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');

const prisma = require('./config/prisma');
const { initSocket } = require('./socket');
const { UPLOADS_ROOT } = require('./middleware/upload');
const { notFoundHandler, errorHandler } = require('./middleware/errorHandler');

// Route imports
const authRoutes = require('./routes/auth.routes');
const adminRoutes = require('./routes/admin.routes');
const gymRoutes = require('./routes/gym.routes');
const customerRoutes = require('./routes/customer.routes');
const trainerRoutes = require('./routes/trainer.routes');
const attendanceRoutes = require('./routes/attendance.routes');
const membershipRoutes = require('./routes/membership.routes');
const paymentRoutes = require('./routes/payment.routes');
const workoutRoutes = require('./routes/workout.routes');
const dietRoutes = require('./routes/diet.routes');
const progressRoutes = require('./routes/progress.routes');
const appointmentRoutes = require('./routes/appointment.routes');
const salaryRoutes = require('./routes/salary.routes');
const expenseRoutes = require('./routes/expense.routes');
const enquiryRoutes = require('./routes/enquiry.routes');
const referralRoutes = require('./routes/referral.routes');
const equipmentRoutes = require('./routes/equipment.routes');
const invoiceRoutes = require('./routes/invoice.routes');
const quotationRoutes = require('./routes/quotation.routes');
const notificationRoutes = require('./routes/notification.routes');
const reportRoutes = require('./routes/report.routes');
const profileRoutes = require('./routes/profile.routes');
const couponRoutes = require('./routes/coupon.routes');

const app = express();
const server = http.createServer(app);

// Initialize Socket.io
const io = initSocket(server);
app.set('io', io);

// Trust proxy if behind reverse proxy
app.set('trust proxy', 1);

// Ensure upload directories exist
['profiles', 'gyms', 'payments', 'progress', 'receipts', 'workouts', 'qr', 'misc'].forEach((dir) => {
  const fullPath = path.join(UPLOADS_ROOT, dir);
  if (!fs.existsSync(fullPath)) {
    fs.mkdirSync(fullPath, { recursive: true });
  }
});

// Core security & performance middleware
app.use(
  helmet({
    crossOriginResourcePolicy: { policy: 'cross-origin' },
  })
);
app.use(
  cors({
    origin: true,
    credentials: true,
  })
);
app.use(compression());
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Rate limiting
const apiLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS, 10) || 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX, 10) || 500,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    error: 'Too many requests, please try again later.',
  },
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    error: 'Too many authentication attempts. Please try again after 15 minutes.',
  },
});

app.use('/api', apiLimiter);
app.use('/api/auth/login', authLimiter);
app.use('/api/auth/admin/login', authLimiter);
app.use('/api/auth/send-otp', authLimiter);

// Static files for uploaded assets
app.use('/uploads', express.static(UPLOADS_ROOT));

// Health check endpoints
const healthHandler = async (req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    res.json({
      success: true,
      message: 'GYM PRO API server is running',
      data: {
        status: 'UP',
        timezone: process.env.TZ,
        timestamp: new Date().toISOString(),
      },
    });
  } catch (err) {
    res.status(503).json({
      success: false,
      error: 'Database health check failed',
    });
  }
};

app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'Welcome to GYM PRO SaaS Backend API',
    data: { version: '1.0.0', docs: '/api/health' },
  });
});
app.get('/health', healthHandler);
app.get('/api/health', healthHandler);

// Mount all API routes
app.use('/api/auth', authRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/gym', gymRoutes);
app.use('/api/customers', customerRoutes);
app.use('/api/trainers', trainerRoutes);
app.use('/api/attendance', attendanceRoutes);
app.use('/api/memberships', membershipRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/workouts', workoutRoutes);
app.use('/api/diet-plans', dietRoutes);
app.use('/api/diets', dietRoutes);
app.use('/api/progress', progressRoutes);
app.use('/api/appointments', appointmentRoutes);
app.use('/api/salaries', salaryRoutes);
app.use('/api/expenses', expenseRoutes);
app.use('/api/enquiries', enquiryRoutes);
app.use('/api/referrals', referralRoutes);
app.use('/api/equipment', equipmentRoutes);
app.use('/api/invoices', invoiceRoutes);
app.use('/api/quotations', quotationRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/coupons', couponRoutes);

// Serve compiled frontend in production if frontend/dist exists
const candidateDistPaths = [
  path.join(__dirname, '../../../frontend/dist'),
  path.join(__dirname, '../../frontend/dist'),
  path.join(__dirname, '../frontend/dist'),
  path.join(process.cwd(), 'frontend/dist'),
  path.join(__dirname, '../../../client/dist'),
  path.join(__dirname, '../../client/dist'),
  path.join(__dirname, '../client/dist'),
  path.join(__dirname, '../dist'),
  path.join(process.cwd(), 'client/dist'),
  path.join(process.cwd(), 'dist'),
];
const clientDistPath = candidateDistPaths.find((p) => fs.existsSync(p));
if (clientDistPath) {
  console.log(`[Static] Serving frontend SPA from: ${clientDistPath}`);
  app.use(express.static(clientDistPath));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api') || req.path.startsWith('/uploads') || req.path.startsWith('/socket.io')) {
      return next();
    }
    res.sendFile(path.join(clientDistPath, 'index.html'));
  });
}

// 404 & global error handling
app.use(notFoundHandler);
app.use(errorHandler);

const PORT = parseInt(process.env.PORT, 10) || 5000;

server.listen(PORT, '0.0.0.0', () => {
  console.log(`GYM PRO Server running on port ${PORT} [${process.env.NODE_ENV || 'development'}] (TZ: ${process.env.TZ})`);

  // Auto-initialize default Super Admin & SaaS plans if missing
  const autoInitDb = async () => {
    try {
      const defaultAdmin = await prisma.user.findUnique({ where: { email: 'admin@gympro.com' } });
      if (!defaultAdmin) {
        console.log('[Auto-Init] Provisioning default Super Admin (admin@gympro.com)...');
        const bcrypt = require('bcryptjs');
        const adminPass = await bcrypt.hash('Admin@123', 10);
        await prisma.user.create({
          data: {
            email: 'admin@gympro.com',
            password: adminPass,
            fullName: 'Arjun Malhotra',
            role: 'SUPER_ADMIN',
            isActive: true,
            isVerified: true,
          },
        });
      }
      const planCount = await prisma.subscriptionPlan.count();
      if (planCount === 0) {
        await prisma.subscriptionPlan.createMany({
          data: [
            { name: 'Starter', description: 'Up to 100 members', monthlyPrice: 999, yearlyPrice: 9999, maxCustomers: 100, maxTrainers: 5, maxBranches: 1, isActive: true },
            { name: 'Professional', description: 'Up to 500 members & multi-branch', monthlyPrice: 1999, yearlyPrice: 19999, maxCustomers: 500, maxTrainers: 20, maxBranches: 3, isPopular: true, isActive: true },
            { name: 'Premium', description: 'Up to 5,000 members & chain scale', monthlyPrice: 3999, yearlyPrice: 39999, maxCustomers: 5000, maxTrainers: 100, maxBranches: 25, isActive: true },
          ],
        });
        console.log('[Auto-Init] Super Admin & SaaS plans seeded successfully!');
      }
    } catch (err) {
      console.warn('[Auto-Init] Notice:', err.message);
    }
  };
  autoInitDb();

  // Run auto-absent for previous day every hour
  const { runAutoAbsentForCompletedDay } = require('./routes/attendance.routes');
  if (typeof runAutoAbsentForCompletedDay === 'function') {
    runAutoAbsentForCompletedDay().catch(() => {});
    setInterval(() => runAutoAbsentForCompletedDay().catch(() => {}), 60 * 60 * 1000);
  }
});

const shutdown = async (signal) => {
  console.log(`\nReceived ${signal}. Shutting down gracefully...`);
  server.close(async () => {
    await prisma.$disconnect();
    process.exit(0);
  });
};

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

module.exports = { app, server, io };

const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');
const prisma = require('./config/prisma');

const resolveUserGymId = async (user) => {
  if (!user) return null;
  if (user.role === 'GYM_OWNER') {
    const ownerProfile = await prisma.gymOwnerProfile.findUnique({
      where: { userId: user.id },
      select: { gymId: true },
    });
    if (ownerProfile) return ownerProfile.gymId;
    const gym = await prisma.gym.findFirst({
      where: { ownerId: user.id },
      select: { id: true },
    });
    return gym?.id || null;
  }
  if (user.role === 'TRAINER') {
    const trainer = await prisma.trainerProfile.findUnique({
      where: { userId: user.id },
      select: { gymId: true },
    });
    return trainer?.gymId || null;
  }
  if (user.role === 'CUSTOMER') {
    const customer = await prisma.customerProfile.findUnique({
      where: { userId: user.id },
      select: { gymId: true },
    });
    return customer?.gymId || null;
  }
  return null;
};

const initSocket = (httpServer) => {
  const io = new Server(httpServer, {
    cors: {
      origin: process.env.CLIENT_URL ? process.env.CLIENT_URL.split(',') : '*',
      methods: ['GET', 'POST', 'PUT', 'DELETE'],
      credentials: true,
    },
  });

  // Authenticate socket connections via JWT
  io.use(async (socket, next) => {
    try {
      let token =
        socket.handshake.auth?.token ||
        socket.handshake.query?.token ||
        socket.handshake.headers?.authorization;

      if (token && token.startsWith('Bearer ')) {
        token = token.slice(7);
      }

      if (!token) {
        return next(new Error('Authentication error: token missing'));
      }

      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await prisma.user.findUnique({
        where: { id: decoded.id },
        select: {
          id: true,
          email: true,
          fullName: true,
          role: true,
          isActive: true,
        },
      });

      if (!user || !user.isActive) {
        return next(new Error('Authentication error: invalid or inactive user'));
      }

      socket.user = user;
      socket.gymId = await resolveUserGymId(user);
      next();
    } catch (err) {
      next(new Error('Authentication error: invalid token'));
    }
  });

  io.on('connection', (socket) => {
    const { user, gymId } = socket;

    // Personal notification room
    socket.join(`user:${user.id}`);

    // Gym-isolated room
    if (gymId) {
      socket.join(`gym:${gymId}`);
      socket.join(`gym:${gymId}:role:${user.role}`);
    }

    if (user.role === 'SUPER_ADMIN') {
      socket.join('admin:platform');
    }

    socket.on('join', (payload) => {
      const requestedGymId = payload?.gymId;
      if (requestedGymId && (user.role === 'SUPER_ADMIN' || requestedGymId === gymId)) {
        socket.join(`gym:${requestedGymId}`);
      }
    });

    socket.on('join_gym', (requestedGymId) => {
      if (!requestedGymId) return;
      if (user.role === 'SUPER_ADMIN' || requestedGymId === gymId) {
        socket.join(`gym:${requestedGymId}`);
        socket.emit('joined_gym', { gymId: requestedGymId });
      } else {
        socket.emit('error_event', { message: 'Unauthorized gym room access' });
      }
    });

    socket.on('leave_gym', (requestedGymId) => {
      if (requestedGymId) {
        socket.leave(`gym:${requestedGymId}`);
      }
    });

    socket.on('ping_check', () => {
      socket.emit('pong_check', { timestamp: new Date().toISOString() });
    });

    socket.on('disconnect', () => {
      // Cleanup handled automatically by socket.io
    });
  });

  return io;
};

const emitToGym = (io, gymId, event, payload) => {
  if (!io || !gymId) return;
  io.to(`gym:${gymId}`).emit(event, payload);
};

const emitToUser = (io, userId, event, payload) => {
  if (!io || !userId) return;
  io.to(`user:${userId}`).emit(event, payload);
};

const emitAttendanceUpdate = (io, gymId, data) => {
  emitToGym(io, gymId, 'attendance:update', data);
  emitToGym(io, gymId, 'attendance:checkin', data);
};

const emitPaymentNotification = (io, gymId, userId, data) => {
  emitToGym(io, gymId, 'payment:notification', data);
  emitToGym(io, gymId, 'payment:updated', data);
  if (userId) {
    emitToUser(io, userId, 'payment:notification', data);
    emitToUser(io, userId, 'payment:updated', data);
  }
};

const emitMembershipStatusChange = (io, gymId, userId, data) => {
  emitToGym(io, gymId, 'membership:status_change', data);
  if (userId) emitToUser(io, userId, 'membership:status_change', data);
};

const emitNewCustomer = (io, gymId, data) => {
  emitToGym(io, gymId, 'customer:new', data);
};

module.exports = {
  initSocket,
  emitToGym,
  emitToUser,
  emitAttendanceUpdate,
  emitPaymentNotification,
  emitMembershipStatusChange,
  emitNewCustomer,
};

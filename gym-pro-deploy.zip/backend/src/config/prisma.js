const path = require('path');
const fs = require('fs');
const { PrismaClient } = require('@prisma/client');

// Locate dev.db in dedicated database folder or fallback to backend/prisma
const databaseFolderDb = path.resolve(__dirname, '../../../database/dev.db');
const backendPrismaDb = path.resolve(__dirname, '../../prisma/dev.db');
const dbPath = fs.existsSync(databaseFolderDb) ? databaseFolderDb : backendPrismaDb;

const globalForPrisma = global;

const prisma =
  globalForPrisma.prisma ||
  new PrismaClient({
    datasources: {
      db: {
        url:
          process.env.DATABASE_URL && !process.env.DATABASE_URL.startsWith('file:./')
            ? process.env.DATABASE_URL
            : `file:${dbPath}`,
      },
    },
    log: process.env.NODE_ENV === 'development' ? ['warn', 'error'] : ['error'],
  });

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma;
}

module.exports = prisma;

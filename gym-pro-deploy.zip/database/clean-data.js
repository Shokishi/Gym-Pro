require('dotenv').config({ path: require('path').resolve(__dirname, '../backend/.env') });
const prisma = require('../backend/src/config/prisma');

async function cleanDataExceptAdmin() {
  console.log('--- Cleaning all data except Super Admin & Platform Configuration ---\n');

  // Verify Super Admin exists
  const admin = await prisma.user.findFirst({
    where: { role: 'SUPER_ADMIN' },
  });

  if (!admin) {
    console.error('Error: Super Admin user not found! Aborting to prevent lockout.');
    process.exit(1);
  }

  console.log(`Found Super Admin: ${admin.fullName} (${admin.email}, ID: ${admin.id})`);

  // Delete records in reverse dependency order
  const operations = [
    { name: 'ExerciseLog', fn: () => prisma.exerciseLog.deleteMany({}) },
    { name: 'Exercise', fn: () => prisma.exercise.deleteMany({}) },
    { name: 'WorkoutPlan', fn: () => prisma.workoutPlan.deleteMany({}) },
    { name: 'DietMeal', fn: () => prisma.dietMeal.deleteMany({}) },
    { name: 'DietPlan', fn: () => prisma.dietPlan.deleteMany({}) },
    { name: 'FitnessProgress', fn: () => prisma.fitnessProgress.deleteMany({}) },
    { name: 'AppointmentBooking', fn: () => prisma.appointmentBooking.deleteMany({}) },
    { name: 'Appointment', fn: () => prisma.appointment.deleteMany({}) },
    { name: 'Attendance', fn: () => prisma.attendance.deleteMany({}) },
    { name: 'TrainerAttendance', fn: () => prisma.trainerAttendance.deleteMany({}) },
    { name: 'Payment', fn: () => prisma.payment.deleteMany({}) },
    { name: 'SubscriptionPayment', fn: () => prisma.subscriptionPayment.deleteMany({}) },
    { name: 'GymSubscription', fn: () => prisma.gymSubscription.deleteMany({}) },
    { name: 'Invoice', fn: () => prisma.invoice.deleteMany({}) },
    { name: 'Quotation', fn: () => prisma.quotation.deleteMany({}) },
    { name: 'Equipment', fn: () => prisma.equipment.deleteMany({}) },
    { name: 'Referral', fn: () => prisma.referral.deleteMany({}) },
    { name: 'Enquiry', fn: () => prisma.enquiry.deleteMany({}) },
    { name: 'Expense', fn: () => prisma.expense.deleteMany({}) },
    { name: 'Salary', fn: () => prisma.salary.deleteMany({}) },
    { name: 'Coupon', fn: () => prisma.coupon.deleteMany({}) },
    { name: 'Domain', fn: () => prisma.domain.deleteMany({}) },
    { name: 'QRPaymentSetting', fn: () => prisma.qRPaymentSetting.deleteMany({}) },
    { name: 'CustomerMembership', fn: () => prisma.customerMembership.deleteMany({}) },
    { name: 'MembershipPlan', fn: () => prisma.membershipPlan.deleteMany({}) },
    { name: 'CustomerProfile', fn: () => prisma.customerProfile.deleteMany({}) },
    { name: 'TrainerInvite', fn: () => prisma.trainerInvite.deleteMany({}) },
    { name: 'TrainerProfile', fn: () => prisma.trainerProfile.deleteMany({}) },
    { name: 'GymOwnerProfile', fn: () => prisma.gymOwnerProfile.deleteMany({}) },
    { name: 'GymBranch', fn: () => prisma.gymBranch.deleteMany({}) },
    { name: 'SupportTicket', fn: () => prisma.supportTicket.deleteMany({}) },
    { name: 'Gym', fn: () => prisma.gym.deleteMany({}) },
    { name: 'Notification', fn: () => prisma.notification.deleteMany({ where: { userId: { not: admin.id } } }) },
    { name: 'AuditLog', fn: () => prisma.auditLog.deleteMany({ where: { userId: { not: admin.id } } }) },
    { name: 'OTPVerification', fn: () => prisma.oTPVerification.deleteMany({}) },
    { name: 'LoginHistory', fn: () => prisma.loginHistory.deleteMany({ where: { userId: { not: admin.id } } }) },
    {
      name: 'Users (Non-Admin)',
      fn: () => prisma.user.deleteMany({ where: { role: { not: 'SUPER_ADMIN' } } }),
    },
  ];

  for (const op of operations) {
    try {
      const res = await op.fn();
      console.log(`Deleted ${res.count ?? 0} ${op.name} record(s)`);
    } catch (err) {
      console.error(`Error deleting ${op.name}:`, err.message);
    }
  }

  // Verify final database state
  console.log('\n--- Final Database Status ---');
  const [
    remainingUsers,
    remainingGyms,
    remainingCustomers,
    remainingTrainers,
    remainingPlans,
    remainingPlatformSettings,
  ] = await Promise.all([
    prisma.user.findMany({ select: { id: true, email: true, fullName: true, role: true } }),
    prisma.gym.count(),
    prisma.customerProfile.count(),
    prisma.trainerProfile.count(),
    prisma.subscriptionPlan.count(),
    prisma.platformSetting.count(),
  ]);

  console.log('Remaining Users:');
  console.table(remainingUsers);
  console.log(`Gyms: ${remainingGyms}`);
  console.log(`Customer Profiles: ${remainingCustomers}`);
  console.log(`Trainer Profiles: ${remainingTrainers}`);
  console.log(`SaaS Subscription Plans: ${remainingPlans}`);
  console.log(`Platform Settings: ${remainingPlatformSettings}`);

  console.log('\n✅ Cleanup complete. Database contains ONLY Super Admin & SaaS platform settings.');
  await prisma.$disconnect();
}

cleanDataExceptAdmin().catch((err) => {
  console.error('Fatal error during cleanup:', err);
  process.exit(1);
});

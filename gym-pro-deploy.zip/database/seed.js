require('dotenv').config({ path: require('path').resolve(__dirname, '../backend/.env') });
process.env.TZ = process.env.TZ || 'Asia/Kolkata';

const bcrypt = require('bcryptjs');
const prisma = require('../backend/src/config/prisma');
const { nowIST, getISTDateOnly } = require('../backend/src/utils/date');

async function main() {
  console.log('Starting GYM PRO database seed...');

  const existingAdmin = await prisma.user.findUnique({
    where: { email: 'admin@gympro.com' },
  });

  if (existingAdmin) {
    console.log('Database already seeded (admin@gympro.com exists). Skipping seed.');
    return;
  }

  const adminPassword = await bcrypt.hash('Admin@123', 10);
  const defaultPassword = await bcrypt.hash('Password@123', 10);

  // 1. Trial & Grace Period Settings & Platform Settings
  await prisma.trialSettings.create({
    data: {
      durationDays: 7,
      isEnabled: true,
      reminderDays: JSON.stringify([5, 6, 7]),
      requirePaymentDetails: false,
    },
  });

  await prisma.gracePeriodSettings.create({
    data: {
      durationDays: 3,
      isEnabled: true,
    },
  });

  await prisma.platformSetting.createMany({
    data: [
      { key: 'platformName', value: JSON.stringify('GYM PRO'), description: 'SaaS Platform Name' },
      { key: 'currency', value: JSON.stringify('INR'), description: 'Default Currency' },
      { key: 'currencySymbol', value: JSON.stringify('₹'), description: 'Currency Symbol' },
      { key: 'defaultGstPercent', value: JSON.stringify(18), description: 'Default GST Rate (%)' },
      { key: 'supportEmail', value: JSON.stringify('support@gympro.in'), description: 'Support Email' },
      { key: 'supportPhone', value: JSON.stringify('+91 98200 11223'), description: 'Support Phone' },
    ],
  });

  // 2. Super Admin
  const superAdmin = await prisma.user.create({
    data: {
      email: 'admin@gympro.com',
      password: adminPassword,
      fullName: 'Arjun Malhotra',
      mobile: '+919820000001',
      role: 'SUPER_ADMIN',
      isActive: true,
      isVerified: true,
      mobileVerified: true,
      emailVerified: true,
    },
  });

  // 3. 3 Subscription Plans (Starter, Professional, Premium in INR)
  const starterPlan = await prisma.subscriptionPlan.create({
    data: {
      name: 'Starter',
      description: 'Perfect for new and small gyms getting started',
      monthlyPrice: 999,
      yearlyPrice: 9999,
      maxCustomers: 100,
      maxTrainers: 5,
      maxBranches: 1,
      features: JSON.stringify([
        'Up to 100 Active Members',
        'Up to 5 Trainers',
        '1 Gym Branch',
        'QR Attendance Check-in',
        'UPI Payment Tracking',
        'Basic Reports & Invoicing',
      ]),
      isActive: true,
    },
  });

  const professionalPlan = await prisma.subscriptionPlan.create({
    data: {
      name: 'Professional',
      description: 'Best value for growing gyms with multiple trainers',
      isPopular: true,
      monthlyPrice: 1999,
      yearlyPrice: 19999,
      maxCustomers: 500,
      maxTrainers: 20,
      maxBranches: 3,
      features: JSON.stringify([
        'Up to 500 Active Members',
        'Up to 20 Trainers',
        'Up to 3 Branches',
        'Workout & Diet Plan Builder',
        'Fitness Progress & BMI Analytics',
        'Staff Payroll & Expense Tracking',
        'PDF Invoices & Quotations',
      ]),
      isActive: true,
    },
  });

  const premiumPlan = await prisma.subscriptionPlan.create({
    data: {
      name: 'Premium',
      description: 'Enterprise-grade features for large gym chains',
      monthlyPrice: 3999,
      yearlyPrice: 39999,
      maxCustomers: 5000,
      maxTrainers: 100,
      maxBranches: 25,
      features: JSON.stringify([
        'Up to 5000 Active Members',
        'Up to 100 Trainers',
        'Up to 25 Branches',
        'Custom Domain & SSL',
        'Real-Time Socket Updates',
        'Advanced P&L & Retention Reports',
        'Priority 24/7 Support',
      ]),
      isActive: true,
    },
  });

  // Platform Coupon
  await prisma.platformCoupon.create({
    data: {
      code: 'LAUNCH20',
      discountType: 'PERCENTAGE',
      discountValue: 20,
      maxUses: 100,
      applicablePlans: JSON.stringify([professionalPlan.id, premiumPlan.id]),
      expiryDate: nowIST().add(180, 'day').toDate(),
      isActive: true,
    },
  });

  // 4. Sample Gym Owner & Gym
  const ownerUser = await prisma.user.create({
    data: {
      email: 'owner@ironpulse.in',
      password: defaultPassword,
      fullName: 'Vikramaditya Singhania',
      mobile: '+919820112233',
      role: 'GYM_OWNER',
      isActive: true,
      isVerified: true,
      mobileVerified: true,
      emailVerified: true,
    },
  });

  const gym = await prisma.gym.create({
    data: {
      name: 'IronPulse Fitness & Strength',
      address: '402, Linking Road, Bandra West',
      city: 'Mumbai',
      state: 'Maharashtra',
      phone: '+919820112233',
      email: 'contact@ironpulse.in',
      ownerId: ownerUser.id,
      isActive: true,
      subscriptionStatus: 'ACTIVE',
      trialStartDate: nowIST().subtract(20, 'day').toDate(),
      trialEndDate: nowIST().subtract(13, 'day').toDate(),
    },
  });

  await prisma.gymOwnerProfile.create({
    data: {
      userId: ownerUser.id,
      gymId: gym.id,
      businessDetails: 'IronPulse Fitness Pvt. Ltd. | GSTIN: 27AABCI1234F1Z5',
      notificationPrefs: JSON.stringify({ email: true, sms: true, whatsapp: true }),
    },
  });

  // Branches
  const bandraBranch = await prisma.gymBranch.create({
    data: {
      gymId: gym.id,
      name: 'Bandra West Flagship',
      address: '402, Linking Road, Bandra West',
      city: 'Mumbai',
      phone: '+919820112233',
      email: 'bandra@ironpulse.in',
      upiId: 'ironpulse.bandra@okicici',
      accountHolderName: 'IronPulse Fitness Pvt Ltd',
      paymentInstructions: 'Scan QR or pay via UPI and share screenshot with transaction ID.',
    },
  });

  const andheriBranch = await prisma.gymBranch.create({
    data: {
      gymId: gym.id,
      name: 'Andheri Lokhandwala Studio',
      address: '12, Oberoi Complex, Andheri West',
      city: 'Mumbai',
      phone: '+919820445566',
      email: 'andheri@ironpulse.in',
      upiId: 'ironpulse.andheri@okicici',
      accountHolderName: 'IronPulse Fitness Pvt Ltd',
      paymentInstructions: 'Pay via GPay / PhonePe / Paytm UPI and upload receipt.',
    },
  });

  // QR Payment Setting
  await prisma.qRPaymentSetting.create({
    data: {
      gymId: gym.id,
      branchId: bandraBranch.id,
      upiId: 'ironpulse.bandra@okicici',
      accountHolderName: 'IronPulse Fitness Pvt Ltd',
      paymentInstructions: 'Please add your Member ID in UPI remarks before submitting screenshot.',
      isActive: true,
    },
  });

  // Gym Subscription & Verified Payment
  const gymSub = await prisma.gymSubscription.create({
    data: {
      gymId: gym.id,
      planId: professionalPlan.id,
      billingPeriod: 'YEARLY',
      startDate: nowIST().subtract(13, 'day').toDate(),
      endDate: nowIST().add(352, 'day').toDate(),
      status: 'ACTIVE',
      amount: 19999,
    },
  });

  await prisma.subscriptionPayment.create({
    data: {
      gymSubscriptionId: gymSub.id,
      gymId: gym.id,
      amount: 19999,
      paymentMethod: 'UPI',
      transactionId: 'UPI20261113987654',
      status: 'VERIFIED',
    },
  });

  await prisma.domain.create({
    data: {
      gymId: gym.id,
      domainName: 'portal.ironpulse.in',
      verificationStatus: 'VERIFIED',
      dnsConfigured: true,
      sslStatus: 'ACTIVE',
      activatedAt: nowIST().subtract(10, 'day').toDate(),
      renewalDate: nowIST().add(355, 'day').toDate(),
    },
  });

  // 5. Trainers (Indian names & +91 phones)
  const trainerData = [
    {
      email: 'rohit.sharma@ironpulse.in',
      fullName: 'Rohit Verma',
      mobile: '+919821100001',
      trainerId: 'TRN-1001',
      specialization: 'Strength & Hypertrophy',
      experience: 6,
      salary: 35000,
      commission: 10,
      branchId: bandraBranch.id,
    },
    {
      email: 'priya.nair@ironpulse.in',
      fullName: 'Priya Nair',
      mobile: '+919821100002',
      trainerId: 'TRN-1002',
      specialization: 'Functional Training & Fat Loss',
      experience: 5,
      salary: 32000,
      commission: 12,
      branchId: bandraBranch.id,
    },
    {
      email: 'kabir.desai@ironpulse.in',
      fullName: 'Kabir Desai',
      mobile: '+919821100003',
      trainerId: 'TRN-1003',
      specialization: 'Yoga & Mobility',
      experience: 4,
      salary: 28000,
      commission: 8,
      branchId: andheriBranch.id,
    },
  ];

  const trainers = [];
  for (const t of trainerData) {
    const u = await prisma.user.create({
      data: {
        email: t.email,
        password: defaultPassword,
        fullName: t.fullName,
        mobile: t.mobile,
        role: 'TRAINER',
        isActive: true,
        isVerified: true,
        mobileVerified: true,
      },
    });
    const tp = await prisma.trainerProfile.create({
      data: {
        userId: u.id,
        gymId: gym.id,
        branchId: t.branchId,
        trainerId: t.trainerId,
        specialization: t.specialization,
        experience: t.experience,
        joiningDate: nowIST().subtract(90, 'day').toDate(),
        salary: t.salary,
        commission: t.commission,
      },
    });
    trainers.push({ user: u, profile: tp });
  }

  // 6. Membership Plans
  const monthlyPlan = await prisma.membershipPlan.create({
    data: {
      gymId: gym.id,
      name: 'Monthly Gold',
      description: 'Full gym floor + cardio + locker access for 30 days',
      durationDays: 30,
      price: 2500,
      joiningFee: 500,
      discount: 0,
      tax: 18,
      services: JSON.stringify(['Gym Floor', 'Cardio Zone', 'Locker & Shower', '1 Body Assessment']),
      planType: 'STANDARD',
      isActive: true,
    },
  });

  const quarterlyPlan = await prisma.membershipPlan.create({
    data: {
      gymId: gym.id,
      name: 'Quarterly Transformation',
      description: '90-day complete strength + group classes + diet chart',
      durationDays: 90,
      price: 6500,
      joiningFee: 0,
      discount: 500,
      tax: 18,
      services: JSON.stringify(['Gym Floor', 'Group Classes', 'Custom Diet Chart', 'Monthly BCA Scan']),
      planType: 'POPULAR',
      isActive: true,
    },
  });

  const annualPlan = await prisma.membershipPlan.create({
    data: {
      gymId: gym.id,
      name: 'Annual Elite VIP',
      description: '365-day unlimited access across all branches + PT sessions',
      durationDays: 365,
      price: 19999,
      joiningFee: 0,
      discount: 1000,
      tax: 18,
      services: JSON.stringify(['All-Branch Access', '4 PT Sessions', 'Steam & Sauna', 'Priority Support']),
      planType: 'PREMIUM',
      isActive: true,
    },
  });

  // Gym Coupon
  await prisma.coupon.create({
    data: {
      gymId: gym.id,
      code: 'FITINDIA10',
      discountType: 'PERCENTAGE',
      discountValue: 10,
      maxUses: 50,
      minOrderAmount: 2000,
      expiryDate: nowIST().add(90, 'day').toDate(),
      applicablePlans: JSON.stringify([quarterlyPlan.id, annualPlan.id]),
      isActive: true,
    },
  });

  // 7. Sample Customers (Indian names)
  const customerData = [
    {
      email: 'aarav.patel@gmail.com',
      fullName: 'Aarav Patel',
      mobile: '+919833001001',
      customerId: 'MEM-1001',
      address: 'Pali Hill, Bandra West, Mumbai',
      emergencyContact: 'Meera Patel',
      emergencyPhone: '+919833001099',
      trainerId: trainers[0].profile.id,
      branchId: bandraBranch.id,
      plan: annualPlan,
    },
    {
      email: 'ananya.iyer@gmail.com',
      fullName: 'Ananya Iyer',
      mobile: '+919833001002',
      customerId: 'MEM-1002',
      address: 'Carter Road, Bandra West, Mumbai',
      emergencyContact: 'Suresh Iyer',
      emergencyPhone: '+919833001098',
      trainerId: trainers[1].profile.id,
      branchId: bandraBranch.id,
      plan: quarterlyPlan,
    },
    {
      email: 'rohan.kulkarni@gmail.com',
      fullName: 'Rohan Kulkarni',
      mobile: '+919833001003',
      customerId: 'MEM-1003',
      address: 'JVPD Scheme, Juhu, Mumbai',
      emergencyContact: 'Sunita Kulkarni',
      emergencyPhone: '+919833001097',
      trainerId: trainers[0].profile.id,
      branchId: bandraBranch.id,
      plan: monthlyPlan,
    },
    {
      email: 'sneha.gupta@gmail.com',
      fullName: 'Sneha Gupta',
      mobile: '+919833001004',
      customerId: 'MEM-1004',
      address: 'Lokhandwala Complex, Andheri West, Mumbai',
      emergencyContact: 'Rajesh Gupta',
      emergencyPhone: '+919833001096',
      trainerId: trainers[2].profile.id,
      branchId: andheriBranch.id,
      plan: quarterlyPlan,
    },
    {
      email: 'karthik.reddy@gmail.com',
      fullName: 'Karthik Reddy',
      mobile: '+919833001005',
      customerId: 'MEM-1005',
      address: 'Versova, Andheri West, Mumbai',
      emergencyContact: 'Lakshmi Reddy',
      emergencyPhone: '+919833001095',
      trainerId: trainers[1].profile.id,
      branchId: andheriBranch.id,
      plan: monthlyPlan,
    },
  ];

  const customers = [];
  for (let i = 0; i < customerData.length; i++) {
    const c = customerData[i];
    const u = await prisma.user.create({
      data: {
        email: c.email,
        password: defaultPassword,
        fullName: c.fullName,
        mobile: c.mobile,
        role: 'CUSTOMER',
        isActive: true,
        isVerified: true,
        mobileVerified: true,
      },
    });
    const cp = await prisma.customerProfile.create({
      data: {
        userId: u.id,
        gymId: gym.id,
        branchId: c.branchId,
        customerId: c.customerId,
        dateOfBirth: new Date(1994 + i, i % 12, 10 + i),
        address: c.address,
        emergencyContact: c.emergencyContact,
        emergencyPhone: c.emergencyPhone,
        assignedTrainerId: c.trainerId,
        joiningDate: nowIST().subtract(45 - i * 5, 'day').toDate(),
      },
    });

    // Assign membership + Invoice + Payment
    const start = nowIST().subtract(15 - i * 2, 'day');
    const end = start.add(c.plan.durationDays, 'day');
    const taxable = Math.max(0, c.plan.price + c.plan.joiningFee - c.plan.discount);
    const taxAmt = Number(((taxable * c.plan.tax) / 100).toFixed(2));
    const totalAmt = Number((taxable + taxAmt).toFixed(2));
    const paidAmt = i === 4 ? 1500 : totalAmt; // Last customer partially paid to demonstrate outstanding dues

    const membership = await prisma.customerMembership.create({
      data: {
        customerId: cp.id,
        planId: c.plan.id,
        gymId: gym.id,
        startDate: start.toDate(),
        endDate: end.toDate(),
        status: 'ACTIVE',
        purchasePrice: c.plan.price,
        joiningFee: c.plan.joiningFee,
        discount: c.plan.discount,
        tax: taxAmt,
        totalPaid: paidAmt,
      },
    });

    await prisma.invoice.create({
      data: {
        gymId: gym.id,
        customerId: cp.id,
        invoiceNumber: `INV-2026-${1001 + i}`,
        membershipId: membership.id,
        items: JSON.stringify([
          {
            description: `${c.plan.name} (${c.plan.durationDays} days)`,
            quantity: 1,
            unitPrice: c.plan.price,
            total: c.plan.price,
          },
        ]),
        subtotal: c.plan.price + c.plan.joiningFee,
        discount: c.plan.discount,
        tax: taxAmt,
        total: totalAmt,
        status: paidAmt >= totalAmt ? 'PAID' : 'PARTIALLY_PAID',
        paidAmount: paidAmt,
        dueDate: end.toDate(),
      },
    });

    await prisma.payment.create({
      data: {
        gymId: gym.id,
        customerId: cp.id,
        membershipId: membership.id,
        amount: paidAmt,
        paymentMethod: i % 2 === 0 ? 'UPI' : 'CASH',
        transactionRef: i % 2 === 0 ? `UPI202611${1000 + i}` : null,
        status: 'APPROVED',
        approvedBy: ownerUser.id,
        approvedAt: start.toDate(),
        notes: `${c.plan.name} membership payment`,
      },
    });

    customers.push({ user: u, profile: cp, membership });
  }

  // Add a pending UPI payment for approval demonstration
  await prisma.payment.create({
    data: {
      gymId: gym.id,
      customerId: customers[4].profile.id,
      membershipId: customers[4].membership.id,
      amount: 2040,
      paymentMethod: 'UPI',
      transactionRef: 'UPI20261126889911',
      status: 'UNDER_REVIEW',
      notes: 'Remaining balance UPI payment',
    },
  });

  // 8. Sample Attendance (today + past 3 days)
  for (let d = 0; d < 4; d++) {
    const attDate = getISTDateOnly(nowIST().subtract(d, 'day').toDate());
    for (let i = 0; i < customers.length; i++) {
      if (d === 1 && i === 3) continue; // vary attendance
      await prisma.attendance.create({
        data: {
          gymId: gym.id,
          customerId: customers[i].profile.id,
          date: attDate,
          status: i === 4 && d === 2 ? 'ABSENT' : 'PRESENT',
          checkInTime: i === 4 && d === 2 ? null : nowIST().subtract(d, 'day').hour(7).minute(15 + i * 10).toDate(),
          checkOutTime: i === 4 && d === 2 ? null : nowIST().subtract(d, 'day').hour(8).minute(30 + i * 10).toDate(),
          markedBy: ownerUser.id,
          method: i % 2 === 0 ? 'QR' : 'MANUAL',
        },
      });
    }
  }

  await prisma.trainerAttendance.create({
    data: {
      gymId: gym.id,
      trainerId: trainers[0].profile.id,
      date: getISTDateOnly(),
      status: 'PRESENT',
      checkInTime: nowIST().hour(6).minute(30).toDate(),
    },
  });

  // 9. Workout Plan & Exercises & ExerciseLog
  const workoutPlan = await prisma.workoutPlan.create({
    data: {
      gymId: gym.id,
      trainerId: trainers[0].profile.id,
      customerId: customers[0].profile.id,
      name: 'Push Day - Chest, Shoulders & Triceps',
      dayOfWeek: 'MONDAY',
      exercises: {
        create: [
          {
            name: 'Barbell Bench Press',
            muscleGroup: 'Chest',
            sets: 4,
            reps: '8-10',
            weight: '60 kg',
            restTime: '90',
            instructions: 'Control eccentric movement for 2 seconds, touch mid-chest lightly.',
            orderIndex: 0,
          },
          {
            name: 'Incline Dumbbell Press',
            muscleGroup: 'Upper Chest',
            sets: 3,
            reps: '10-12',
            weight: '22.5 kg',
            restTime: '75',
            instructions: 'Set bench to 30 degrees incline.',
            orderIndex: 1,
          },
          {
            name: 'Overhead Dumbbell Shoulder Press',
            muscleGroup: 'Shoulders',
            sets: 3,
            reps: '10-12',
            weight: '17.5 kg',
            restTime: '60',
            instructions: 'Keep core braced and avoid lower back arch.',
            orderIndex: 2,
          },
          {
            name: 'Rope Tricep Pushdown',
            muscleGroup: 'Triceps',
            sets: 3,
            reps: '12-15',
            weight: '25 kg',
            restTime: '45',
            instructions: 'Lock elbows at sides and flare rope at bottom.',
            orderIndex: 3,
          },
        ],
      },
    },
    include: { exercises: true },
  });

  await prisma.exerciseLog.create({
    data: {
      exerciseId: workoutPlan.exercises[0].id,
      customerId: customers[0].profile.id,
      date: new Date(),
      completed: true,
      actualSets: 4,
      actualReps: '10, 9, 8, 8',
      actualWeight: '60 kg',
      notes: 'Felt strong on top set.',
    },
  });

  // 10. Diet Plan & Meals (Indian fitness nutrition)
  await prisma.dietPlan.create({
    data: {
      gymId: gym.id,
      trainerId: trainers[1].profile.id,
      customerId: customers[0].profile.id,
      name: 'Lean Muscle Gain - Indian High Protein Plan',
      isActive: true,
      meals: {
        create: [
          {
            mealType: 'BREAKFAST',
            name: 'Moong Dal Chilla with Paneer Stuffing',
            description: '2 Moong Dal Chillas stuffed with 100g low-fat paneer + mint chutney',
            calories: 420,
            protein: 28,
            carbs: 42,
            fats: 14,
            instructions: 'Cook with 1 tsp desi ghee on non-stick tawa.',
          },
          {
            mealType: 'LUNCH',
            name: 'Grilled Chicken / Soya Bhurji with Brown Rice',
            description: '150g grilled chicken breast (or 60g soya chunks), 1 cup brown rice, cucumber raita',
            calories: 560,
            protein: 42,
            carbs: 55,
            fats: 12,
            instructions: 'Include mixed green salad before meal.',
          },
          {
            mealType: 'PRE_WORKOUT',
            name: 'Banana & Black Coffee',
            description: '1 medium banana + 1 cup black coffee + 5 soaked almonds',
            calories: 150,
            protein: 3,
            carbs: 28,
            fats: 4,
            instructions: 'Consume 40 minutes prior to training.',
          },
          {
            mealType: 'POST_WORKOUT',
            name: 'Whey Protein Isolate Shake',
            description: '1 scoop whey protein in 300ml chilled water',
            calories: 120,
            protein: 25,
            carbs: 2,
            fats: 1,
            instructions: 'Take within 30 minutes post workout.',
          },
          {
            mealType: 'DINNER',
            name: 'Tandoori Paneer Tikka & 2 Multigrain Rotis',
            description: '150g tandoori paneer tikka with bell peppers + 2 phulkas + dal',
            calories: 510,
            protein: 30,
            carbs: 48,
            fats: 18,
            instructions: 'Finish dinner at least 2 hours before sleep.',
          },
        ],
      },
    },
  });

  // 11. Fitness Progress
  await prisma.fitnessProgress.createMany({
    data: [
      {
        customerId: customers[0].profile.id,
        gymId: gym.id,
        date: nowIST().subtract(30, 'day').toDate(),
        weight: 78.5,
        height: 176,
        bmi: 25.34,
        bodyFat: 21.0,
        chest: 98,
        waist: 86,
        hips: 99,
        biceps: 34,
        thighs: 56,
        notes: 'Initial baseline assessment',
        measuredBy: trainers[0].user.id,
      },
      {
        customerId: customers[0].profile.id,
        gymId: gym.id,
        date: nowIST().toDate(),
        weight: 76.2,
        height: 176,
        bmi: 24.6,
        bodyFat: 18.4,
        chest: 100,
        waist: 83,
        hips: 97,
        biceps: 35.5,
        thighs: 57,
        notes: 'Great recomposition progress in 4 weeks!',
        measuredBy: trainers[0].user.id,
      },
    ],
  });

  // 12. Appointments & Bookings
  const ptAppt = await prisma.appointment.create({
    data: {
      gymId: gym.id,
      trainerId: trainers[0].profile.id,
      customerId: customers[0].profile.id,
      type: 'PERSONAL_TRAINING',
      title: '1-on-1 Deadlifts & Form Check',
      date: nowIST().add(1, 'day').toDate(),
      startTime: '07:30',
      endTime: '08:30',
      status: 'CONFIRMED',
      capacity: 1,
      bookedCount: 1,
      notes: 'Focus on hip hinge mechanics.',
    },
  });

  await prisma.appointmentBooking.create({
    data: {
      appointmentId: ptAppt.id,
      customerId: customers[0].profile.id,
      status: 'CONFIRMED',
    },
  });

  await prisma.appointment.create({
    data: {
      gymId: gym.id,
      trainerId: trainers[1].profile.id,
      type: 'GROUP_CLASS',
      title: 'Morning HIIT & Core Blast',
      date: nowIST().add(2, 'day').toDate(),
      startTime: '08:00',
      endTime: '09:00',
      status: 'SCHEDULED',
      capacity: 15,
      bookedCount: 0,
      notes: 'Bring water bottle and sweat towel.',
    },
  });

  // 13. Salaries & Expenses
  const currentMonth = nowIST().month() + 1;
  const currentYear = nowIST().year();

  await prisma.salary.create({
    data: {
      gymId: gym.id,
      trainerId: trainers[0].profile.id,
      month: currentMonth,
      year: currentYear,
      baseSalary: 35000,
      commission: 4500,
      bonus: 2000,
      deductions: 0,
      totalAmount: 41500,
      status: 'PAID',
      paidAt: nowIST().subtract(2, 'day').toDate(),
      notes: 'Monthly salary + PT commission',
    },
  });

  await prisma.expense.createMany({
    data: [
      {
        gymId: gym.id,
        branchId: bandraBranch.id,
        category: 'RENT',
        title: 'Monthly Rent - Bandra West',
        description: 'Monthly commercial lease - Bandra West',
        paymentMethod: 'BANK_TRANSFER',
        amount: 85000,
        date: nowIST().subtract(5, 'day').toDate(),
      },
      {
        gymId: gym.id,
        branchId: bandraBranch.id,
        category: 'ELECTRICITY',
        title: 'Electricity Bill',
        description: 'Adani Electricity monthly bill',
        paymentMethod: 'UPI',
        amount: 18500,
        date: nowIST().subtract(3, 'day').toDate(),
      },
      {
        gymId: gym.id,
        branchId: andheriBranch.id,
        category: 'REPAIRS',
        title: 'Treadmill Maintenance',
        description: 'Treadmill belt lubrication & motor service',
        paymentMethod: 'CASH',
        amount: 4200,
        date: nowIST().subtract(1, 'day').toDate(),
      },
    ],
  });

  // 14. Enquiries, Referrals, Equipment, Quotation
  await prisma.enquiry.createMany({
    data: [
      {
        gymId: gym.id,
        name: 'Siddharth Joshi',
        mobile: '+919870112233',
        email: 'siddharth.j@gmail.com',
        source: 'INSTAGRAM',
        status: 'FOLLOW_UP',
        notes: 'Interested in Quarterly Transformation plan',
        followUpDate: nowIST().add(1, 'day').toDate(),
        assignedTo: ownerUser.id,
      },
      {
        gymId: gym.id,
        name: 'Pooja Mehta',
        mobile: '+919870112244',
        email: 'pooja.mehta@gmail.com',
        source: 'WALK_IN',
        status: 'NEW',
        notes: 'Looking for morning yoga & fat loss batch',
        followUpDate: nowIST().add(2, 'day').toDate(),
        assignedTo: trainers[2].user.id,
      },
    ],
  });

  await prisma.referral.create({
    data: {
      gymId: gym.id,
      referrerId: customers[0].profile.id,
      referredName: 'Devansh Kapoor',
      referredMobile: '+919870556677',
      status: 'JOINED',
      rewardType: 'CASHBACK',
      rewardValue: 500,
      rewardIssued: true,
    },
  });

  await prisma.equipment.createMany({
    data: [
      {
        gymId: gym.id,
        branchId: bandraBranch.id,
        name: 'Jerai Commercial Power Rack',
        category: 'Strength',
        quantity: 2,
        purchaseDate: nowIST().subtract(180, 'day').toDate(),
        cost: 120000,
        condition: 'EXCELLENT',
        supplier: 'Jerai Fitness India',
        warrantyExpiry: nowIST().add(540, 'day').toDate(),
        lastMaintenanceDate: nowIST().subtract(30, 'day').toDate(),
        nextMaintenanceDate: nowIST().add(60, 'day').toDate(),
      },
      {
        gymId: gym.id,
        branchId: bandraBranch.id,
        name: 'Cosco Pro Commercial Treadmill',
        category: 'Cardio',
        quantity: 4,
        purchaseDate: nowIST().subtract(300, 'day').toDate(),
        cost: 340000,
        condition: 'GOOD',
        supplier: 'Cosco Sports',
        warrantyExpiry: nowIST().add(365, 'day').toDate(),
        lastMaintenanceDate: nowIST().subtract(85, 'day').toDate(),
        nextMaintenanceDate: nowIST().add(5, 'day').toDate(),
        notes: 'Belt tension check due soon',
      },
    ],
  });

  await prisma.quotation.create({
    data: {
      gymId: gym.id,
      customerId: customers[2].profile.id,
      quotationNumber: 'QTN-2026-1001',
      items: JSON.stringify([
        { description: 'Annual Elite VIP Upgrade', quantity: 1, unitPrice: 19999, total: 19999 },
      ]),
      subtotal: 19999,
      discount: 1000,
      tax: 3419.82,
      total: 22418.82,
      status: 'SENT',
      termsAndConditions: 'Valid for 15 days. Non-transferable.',
      expiryDate: nowIST().add(15, 'day').toDate(),
    },
  });

  // 15. Sample Notifications
  await prisma.notification.createMany({
    data: [
      {
        userId: superAdmin.id,
        type: 'SYSTEM',
        title: 'GYM PRO Platform Initialized',
        message: 'Platform seed completed successfully. 1 gym and 3 subscription plans active.',
        data: JSON.stringify({}),
      },
      {
        userId: ownerUser.id,
        gymId: gym.id,
        type: 'PAYMENT_REVIEW',
        title: 'Pending UPI Payment Verification',
        message: 'Karthik Reddy submitted ₹2,040 via UPI for review.',
        data: JSON.stringify({ amount: 2040 }),
      },
      {
        userId: customers[0].user.id,
        gymId: gym.id,
        type: 'WORKOUT',
        title: 'New Workout & Diet Plan Assigned',
        message: 'Your trainer Rohit Verma updated your Monday Push workout and diet plan.',
        data: JSON.stringify({}),
      },
    ],
  });

  console.log('GYM PRO database seeded successfully!');
  console.log('-----------------------------------------');
  console.log('Super Admin : admin@gympro.com / Admin@123');
  console.log('Gym Owner   : owner@ironpulse.in / Password@123');
  console.log('Trainer     : rohit.sharma@ironpulse.in / Password@123');
  console.log('Customer    : aarav.patel@gmail.com / Password@123');
  console.log('-----------------------------------------');
}

main()
  .catch((err) => {
    console.error('Seed failed:', err);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

# GYM PRO - Database Directory

This directory contains the central persistent database assets, schema definitions, and migration/seeding scripts for the GYM PRO platform.

---

## Directory Structure

```
database/
├── dev.db                 # Persistent SQLite Database file (WAL mode supported)
├── prisma/
│   └── schema.prisma      # Central Prisma schema (37 multi-tenant models)
├── seed.js                # 15-stage seeder for full initial demo data
├── clean-data.js          # Production cleanup script (keeps only Super Admin)
└── README.md              # Database documentation and commands
```

---

## Available Commands

From the project root:

| Command | Description |
| :--- | :--- |
| `npm run db:seed` | Populates sample gyms, trainers, members, workouts, diets, and invoices |
| `npm run db:clean` | Removes all test/demo data, preserving only the Super Admin account and SaaS plans |
| `npm run db:reset` | Resets schema to sync and applies initial seed data |

---

## Super Admin Default Credentials
- **Email**: `admin@gympro.com`
- **Password**: `Admin@123`
- **Role**: `SUPER_ADMIN`

/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        dark: {
          bg: '#101214',
          surface: '#191D21',
          'surface-2': '#22272D',
          border: '#2A2F36',
        },
        accent: {
          DEFAULT: '#F28C28',
          hover: '#E07D1A',
          light: '#F28C2820',
        },
        'text-primary': '#F5F5F5',
        'text-secondary': '#A6ADB5',
        success: {
          DEFAULT: '#27AE60',
          light: '#27AE6020',
        },
        warning: {
          DEFAULT: '#F2B544',
          light: '#F2B54420',
        },
        error: {
          DEFAULT: '#E05252',
          light: '#E0525220',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
    },
  },
  plugins: [require('@tailwindcss/forms')],
};

import { useState, useCallback } from 'react';

export const usePagination = (initialPage = 1, initialLimit = 10) => {
  const [page, setPage] = useState(initialPage);
  const [limit, setLimit] = useState(initialLimit);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);

  const updateMeta = useCallback((meta = {}) => {
    if (meta.page !== undefined) setPage(meta.page);
    if (meta.limit !== undefined) setLimit(meta.limit);
    if (meta.total !== undefined) setTotal(meta.total);
    if (meta.totalPages !== undefined) setTotalPages(Math.max(1, meta.totalPages));
  }, []);

  const resetPage = useCallback(() => setPage(1), []);

  return {
    page,
    limit,
    total,
    totalPages,
    setPage,
    setLimit,
    updateMeta,
    resetPage,
  };
};

export default usePagination;

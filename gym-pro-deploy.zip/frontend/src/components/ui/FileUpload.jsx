import React, { useState, useRef } from 'react';
import { Upload, X, FileText } from 'lucide-react';

export const FileUpload = ({
  label,
  accept = 'image/*,.pdf',
  value,
  previewUrl,
  onChange,
  error,
  hint = 'PNG, JPG, WEBP or PDF up to 5MB',
  maxSizeMB = 5,
}) => {
  const [dragging, setDragging] = useState(false);
  const [localError, setLocalError] = useState('');
  const [localPreview, setLocalPreview] = useState('');
  const inputRef = useRef(null);

  const handleFile = (file) => {
    if (!file) return;
    setLocalError('');
    if (file.size > maxSizeMB * 1024 * 1024) {
      setLocalError(`File exceeds maximum size of ${maxSizeMB}MB`);
      return;
    }
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => setLocalPreview(e.target.result);
      reader.readAsDataURL(file);
    } else {
      setLocalPreview('');
    }
    onChange?.(file);
  };

  const activePreview = localPreview || previewUrl;
  const displayError = error || localError;

  return (
    <div className="w-full">
      {label && <label className="block text-sm font-medium text-text-secondary mb-1.5">{label}</label>}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragging(false);
          const file = e.dataTransfer.files?.[0];
          handleFile(file);
        }}
        onClick={() => inputRef.current?.click()}
        className={`border-2 border-dashed rounded-xl p-5 text-center cursor-pointer transition-colors ${
          dragging
            ? 'border-accent bg-accent-light'
            : displayError
            ? 'border-error bg-error-light/30'
            : 'border-dark-border bg-dark-bg hover:border-accent/60'
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          accept={accept}
          className="hidden"
          onChange={(e) => handleFile(e.target.files?.[0])}
        />

        {activePreview ? (
          <div className="relative inline-block">
            <img
              src={activePreview}
              alt="Preview"
              className="max-h-36 rounded-lg border border-dark-border object-contain mx-auto"
            />
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setLocalPreview('');
                onChange?.(null);
              }}
              className="absolute -top-2 -right-2 p-1 rounded-full bg-error text-white shadow"
              aria-label="Remove file"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : value && typeof value === 'object' ? (
          <div className="flex items-center justify-center gap-2 text-sm text-text-primary">
            <FileText className="w-5 h-5 text-accent" />
            <span className="truncate max-w-xs">{value.name}</span>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-dark-surface-2 flex items-center justify-center text-accent">
              <Upload className="w-5 h-5" />
            </div>
            <p className="text-sm text-text-primary font-medium">
              Click to upload or drag & drop
            </p>
            <p className="text-xs text-text-secondary">{hint}</p>
          </div>
        )}
      </div>
      {displayError && <p className="mt-1.5 text-xs text-error">{displayError}</p>}
    </div>
  );
};

export default FileUpload;

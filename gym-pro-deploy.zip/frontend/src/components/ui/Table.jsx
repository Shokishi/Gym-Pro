import React, { useState, useMemo } from 'react';
import { ArrowUpDown, ArrowUp, ArrowDown, ChevronLeft, ChevronRight } from 'lucide-react';
import EmptyState from './EmptyState';
import Skeleton from './Skeleton';

export const Table = ({
  columns = [],
  data = [],
  loading = false,
  keyField = 'id',
  onRowClick,
  emptyTitle = 'No records found',
  emptyMessage = 'Try adjusting your search or filters to find what you are looking for.',
  emptyAction,
  pagination,
  onPageChange,
  sortBy: controlledSortBy,
  sortOrder: controlledSortOrder,
  onSortChange,
}) => {
  const [internalSort, setInternalSort] = useState({ key: null, direction: 'asc' });
  const activeSortKey = controlledSortBy !== undefined ? controlledSortBy : internalSort.key;
  const activeSortOrder = controlledSortOrder !== undefined ? controlledSortOrder : internalSort.direction;

  const handleSort = (col) => {
    if (!col.sortable) return;
    const key = col.sortKey || col.key;
    const nextDirection =
      activeSortKey === key && activeSortOrder === 'asc' ? 'desc' : 'asc';

    if (onSortChange) {
      onSortChange(key, nextDirection);
    } else {
      setInternalSort({ key, direction: nextDirection });
    }
  };

  const sortedData = useMemo(() => {
    if (onSortChange || !activeSortKey) return data;
    return [...data].sort((a, b) => {
      const aVal = a?.[activeSortKey] ?? '';
      const bVal = b?.[activeSortKey] ?? '';
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return activeSortOrder === 'asc' ? aVal - bVal : bVal - aVal;
      }
      return activeSortOrder === 'asc'
        ? String(aVal).localeCompare(String(bVal))
        : String(bVal).localeCompare(String(aVal));
    });
  }, [data, activeSortKey, activeSortOrder, onSortChange]);

  if (loading) {
    return <Skeleton variant="table" rows={6} columns={columns.length || 5} />;
  }

  if (!data || data.length === 0) {
    return (
      <div className="bg-dark-surface border border-dark-border rounded-xl p-6">
        <EmptyState title={emptyTitle} message={emptyMessage} action={emptyAction} />
      </div>
    );
  }

  const page = pagination?.page || 1;
  const totalPages = pagination?.totalPages || 1;
  const total = pagination?.total ?? data.length;

  return (
    <div className="bg-dark-surface border border-dark-border rounded-xl overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-dark-border bg-dark-surface-2/70">
              {columns.map((col, idx) => {
                const key = col.sortKey || col.key || idx;
                const isSorted = activeSortKey === key;
                return (
                  <th
                    key={col.key || idx}
                    onClick={() => handleSort(col)}
                    className={`px-4 py-3.5 text-xs font-semibold uppercase tracking-wider text-text-secondary whitespace-nowrap ${
                      col.sortable ? 'cursor-pointer select-none hover:text-text-primary' : ''
                    } ${col.align === 'right' ? 'text-right' : col.align === 'center' ? 'text-center' : ''}`}
                  >
                    <span className="inline-flex items-center gap-1.5">
                      {col.header || col.label}
                      {col.sortable && (
                        <span className="text-text-secondary/60">
                          {isSorted ? (
                            activeSortOrder === 'asc' ? (
                              <ArrowUp className="w-3.5 h-3.5 text-accent" />
                            ) : (
                              <ArrowDown className="w-3.5 h-3.5 text-accent" />
                            )
                          ) : (
                            <ArrowUpDown className="w-3.5 h-3.5" />
                          )}
                        </span>
                      )}
                    </span>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody className="divide-y divide-dark-border/60">
            {sortedData.map((row, rowIndex) => (
              <tr
                key={row?.[keyField] || row?._id || rowIndex}
                onClick={() => onRowClick?.(row)}
                className={`transition-colors ${
                  rowIndex % 2 === 1 ? 'bg-dark-bg/40' : 'bg-transparent'
                } hover:bg-dark-surface-2/70 ${onRowClick ? 'cursor-pointer' : ''}`}
              >
                {columns.map((col, colIdx) => (
                  <td
                    key={col.key || colIdx}
                    className={`px-4 py-3.5 text-sm text-text-primary whitespace-nowrap ${
                      col.align === 'right' ? 'text-right' : col.align === 'center' ? 'text-center' : ''
                    } ${col.className || ''}`}
                  >
                    {col.render ? col.render(row, rowIndex) : row?.[col.key] ?? '—'}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {pagination && totalPages > 1 && (
        <div className="px-4 py-3 border-t border-dark-border bg-dark-surface-2/30 flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs text-text-secondary">
            Page <span className="font-semibold text-text-primary">{page}</span> of{' '}
            <span className="font-semibold text-text-primary">{totalPages}</span>
            {total > 0 && (
              <>
                {' '}
                • <span className="font-semibold text-text-primary">{total}</span> total records
              </>
            )}
          </p>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              disabled={page <= 1}
              onClick={() => onPageChange?.(page - 1)}
              className="p-1.5 rounded-lg border border-dark-border bg-dark-bg text-text-secondary hover:text-text-primary hover:border-accent/50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              aria-label="Previous page"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              let pageNum = i + 1;
              if (totalPages > 5 && page > 3) {
                pageNum = Math.min(totalPages - 4 + i, Math.max(1, page - 2 + i));
              }
              return (
                <button
                  key={pageNum}
                  type="button"
                  onClick={() => onPageChange?.(pageNum)}
                  className={`min-w-[30px] h-[30px] px-2 rounded-lg text-xs font-medium transition-colors ${
                    pageNum === page
                      ? 'bg-accent text-dark-bg font-semibold'
                      : 'bg-dark-bg border border-dark-border text-text-secondary hover:text-text-primary'
                  }`}
                >
                  {pageNum}
                </button>
              );
            })}
            <button
              type="button"
              disabled={page >= totalPages}
              onClick={() => onPageChange?.(page + 1)}
              className="p-1.5 rounded-lg border border-dark-border bg-dark-bg text-text-secondary hover:text-text-primary hover:border-accent/50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              aria-label="Next page"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Table;

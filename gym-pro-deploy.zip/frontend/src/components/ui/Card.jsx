import React from 'react';

export const Card = ({
  title,
  subtitle,
  icon: Icon,
  actions,
  footer,
  noPadding = false,
  elevated = false,
  className = '',
  children,
}) => {
  return (
    <div
      className={`${
        elevated ? 'bg-dark-surface-2' : 'bg-dark-surface'
      } border border-dark-border rounded-xl overflow-hidden ${className}`}
    >
      {(title || actions) && (
        <div className="px-5 py-4 border-b border-dark-border flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            {Icon && (
              <div className="w-9 h-9 rounded-lg bg-accent-light text-accent flex items-center justify-center shrink-0">
                <Icon className="w-5 h-5" />
              </div>
            )}
            <div className="min-w-0">
              {title && (
                <h3 className="text-base font-semibold text-text-primary truncate">{title}</h3>
              )}
              {subtitle && (
                <p className="text-xs text-text-secondary mt-0.5 truncate">{subtitle}</p>
              )}
            </div>
          </div>
          {actions && <div className="flex items-center gap-2 flex-wrap">{actions}</div>}
        </div>
      )}
      <div className={noPadding ? '' : 'p-5'}>{children}</div>
      {footer && (
        <div className="px-5 py-3.5 bg-dark-surface-2/40 border-t border-dark-border">{footer}</div>
      )}
    </div>
  );
};

export default Card;

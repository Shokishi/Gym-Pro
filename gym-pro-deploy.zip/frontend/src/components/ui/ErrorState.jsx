import React from 'react';
import { AlertCircle, RefreshCw } from 'lucide-react';
import Button from './Button';

export const ErrorState = ({
  title = 'Failed to load data',
  message = 'Something went wrong while fetching records.',
  onRetry,
  className = '',
}) => {
  return (
    <div
      className={`bg-dark-surface border border-error/30 rounded-xl p-6 flex flex-col items-center text-center ${className}`}
    >
      <div className="w-12 h-12 rounded-full bg-error-light text-error flex items-center justify-center mb-3">
        <AlertCircle className="w-6 h-6" />
      </div>
      <h4 className="text-base font-semibold text-text-primary">{title}</h4>
      <p className="text-sm text-text-secondary mt-1 max-w-md">{message}</p>
      {onRetry && (
        <Button
          variant="secondary"
          size="sm"
          icon={RefreshCw}
          onClick={onRetry}
          className="mt-4"
        >
          Retry
        </Button>
      )}
    </div>
  );
};

export default ErrorState;

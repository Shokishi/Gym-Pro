import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Download } from 'lucide-react';
import Button from './Button';

export const QRCodeDisplay = ({
  value = '',
  size = 200,
  label,
  downloadName = 'gympro-qr.png',
  showDownload = false,
  className = '',
}) => {
  const [dataUrl, setDataUrl] = useState('');

  useEffect(() => {
    let active = true;
    if (!value) {
      setDataUrl('');
      return undefined;
    }

    QRCode.toDataURL(String(value), {
      width: size,
      margin: 2,
      color: {
        dark: '#101214',
        light: '#FFFFFF',
      },
    })
      .then((url) => {
        if (active) setDataUrl(url);
      })
      .catch(() => {
        if (active) setDataUrl('');
      });

    return () => {
      active = false;
    };
  }, [value, size]);

  const handleDownload = () => {
    if (!dataUrl) return;
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = downloadName;
    a.click();
  };

  if (!value) return null;

  return (
    <div className={`inline-flex flex-col items-center gap-3 ${className}`}>
      <div className="p-3 bg-white rounded-2xl shadow-lg inline-block">
        {dataUrl ? (
          <img src={dataUrl} alt={label || 'QR Code'} width={size} height={size} className="block" />
        ) : (
          <div style={{ width: size, height: size }} className="bg-gray-200 animate-pulse rounded-lg" />
        )}
      </div>
      {label && <p className="text-xs text-text-secondary text-center">{label}</p>}
      {showDownload && dataUrl && (
        <Button variant="secondary" size="sm" icon={Download} onClick={handleDownload}>
          Download QR
        </Button>
      )}
    </div>
  );
};

export default QRCodeDisplay;

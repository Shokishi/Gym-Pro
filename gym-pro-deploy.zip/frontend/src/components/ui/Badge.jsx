import React from 'react';

const STATUS_STYLES = {
  active: 'bg-success-light text-success border-success/30',
  paid: 'bg-success-light text-success border-success/30',
  verified: 'bg-success-light text-success border-success/30',
  approved: 'bg-success-light text-success border-success/30',
  completed: 'bg-success-light text-success border-success/30',
  present: 'bg-success-light text-success border-success/30',
  converted: 'bg-success-light text-success border-success/30',
  resolved: 'bg-success-light text-success border-success/30',
  available: 'bg-success-light text-success border-success/30',
  good: 'bg-success-light text-success border-success/30',

  pending: 'bg-warning-light text-warning border-warning/30',
  trial: 'bg-warning-light text-warning border-warning/30',
  expiring: 'bg-warning-light text-warning border-warning/30',
  frozen: 'bg-warning-light text-warning border-warning/30',
  partial: 'bg-warning-light text-warning border-warning/30',
  maintenance: 'bg-warning-light text-warning border-warning/30',
  scheduled: 'bg-warning-light text-warning border-warning/30',
  in_progress: 'bg-warning-light text-warning border-warning/30',
  follow_up: 'bg-warning-light text-warning border-warning/30',

  inactive: 'bg-dark-surface-2 text-text-secondary border-dark-border',
  draft: 'bg-dark-surface-2 text-text-secondary border-dark-border',
  neutral: 'bg-dark-surface-2 text-text-secondary border-dark-border',
  closed: 'bg-dark-surface-2 text-text-secondary border-dark-border',

  expired: 'bg-error-light text-error border-error/30',
  suspended: 'bg-error-light text-error border-error/30',
  rejected: 'bg-error-light text-error border-error/30',
  cancelled: 'bg-error-light text-error border-error/30',
  failed: 'bg-error-light text-error border-error/30',
  absent: 'bg-error-light text-error border-error/30',
  overdue: 'bg-error-light text-error border-error/30',
  out_of_order: 'bg-error-light text-error border-error/30',
  danger: 'bg-error-light text-error border-error/30',

  accent: 'bg-accent-light text-accent border-accent/30',
  owner: 'bg-accent-light text-accent border-accent/30',
  admin: 'bg-purple-500/15 text-purple-400 border-purple-500/30',
  trainer: 'bg-blue-500/15 text-blue-400 border-blue-500/30',
  customer: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
};

export const Badge = ({ children, variant, status, dot = false, className = '' }) => {
  const key = String(variant || status || 'neutral')
    .toLowerCase()
    .replace(/[\s-]+/g, '_');
  const style = STATUS_STYLES[key] || STATUS_STYLES.neutral;
  const label = children ?? String(status || variant || '—').replace(/_/g, ' ');

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border capitalize whitespace-nowrap ${style} ${className}`}
    >
      {dot && <span className="w-1.5 h-1.5 rounded-full bg-current" />}
      {label}
    </span>
  );
};

export default Badge;

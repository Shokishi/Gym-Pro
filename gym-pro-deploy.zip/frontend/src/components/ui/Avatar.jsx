import React, { useState } from 'react';
import { getInitials } from '../../utils/formatters';

const SIZES = {
  xs: 'w-7 h-7 text-[11px]',
  sm: 'w-8 h-8 text-xs',
  md: 'w-10 h-10 text-sm',
  lg: 'w-12 h-12 text-base',
  xl: 'w-16 h-16 text-xl',
};

export const Avatar = ({
  src,
  name = '',
  size = 'md',
  status,
  className = '',
}) => {
  const [imgError, setImgError] = useState(false);
  const initials = getInitials(name);
  const sizeClass = SIZES[size] || SIZES.md;

  return (
    <div className={`relative inline-flex shrink-0 ${className}`}>
      {src && !imgError ? (
        <img
          src={src}
          alt={name || 'Avatar'}
          onError={() => setImgError(true)}
          className={`${sizeClass} rounded-full object-cover border border-dark-border bg-dark-surface-2`}
        />
      ) : (
        <div
          className={`${sizeClass} rounded-full bg-accent-light border border-accent/30 text-accent font-semibold flex items-center justify-center select-none`}
        >
          {initials}
        </div>
      )}
      {status && (
        <span
          className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full ring-2 ring-dark-surface ${
            status === 'online' || status === 'active'
              ? 'bg-success'
              : status === 'busy'
              ? 'bg-warning'
              : 'bg-text-secondary'
          }`}
        />
      )}
    </div>
  );
};

export default Avatar;

import React from 'react';
import { Calendar } from 'lucide-react';
import { DATE_PRESETS } from '../../utils/constants';

export const DateRangeFilter = ({
  preset = '30d',
  onPresetChange,
  startDate = '',
  endDate = '',
  onCustomChange,
  className = '',
}) => {
  return (
    <div className={`flex flex-wrap items-center gap-2 ${className}`}>
      <div className="inline-flex flex-wrap items-center bg-dark-surface border border-dark-border rounded-lg p-1 gap-1">
        {DATE_PRESETS.map((item) => {
          const active = preset === item.key;
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => onPresetChange?.(item.key)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                active
                  ? 'bg-accent text-dark-bg font-semibold'
                  : 'text-text-secondary hover:text-text-primary hover:bg-dark-surface-2'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </div>

      {preset === 'custom' && (
        <div className="flex items-center gap-2">
          <div className="relative">
            <Calendar className="w-3.5 h-3.5 text-text-secondary absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="date"
              value={startDate}
              onChange={(e) => onCustomChange?.({ startDate: e.target.value, endDate })}
              className="bg-dark-surface border border-dark-border rounded-lg pl-8 pr-2.5 py-1.5 text-xs text-text-primary focus:outline-none focus:border-accent"
            />
          </div>
          <span className="text-xs text-text-secondary">to</span>
          <div className="relative">
            <Calendar className="w-3.5 h-3.5 text-text-secondary absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="date"
              value={endDate}
              onChange={(e) => onCustomChange?.({ startDate, endDate: e.target.value })}
              className="bg-dark-surface border border-dark-border rounded-lg pl-8 pr-2.5 py-1.5 text-xs text-text-primary focus:outline-none focus:border-accent"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default DateRangeFilter;

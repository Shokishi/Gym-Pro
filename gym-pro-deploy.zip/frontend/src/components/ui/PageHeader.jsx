import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export const PageHeader = ({
  title,
  subtitle,
  backTo,
  actions,
  badge,
  className = '',
}) => {
  const navigate = useNavigate();

  return (
    <div className={`flex flex-wrap items-center justify-between gap-4 mb-6 ${className}`}>
      <div className="flex items-start gap-3 min-w-0">
        {backTo && (
          <button
            type="button"
            onClick={() => (typeof backTo === 'string' ? navigate(backTo) : navigate(-1))}
            className="mt-0.5 p-2 rounded-lg bg-dark-surface border border-dark-border text-text-secondary hover:text-text-primary hover:border-accent/50 transition-colors shrink-0"
            aria-label="Go back"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
        )}
        <div className="min-w-0">
          <div className="flex items-center gap-2.5 flex-wrap">
            <h1 className="text-xl sm:text-2xl font-bold text-text-primary tracking-tight truncate">
              {title}
            </h1>
            {badge}
          </div>
          {subtitle && <p className="text-sm text-text-secondary mt-1">{subtitle}</p>}
        </div>
      </div>

      {actions && <div className="flex items-center gap-2.5 flex-wrap">{actions}</div>}
    </div>
  );
};

export default PageHeader;

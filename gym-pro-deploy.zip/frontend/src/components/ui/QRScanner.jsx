import React, { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { Camera, CameraOff, QrCode } from 'lucide-react';
import Button from './Button';
import Input from './Input';

export const QRScanner = ({ onScan, onError, className = '' }) => {
  const elementId = useRef(`qr-reader-${Math.random().toString(36).slice(2, 9)}`);
  const scannerRef = useRef(null);
  const [scanning, setScanning] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const [manualCode, setManualCode] = useState('');

  const stopScanner = async () => {
    if (scannerRef.current) {
      try {
        if (scannerRef.current.isScanning) {
          await scannerRef.current.stop();
        }
        await scannerRef.current.clear();
      } catch {
        // Ignore cleanup errors
      }
      scannerRef.current = null;
    }
    setScanning(false);
  };

  const startScanner = async () => {
    setCameraError('');
    try {
      const html5QrCode = new Html5Qrcode(elementId.current);
      scannerRef.current = html5QrCode;
      setScanning(true);

      await html5QrCode.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 220, height: 220 } },
        (decodedText) => {
          onScan?.(decodedText);
          stopScanner();
        },
        () => {}
      );
    } catch (err) {
      setScanning(false);
      const msg = err?.message || 'Camera access denied or unavailable on this device.';
      setCameraError(msg);
      onError?.(msg);
    }
  };

  useEffect(() => {
    return () => {
      stopScanner();
    };
  }, []);

  const handleManualSubmit = (e) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    onScan?.(manualCode.trim());
    setManualCode('');
  };

  return (
    <div className={`space-y-4 ${className}`}>
      <div className="bg-dark-bg border border-dark-border rounded-xl overflow-hidden p-4 flex flex-col items-center justify-center min-h-[240px]">
        <div id={elementId.current} className="w-full max-w-xs mx-auto" />

        {!scanning && (
          <div className="text-center space-y-3 py-4">
            <div className="w-12 h-12 rounded-2xl bg-accent-light text-accent flex items-center justify-center mx-auto">
              <QrCode className="w-6 h-6" />
            </div>
            <p className="text-sm text-text-secondary">
              Scan member QR pass using your camera or enter code manually below.
            </p>
            <Button icon={Camera} onClick={startScanner}>
              Start Camera Scanner
            </Button>
          </div>
        )}

        {scanning && (
          <Button
            variant="danger"
            size="sm"
            icon={CameraOff}
            onClick={stopScanner}
            className="mt-3"
          >
            Stop Camera
          </Button>
        )}

        {cameraError && (
          <p className="text-xs text-warning mt-3 text-center">{cameraError}</p>
        )}
      </div>

      <form onSubmit={handleManualSubmit} className="flex items-end gap-2">
        <Input
          label="Manual QR / Member Code"
          placeholder="Enter member QR token or ID..."
          value={manualCode}
          onChange={(e) => setManualCode(e.target.value)}
        />
        <Button type="submit" variant="secondary" disabled={!manualCode.trim()}>
          Verify
        </Button>
      </form>
    </div>
  );
};

export default QRScanner;

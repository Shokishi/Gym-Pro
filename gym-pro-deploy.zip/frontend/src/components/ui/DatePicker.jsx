import React, { forwardRef } from 'react';
import { Calendar } from 'lucide-react';

export const DatePicker = forwardRef(
  ({ label, error, hint, required = false, className = '', containerClassName = '', ...props }, ref) => {
    return (
      <div className={`w-full ${containerClassName}`}>
        {label && (
          <label className="block text-sm font-medium text-text-secondary mb-1.5">
            {label}
            {required && <span className="text-error ml-1">*</span>}
          </label>
        )}
        <div className="relative">
          <Calendar className="w-4 h-4 text-text-secondary absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            ref={ref}
            type="date"
            className={`w-full bg-dark-bg border rounded-lg pl-10 pr-3.5 py-2.5 text-sm text-text-primary transition-colors focus:outline-none focus:ring-1 ${
              error
                ? 'border-error focus:border-error focus:ring-error'
                : 'border-dark-border focus:border-accent focus:ring-accent'
            } ${className}`}
            {...props}
          />
        </div>
        {error ? (
          <p className="mt-1.5 text-xs text-error">{error}</p>
        ) : hint ? (
          <p className="mt-1.5 text-xs text-text-secondary">{hint}</p>
        ) : null}
      </div>
    );
  }
);

DatePicker.displayName = 'DatePicker';
export default DatePicker;

import React from 'react';
import { Loader2 } from 'lucide-react';

const VARIANTS = {
  primary: 'bg-accent hover:bg-accent-hover text-dark-bg font-semibold shadow-sm shadow-accent/20',
  secondary: 'bg-dark-surface-2 hover:bg-[#2C323A] text-text-primary border border-dark-border',
  danger: 'bg-error hover:bg-[#C94343] text-white font-semibold',
  success: 'bg-success hover:bg-[#219653] text-white font-semibold',
  ghost: 'bg-transparent hover:bg-dark-surface-2 text-text-secondary hover:text-text-primary',
  outline: 'bg-transparent border border-accent text-accent hover:bg-accent-light',
};

const SIZES = {
  xs: 'px-2.5 py-1.5 text-xs rounded-md',
  sm: 'px-3 py-1.5 text-xs rounded-lg',
  md: 'px-4 py-2.5 text-sm rounded-lg',
  lg: 'px-5 py-3 text-base rounded-xl',
};

export const Button = ({
  children,
  variant = 'primary',
  size = 'md',
  loading = false,
  disabled = false,
  icon: Icon,
  rightIcon: RightIcon,
  fullWidth = false,
  type = 'button',
  className = '',
  ...props
}) => {
  const isDisabled = disabled || loading;

  return (
    <button
      type={type}
      disabled={isDisabled}
      className={`inline-flex items-center justify-center gap-2 font-medium transition-all duration-150 focus:outline-none focus:ring-2 focus:ring-accent/50 disabled:opacity-50 disabled:cursor-not-allowed ${
        VARIANTS[variant] || VARIANTS.primary
      } ${SIZES[size] || SIZES.md} ${fullWidth ? 'w-full' : ''} ${className}`}
      {...props}
    >
      {loading ? (
        <Loader2 className="w-4 h-4 animate-spin shrink-0" />
      ) : Icon ? (
        <Icon className="w-4 h-4 shrink-0" />
      ) : null}
      {children}
      {!loading && RightIcon && <RightIcon className="w-4 h-4 shrink-0" />}
    </button>
  );
};

export default Button;

import React from 'react';

export const Tabs = ({ tabs = [], activeTab, onChange, className = '' }) => {
  return (
    <div className={`border-b border-dark-border overflow-x-auto gym-scrollbar-none ${className}`}>
      <div className="flex items-center gap-1 min-w-max">
        {tabs.map((tab) => {
          const key = tab.key || tab.id || tab.value;
          const isActive = activeTab === key;
          const Icon = tab.icon;

          return (
            <button
              key={key}
              type="button"
              onClick={() => onChange?.(key)}
              className={`inline-flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                isActive
                  ? 'border-accent text-accent'
                  : 'border-transparent text-text-secondary hover:text-text-primary hover:border-dark-border'
              }`}
            >
              {Icon && <Icon className="w-4 h-4" />}
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span
                  className={`px-1.5 py-0.5 text-[11px] rounded-full ${
                    isActive
                      ? 'bg-accent text-dark-bg font-semibold'
                      : 'bg-dark-surface-2 text-text-secondary'
                  }`}
                >
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default Tabs;

import React, { forwardRef } from 'react';

export const Textarea = forwardRef(
  (
    {
      label,
      error,
      hint,
      rows = 3,
      required = false,
      className = '',
      containerClassName = '',
      id,
      ...props
    },
    ref
  ) => {
    const textareaId = id || props.name;

    return (
      <div className={`w-full ${containerClassName}`}>
        {label && (
          <label
            htmlFor={textareaId}
            className="block text-sm font-medium text-text-secondary mb-1.5"
          >
            {label}
            {required && <span className="text-error ml-1">*</span>}
          </label>
        )}
        <textarea
          ref={ref}
          id={textareaId}
          rows={rows}
          className={`w-full bg-dark-bg border rounded-lg px-3.5 py-2.5 text-sm text-text-primary placeholder-text-secondary/50 transition-colors focus:outline-none focus:ring-1 ${
            error
              ? 'border-error focus:border-error focus:ring-error'
              : 'border-dark-border focus:border-accent focus:ring-accent'
          } disabled:opacity-60 disabled:cursor-not-allowed ${className}`}
          {...props}
        />
        {error ? (
          <p className="mt-1.5 text-xs text-error">{error}</p>
        ) : hint ? (
          <p className="mt-1.5 text-xs text-text-secondary">{hint}</p>
        ) : null}
      </div>
    );
  }
);

Textarea.displayName = 'Textarea';
export default Textarea;

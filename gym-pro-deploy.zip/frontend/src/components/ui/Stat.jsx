import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

const ICON_COLOR_MAP = {
  accent: 'bg-accent-light text-accent',
  success: 'bg-success-light text-success',
  warning: 'bg-warning-light text-warning',
  error: 'bg-error-light text-error',
  info: 'bg-blue-500/15 text-blue-400',
};

export const Stat = ({
  label,
  value,
  icon: Icon,
  trend,
  trendLabel,
  color = 'accent',
  subtitle,
  onClick,
  className = '',
}) => {
  const isPositive = typeof trend === 'number' ? trend >= 0 : String(trend || '').startsWith('+');
  const iconStyle = ICON_COLOR_MAP[color] || ICON_COLOR_MAP.accent;

  return (
    <div
      onClick={onClick}
      className={`bg-dark-surface border border-dark-border rounded-xl p-5 transition-colors ${
        onClick ? 'cursor-pointer hover:border-accent/50' : ''
      } ${className}`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-medium uppercase tracking-wider text-text-secondary truncate">
            {label}
          </p>
          <p className="text-2xl font-bold text-text-primary mt-2 tracking-tight truncate">
            {value}
          </p>
        </div>
        {Icon && (
          <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${iconStyle}`}>
            <Icon className="w-5 h-5" />
          </div>
        )}
      </div>

      {(trend !== undefined || subtitle) && (
        <div className="mt-3 pt-3 border-t border-dark-border/60 flex items-center justify-between gap-2 text-xs">
          {trend !== undefined ? (
            <span
              className={`inline-flex items-center gap-1 font-semibold ${
                isPositive ? 'text-success' : 'text-error'
              }`}
            >
              {isPositive ? (
                <TrendingUp className="w-3.5 h-3.5" />
              ) : (
                <TrendingDown className="w-3.5 h-3.5" />
              )}
              {typeof trend === 'number' ? `${trend > 0 ? '+' : ''}${trend}%` : trend}
            </span>
          ) : (
            <span />
          )}
          {(trendLabel || subtitle) && (
            <span className="text-text-secondary truncate">{trendLabel || subtitle}</span>
          )}
        </div>
      )}
    </div>
  );
};

export default Stat;

import React, { forwardRef } from 'react';

export const Select = forwardRef(
  (
    {
      label,
      error,
      hint,
      options = [],
      placeholder = 'Select an option',
      required = false,
      className = '',
      containerClassName = '',
      children,
      id,
      ...props
    },
    ref
  ) => {
    const selectId = id || props.name;

    return (
      <div className={`w-full ${containerClassName}`}>
        {label && (
          <label
            htmlFor={selectId}
            className="block text-sm font-medium text-text-secondary mb-1.5"
          >
            {label}
            {required && <span className="text-error ml-1">*</span>}
          </label>
        )}
        <select
          ref={ref}
          id={selectId}
          className={`w-full bg-dark-bg border rounded-lg px-3.5 py-2.5 text-sm text-text-primary transition-colors focus:outline-none focus:ring-1 ${
            error
              ? 'border-error focus:border-error focus:ring-error'
              : 'border-dark-border focus:border-accent focus:ring-accent'
          } disabled:opacity-60 disabled:cursor-not-allowed ${className}`}
          {...props}
        >
          {placeholder && <option value="">{placeholder}</option>}
          {options.map((opt) => {
            const val = typeof opt === 'object' ? opt.value : opt;
            const lbl = typeof opt === 'object' ? opt.label : opt;
            return (
              <option key={val} value={val} className="bg-dark-surface text-text-primary">
                {lbl}
              </option>
            );
          })}
          {children}
        </select>
        {error ? (
          <p className="mt-1.5 text-xs text-error">{error}</p>
        ) : hint ? (
          <p className="mt-1.5 text-xs text-text-secondary">{hint}</p>
        ) : null}
      </div>
    );
  }
);

Select.displayName = 'Select';
export default Select;

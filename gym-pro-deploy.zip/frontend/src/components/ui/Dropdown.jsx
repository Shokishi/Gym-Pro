import React, { useState, useRef, useEffect } from 'react';
import { MoreVertical } from 'lucide-react';

export const Dropdown = ({
  trigger,
  items = [],
  align = 'right',
  className = '',
}) => {
  const [open, setOpen] = useState(false);
  const containerRef = useRef(null);

  useEffect(() => {
    const handleOutsideClick = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  return (
    <div ref={containerRef} className={`relative inline-block text-left ${className}`}>
      <div
        onClick={(e) => {
          e.stopPropagation();
          setOpen((prev) => !prev);
        }}
        className="cursor-pointer"
      >
        {trigger || (
          <button
            type="button"
            className="p-2 rounded-lg text-text-secondary hover:text-text-primary hover:bg-dark-surface-2 transition-colors"
            aria-label="Open menu"
          >
            <MoreVertical className="w-4 h-4" />
          </button>
        )}
      </div>

      {open && (
        <div
          className={`absolute z-40 mt-2 w-52 rounded-xl bg-dark-surface-2 border border-dark-border shadow-2xl py-1.5 ${
            align === 'right' ? 'right-0' : 'left-0'
          }`}
        >
          {items.map((item, idx) => {
            if (item.divider) {
              return <div key={idx} className="my-1 border-t border-dark-border" />;
            }
            const Icon = item.icon;
            return (
              <button
                key={item.label || idx}
                type="button"
                disabled={item.disabled}
                onClick={(e) => {
                  e.stopPropagation();
                  setOpen(false);
                  item.onClick?.();
                }}
                className={`w-full px-4 py-2 text-left text-sm flex items-center gap-2.5 transition-colors disabled:opacity-40 ${
                  item.danger
                    ? 'text-error hover:bg-error-light'
                    : 'text-text-primary hover:bg-dark-surface hover:text-accent'
                }`}
              >
                {Icon && <Icon className="w-4 h-4 shrink-0" />}
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default Dropdown;

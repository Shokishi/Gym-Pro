import React from 'react';

const BAR_COLORS = {
  accent: 'bg-accent',
  success: 'bg-success',
  warning: 'bg-warning',
  error: 'bg-error',
};

export const ProgressBar = ({
  value = 0,
  max = 100,
  label,
  showPercentage = true,
  color = 'accent',
  size = 'md',
  className = '',
}) => {
  const pct = max > 0 ? Math.min(100, Math.max(0, Math.round((value / max) * 100))) : 0;
  const heightClass = size === 'sm' ? 'h-1.5' : size === 'lg' ? 'h-3' : 'h-2';

  return (
    <div className={`w-full ${className}`}>
      {(label || showPercentage) && (
        <div className="flex items-center justify-between text-xs mb-1.5">
          <span className="text-text-secondary font-medium">{label}</span>
          {showPercentage && <span className="text-text-primary font-semibold">{pct}%</span>}
        </div>
      )}
      <div className={`w-full bg-dark-bg border border-dark-border/60 rounded-full overflow-hidden ${heightClass}`}>
        <div
          className={`${BAR_COLORS[color] || BAR_COLORS.accent} ${heightClass} rounded-full transition-all duration-300`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
};

export default ProgressBar;

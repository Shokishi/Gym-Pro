import React from 'react';

const PulseBar = ({ className = '' }) => (
  <div className={`animate-pulse bg-dark-surface-2 rounded-lg ${className}`} />
);

export const Skeleton = ({
  variant = 'card',
  rows = 5,
  columns = 5,
  count = 4,
  className = '',
}) => {
  if (variant === 'stats') {
    return (
      <div className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 ${className}`}>
        {Array.from({ length: count }).map((_, i) => (
          <div key={i} className="bg-dark-surface border border-dark-border rounded-xl p-5 space-y-3">
            <div className="flex justify-between items-start">
              <div className="space-y-2 flex-1">
                <PulseBar className="h-3 w-24" />
                <PulseBar className="h-7 w-32" />
              </div>
              <PulseBar className="h-11 w-11 rounded-xl shrink-0" />
            </div>
            <PulseBar className="h-3 w-28" />
          </div>
        ))}
      </div>
    );
  }

  if (variant === 'table') {
    return (
      <div className={`bg-dark-surface border border-dark-border rounded-xl overflow-hidden ${className}`}>
        <div className="p-4 border-b border-dark-border bg-dark-surface-2/40 flex gap-4">
          {Array.from({ length: columns }).map((_, c) => (
            <PulseBar key={c} className="h-4 flex-1" />
          ))}
        </div>
        <div className="divide-y divide-dark-border/60">
          {Array.from({ length: rows }).map((_, r) => (
            <div key={r} className="p-4 flex gap-4 items-center">
              {Array.from({ length: columns }).map((__, c) => (
                <PulseBar key={c} className="h-4 flex-1" />
              ))}
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (variant === 'list') {
    return (
      <div className={`space-y-3 ${className}`}>
        {Array.from({ length: rows }).map((_, i) => (
          <div key={i} className="bg-dark-surface border border-dark-border rounded-xl p-4 flex items-center gap-4">
            <PulseBar className="w-10 h-10 rounded-full shrink-0" />
            <div className="flex-1 space-y-2">
              <PulseBar className="h-4 w-48" />
              <PulseBar className="h-3 w-72 max-w-full" />
            </div>
            <PulseBar className="h-7 w-20 rounded-full shrink-0" />
          </div>
        ))}
      </div>
    );
  }

  if (variant === 'text') {
    return (
      <div className={`space-y-2 ${className}`}>
        {Array.from({ length: rows }).map((_, i) => (
          <PulseBar key={i} className={`h-4 ${i === rows - 1 ? 'w-2/3' : 'w-full'}`} />
        ))}
      </div>
    );
  }

  return (
    <div className={`bg-dark-surface border border-dark-border rounded-xl p-5 space-y-4 ${className}`}>
      <PulseBar className="h-5 w-40" />
      <PulseBar className="h-32 w-full" />
    </div>
  );
};

export default Skeleton;

import React from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import { formatCurrency } from '../../utils/formatters';
import EmptyState from '../ui/EmptyState';
import { BarChart3 } from 'lucide-react';

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-dark-surface-2 border border-dark-border rounded-xl px-3.5 py-2.5 shadow-xl text-xs">
      <p className="font-semibold text-text-primary mb-1">{label}</p>
      {payload.map((entry, idx) => (
        <p key={idx} className="flex items-center gap-2 text-text-secondary">
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
          <span>{entry.name}:</span>
          <span className="font-semibold text-text-primary">{formatCurrency(entry.value)}</span>
        </p>
      ))}
    </div>
  );
};

export const RevenueChart = ({
  data = [],
  type = 'area',
  dataKey = 'revenue',
  secondaryKey,
  xKey = 'label',
  height = 280,
}) => {
  if (!data || data.length === 0) {
    return (
      <EmptyState
        icon={BarChart3}
        title="No revenue data"
        message="Revenue trends will appear here once transactions are recorded."
        className="py-8"
      />
    );
  }

  return (
    <div style={{ width: '100%', height }}>
      <ResponsiveContainer width="100%" height="100%">
        {type === 'bar' ? (
          <BarChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#2A2F36" vertical={false} />
            <XAxis dataKey={xKey} stroke="#A6ADB5" fontSize={12} tickLine={false} axisLine={false} />
            <YAxis
              stroke="#A6ADB5"
              fontSize={12}
              tickLine={false}
              axisLine={false}
              tickFormatter={(v) => (v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v)}
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey={dataKey} name="Revenue" fill="#F28C28" radius={[6, 6, 0, 0]} />
            {secondaryKey && (
              <Bar dataKey={secondaryKey} name="Expenses" fill="#E05252" radius={[6, 6, 0, 0]} />
            )}
          </BarChart>
        ) : (
          <AreaChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
            <defs>
              <linearGradient id="revAccentGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#F28C28" stopOpacity={0.35} />
                <stop offset="95%" stopColor="#F28C28" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="revSuccessGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#27AE60" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#27AE60" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#2A2F36" vertical={false} />
            <XAxis dataKey={xKey} stroke="#A6ADB5" fontSize={12} tickLine={false} axisLine={false} />
            <YAxis
              stroke="#A6ADB5"
              fontSize={12}
              tickLine={false}
              axisLine={false}
              tickFormatter={(v) => (v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v)}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              type="monotone"
              dataKey={dataKey}
              name="Revenue"
              stroke="#F28C28"
              strokeWidth={2.5}
              fillOpacity={1}
              fill="url(#revAccentGradient)"
            />
            {secondaryKey && (
              <Area
                type="monotone"
                dataKey={secondaryKey}
                name="Profit"
                stroke="#27AE60"
                strokeWidth={2}
                fillOpacity={1}
                fill="url(#revSuccessGradient)"
              />
            )}
          </AreaChart>
        )}
      </ResponsiveContainer>
    </div>
  );
};

export default RevenueChart;

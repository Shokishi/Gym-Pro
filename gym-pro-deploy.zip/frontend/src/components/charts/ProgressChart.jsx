import React from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { Activity } from 'lucide-react';
import EmptyState from '../ui/EmptyState';

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-dark-surface-2 border border-dark-border rounded-xl px-3.5 py-2.5 shadow-xl text-xs">
      <p className="font-semibold text-text-primary mb-1">{label}</p>
      {payload.map((entry, idx) => (
        <p key={idx} className="flex items-center gap-2 text-text-secondary">
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
          <span>{entry.name}:</span>
          <span className="font-semibold text-text-primary">{entry.value}</span>
        </p>
      ))}
    </div>
  );
};

export const ProgressChart = ({
  data = [],
  xKey = 'date',
  metrics = [
    { key: 'weight', name: 'Weight (kg)', color: '#F28C28' },
    { key: 'bodyFat', name: 'Body Fat (%)', color: '#F2B544' },
    { key: 'muscleMass', name: 'Muscle Mass (kg)', color: '#27AE60' },
  ],
  height = 280,
}) => {
  if (!data || data.length === 0) {
    return (
      <EmptyState
        icon={Activity}
        title="No progress logs yet"
        message="Log body measurements over time to visualize fitness progress."
        className="py-8"
      />
    );
  }

  return (
    <div style={{ width: '100%', height }}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 10, right: 12, left: -15, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#2A2F36" vertical={false} />
          <XAxis dataKey={xKey} stroke="#A6ADB5" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis stroke="#A6ADB5" fontSize={12} tickLine={false} axisLine={false} />
          <Tooltip content={<CustomTooltip />} />
          <Legend wrapperStyle={{ fontSize: '12px', color: '#A6ADB5' }} />
          {metrics.map((m) => (
            <Line
              key={m.key}
              type="monotone"
              dataKey={m.key}
              name={m.name}
              stroke={m.color}
              strokeWidth={2.5}
              dot={{ r: 3.5, fill: m.color }}
              connectNulls
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ProgressChart;

import React from 'react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';
import { Wallet } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';
import EmptyState from '../ui/EmptyState';

const COLORS = ['#E05252', '#F28C28', '#F2B544', '#27AE60', '#3B82F6', '#94A3B8'];

const CustomTooltip = ({ active, payload }) => {
  if (!active || !payload?.length) return null;
  const item = payload[0];
  return (
    <div className="bg-dark-surface-2 border border-dark-border rounded-xl px-3.5 py-2 shadow-xl text-xs">
      <p className="font-semibold text-text-primary">{item.name}</p>
      <p className="text-text-secondary mt-0.5">
        Amount: <span className="font-semibold text-error">{formatCurrency(item.value)}</span>
      </p>
    </div>
  );
};

export const ExpenseChart = ({
  data = [],
  nameKey = 'category',
  valueKey = 'amount',
  height = 280,
}) => {
  if (!data || data.length === 0) {
    return (
      <EmptyState
        icon={Wallet}
        title="No expense breakdown"
        message="Expense distribution across categories will appear here."
        className="py-8"
      />
    );
  }

  return (
    <div style={{ width: '100%', height }}>
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            dataKey={valueKey}
            nameKey={nameKey}
            cx="50%"
            cy="46%"
            innerRadius={56}
            outerRadius={88}
            paddingAngle={3}
            stroke="#191D21"
            strokeWidth={2}
          >
            {data.map((entry, idx) => (
              <Cell key={entry[nameKey] || idx} fill={COLORS[idx % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip />} />
          <Legend wrapperStyle={{ fontSize: '12px', color: '#A6ADB5' }} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ExpenseChart;

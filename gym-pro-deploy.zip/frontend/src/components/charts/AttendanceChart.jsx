import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { CalendarCheck } from 'lucide-react';
import EmptyState from '../ui/EmptyState';

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-dark-surface-2 border border-dark-border rounded-xl px-3.5 py-2.5 shadow-xl text-xs">
      <p className="font-semibold text-text-primary mb-1">{label}</p>
      {payload.map((entry, idx) => (
        <p key={idx} className="flex items-center gap-2 text-text-secondary">
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
          <span>{entry.name}:</span>
          <span className="font-semibold text-text-primary">{entry.value}</span>
        </p>
      ))}
    </div>
  );
};

export const AttendanceChart = ({
  data = [],
  xKey = 'label',
  presentKey = 'present',
  absentKey = 'absent',
  height = 280,
}) => {
  if (!data || data.length === 0) {
    return (
      <EmptyState
        icon={CalendarCheck}
        title="No attendance records"
        message="Attendance check-in trends will appear once members check in."
        className="py-8"
      />
    );
  }

  const hasAbsent = data.some((d) => d[absentKey] !== undefined);

  return (
    <div style={{ width: '100%', height }}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#2A2F36" vertical={false} />
          <XAxis dataKey={xKey} stroke="#A6ADB5" fontSize={12} tickLine={false} axisLine={false} />
          <YAxis stroke="#A6ADB5" fontSize={12} tickLine={false} axisLine={false} allowDecimals={false} />
          <Tooltip content={<CustomTooltip />} />
          {hasAbsent && <Legend wrapperStyle={{ fontSize: '12px', color: '#A6ADB5' }} />}
          <Bar dataKey={presentKey} name="Check-ins" fill="#27AE60" radius={[6, 6, 0, 0]} />
          {hasAbsent && (
            <Bar dataKey={absentKey} name="Absent" fill="#E05252" radius={[6, 6, 0, 0]} />
          )}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default AttendanceChart;

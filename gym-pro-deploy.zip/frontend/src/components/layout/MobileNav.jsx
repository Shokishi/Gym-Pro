import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { MoreHorizontal, X, LogOut } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

export const MobileNav = ({ primaryItems = [], moreItems = [] }) => {
  const [moreOpen, setMoreOpen] = useState(false);
  const { logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    setMoreOpen(false);
    await logout();
    navigate('/login');
  };

  return (
    <>
      <nav className="fixed bottom-0 inset-x-0 z-40 bg-dark-surface/95 backdrop-blur border-t border-dark-border lg:hidden">
        <div className="grid grid-cols-5 h-16 max-w-lg mx-auto">
          {primaryItems.slice(0, 4).map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                onClick={() => setMoreOpen(false)}
                className={({ isActive }) =>
                  `flex flex-col items-center justify-center gap-1 text-[11px] font-medium transition-colors ${
                    isActive ? 'text-accent' : 'text-text-secondary hover:text-text-primary'
                  }`
                }
              >
                {Icon && <Icon className="w-5 h-5" />}
                <span className="truncate max-w-full px-1">{item.label}</span>
              </NavLink>
            );
          })}

          {moreItems.length > 0 && (
            <button
              type="button"
              onClick={() => setMoreOpen((prev) => !prev)}
              className={`flex flex-col items-center justify-center gap-1 text-[11px] font-medium transition-colors ${
                moreOpen ? 'text-accent' : 'text-text-secondary hover:text-text-primary'
              }`}
            >
              <MoreHorizontal className="w-5 h-5" />
              <span>More</span>
            </button>
          )}
        </div>
      </nav>

      {/* More Bottom Sheet */}
      {moreOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex flex-col justify-end">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setMoreOpen(false)}
          />
          <div className="relative bg-dark-surface border-t border-dark-border rounded-t-2xl p-5 pb-8 z-10 max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold text-text-primary">More Options</h3>
              <button
                type="button"
                onClick={() => setMoreOpen(false)}
                className="p-1.5 rounded-lg text-text-secondary hover:text-text-primary hover:bg-dark-surface-2"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {moreItems.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    onClick={() => setMoreOpen(false)}
                    className={({ isActive }) =>
                      `flex flex-col items-center justify-center gap-2 p-3 rounded-xl border text-center transition-colors ${
                        isActive
                          ? 'bg-accent-light border-accent text-accent'
                          : 'bg-dark-bg border-dark-border text-text-secondary hover:text-text-primary'
                      }`
                    }
                  >
                    {Icon && <Icon className="w-5 h-5" />}
                    <span className="text-xs font-medium">{item.label}</span>
                  </NavLink>
                );
              })}
            </div>
            <button
              type="button"
              onClick={handleLogout}
              className="mt-4 w-full py-2.5 rounded-xl bg-error-light border border-error/30 text-error text-sm font-semibold flex items-center justify-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default MobileNav;

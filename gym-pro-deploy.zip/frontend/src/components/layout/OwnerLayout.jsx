import React, { useState } from 'react';
import { Outlet, Link } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  Dumbbell,
  CalendarCheck,
  IdCard,
  CreditCard,
  QrCode,
  FileSpreadsheet,
  FileText,
  Flame,
  Utensils,
  CalendarClock,
  Wallet,
  Receipt,
  UserPlus,
  Share2,
  Wrench,
  Bell,
  BarChart3,
  Building2,
  ShieldCheck,
  History,
  User,
  Settings,
  Crown,
  AlertTriangle,
} from 'lucide-react';
import Sidebar from './Sidebar';
import Header from './Header';
import { useAuth } from '../../contexts/AuthContext';

const OWNER_NAV_ITEMS = [
  { label: 'Dashboard', to: '/owner/dashboard', icon: LayoutDashboard },
  { label: 'Customers', to: '/owner/customers', icon: Users },
  { label: 'Trainers', to: '/owner/trainers', icon: Dumbbell },
  { label: 'Attendance', to: '/owner/attendance', icon: CalendarCheck },
  { label: 'Memberships', to: '/owner/memberships', icon: IdCard },
  { label: 'Payments', to: '/owner/payments', icon: CreditCard },
  { label: 'QR Settings', to: '/owner/qr-settings', icon: QrCode },
  { label: 'Quotations', to: '/owner/quotations', icon: FileSpreadsheet },
  { label: 'Invoices', to: '/owner/invoices', icon: FileText },
  { label: 'Workouts', to: '/owner/workouts', icon: Flame },
  { label: 'Diet Plans', to: '/owner/diets', icon: Utensils },
  { label: 'Appointments', to: '/owner/appointments', icon: CalendarClock },
  { label: 'Salaries', to: '/owner/salaries', icon: Wallet },
  { label: 'Expenses', to: '/owner/expenses', icon: Receipt },
  { label: 'Enquiries', to: '/owner/enquiries', icon: UserPlus },
  { label: 'Referrals', to: '/owner/referrals', icon: Share2 },
  { label: 'Equipment', to: '/owner/equipment', icon: Wrench },
  { label: 'Notifications', to: '/owner/notifications', icon: Bell },
  { label: 'Reports', to: '/owner/reports', icon: BarChart3 },
  { label: 'Branches', to: '/owner/branches', icon: Building2 },
  { label: 'Permissions', to: '/owner/permissions', icon: ShieldCheck },
  { label: 'Audit Logs', to: '/owner/audit-logs', icon: History },
  { label: 'Subscription', to: '/owner/subscription', icon: Crown },
  { label: 'Profile', to: '/owner/profile', icon: User },
  { label: 'Settings', to: '/owner/settings', icon: Settings },
];

export const OwnerLayout = ({ children }) => {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { gym } = useAuth();

  const isExpired = gym?.subscriptionStatus === 'EXPIRED';
  const isGracePeriod = gym?.subscriptionStatus === 'GRACE_PERIOD';

  return (
    <div className="min-h-screen bg-dark-bg text-text-primary flex">
      <Sidebar
        items={OWNER_NAV_ITEMS}
        collapsed={collapsed}
        onToggleCollapse={() => setCollapsed((p) => !p)}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
        portalLabel="Gym Owner"
        brandName={gym?.name || 'GYM PRO'}
      />
      <div className="flex-1 flex flex-col min-w-0">
        <Header
          onOpenMobileMenu={() => setMobileOpen(true)}
          title={gym?.name || 'Owner Portal'}
          profilePath="/owner/profile"
          settingsPath="/owner/settings"
          notificationsPath="/owner/notifications"
        />

        {isExpired && (
          <div className="bg-danger/15 border-b border-danger/30 px-4 py-2.5 flex items-center justify-between text-xs text-danger">
            <div className="flex items-center gap-2 font-medium">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>
                Your GYM PRO subscription has expired. Operational features are temporarily locked. Your data remains fully safe.
              </span>
            </div>
            <Link
              to="/owner/subscription"
              className="px-3 py-1 rounded bg-danger text-white font-semibold hover:bg-danger/90 shrink-0"
            >
              Renew Subscription
            </Link>
          </div>
        )}

        {isGracePeriod && (
          <div className="bg-warning/15 border-b border-warning/30 px-4 py-2.5 flex items-center justify-between text-xs text-warning">
            <div className="flex items-center gap-2 font-medium">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>
                Your subscription renewal is in grace period. Please renew to avoid service interruption.
              </span>
            </div>
            <Link
              to="/owner/subscription"
              className="px-3 py-1 rounded bg-warning text-dark-bg font-semibold hover:bg-warning/90 shrink-0"
            >
              Renew Now
            </Link>
          </div>
        )}

        <main className="flex-1 p-4 sm:p-6 max-w-[1600px] w-full mx-auto">
          {children || <Outlet />}
        </main>
      </div>
    </div>
  );
};

export default OwnerLayout;

import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import {
  LayoutDashboard,
  Building2,
  Users,
  Layers,
  BadgeDollarSign,
  Clock,
  CreditCard,
  Receipt,
  Tag,
  Globe,
  Bell,
  LifeBuoy,
  BarChart3,
  FileBarChart,
  ShieldAlert,
  Settings,
  UserCog,
} from 'lucide-react';
import Sidebar from './Sidebar';
import Header from './Header';

const ADMIN_NAV_ITEMS = [
  { label: 'Dashboard', to: '/admin/dashboard', icon: LayoutDashboard },
  { label: 'Gym Management', to: '/admin/gyms', icon: Building2 },
  { label: 'All Users', to: '/admin/users', icon: Users },
  { label: 'Subscription Plans', to: '/admin/plans', icon: Layers },
  { label: 'Pricing', to: '/admin/pricing', icon: BadgeDollarSign },
  { label: 'Free Trial Settings', to: '/admin/trial-settings', icon: Clock },
  { label: 'Subscriptions', to: '/admin/subscriptions', icon: CreditCard },
  { label: 'Subscription Payments', to: '/admin/subscription-payments', icon: Receipt },
  { label: 'Coupons & Offers', to: '/admin/coupons', icon: Tag },
  { label: 'Domain Management', to: '/admin/domains', icon: Globe },
  { label: 'Notifications', to: '/admin/notifications', icon: Bell },
  { label: 'Customer Support', to: '/admin/support', icon: LifeBuoy },
  { label: 'Analytics', to: '/admin/analytics', icon: BarChart3 },
  { label: 'Reports', to: '/admin/reports', icon: FileBarChart },
  { label: 'Audit Logs', to: '/admin/audit-logs', icon: ShieldAlert },
  { label: 'Platform Settings', to: '/admin/settings', icon: Settings },
  { label: 'Admin Profile', to: '/admin/profile', icon: UserCog },
];

export const AdminLayout = ({ children }) => {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-dark-bg text-text-primary flex">
      <Sidebar
        items={ADMIN_NAV_ITEMS}
        collapsed={collapsed}
        onToggleCollapse={() => setCollapsed((p) => !p)}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
        portalLabel="Super Admin"
      />
      <div className="flex-1 flex flex-col min-w-0">
        <Header
          onOpenMobileMenu={() => setMobileOpen(true)}
          title="Super Admin Console"
          profilePath="/admin/profile"
          settingsPath="/admin/settings"
          notificationsPath="/admin/notifications"
        />
        <main className="flex-1 p-4 sm:p-6 max-w-[1600px] w-full mx-auto">
          {children || <Outlet />}
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;

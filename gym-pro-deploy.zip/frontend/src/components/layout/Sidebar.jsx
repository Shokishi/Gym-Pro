import React from 'react';
import { NavLink } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Dumbbell, X } from 'lucide-react';

export const Sidebar = ({
  items = [],
  collapsed = false,
  onToggleCollapse,
  mobileOpen = false,
  onCloseMobile,
  portalLabel = 'Portal',
  brandName = 'GYM PRO',
}) => {
  const renderNavItems = (isMobile = false) => (
    <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
      {items.map((item) => {
        if (item.divider) {
          return (
            <div key={item.key || Math.random()} className="my-2 border-t border-dark-border/80" />
          );
        }
        const Icon = item.icon;
        return (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            onClick={() => isMobile && onCloseMobile?.()}
            title={collapsed && !isMobile ? item.label : undefined}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                isActive
                  ? 'bg-accent text-dark-bg font-semibold shadow-sm shadow-accent/25'
                  : 'text-text-secondary hover:text-text-primary hover:bg-dark-surface-2'
              } ${collapsed && !isMobile ? 'justify-center px-2' : ''}`
            }
          >
            {Icon && <Icon className="w-4 h-4 shrink-0" />}
            {(!collapsed || isMobile) && <span className="truncate">{item.label}</span>}
          </NavLink>
        );
      })}
    </nav>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside
        className={`hidden lg:flex flex-col bg-dark-surface border-r border-dark-border shrink-0 transition-all duration-200 h-screen sticky top-0 ${
          collapsed ? 'w-[74px]' : 'w-64'
        }`}
      >
        <div className="h-16 px-4 border-b border-dark-border flex items-center justify-between gap-2 shrink-0">
          <div className={`flex items-center gap-2.5 min-w-0 ${collapsed ? 'justify-center w-full' : ''}`}>
            <div className="w-9 h-9 rounded-xl bg-accent flex items-center justify-center text-dark-bg shrink-0 shadow-md shadow-accent/20">
              <Dumbbell className="w-5 h-5" />
            </div>
            {!collapsed && (
              <div className="min-w-0">
                <span className="text-base font-extrabold tracking-tight text-text-primary block truncate">
                  {brandName}
                </span>
                <span className="text-[10px] font-semibold uppercase tracking-widest text-accent block">
                  {portalLabel}
                </span>
              </div>
            )}
          </div>
          {!collapsed && onToggleCollapse && (
            <button
              type="button"
              onClick={onToggleCollapse}
              className="p-1.5 rounded-lg text-text-secondary hover:text-text-primary hover:bg-dark-surface-2 transition-colors"
              aria-label="Collapse sidebar"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          )}
        </div>

        {collapsed && onToggleCollapse && (
          <button
            type="button"
            onClick={onToggleCollapse}
            className="mx-auto mt-3 p-1.5 rounded-lg bg-dark-surface-2 text-text-secondary hover:text-text-primary transition-colors"
            aria-label="Expand sidebar"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        )}

        {renderNavItems(false)}
      </aside>

      {/* Mobile Slide-over Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <aside className="relative w-72 max-w-[85vw] bg-dark-surface border-r border-dark-border h-full flex flex-col z-10">
            <div className="h-16 px-4 border-b border-dark-border flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-accent flex items-center justify-center text-dark-bg">
                  <Dumbbell className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-base font-extrabold text-text-primary block">{brandName}</span>
                  <span className="text-[10px] font-semibold uppercase tracking-widest text-accent block">
                    {portalLabel}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={onCloseMobile}
                className="p-1.5 rounded-lg text-text-secondary hover:text-text-primary hover:bg-dark-surface-2"
                aria-label="Close navigation"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            {renderNavItems(true)}
          </aside>
        </div>
      )}
    </>
  );
};

export default Sidebar;

import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Menu,
  Bell,
  LogOut,
  User,
  Settings,
  Building2,
  CheckCheck,
  Wifi,
  WifiOff,
  ChevronDown,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useGym } from '../../contexts/GymContext';
import { useSocket } from '../../contexts/SocketContext';
import Avatar from '../ui/Avatar';
import { ROLES } from '../../utils/constants';
import { formatRelativeTime } from '../../utils/formatters';

export const Header = ({
  onOpenMobileMenu,
  profilePath = '/owner/profile',
  settingsPath,
  notificationsPath = '/owner/notifications',
  title,
}) => {
  const { user, role, gym, logout } = useAuth();
  const { branches, activeBranchId, switchBranch } = useGym();
  const { connected, unreadCount, recentNotifications, markAllRead } = useSocket();
  const navigate = useNavigate();

  const [notifOpen, setNotifOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const notifRef = useRef(null);
  const profileRef = useRef(null);

  useEffect(() => {
    const handleOutside = (e) => {
      if (notifRef.current && !notifRef.current.contains(e.target)) setNotifOpen(false);
      if (profileRef.current && !profileRef.current.contains(e.target)) setProfileOpen(false);
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const handleLogout = async () => {
    setProfileOpen(false);
    await logout();
    navigate('/login');
  };

  return (
    <header className="h-16 bg-dark-surface/95 backdrop-blur border-b border-dark-border px-4 sm:px-6 flex items-center justify-between gap-3 sticky top-0 z-30 shrink-0">
      <div className="flex items-center gap-3 min-w-0">
        {onOpenMobileMenu && (
          <button
            type="button"
            onClick={onOpenMobileMenu}
            className="lg:hidden p-2 rounded-lg text-text-secondary hover:text-text-primary hover:bg-dark-surface-2 transition-colors"
            aria-label="Open menu"
          >
            <Menu className="w-5 h-5" />
          </button>
        )}

        <div className="min-w-0">
          <h2 className="text-sm sm:text-base font-semibold text-text-primary truncate">
            {title || gym?.name || 'GYM PRO'}
          </h2>
          <div className="hidden sm:flex items-center gap-2 text-[11px] text-text-secondary">
            <span className="inline-flex items-center gap-1">
              {connected ? (
                <Wifi className="w-3 h-3 text-success" />
              ) : (
                <WifiOff className="w-3 h-3 text-text-secondary" />
              )}
              {connected ? 'Live Sync' : 'Offline Sync'}
            </span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-3">
        {/* Branch Switcher for Gym Owner */}
        {role === ROLES.OWNER && branches.length > 0 && (
          <div className="hidden md:flex items-center gap-1.5 bg-dark-bg border border-dark-border rounded-lg px-2.5 py-1.5">
            <Building2 className="w-4 h-4 text-accent shrink-0" />
            <select
              value={activeBranchId}
              onChange={(e) => switchBranch(e.target.value)}
              className="bg-transparent border-0 text-xs text-text-primary focus:ring-0 py-0 pr-6 cursor-pointer"
              aria-label="Select branch"
            >
              <option value="ALL" className="bg-dark-surface">
                All Branches
              </option>
              {branches.map((b) => (
                <option key={b.id || b._id} value={b.id || b._id} className="bg-dark-surface">
                  {b.name}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Notifications Bell */}
        <div ref={notifRef} className="relative">
          <button
            type="button"
            onClick={() => setNotifOpen((prev) => !prev)}
            className="relative p-2 rounded-lg bg-dark-bg border border-dark-border text-text-secondary hover:text-text-primary hover:border-accent/50 transition-colors"
            aria-label="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-accent text-dark-bg text-[10px] font-bold flex items-center justify-center">
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>

          {notifOpen && (
            <div className="absolute right-0 mt-2 w-80 max-w-[90vw] bg-dark-surface-2 border border-dark-border rounded-xl shadow-2xl overflow-hidden z-50">
              <div className="px-4 py-3 border-b border-dark-border flex items-center justify-between">
                <span className="text-sm font-semibold text-text-primary">Notifications</span>
                {unreadCount > 0 && (
                  <button
                    type="button"
                    onClick={markAllRead}
                    className="inline-flex items-center gap-1 text-xs text-accent hover:underline"
                  >
                    <CheckCheck className="w-3.5 h-3.5" />
                    Mark all read
                  </button>
                )}
              </div>

              <div className="max-h-72 overflow-y-auto divide-y divide-dark-border/60">
                {recentNotifications.length === 0 ? (
                  <p className="py-8 text-center text-xs text-text-secondary">
                    You're all caught up!
                  </p>
                ) : (
                  recentNotifications.slice(0, 6).map((n, idx) => (
                    <div
                      key={n.id || n._id || idx}
                      className={`px-4 py-3 hover:bg-dark-surface transition-colors ${
                        !n.isRead && !n.read ? 'bg-accent-light/30' : ''
                      }`}
                    >
                      <p className="text-xs font-semibold text-text-primary truncate">
                        {n.title || 'Notification'}
                      </p>
                      <p className="text-xs text-text-secondary mt-0.5 line-clamp-2">
                        {n.message || n.body}
                      </p>
                      <p className="text-[10px] text-text-secondary/70 mt-1">
                        {formatRelativeTime(n.createdAt)}
                      </p>
                    </div>
                  ))
                )}
              </div>

              <button
                type="button"
                onClick={() => {
                  setNotifOpen(false);
                  navigate(notificationsPath);
                }}
                className="w-full py-2.5 text-center text-xs font-medium text-accent bg-dark-surface hover:bg-dark-bg border-t border-dark-border transition-colors"
              >
                View all notifications
              </button>
            </div>
          )}
        </div>

        {/* User Profile Dropdown */}
        <div ref={profileRef} className="relative">
          <button
            type="button"
            onClick={() => setProfileOpen((prev) => !prev)}
            className="flex items-center gap-2.5 pl-1.5 pr-2.5 py-1 rounded-xl bg-dark-bg border border-dark-border hover:border-accent/50 transition-colors"
          >
            <Avatar src={user?.avatar} name={user?.name || 'User'} size="sm" status="online" />
            <div className="hidden sm:block text-left max-w-[120px]">
              <p className="text-xs font-semibold text-text-primary truncate">
                {user?.name || 'User'}
              </p>
              <p className="text-[10px] text-accent uppercase tracking-wider font-medium">
                {role || 'MEMBER'}
              </p>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-text-secondary hidden sm:block" />
          </button>

          {profileOpen && (
            <div className="absolute right-0 mt-2 w-52 bg-dark-surface-2 border border-dark-border rounded-xl shadow-2xl py-1.5 z-50">
              <div className="px-4 py-2 border-b border-dark-border">
                <p className="text-xs font-semibold text-text-primary truncate">{user?.name}</p>
                <p className="text-[11px] text-text-secondary truncate">
                  {user?.mobile || user?.phone || user?.email}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setProfileOpen(false);
                  navigate(profilePath);
                }}
                className="w-full px-4 py-2 text-left text-sm text-text-primary hover:bg-dark-surface hover:text-accent flex items-center gap-2.5"
              >
                <User className="w-4 h-4" />
                My Profile
              </button>
              {settingsPath && (
                <button
                  type="button"
                  onClick={() => {
                    setProfileOpen(false);
                    navigate(settingsPath);
                  }}
                  className="w-full px-4 py-2 text-left text-sm text-text-primary hover:bg-dark-surface hover:text-accent flex items-center gap-2.5"
                >
                  <Settings className="w-4 h-4" />
                  Settings
                </button>
              )}
              <div className="my-1 border-t border-dark-border" />
              <button
                type="button"
                onClick={handleLogout}
                className="w-full px-4 py-2 text-left text-sm text-error hover:bg-error-light flex items-center gap-2.5"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;

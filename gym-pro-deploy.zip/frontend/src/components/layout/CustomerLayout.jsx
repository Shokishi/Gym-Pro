import React, { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import {
  Home,
  QrCode,
  Flame,
  Utensils,
  CreditCard,
  IdCard,
  TrendingUp,
  CalendarClock,
  Bell,
  User,
} from 'lucide-react';
import Sidebar from './Sidebar';
import Header from './Header';
import MobileNav from './MobileNav';

export const CustomerLayout = ({ children }) => {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const base = location.pathname.startsWith('/app') ? '/app' : '/customer';

  const primaryItems = [
    { label: 'Home', to: `${base}/home`, icon: Home },
    { label: 'Attendance', to: `${base}/attendance`, icon: QrCode },
    { label: 'Workout', to: `${base}/workout`, icon: Flame },
    { label: 'Diet', to: `${base}/diet`, icon: Utensils },
  ];

  const moreItems = [
    { label: 'Payments', to: `${base}/payments`, icon: CreditCard },
    { label: 'Membership', to: `${base}/membership`, icon: IdCard },
    { label: 'Progress', to: `${base}/progress`, icon: TrendingUp },
    { label: 'Appointments', to: `${base}/appointments`, icon: CalendarClock },
    { label: 'Notifications', to: `${base}/notifications`, icon: Bell },
    { label: 'Profile', to: `${base}/profile`, icon: User },
  ];

  const allItems = [...primaryItems, ...moreItems];

  return (
    <div className="min-h-screen bg-dark-bg text-text-primary flex">
      <Sidebar
        items={allItems}
        collapsed={collapsed}
        onToggleCollapse={() => setCollapsed((p) => !p)}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
        portalLabel="Member App"
      />
      <div className="flex-1 flex flex-col min-w-0">
        <Header
          onOpenMobileMenu={() => setMobileOpen(true)}
          title="Member Portal"
          profilePath={`${base}/profile`}
          notificationsPath={`${base}/notifications`}
        />
        <main className="flex-1 p-4 sm:p-6 pb-24 lg:pb-6 max-w-5xl w-full mx-auto">
          {children || <Outlet />}
        </main>
        <MobileNav primaryItems={primaryItems} moreItems={moreItems} />
      </div>
    </div>
  );
};

export default CustomerLayout;

import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  CalendarCheck,
  Flame,
  Utensils,
  CalendarClock,
  Bell,
  User,
} from 'lucide-react';
import Sidebar from './Sidebar';
import Header from './Header';
import MobileNav from './MobileNav';

const TRAINER_NAV_ITEMS = [
  { label: 'Dashboard', to: '/trainer/dashboard', icon: LayoutDashboard },
  { label: 'My Customers', to: '/trainer/customers', icon: Users },
  { label: 'Attendance', to: '/trainer/attendance', icon: CalendarCheck },
  { label: 'Workout Plans', to: '/trainer/workouts', icon: Flame },
  { label: 'Diet Plans', to: '/trainer/diets', icon: Utensils },
  { label: 'Schedule', to: '/trainer/schedule', icon: CalendarClock },
  { label: 'Notifications', to: '/trainer/notifications', icon: Bell },
  { label: 'Profile', to: '/trainer/profile', icon: User },
];

export const TrainerLayout = ({ children }) => {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-dark-bg text-text-primary flex">
      <Sidebar
        items={TRAINER_NAV_ITEMS}
        collapsed={collapsed}
        onToggleCollapse={() => setCollapsed((p) => !p)}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
        portalLabel="Trainer Portal"
      />
      <div className="flex-1 flex flex-col min-w-0">
        <Header
          onOpenMobileMenu={() => setMobileOpen(true)}
          title="Trainer Workspace"
          profilePath="/trainer/profile"
          notificationsPath="/trainer/notifications"
        />
        <main className="flex-1 p-4 sm:p-6 pb-24 lg:pb-6 max-w-7xl w-full mx-auto">
          {children || <Outlet />}
        </main>
        <MobileNav
          primaryItems={TRAINER_NAV_ITEMS.slice(0, 4)}
          moreItems={TRAINER_NAV_ITEMS.slice(4)}
        />
      </div>
    </div>
  );
};

export default TrainerLayout;

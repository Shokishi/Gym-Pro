import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Bell, Check, CheckCheck, Send, Trash2, Filter } from 'lucide-react';
import notificationService from '../../services/notificationService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatRelativeTime } from '../../utils/formatters';
import { validateForm } from '../../utils/validators';
import { useSocket } from '../../contexts/SocketContext';
import {
  PageHeader,
  Card,
  Button,
  Badge,
  EmptyState,
  Skeleton,
  ErrorState,
  Modal,
  Input,
  Textarea,
  Select,
  ConfirmDialog,
} from '../ui';

export const NotificationsCenter = ({
  title = 'Notifications',
  subtitle = 'Stay updated with alerts, reminders, and system announcements',
  canBroadcast = false,
  targetOptions = [
    { value: 'ALL', label: 'All Members & Staff' },
    { value: 'CUSTOMERS', label: 'Customers Only' },
    { value: 'TRAINERS', label: 'Trainers Only' },
  ],
}) => {
  const { refreshNotifications, setUnreadCount } = useSocket();
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filter, setFilter] = useState('ALL');
  const [composeOpen, setComposeOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const [form, setForm] = useState({
    title: '',
    message: '',
    audience: targetOptions[0]?.value || 'ALL',
    type: 'ANNOUNCEMENT',
  });
  const [errors, setErrors] = useState({});

  const fetchNotifications = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await notificationService.getAll({
        status: filter === 'UNREAD' ? 'unread' : undefined,
      });
      const list = extractList(res);
      setNotifications(list);
      setUnreadCount(list.filter((n) => !n.isRead && !n.read).length);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [filter, setUnreadCount]);

  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  const handleMarkRead = async (id) => {
    try {
      await notificationService.markRead(id);
      setNotifications((prev) =>
        prev.map((n) => ((n.id || n._id) === id ? { ...n, isRead: true, read: true } : n))
      );
      refreshNotifications();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await notificationService.markAllRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true, read: true })));
      setUnreadCount(0);
      toast.success('All notifications marked as read');
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const handleSend = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      title: { required: true, label: 'Title', minLength: 3 },
      message: { required: true, label: 'Message', minLength: 5 },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSending(true);
    try {
      await notificationService.send(form);
      toast.success('Notification sent successfully');
      setComposeOpen(false);
      setForm({ title: '', message: '', audience: targetOptions[0]?.value || 'ALL', type: 'ANNOUNCEMENT' });
      setErrors({});
      fetchNotifications();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSending(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await notificationService.delete(deleteTarget.id || deleteTarget._id);
      setNotifications((prev) =>
        prev.filter((n) => (n.id || n._id) !== (deleteTarget.id || deleteTarget._id))
      );
      toast.success('Notification deleted');
      setDeleteTarget(null);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  const visible = notifications.filter((n) =>
    filter === 'UNREAD' ? !n.isRead && !n.read : true
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title={title}
        subtitle={subtitle}
        actions={
          <div className="flex items-center gap-2.5 flex-wrap">
            <Button variant="secondary" size="sm" icon={CheckCheck} onClick={handleMarkAllRead}>
              Mark All Read
            </Button>
            {canBroadcast && (
              <Button size="sm" icon={Send} onClick={() => setComposeOpen(true)}>
                Send Broadcast
              </Button>
            )}
          </div>
        }
      />

      <div className="flex items-center gap-2">
        <Filter className="w-4 h-4 text-text-secondary" />
        {['ALL', 'UNREAD'].map((key) => (
          <button
            key={key}
            type="button"
            onClick={() => setFilter(key)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              filter === key
                ? 'bg-accent text-dark-bg font-semibold'
                : 'bg-dark-surface border border-dark-border text-text-secondary hover:text-text-primary'
            }`}
          >
            {key === 'ALL' ? 'All Notifications' : 'Unread Only'}
          </button>
        ))}
      </div>

      {loading ? (
        <Skeleton variant="list" rows={5} />
      ) : error ? (
        <ErrorState message={error} onRetry={fetchNotifications} />
      ) : visible.length === 0 ? (
        <Card>
          <EmptyState
            icon={Bell}
            title="No notifications"
            message={
              filter === 'UNREAD'
                ? 'You have no unread notifications.'
                : 'Notifications and alerts will show up here.'
            }
          />
        </Card>
      ) : (
        <div className="space-y-3">
          {visible.map((item) => {
            const id = item.id || item._id;
            const isRead = Boolean(item.isRead || item.read);
            return (
              <div
                key={id}
                className={`bg-dark-surface border rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-colors ${
                  isRead ? 'border-dark-border' : 'border-accent/40 bg-accent-light/10'
                }`}
              >
                <div className="flex items-start gap-3.5 min-w-0">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      isRead ? 'bg-dark-surface-2 text-text-secondary' : 'bg-accent-light text-accent'
                    }`}
                  >
                    <Bell className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="text-sm font-semibold text-text-primary">
                        {item.title || 'System Notification'}
                      </h4>
                      {!isRead && <Badge variant="accent">New</Badge>}
                      {item.type && <Badge variant="neutral">{item.type}</Badge>}
                    </div>
                    <p className="text-sm text-text-secondary mt-1">{item.message || item.body}</p>
                    <p className="text-xs text-text-secondary/70 mt-1.5">
                      {formatRelativeTime(item.createdAt)}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                  {!isRead && (
                    <Button
                      variant="secondary"
                      size="xs"
                      icon={Check}
                      onClick={() => handleMarkRead(id)}
                    >
                      Mark Read
                    </Button>
                  )}
                  <button
                    type="button"
                    onClick={() => setDeleteTarget(item)}
                    className="p-2 rounded-lg text-text-secondary hover:text-error hover:bg-error-light transition-colors"
                    aria-label="Delete notification"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal
        isOpen={composeOpen}
        onClose={() => setComposeOpen(false)}
        title="Send Notification Broadcast"
        subtitle="Deliver instant push & in-app alerts"
      >
        <form onSubmit={handleSend} className="space-y-4">
          <Select
            label="Audience"
            value={form.audience}
            options={targetOptions}
            onChange={(e) => setForm((p) => ({ ...p, audience: e.target.value }))}
          />
          <Select
            label="Category"
            value={form.type}
            options={[
              { value: 'ANNOUNCEMENT', label: 'Announcement' },
              { value: 'REMINDER', label: 'Payment / Renewal Reminder' },
              { value: 'PROMO', label: 'Offer / Promotion' },
              { value: 'ALERT', label: 'System Alert' },
            ]}
            onChange={(e) => setForm((p) => ({ ...p, type: e.target.value }))}
          />
          <Input
            label="Title"
            required
            placeholder="e.g. Holiday Gym Hours Update"
            value={form.title}
            error={errors.title}
            onChange={(e) => {
              setForm((p) => ({ ...p, title: e.target.value }));
              setErrors((p) => ({ ...p, title: '' }));
            }}
          />
          <Textarea
            label="Message"
            required
            rows={4}
            placeholder="Write the announcement message..."
            value={form.message}
            error={errors.message}
            onChange={(e) => {
              setForm((p) => ({ ...p, message: e.target.value }));
              setErrors((p) => ({ ...p, message: '' }));
            }}
          />
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setComposeOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={sending} icon={Send}>
              Send Notification
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Notification"
        message="Are you sure you want to remove this notification?"
        confirmLabel="Delete"
      />
    </div>
  );
};

export default NotificationsCenter;

import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Plus, Trash2, Save, Dumbbell } from 'lucide-react';
import workoutService from '../../services/workoutService';
import customerService from '../../services/customerService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { DAYS_OF_WEEK, FITNESS_GOALS } from '../../utils/constants';
import { validateForm } from '../../utils/validators';
import { Card, Input, Select, Textarea, Button } from '../ui';

const EMPTY_EXERCISE = () => ({
  day: 'Monday',
  name: '',
  muscleGroup: 'Chest',
  sets: 3,
  reps: '10-12',
  restSeconds: 60,
  notes: '',
});

export const WorkoutBuilder = ({ initialPlan = null, onSaved, onCancel, isTrainer = false }) => {
  const [customers, setCustomers] = useState([]);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});

  const [form, setForm] = useState({
    name: initialPlan?.name || initialPlan?.title || '',
    goal: initialPlan?.goal || 'MUSCLE_GAIN',
    difficulty: initialPlan?.difficulty || 'INTERMEDIATE',
    durationWeeks: initialPlan?.durationWeeks || 4,
    customerId: initialPlan?.customerId || '',
    description: initialPlan?.description || '',
    exercises:
      Array.isArray(initialPlan?.exercises) && initialPlan.exercises.length > 0
        ? initialPlan.exercises
        : [EMPTY_EXERCISE()],
  });

  useEffect(() => {
    const loadCustomers = async () => {
      try {
        const res = await customerService.getAll({ limit: 100 });
        setCustomers(extractList(res));
      } catch {
        // Optional assignment list
      }
    };
    loadCustomers();
  }, [isTrainer]);

  const updateExercise = (idx, field, value) => {
    setForm((prev) => ({
      ...prev,
      exercises: prev.exercises.map((ex, i) => (i === idx ? { ...ex, [field]: value } : ex)),
    }));
  };

  const addExercise = () => {
    setForm((prev) => ({ ...prev, exercises: [...prev.exercises, EMPTY_EXERCISE()] }));
  };

  const removeExercise = (idx) => {
    if (form.exercises.length <= 1) return;
    setForm((prev) => ({
      ...prev,
      exercises: prev.exercises.filter((_, i) => i !== idx),
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      name: { required: true, label: 'Plan Name', minLength: 3 },
      durationWeeks: { required: true, label: 'Duration (Weeks)', min: 1 },
    });

    const invalidExercise = form.exercises.some((ex) => !ex.name.trim());
    if (!isValid || invalidExercise) {
      setErrors({
        ...vErrors,
        exercises: invalidExercise ? 'Each exercise must have a name' : '',
      });
      return;
    }

    setSaving(true);
    try {
      const payload = {
        ...form,
        title: form.name,
        durationWeeks: Number(form.durationWeeks),
        exercises: form.exercises.map((ex) => ({
          ...ex,
          sets: Number(ex.sets || 3),
          restSeconds: Number(ex.restSeconds || 60),
        })),
      };

      if (initialPlan?.id || initialPlan?._id) {
        await workoutService.update(initialPlan.id || initialPlan._id, payload);
        toast.success('Workout plan updated');
      } else {
        await workoutService.create(payload);
        toast.success('Workout plan created');
      }
      onSaved?.();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card title="Workout Plan Overview" icon={Dumbbell}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Plan Name"
            required
            placeholder="e.g. 4-Day Hypertrophy Split"
            value={form.name}
            error={errors.name}
            onChange={(e) => {
              setForm((p) => ({ ...p, name: e.target.value }));
              setErrors((p) => ({ ...p, name: '' }));
            }}
          />
          <Select
            label="Fitness Goal"
            value={form.goal}
            options={FITNESS_GOALS}
            onChange={(e) => setForm((p) => ({ ...p, goal: e.target.value }))}
          />
          <Select
            label="Difficulty Level"
            value={form.difficulty}
            options={[
              { value: 'BEGINNER', label: 'Beginner' },
              { value: 'INTERMEDIATE', label: 'Intermediate' },
              { value: 'ADVANCED', label: 'Advanced' },
            ]}
            onChange={(e) => setForm((p) => ({ ...p, difficulty: e.target.value }))}
          />
          <Input
            label="Duration (Weeks)"
            type="number"
            min={1}
            max={52}
            value={form.durationWeeks}
            error={errors.durationWeeks}
            onChange={(e) => setForm((p) => ({ ...p, durationWeeks: e.target.value }))}
          />
          <Select
            label="Assign to Member (Optional)"
            placeholder="Save as reusable template"
            value={form.customerId}
            options={customers.map((c) => ({
              value: c.id || c._id,
              label: `${c.name} (${c.mobile || c.phone || ''})`,
            }))}
            onChange={(e) => setForm((p) => ({ ...p, customerId: e.target.value }))}
          />
          <Textarea
            label="Plan Description"
            rows={2}
            placeholder="Warmup guidance, progression notes..."
            value={form.description}
            onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
          />
        </div>
      </Card>

      <Card
        title="Exercise Schedule"
        subtitle="Add exercises per training day with sets, reps, and rest intervals"
        actions={
          <Button type="button" size="sm" variant="secondary" icon={Plus} onClick={addExercise}>
            Add Exercise
          </Button>
        }
      >
        {errors.exercises && <p className="text-xs text-error mb-3">{errors.exercises}</p>}

        <div className="space-y-4">
          {form.exercises.map((ex, idx) => (
            <div
              key={idx}
              className="p-4 rounded-xl bg-dark-bg border border-dark-border space-y-3"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-accent">
                  Exercise #{idx + 1}
                </span>
                {form.exercises.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeExercise(idx)}
                    className="text-xs text-error hover:underline inline-flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Remove
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
                <Select
                  label="Day"
                  value={ex.day}
                  options={DAYS_OF_WEEK}
                  onChange={(e) => updateExercise(idx, 'day', e.target.value)}
                />
                <Input
                  label="Exercise Name"
                  required
                  placeholder="e.g. Bench Press"
                  containerClassName="lg:col-span-2"
                  value={ex.name}
                  onChange={(e) => updateExercise(idx, 'name', e.target.value)}
                />
                <Input
                  label="Sets"
                  type="number"
                  min={1}
                  value={ex.sets}
                  onChange={(e) => updateExercise(idx, 'sets', e.target.value)}
                />
                <Input
                  label="Reps"
                  placeholder="e.g. 10-12"
                  value={ex.reps}
                  onChange={(e) => updateExercise(idx, 'reps', e.target.value)}
                />
                <Input
                  label="Rest (sec)"
                  type="number"
                  min={10}
                  value={ex.restSeconds}
                  onChange={(e) => updateExercise(idx, 'restSeconds', e.target.value)}
                />
              </div>
            </div>
          ))}
        </div>
      </Card>

      <div className="flex items-center justify-end gap-3">
        {onCancel && (
          <Button type="button" variant="secondary" onClick={onCancel}>
            Cancel
          </Button>
        )}
        <Button type="submit" loading={saving} icon={Save}>
          {initialPlan ? 'Update Workout Plan' : 'Save Workout Plan'}
        </Button>
      </div>
    </form>
  );
};

export default WorkoutBuilder;

import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Plus, Trash2, Save, Utensils } from 'lucide-react';
import dietService from '../../services/dietService';
import customerService from '../../services/customerService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { FITNESS_GOALS } from '../../utils/constants';
import { validateForm } from '../../utils/validators';
import { Card, Input, Select, Textarea, Button } from '../ui';

const EMPTY_MEAL = () => ({
  mealTime: 'Breakfast',
  time: '08:00 AM',
  items: '',
  calories: 450,
  protein: 30,
  carbs: 45,
  fats: 12,
});

export const DietBuilder = ({ initialPlan = null, onSaved, onCancel }) => {
  const [customers, setCustomers] = useState([]);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});

  const [form, setForm] = useState({
    name: initialPlan?.name || initialPlan?.title || '',
    goal: initialPlan?.goal || 'WEIGHT_LOSS',
    dietType: initialPlan?.dietType || 'HIGH_PROTEIN',
    customerId: initialPlan?.customerId || '',
    notes: initialPlan?.notes || '',
    meals:
      Array.isArray(initialPlan?.meals) && initialPlan.meals.length > 0
        ? initialPlan.meals
        : [EMPTY_MEAL()],
  });

  useEffect(() => {
    customerService
      .getAll({ limit: 100 })
      .then((res) => setCustomers(extractList(res)))
      .catch(() => {});
  }, []);

  const totals = form.meals.reduce(
    (acc, m) => ({
      calories: acc.calories + Number(m.calories || 0),
      protein: acc.protein + Number(m.protein || 0),
      carbs: acc.carbs + Number(m.carbs || 0),
      fats: acc.fats + Number(m.fats || 0),
    }),
    { calories: 0, protein: 0, carbs: 0, fats: 0 }
  );

  const updateMeal = (idx, field, value) => {
    setForm((prev) => ({
      ...prev,
      meals: prev.meals.map((m, i) => (i === idx ? { ...m, [field]: value } : m)),
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      name: { required: true, label: 'Diet Plan Name', minLength: 3 },
    });

    const missingItems = form.meals.some((m) => !String(m.items || '').trim());
    if (!isValid || missingItems) {
      setErrors({
        ...vErrors,
        meals: missingItems ? 'Each meal must specify food items' : '',
      });
      return;
    }

    setSaving(true);
    try {
      const payload = {
        ...form,
        title: form.name,
        totalCalories: totals.calories,
        totalProtein: totals.protein,
        totalCarbs: totals.carbs,
        totalFats: totals.fats,
        meals: form.meals.map((m) => ({
          ...m,
          calories: Number(m.calories || 0),
          protein: Number(m.protein || 0),
          carbs: Number(m.carbs || 0),
          fats: Number(m.fats || 0),
        })),
      };

      if (initialPlan?.id || initialPlan?._id) {
        await dietService.update(initialPlan.id || initialPlan._id, payload);
        toast.success('Diet plan updated');
      } else {
        await dietService.create(payload);
        toast.success('Diet plan created');
      }
      onSaved?.();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card title="Diet Plan Details" icon={Utensils}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Plan Name"
            required
            placeholder="e.g. Lean Cut 2100 kcal"
            value={form.name}
            error={errors.name}
            onChange={(e) => {
              setForm((p) => ({ ...p, name: e.target.value }));
              setErrors((p) => ({ ...p, name: '' }));
            }}
          />
          <Select
            label="Goal"
            value={form.goal}
            options={FITNESS_GOALS}
            onChange={(e) => setForm((p) => ({ ...p, goal: e.target.value }))}
          />
          <Select
            label="Diet Preference"
            value={form.dietType}
            options={[
              { value: 'HIGH_PROTEIN', label: 'High Protein' },
              { value: 'VEGETARIAN', label: 'Vegetarian' },
              { value: 'NON_VEG', label: 'Non-Vegetarian' },
              { value: 'VEGAN', label: 'Vegan' },
              { value: 'KETO', label: 'Ketogenic' },
              { value: 'BALANCED', label: 'Balanced' },
            ]}
            onChange={(e) => setForm((p) => ({ ...p, dietType: e.target.value }))}
          />
          <Select
            label="Assign to Member (Optional)"
            placeholder="Save as template"
            value={form.customerId}
            options={customers.map((c) => ({
              value: c.id || c._id,
              label: `${c.name} (${c.mobile || c.phone || ''})`,
            }))}
            onChange={(e) => setForm((p) => ({ ...p, customerId: e.target.value }))}
          />
        </div>
        <div className="mt-4">
          <Textarea
            label="Hydration & Supplement Notes"
            rows={2}
            placeholder="e.g. 4L water daily, 1 scoop whey post-workout..."
            value={form.notes}
            onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))}
          />
        </div>

        <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-dark-border">
          <div className="p-3 rounded-lg bg-dark-bg border border-dark-border text-center">
            <p className="text-xs text-text-secondary">Total Calories</p>
            <p className="text-lg font-bold text-accent">{totals.calories} kcal</p>
          </div>
          <div className="p-3 rounded-lg bg-dark-bg border border-dark-border text-center">
            <p className="text-xs text-text-secondary">Protein</p>
            <p className="text-lg font-bold text-success">{totals.protein}g</p>
          </div>
          <div className="p-3 rounded-lg bg-dark-bg border border-dark-border text-center">
            <p className="text-xs text-text-secondary">Carbs</p>
            <p className="text-lg font-bold text-warning">{totals.carbs}g</p>
          </div>
          <div className="p-3 rounded-lg bg-dark-bg border border-dark-border text-center">
            <p className="text-xs text-text-secondary">Fats</p>
            <p className="text-lg font-bold text-text-primary">{totals.fats}g</p>
          </div>
        </div>
      </Card>

      <Card
        title="Daily Meals"
        actions={
          <Button
            type="button"
            size="sm"
            variant="secondary"
            icon={Plus}
            onClick={() => setForm((p) => ({ ...p, meals: [...p.meals, EMPTY_MEAL()] }))}
          >
            Add Meal
          </Button>
        }
      >
        {errors.meals && <p className="text-xs text-error mb-3">{errors.meals}</p>}
        <div className="space-y-4">
          {form.meals.map((meal, idx) => (
            <div key={idx} className="p-4 rounded-xl bg-dark-bg border border-dark-border space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase text-accent">Meal #{idx + 1}</span>
                {form.meals.length > 1 && (
                  <button
                    type="button"
                    onClick={() =>
                      setForm((p) => ({ ...p, meals: p.meals.filter((_, i) => i !== idx) }))
                    }
                    className="text-xs text-error hover:underline inline-flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Remove
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
                <Select
                  label="Meal"
                  value={meal.mealTime}
                  options={[
                    'Breakfast',
                    'Mid-Morning Snack',
                    'Lunch',
                    'Pre-Workout',
                    'Post-Workout',
                    'Dinner',
                  ]}
                  onChange={(e) => updateMeal(idx, 'mealTime', e.target.value)}
                />
                <Input
                  label="Time"
                  placeholder="08:00 AM"
                  value={meal.time}
                  onChange={(e) => updateMeal(idx, 'time', e.target.value)}
                />
                <Input
                  label="Calories"
                  type="number"
                  value={meal.calories}
                  onChange={(e) => updateMeal(idx, 'calories', e.target.value)}
                />
                <Input
                  label="Protein (g)"
                  type="number"
                  value={meal.protein}
                  onChange={(e) => updateMeal(idx, 'protein', e.target.value)}
                />
                <Input
                  label="Carbs (g)"
                  type="number"
                  value={meal.carbs}
                  onChange={(e) => updateMeal(idx, 'carbs', e.target.value)}
                />
                <Input
                  label="Fats (g)"
                  type="number"
                  value={meal.fats}
                  onChange={(e) => updateMeal(idx, 'fats', e.target.value)}
                />
              </div>

              <Textarea
                label="Food Items & Portions"
                rows={2}
                required
                placeholder="e.g. 4 egg whites, 2 whole eggs, 60g oats, 1 banana"
                value={meal.items}
                onChange={(e) => updateMeal(idx, 'items', e.target.value)}
              />
            </div>
          ))}
        </div>
      </Card>

      <div className="flex items-center justify-end gap-3">
        {onCancel && (
          <Button type="button" variant="secondary" onClick={onCancel}>
            Cancel
          </Button>
        )}
        <Button type="submit" loading={saving} icon={Save}>
          {initialPlan ? 'Update Diet Plan' : 'Save Diet Plan'}
        </Button>
      </div>
    </form>
  );
};

export default DietBuilder;

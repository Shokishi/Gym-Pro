import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { User, Lock, Camera, Save, Shield, History, Clock } from 'lucide-react';
import profileService from '../../services/profileService';
import { useAuth } from '../../contexts/AuthContext';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { validateForm } from '../../utils/validators';
import { ROLES } from '../../utils/constants';
import { PageHeader, Card, Input, Button, Avatar, Badge, Skeleton } from '../ui';

export const ProfileManager = ({ title = 'My Profile', subtitle = 'Manage your personal details and account security' }) => {
  const { user, role, updateUser } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [changingPass, setChangingPass] = useState(false);
  const [loginHistory, setLoginHistory] = useState([]);

  const isAdmin = role === ROLES.ADMIN;

  const [profileForm, setProfileForm] = useState({
    name: user?.fullName || user?.name || '',
    email: user?.email || '',
    mobile: user?.mobile || user?.phone || '',
    specialization: user?.specialization || '',
    bio: user?.bio || '',
    address: user?.address || '',
    emergencyContact: user?.emergencyContact || '',
    twoFactorEnabled: user?.twoFactorEnabled || false,
  });
  const [profileErrors, setProfileErrors] = useState({});

  const [passForm, setPassForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [passErrors, setPassErrors] = useState({});

  useEffect(() => {
    let active = true;
    const loadProfile = async () => {
      try {
        const [profRes, historyRes] = await Promise.allSettled([
          profileService.getProfile(),
          profileService.getLoginHistory(),
        ]);

        if (active && profRes.status === 'fulfilled') {
          const data = extractData(profRes.value);
          if (data) {
            setProfileForm({
              name: data.fullName || data.name || user?.name || '',
              email: data.email || user?.email || '',
              mobile: data.mobile || data.phone || user?.mobile || '',
              specialization: data.specialization || '',
              bio: data.bio || '',
              address: data.address || '',
              emergencyContact: data.emergencyContact || '',
              twoFactorEnabled: Boolean(data.twoFactorEnabled),
            });
            updateUser(data);
          }
        }

        if (active && historyRes.status === 'fulfilled') {
          const hData = extractData(historyRes.value);
          if (Array.isArray(hData)) {
            setLoginHistory(hData.slice(0, 5));
          }
        }
      } catch {
        // Fallback to context user
      } finally {
        if (active) setLoading(false);
      }
    };
    loadProfile();
    return () => {
      active = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSaveProfile = async (e) => {
    e.preventDefault();
    const rules = {
      name: { required: true, label: 'Full Name', minLength: 2 },
      email: { email: true, label: 'Email' },
    };

    if (!isAdmin) {
      rules.mobile = { required: true, label: 'Mobile Number', mobile: true };
    }

    const { isValid, errors } = validateForm(profileForm, rules);
    if (!isValid) {
      setProfileErrors(errors);
      return;
    }

    setSaving(true);
    try {
      const res = await profileService.updateProfile({
        name: profileForm.name,
        fullName: profileForm.name,
        email: profileForm.email,
        mobile: profileForm.mobile,
        specialization: profileForm.specialization,
        bio: profileForm.bio,
        address: profileForm.address,
        emergencyContact: profileForm.emergencyContact,
        twoFactorEnabled: profileForm.twoFactorEnabled,
      });
      const updated = extractData(res) || profileForm;
      updateUser(updated);
      toast.success('Profile updated successfully');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleAvatarChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('avatar', file);
    try {
      const res = await profileService.uploadAvatar(formData);
      const data = extractData(res);
      const photoUrl = data?.avatar || data?.url || data?.profilePhoto;
      if (photoUrl) {
        updateUser({ avatar: photoUrl, profilePhoto: photoUrl });
      }
      toast.success('Profile photo updated');
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    const { isValid, errors } = validateForm(passForm, {
      currentPassword: { required: true, label: 'Current Password' },
      newPassword: { required: true, label: 'New Password', minLength: 6 },
      confirmPassword: {
        required: true,
        label: 'Confirm Password',
        match: 'newPassword',
        matchMessage: 'Passwords do not match',
      },
    });
    if (!isValid) {
      setPassErrors(errors);
      return;
    }

    setChangingPass(true);
    try {
      await profileService.changePassword({
        currentPassword: passForm.currentPassword,
        newPassword: passForm.newPassword,
      });
      toast.success('Password changed successfully');
      setPassForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
      setPassErrors({});
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setChangingPass(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <PageHeader title={title} subtitle={subtitle} />
        <Skeleton variant="card" />
        <Skeleton variant="card" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader title={title} subtitle={subtitle} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1">
          <div className="flex flex-col items-center text-center py-4">
            <div className="relative">
              <Avatar
                src={user?.avatar || user?.profilePhoto}
                name={profileForm.name}
                size="xl"
                status="active"
              />
              <label className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-accent text-dark-bg flex items-center justify-center cursor-pointer shadow-lg hover:bg-accent-hover transition-colors">
                <Camera className="w-4 h-4" />
                <input type="file" accept="image/*" className="hidden" onChange={handleAvatarChange} />
              </label>
            </div>
            <h3 className="text-lg font-bold text-text-primary mt-4">{profileForm.name}</h3>
            <p className="text-sm text-text-secondary mt-0.5">{profileForm.email || profileForm.mobile}</p>
            <div className="mt-3">
              <Badge variant={role}>{role}</Badge>
            </div>
          </div>
        </Card>

        <div className="lg:col-span-2 space-y-6">
          <Card title="Personal Information" icon={User}>
            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input
                  label="Full Name"
                  required
                  value={profileForm.name}
                  error={profileErrors.name}
                  onChange={(e) => {
                    setProfileForm((p) => ({ ...p, name: e.target.value }));
                    setProfileErrors((p) => ({ ...p, name: '' }));
                  }}
                />
                <Input
                  label={isAdmin ? 'Mobile Number (Optional for Super Admin)' : 'Mobile Number'}
                  required={!isAdmin}
                  value={profileForm.mobile}
                  error={profileErrors.mobile}
                  placeholder={isAdmin ? '+91 (Optional)' : '10-digit mobile'}
                  onChange={(e) => {
                    setProfileForm((p) => ({ ...p, mobile: e.target.value }));
                    setProfileErrors((p) => ({ ...p, mobile: '' }));
                  }}
                />
                <Input
                  label="Email Address"
                  type="email"
                  value={profileForm.email}
                  error={profileErrors.email}
                  onChange={(e) => {
                    setProfileForm((p) => ({ ...p, email: e.target.value }));
                    setProfileErrors((p) => ({ ...p, email: '' }));
                  }}
                />
                <Input
                  label="Emergency Contact"
                  value={profileForm.emergencyContact}
                  onChange={(e) => setProfileForm((p) => ({ ...p, emergencyContact: e.target.value }))}
                />
              </div>

              <Input
                label="Address"
                value={profileForm.address}
                onChange={(e) => setProfileForm((p) => ({ ...p, address: e.target.value }))}
              />

              {isAdmin && (
                <div className="flex items-center justify-between p-3 rounded-xl bg-dark-bg border border-dark-border mt-3">
                  <div>
                    <p className="text-sm font-semibold text-text-primary flex items-center gap-1.5">
                      <Shield className="w-4 h-4 text-accent" /> Two-Factor Authentication (2FA)
                    </p>
                    <p className="text-xs text-text-secondary mt-0.5">
                      Require OTP verification whenever logging in to the Super Admin portal
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={profileForm.twoFactorEnabled}
                    onChange={(e) => setProfileForm((p) => ({ ...p, twoFactorEnabled: e.target.checked }))}
                    className="w-5 h-5 rounded accent-accent cursor-pointer"
                  />
                </div>
              )}

              <div className="flex justify-end pt-2">
                <Button type="submit" loading={saving} icon={Save}>
                  Save Changes
                </Button>
              </div>
            </form>
          </Card>

          <Card title="Security & Password" icon={Lock}>
            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <Input
                label="Current Password"
                type="password"
                required
                value={passForm.currentPassword}
                error={passErrors.currentPassword}
                onChange={(e) => {
                  setPassForm((p) => ({ ...p, currentPassword: e.target.value }));
                  setPassErrors((p) => ({ ...p, currentPassword: '' }));
                }}
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input
                  label="New Password"
                  type="password"
                  required
                  value={passForm.newPassword}
                  error={passErrors.newPassword}
                  onChange={(e) => {
                    setPassForm((p) => ({ ...p, newPassword: e.target.value }));
                    setPassErrors((p) => ({ ...p, newPassword: '' }));
                  }}
                />
                <Input
                  label="Confirm New Password"
                  type="password"
                  required
                  value={passForm.confirmPassword}
                  error={passErrors.confirmPassword}
                  onChange={(e) => {
                    setPassForm((p) => ({ ...p, confirmPassword: e.target.value }));
                    setPassErrors((p) => ({ ...p, confirmPassword: '' }));
                  }}
                />
              </div>
              <div className="flex justify-end">
                <Button type="submit" variant="secondary" loading={changingPass}>
                  Update Password
                </Button>
              </div>
            </form>
          </Card>

          {loginHistory.length > 0 && (
            <Card title="Recent Login History" icon={History}>
              <div className="space-y-2">
                {loginHistory.map((item, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-3 rounded-lg bg-dark-bg border border-dark-border text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-accent" />
                      <span className="text-text-primary font-medium">
                        {item.createdAt ? new Date(item.createdAt).toLocaleString() : 'Recently'}
                      </span>
                    </div>
                    <span className="text-text-secondary font-mono">
                      {item.ipAddress || '127.0.0.1'} • {item.device || 'Web Browser'}
                    </span>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProfileManager;

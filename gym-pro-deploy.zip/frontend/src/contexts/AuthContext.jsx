import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import toast from 'react-hot-toast';
import authService from '../services/authService';
import { TOKEN_KEYS, PORTAL_HOME, normalizeRole, ROLES } from '../utils/constants';
import { extractData, getErrorMessage } from '../utils/apiHelpers';

const AuthContext = createContext(null);

const readStoredJson = (key) => {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => readStoredJson(TOKEN_KEYS.USER));
  const [gym, setGym] = useState(() => readStoredJson(TOKEN_KEYS.GYM));
  const [loading, setLoading] = useState(() => Boolean(localStorage.getItem(TOKEN_KEYS.ACCESS)));

  const role = normalizeRole(user?.role);
  const isAuthenticated = Boolean(user && localStorage.getItem(TOKEN_KEYS.ACCESS));

  const persistSession = useCallback((payload) => {
    const token = payload?.accessToken || payload?.token;
    const refreshToken = payload?.refreshToken;
    const userData = payload?.user || (payload?.id || payload?.role ? payload : null);
    const gymData = payload?.gym || userData?.gym || null;

    if (token) localStorage.setItem(TOKEN_KEYS.ACCESS, token);
    if (refreshToken) localStorage.setItem(TOKEN_KEYS.REFRESH, refreshToken);
    if (userData) {
      const normalized = { ...userData, role: normalizeRole(userData.role) };
      localStorage.setItem(TOKEN_KEYS.USER, JSON.stringify(normalized));
      setUser(normalized);
    }
    if (gymData) {
      localStorage.setItem(TOKEN_KEYS.GYM, JSON.stringify(gymData));
      setGym(gymData);
    }
    return userData ? { ...userData, role: normalizeRole(userData.role) } : null;
  }, []);

  const clearSession = useCallback(() => {
    localStorage.removeItem(TOKEN_KEYS.ACCESS);
    localStorage.removeItem(TOKEN_KEYS.REFRESH);
    localStorage.removeItem(TOKEN_KEYS.USER);
    localStorage.removeItem(TOKEN_KEYS.GYM);
    localStorage.removeItem('gympro_active_branch_id');
    setUser(null);
    setGym(null);
  }, []);

  const refreshUser = useCallback(async () => {
    const token = localStorage.getItem(TOKEN_KEYS.ACCESS);
    if (!token) {
      setLoading(false);
      return null;
    }
    try {
      const res = await authService.me();
      const data = extractData(res);
      const userData = data?.user || data;
      const gymData = data?.gym || userData?.gym || null;
      if (userData) {
        const normalized = { ...userData, role: normalizeRole(userData.role) };
        localStorage.setItem(TOKEN_KEYS.USER, JSON.stringify(normalized));
        setUser(normalized);
      }
      if (gymData) {
        localStorage.setItem(TOKEN_KEYS.GYM, JSON.stringify(gymData));
        setGym(gymData);
      }
      return userData;
    } catch (err) {
      if (err?.response?.status === 401) {
        clearSession();
      }
      return null;
    } finally {
      setLoading(false);
    }
  }, [clearSession]);

  useEffect(() => {
    refreshUser();
  }, [refreshUser]);

  // Listen for 401 token refresh failures from Axios interceptor
  useEffect(() => {
    const handleExpired = () => {
      clearSession();
      toast.error('Session expired. Please sign in again.');
    };
    window.addEventListener('gympro:auth-expired', handleExpired);
    return () => window.removeEventListener('gympro:auth-expired', handleExpired);
  }, [clearSession]);

  // Proactive background token refresh every 14 minutes
  useEffect(() => {
    if (!isAuthenticated) return undefined;
    const interval = setInterval(async () => {
      const refreshToken = localStorage.getItem(TOKEN_KEYS.REFRESH);
      if (!refreshToken) return;
      try {
        const res = await authService.refreshToken(refreshToken);
        const data = extractData(res);
        if (data?.accessToken || data?.token) {
          localStorage.setItem(TOKEN_KEYS.ACCESS, data.accessToken || data.token);
          if (data.refreshToken) localStorage.setItem(TOKEN_KEYS.REFRESH, data.refreshToken);
        }
      } catch {
        // Handled by interceptor on next API call
      }
    }, 14 * 60 * 1000);
    return () => clearInterval(interval);
  }, [isAuthenticated]);

  const login = async (credentials) => {
    const isSuperAdmin = normalizeRole(credentials?.role) === ROLES.ADMIN;
    const res = isSuperAdmin && credentials?.email
      ? await authService.adminLogin(credentials)
      : await authService.login(credentials);
    const data = extractData(res);
    if (data?.requireOtp || data?.otpRequired) {
      return {
        requireOtp: true,
        mobile: data?.mobile || credentials.mobile,
        purpose: data?.purpose || 'LOGIN',
        devOtp: data?.devOtp,
      };
    }
    const loggedInUser = persistSession(data);
    const userRole = normalizeRole(loggedInUser?.role || credentials.role);
    return {
      user: loggedInUser,
      role: userRole,
      redirectTo: PORTAL_HOME[userRole] || '/owner/dashboard',
    };
  };

  const registerOwner = async (payload) => {
    const res = await authService.registerOwner(payload);
    const data = extractData(res);
    if (data?.accessToken || data?.token) {
      persistSession(data);
    }
    return data;
  };

  const registerTrainer = async (payload) => {
    const res = await authService.registerTrainer(payload);
    const data = extractData(res);
    if (data?.accessToken || data?.token) {
      persistSession(data);
    }
    return data;
  };

  const registerCustomer = async (payload) => {
    const res = await authService.registerCustomer(payload);
    const data = extractData(res);
    if (data?.accessToken || data?.token) {
      persistSession(data);
    }
    return data;
  };

  const logout = async () => {
    try {
      if (localStorage.getItem(TOKEN_KEYS.ACCESS)) {
        await authService.logout();
      }
    } catch {
      // Proceed with local cleanup even if server logout fails
    } finally {
      clearSession();
      toast.success('Signed out successfully');
    }
  };

  const updateUser = useCallback((partial) => {
    setUser((prev) => {
      const next = { ...(prev || {}), ...partial };
      localStorage.setItem(TOKEN_KEYS.USER, JSON.stringify(next));
      return next;
    });
  }, []);

  const updateGym = useCallback((partial) => {
    setGym((prev) => {
      const next = { ...(prev || {}), ...partial };
      localStorage.setItem(TOKEN_KEYS.GYM, JSON.stringify(next));
      return next;
    });
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        gym,
        loading,
        isAuthenticated,
        login,
        registerOwner,
        registerTrainer,
        registerCustomer,
        logout,
        refreshUser,
        updateUser,
        updateGym,
        persistSession,
        getErrorMessage,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};

export const ProtectedRoute = ({ allowedRoles = [], children }) => {
  const { isAuthenticated, role, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen bg-dark-bg flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-dark-surface-2 border-t-accent rounded-full animate-spin" />
          <p className="text-sm text-text-secondary">Loading GYM PRO workspace...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (allowedRoles.length > 0 && !allowedRoles.includes(role)) {
    const home = PORTAL_HOME[role] || '/login';
    return <Navigate to={home} replace />;
  }

  return children;
};

export default AuthContext;

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useAuth } from './AuthContext';
import gymService from '../services/gymService';
import { extractData, extractList } from '../utils/apiHelpers';
import { ROLES } from '../utils/constants';

const GymContext = createContext(null);

export const GymProvider = ({ children }) => {
  const { isAuthenticated, role, gym, updateGym } = useAuth();
  const [branches, setBranches] = useState([]);
  const [activeBranchId, setActiveBranchId] = useState(
    () => localStorage.getItem('gympro_active_branch_id') || 'ALL'
  );
  const [subscription, setSubscription] = useState(null);
  const [gymLoading, setGymLoading] = useState(false);

  const refreshGymData = useCallback(async () => {
    if (!isAuthenticated || role === ROLES.ADMIN) return;
    setGymLoading(true);
    try {
      if (role === ROLES.OWNER) {
        const [profileRes, branchesRes, subRes] = await Promise.allSettled([
          gymService.getGymProfile(),
          gymService.getBranches(),
          gymService.getMySubscription(),
        ]);

        if (profileRes.status === 'fulfilled') {
          const gymData = extractData(profileRes.value);
          if (gymData) updateGym(gymData);
        }
        if (branchesRes.status === 'fulfilled') {
          setBranches(extractList(branchesRes.value));
        }
        if (subRes.status === 'fulfilled') {
          setSubscription(extractData(subRes.value));
        }
      }
    } finally {
      setGymLoading(false);
    }
  }, [isAuthenticated, role, updateGym]);

  useEffect(() => {
    refreshGymData();
  }, [refreshGymData]);

  const switchBranch = useCallback((branchId) => {
    const val = branchId || 'ALL';
    setActiveBranchId(val);
    if (val === 'ALL') localStorage.removeItem('gympro_active_branch_id');
    else localStorage.setItem('gympro_active_branch_id', val);
  }, []);

  const activeBranch = branches.find((b) => String(b.id || b._id) === String(activeBranchId)) || null;

  return (
    <GymContext.Provider
      value={{
        gym,
        branches,
        activeBranchId,
        activeBranch,
        subscription,
        gymLoading,
        switchBranch,
        refreshGymData,
      }}
    >
      {children}
    </GymContext.Provider>
  );
};

export const useGym = () => {
  const ctx = useContext(GymContext);
  if (!ctx) throw new Error('useGym must be used within GymProvider');
  return ctx;
};

export default GymContext;

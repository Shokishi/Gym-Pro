import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from 'react';
import { io } from 'socket.io-client';
import toast from 'react-hot-toast';
import { useAuth } from './AuthContext';
import { SOCKET_URL, TOKEN_KEYS } from '../utils/constants';
import notificationService from '../services/notificationService';
import { extractList } from '../utils/apiHelpers';

const SocketContext = createContext(null);

export const SocketProvider = ({ children }) => {
  const { isAuthenticated, user, gym } = useAuth();
  const [socket, setSocket] = useState(null);
  const [connected, setConnected] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [recentNotifications, setRecentNotifications] = useState([]);
  const socketRef = useRef(null);

  const fetchUnreadNotifications = useCallback(async () => {
    if (!isAuthenticated) return;
    try {
      const res = await notificationService.getAll({ limit: 10 });
      const list = extractList(res);
      setRecentNotifications(list);
      const unread = list.filter((n) => !n.isRead && !n.read).length;
      setUnreadCount(unread);
    } catch {
      // Silently ignore initial notification fetch failure
    }
  }, [isAuthenticated]);

  useEffect(() => {
    fetchUnreadNotifications();
  }, [fetchUnreadNotifications]);

  useEffect(() => {
    if (!isAuthenticated) {
      if (socketRef.current) {
        socketRef.current.disconnect();
        socketRef.current = null;
      }
      setSocket(null);
      setConnected(false);
      return undefined;
    }

    const token = localStorage.getItem(TOKEN_KEYS.ACCESS);
    const instance = io(SOCKET_URL, {
      auth: { token },
      transports: ['websocket', 'polling'],
      reconnectionAttempts: 5,
      reconnectionDelay: 3000,
    });

    socketRef.current = instance;
    setSocket(instance);

    instance.on('connect', () => {
      setConnected(true);
      if (user?.id || user?._id) {
        instance.emit('join', { userId: user.id || user._id, gymId: gym?.id || gym?._id });
      }
    });

    instance.on('disconnect', () => {
      setConnected(false);
    });

    instance.on('notification:new', (notification) => {
      setUnreadCount((c) => c + 1);
      setRecentNotifications((prev) => [notification, ...prev].slice(0, 15));
      toast(notification?.title || notification?.message || 'New notification received', {
        icon: '🔔',
      });
    });

    instance.on('attendance:checkin', (payload) => {
      window.dispatchEvent(new CustomEvent('gympro:attendance-update', { detail: payload }));
    });

    instance.on('payment:updated', (payload) => {
      window.dispatchEvent(new CustomEvent('gympro:payment-update', { detail: payload }));
    });

    return () => {
      instance.disconnect();
      socketRef.current = null;
      setSocket(null);
      setConnected(false);
    };
  }, [isAuthenticated, user?.id, user?._id, gym?.id, gym?._id]);

  const markAllRead = useCallback(async () => {
    try {
      await notificationService.markAllRead();
      setUnreadCount(0);
      setRecentNotifications((prev) => prev.map((n) => ({ ...n, isRead: true, read: true })));
    } catch {
      // Ignore if endpoint unavailable
    }
  }, []);

  const emitEvent = useCallback((event, payload) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit(event, payload);
    }
  }, []);

  return (
    <SocketContext.Provider
      value={{
        socket,
        connected,
        unreadCount,
        setUnreadCount,
        recentNotifications,
        refreshNotifications: fetchUnreadNotifications,
        markAllRead,
        emitEvent,
      }}
    >
      {children}
    </SocketContext.Provider>
  );
};

export const useSocket = () => {
  const ctx = useContext(SocketContext);
  if (!ctx) throw new Error('useSocket must be used within SocketProvider');
  return ctx;
};

export default SocketContext;

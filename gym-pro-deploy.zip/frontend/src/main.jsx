import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './contexts/AuthContext';
import { GymProvider } from './contexts/GymContext';
import { SocketProvider } from './contexts/SocketContext';
import App from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <GymProvider>
          <SocketProvider>
            <App />
            <Toaster
              position="top-right"
              toastOptions={{
                duration: 3500,
                style: {
                  background: '#191D21',
                  color: '#F5F5F5',
                  border: '1px solid #2A2F36',
                  borderRadius: '12px',
                  fontSize: '13px',
                },
                success: {
                  iconTheme: {
                    primary: '#27AE60',
                    secondary: '#101214',
                  },
                },
                error: {
                  iconTheme: {
                    primary: '#E05252',
                    secondary: '#101214',
                  },
                },
              }}
            />
          </SocketProvider>
        </GymProvider>
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>
);

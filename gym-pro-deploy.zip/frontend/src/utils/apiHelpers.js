const COMMON_LIST_KEYS = [
  'items',
  'records',
  'rows',
  'results',
  'list',
  'users',
  'gyms',
  'customers',
  'members',
  'trainers',
  'payments',
  'plans',
  'memberships',
  'invoices',
  'quotations',
  'notifications',
  'logs',
  'auditLogs',
  'tickets',
  'coupons',
  'domains',
  'subscriptions',
  'branches',
  'appointments',
  'classes',
  'expenses',
  'salaries',
  'enquiries',
  'referrals',
  'equipment',
  'workouts',
  'workoutPlans',
  'diets',
  'dietPlans',
  'attendance',
  'progress',
  'permissions',
];

export const extractData = (response, fallback = null) => {
  if (!response) return fallback;
  const payload = response.data !== undefined ? response.data : response;
  if (payload && typeof payload === 'object' && 'data' in payload && payload.data !== undefined) {
    return payload.data;
  }
  return payload ?? fallback;
};

export const extractList = (response, extraKeys = []) => {
  const data = extractData(response, []);
  if (Array.isArray(data)) return data;
  if (data && typeof data === 'object') {
    const keys = [...extraKeys, ...COMMON_LIST_KEYS];
    for (const key of keys) {
      if (Array.isArray(data[key])) return data[key];
    }
    if (data.data && Array.isArray(data.data)) return data.data;
  }
  return [];
};

export const extractPagination = (response, defaultLimit = 10) => {
  const root = response?.data || response || {};
  const data = root?.data && typeof root.data === 'object' && !Array.isArray(root.data) ? root.data : root;
  const meta = data?.pagination || data?.meta || root?.pagination || root?.meta || data;

  const total = Number(meta?.total ?? meta?.totalCount ?? meta?.count ?? 0);
  const page = Number(meta?.page ?? meta?.currentPage ?? 1);
  const limit = Number(meta?.limit ?? meta?.pageSize ?? meta?.perPage ?? defaultLimit);
  const totalPages = Number(meta?.totalPages ?? meta?.pages ?? (total > 0 ? Math.ceil(total / limit) : 1));

  return {
    page: Math.max(1, page),
    limit: Math.max(1, limit),
    total: Math.max(0, total),
    totalPages: Math.max(1, totalPages),
  };
};

export const getErrorMessage = (error, fallback = 'Something went wrong. Please try again.') => {
  if (!error) return fallback;
  if (typeof error === 'string') return error;

  const responseData = error?.response?.data;
  if (responseData) {
    if (typeof responseData === 'string') {
      if (responseData.trim().startsWith('<') || responseData.includes('<!DOCTYPE')) {
        return 'Backend API not reachable. Please ensure the backend server is running.';
      }
      return responseData;
    }
    if (responseData.message) return responseData.message;
    if (responseData.error) {
      return typeof responseData.error === 'string'
        ? responseData.error
        : responseData.error.message || fallback;
    }
    if (Array.isArray(responseData.errors) && responseData.errors.length > 0) {
      return responseData.errors.map((e) => e.message || e.msg || e).join(', ');
    }
  }

  if (error.code === 'ERR_NETWORK') {
    return 'Unable to connect to the server. Please verify the API server is running.';
  }

  return error.message || fallback;
};

export const buildQueryParams = (params = {}) => {
  const clean = {};
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '' && value !== 'ALL') {
      clean[key] = value;
    }
  });
  return clean;
};

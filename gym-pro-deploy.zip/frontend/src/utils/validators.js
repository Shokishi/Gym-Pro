export const isValidMobile = (value = '') => {
  const cleaned = String(value).replace(/[\s\-()]/g, '');
  return /^(\+?\d{1,3})?\d{10}$/.test(cleaned);
};

export const isValidEmail = (value = '') => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value).trim());
};

export const isValidPassword = (value = '', minLength = 6) => {
  return String(value).length >= minLength;
};

/**
 * Validates form fields against a declarative rule schema.
 * rule: { required?, label?, minLength?, maxLength?, pattern?, min?, max?, custom? }
 */
export const validateForm = (values = {}, rules = {}) => {
  const errors = {};

  Object.entries(rules).forEach(([field, rule]) => {
    const val = values[field];
    const label = rule.label || field;
    const strVal = val === undefined || val === null ? '' : String(val).trim();

    if (rule.required && !strVal && val !== 0 && val !== false) {
      errors[field] = `${label} is required`;
      return;
    }

    if (!strVal) return;

    if (rule.mobile && !isValidMobile(strVal)) {
      errors[field] = `Enter a valid 10-digit ${label.toLowerCase()}`;
      return;
    }

    if (rule.email && !isValidEmail(strVal)) {
      errors[field] = `Enter a valid email address`;
      return;
    }

    if (rule.minLength && strVal.length < rule.minLength) {
      errors[field] = `${label} must be at least ${rule.minLength} characters`;
      return;
    }

    if (rule.maxLength && strVal.length > rule.maxLength) {
      errors[field] = `${label} must be at most ${rule.maxLength} characters`;
      return;
    }

    if (rule.min !== undefined && Number(val) < rule.min) {
      errors[field] = `${label} must be at least ${rule.min}`;
      return;
    }

    if (rule.max !== undefined && Number(val) > rule.max) {
      errors[field] = `${label} must be at most ${rule.max}`;
      return;
    }

    if (rule.match && val !== values[rule.match]) {
      errors[field] = rule.matchMessage || `${label} does not match`;
      return;
    }

    if (rule.custom) {
      const customErr = rule.custom(val, values);
      if (customErr) errors[field] = customErr;
    }
  });

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
};

import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { formatCurrency, formatDate } from './formatters';

const applyBrandHeader = (doc, title, gym = {}) => {
  doc.setFillColor(16, 18, 20);
  doc.rect(0, 0, 210, 36, 'F');

  doc.setFillColor(242, 140, 40);
  doc.rect(0, 34, 210, 2, 'F');

  doc.setTextColor(242, 140, 40);
  doc.setFontSize(20);
  doc.setFont('helvetica', 'bold');
  doc.text(gym?.name || 'GYM PRO', 14, 17);

  doc.setTextColor(166, 173, 181);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  const subtitle = [gym?.address, gym?.phone, gym?.email].filter(Boolean).join(' • ') || 'Professional Gym Management SaaS';
  doc.text(subtitle.slice(0, 85), 14, 25);

  doc.setTextColor(245, 245, 245);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text(title, 196, 20, { align: 'right' });
};

export const generateInvoicePDF = (invoice, gym = {}) => {
  const doc = new jsPDF();
  applyBrandHeader(doc, 'TAX INVOICE', gym);

  doc.setTextColor(30, 30, 30);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text(`Invoice #: ${invoice.invoiceNumber || invoice.id || 'INV-001'}`, 14, 48);
  doc.setFont('helvetica', 'normal');
  doc.text(`Date: ${formatDate(invoice.issueDate || invoice.createdAt)}`, 14, 54);
  doc.text(`Due Date: ${formatDate(invoice.dueDate)}`, 14, 60);
  doc.text(`Status: ${String(invoice.status || 'PAID').toUpperCase()}`, 14, 66);

  const customerName = invoice.customerName || invoice.customer?.name || 'Valued Member';
  const customerPhone = invoice.customerPhone || invoice.customer?.phone || invoice.customer?.mobile || '';
  const customerEmail = invoice.customerEmail || invoice.customer?.email || '';

  doc.setFont('helvetica', 'bold');
  doc.text('Billed To:', 130, 48);
  doc.setFont('helvetica', 'normal');
  doc.text(customerName, 130, 54);
  if (customerPhone) doc.text(customerPhone, 130, 60);
  if (customerEmail) doc.text(customerEmail, 130, 66);

  const items = Array.isArray(invoice.items) && invoice.items.length > 0
    ? invoice.items
    : [
        {
          description: invoice.description || invoice.planName || 'Gym Membership / Services',
          quantity: 1,
          unitPrice: invoice.subtotal ?? invoice.amount ?? invoice.total ?? 0,
          total: invoice.subtotal ?? invoice.amount ?? invoice.total ?? 0,
        },
      ];

  autoTable(doc, {
    startY: 76,
    head: [['#', 'Description', 'Qty', 'Unit Price', 'Amount']],
    body: items.map((item, idx) => [
      idx + 1,
      item.description || item.name || 'Item',
      item.quantity || 1,
      formatCurrency(item.unitPrice ?? item.price ?? 0),
      formatCurrency(item.total ?? (Number(item.quantity || 1) * Number(item.unitPrice ?? item.price ?? 0))),
    ]),
    headStyles: { fillColor: [25, 29, 33], textColor: [242, 140, 40], fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [248, 249, 250] },
    styles: { fontSize: 9.5, cellPadding: 4 },
  });

  const finalY = (doc.lastAutoTable?.finalY || 120) + 10;
  const subtotal = Number(invoice.subtotal ?? invoice.amount ?? invoice.total ?? 0);
  const tax = Number(invoice.tax ?? invoice.gst ?? 0);
  const discount = Number(invoice.discount ?? 0);
  const total = Number(invoice.total ?? subtotal + tax - discount);

  doc.setFontSize(10);
  doc.text(`Subtotal: ${formatCurrency(subtotal)}`, 196, finalY, { align: 'right' });
  if (discount > 0) doc.text(`Discount: -${formatCurrency(discount)}`, 196, finalY + 6, { align: 'right' });
  if (tax > 0) doc.text(`Tax / GST: ${formatCurrency(tax)}`, 196, finalY + (discount > 0 ? 12 : 6), { align: 'right' });

  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  const totalOffset = (discount > 0 ? 6 : 0) + (tax > 0 ? 6 : 0) + 8;
  doc.text(`Total Amount: ${formatCurrency(total)}`, 196, finalY + totalOffset, { align: 'right' });

  if (invoice.notes) {
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 100, 100);
    doc.text(`Notes: ${invoice.notes}`, 14, finalY + totalOffset + 14);
  }

  doc.save(`${invoice.invoiceNumber || `invoice-${invoice.id || 'doc'}`}.pdf`);
};

export const generateQuotationPDF = (quotation, gym = {}) => {
  const doc = new jsPDF();
  applyBrandHeader(doc, 'QUOTATION', gym);

  doc.setTextColor(30, 30, 30);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text(`Quotation #: ${quotation.quotationNumber || quotation.id || 'QT-001'}`, 14, 48);
  doc.setFont('helvetica', 'normal');
  doc.text(`Date: ${formatDate(quotation.createdAt || new Date())}`, 14, 54);
  doc.text(`Valid Until: ${formatDate(quotation.validUntil)}`, 14, 60);

  doc.setFont('helvetica', 'bold');
  doc.text('Prepared For:', 130, 48);
  doc.setFont('helvetica', 'normal');
  doc.text(quotation.customerName || quotation.clientName || 'Prospective Member', 130, 54);
  if (quotation.customerPhone || quotation.phone) doc.text(quotation.customerPhone || quotation.phone, 130, 60);
  if (quotation.customerEmail || quotation.email) doc.text(quotation.customerEmail || quotation.email, 130, 66);

  const items = Array.isArray(quotation.items) ? quotation.items : [];
  autoTable(doc, {
    startY: 76,
    head: [['#', 'Item / Plan', 'Qty', 'Rate', 'Amount']],
    body: items.map((item, idx) => [
      idx + 1,
      item.description || item.name || 'Service',
      item.quantity || 1,
      formatCurrency(item.unitPrice ?? item.price ?? 0),
      formatCurrency(item.total ?? Number(item.quantity || 1) * Number(item.unitPrice ?? item.price ?? 0)),
    ]),
    headStyles: { fillColor: [25, 29, 33], textColor: [242, 140, 40], fontStyle: 'bold' },
  });

  const finalY = (doc.lastAutoTable?.finalY || 120) + 12;
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text(`Estimated Total: ${formatCurrency(quotation.total ?? quotation.totalAmount ?? 0)}`, 196, finalY, {
    align: 'right',
  });

  doc.save(`${quotation.quotationNumber || `quotation-${quotation.id || 'doc'}`}.pdf`);
};

export const generateReportPDF = ({ title = 'Report', subtitle = '', columns = [], rows = [], filename = 'report.pdf', gym = {} }) => {
  const doc = new jsPDF();
  applyBrandHeader(doc, title.toUpperCase(), gym);

  doc.setTextColor(60, 60, 60);
  doc.setFontSize(9.5);
  if (subtitle) doc.text(subtitle, 14, 44);
  doc.text(`Generated: ${formatDate(new Date(), 'DD MMM YYYY, hh:mm A')}`, 14, subtitle ? 50 : 44);

  autoTable(doc, {
    startY: subtitle ? 56 : 50,
    head: [columns],
    body: rows,
    headStyles: { fillColor: [25, 29, 33], textColor: [242, 140, 40], fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [248, 249, 250] },
    styles: { fontSize: 8.5, cellPadding: 3 },
  });

  doc.save(filename);
};

export const exportToCSV = (filename, headers = [], rows = []) => {
  const escape = (val) => {
    const str = String(val ?? '');
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };
  const csv = [headers.map(escape).join(','), ...rows.map((r) => r.map(escape).join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename.endsWith('.csv') ? filename : `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

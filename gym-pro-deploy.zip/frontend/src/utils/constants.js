export const API_BASE_URL = import.meta.env.VITE_API_URL || '/api';
export const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || (typeof window !== 'undefined' ? window.location.origin : 'http://localhost:5000');

export const ROLES = {
  ADMIN: 'ADMIN',
  OWNER: 'OWNER',
  TRAINER: 'TRAINER',
  CUSTOMER: 'CUSTOMER',
};

export const normalizeRole = (role) => {
  if (!role) return '';
  const upper = String(role).toUpperCase().trim();
  if (upper === 'SUPER_ADMIN' || upper === 'SUPERADMIN' || upper === 'ADMIN') return ROLES.ADMIN;
  if (upper === 'GYM_OWNER' || upper === 'OWNER') return ROLES.OWNER;
  if (upper === 'TRAINER' || upper === 'COACH') return ROLES.TRAINER;
  if (upper === 'CUSTOMER' || upper === 'MEMBER') return ROLES.CUSTOMER;
  return upper;
};

export const PORTAL_HOME = {
  [ROLES.ADMIN]: '/admin/dashboard',
  [ROLES.OWNER]: '/owner/dashboard',
  [ROLES.TRAINER]: '/trainer/dashboard',
  [ROLES.CUSTOMER]: '/customer/home',
};

export const DATE_PRESETS = [
  { key: 'today', label: 'Today' },
  { key: '7d', label: '7 Days' },
  { key: '30d', label: '30 Days' },
  { key: 'this_month', label: 'This Month' },
  { key: 'custom', label: 'Custom' },
];

export const PAYMENT_METHODS = [
  { value: 'UPI', label: 'UPI / QR Code' },
  { value: 'CASH', label: 'Cash' },
  { value: 'CARD', label: 'Debit / Credit Card' },
  { value: 'BANK_TRANSFER', label: 'Bank Transfer / NEFT' },
  { value: 'ONLINE', label: 'Online Gateway' },
];

export const FITNESS_GOALS = [
  { value: 'WEIGHT_LOSS', label: 'Weight Loss' },
  { value: 'MUSCLE_GAIN', label: 'Muscle Gain' },
  { value: 'STRENGTH', label: 'Strength & Conditioning' },
  { value: 'ENDURANCE', label: 'Endurance & Stamina' },
  { value: 'GENERAL_FITNESS', label: 'General Fitness' },
  { value: 'FLEXIBILITY', label: 'Flexibility & Mobility' },
];

export const DAYS_OF_WEEK = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday',
];

export const TOKEN_KEYS = {
  ACCESS: 'gympro_access_token',
  REFRESH: 'gympro_refresh_token',
  USER: 'gympro_user',
  GYM: 'gympro_gym',
};

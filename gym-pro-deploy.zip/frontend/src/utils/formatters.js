import dayjs from 'dayjs';

export const formatCurrency = (amount, currency = 'INR') => {
  const num = Number(amount || 0);
  if (Number.isNaN(num)) return '₹0';
  const locale = currency === 'INR' ? 'en-IN' : 'en-US';
  try {
    return new Intl.NumberFormat(locale, {
      style: 'currency',
      currency,
      maximumFractionDigits: num % 1 === 0 ? 0 : 2,
    }).format(num);
  } catch {
    return `₹${num.toLocaleString('en-IN')}`;
  }
};

export const formatNumber = (value) => {
  const num = Number(value || 0);
  if (Number.isNaN(num)) return '0';
  return num.toLocaleString('en-IN');
};

export const formatDate = (date, pattern = 'DD MMM YYYY') => {
  if (!date) return '—';
  const parsed = dayjs(date);
  return parsed.isValid() ? parsed.format(pattern) : '—';
};

export const formatDateTime = (date) => {
  if (!date) return '—';
  const parsed = dayjs(date);
  return parsed.isValid() ? parsed.format('DD MMM YYYY, hh:mm A') : '—';
};

export const formatTime = (date) => {
  if (!date) return '—';
  if (typeof date === 'string' && /^\d{2}:\d{2}/.test(date)) {
    const [h, m] = date.split(':').map(Number);
    const suffix = h >= 12 ? 'PM' : 'AM';
    const hour12 = h % 12 || 12;
    return `${String(hour12).padStart(2, '0')}:${String(m).padStart(2, '0')} ${suffix}`;
  }
  const parsed = dayjs(date);
  return parsed.isValid() ? parsed.format('hh:mm A') : '—';
};

export const formatRelativeTime = (date) => {
  if (!date) return '';
  const diffMin = dayjs().diff(dayjs(date), 'minute');
  if (diffMin < 1) return 'Just now';
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  const diffDays = Math.floor(diffHr / 24);
  if (diffDays < 7) return `${diffDays}d ago`;
  return formatDate(date);
};

export const getInitials = (name = '') => {
  const parts = String(name).trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return 'GP';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
};

export const calculateBMI = (weightKg, heightCm) => {
  const w = Number(weightKg);
  const h = Number(heightCm);
  if (!w || !h || w <= 0 || h <= 0) return { bmi: null, category: 'N/A' };
  const meters = h / 100;
  const bmi = Number((w / (meters * meters)).toFixed(1));
  let category = 'Normal';
  if (bmi < 18.5) category = 'Underweight';
  else if (bmi >= 25 && bmi < 30) category = 'Overweight';
  else if (bmi >= 30) category = 'Obese';
  return { bmi, category };
};

export const getDateRangeFromPreset = (preset, customStart, customEnd) => {
  const today = dayjs();
  switch (preset) {
    case 'today':
      return {
        startDate: today.startOf('day').format('YYYY-MM-DD'),
        endDate: today.endOf('day').format('YYYY-MM-DD'),
      };
    case '7d':
      return {
        startDate: today.subtract(6, 'day').format('YYYY-MM-DD'),
        endDate: today.format('YYYY-MM-DD'),
      };
    case '30d':
      return {
        startDate: today.subtract(29, 'day').format('YYYY-MM-DD'),
        endDate: today.format('YYYY-MM-DD'),
      };
    case 'this_month':
      return {
        startDate: today.startOf('month').format('YYYY-MM-DD'),
        endDate: today.endOf('month').format('YYYY-MM-DD'),
      };
    case 'custom':
      return {
        startDate: customStart || today.subtract(29, 'day').format('YYYY-MM-DD'),
        endDate: customEnd || today.format('YYYY-MM-DD'),
      };
    default:
      return {
        startDate: today.subtract(29, 'day').format('YYYY-MM-DD'),
        endDate: today.format('YYYY-MM-DD'),
      };
  }
};

export const getDaysRemaining = (endDate) => {
  if (!endDate) return 0;
  return dayjs(endDate).startOf('day').diff(dayjs().startOf('day'), 'day');
};

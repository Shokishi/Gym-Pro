import React from 'react';
import { Routes, Route, Navigate, Link } from 'react-router-dom';
import { ProtectedRoute } from './contexts/AuthContext';
import { ROLES } from './utils/constants';

// Layouts
import AdminLayout from './components/layout/AdminLayout';
import OwnerLayout from './components/layout/OwnerLayout';
import TrainerLayout from './components/layout/TrainerLayout';
import CustomerLayout from './components/layout/CustomerLayout';

// Auth & Landing Pages
import LandingPage from './pages/auth/LandingPage';
import LoginPage from './pages/auth/LoginPage';
import RegisterPage from './pages/auth/RegisterPage';
import TrainerRegisterPage from './pages/auth/TrainerRegisterPage';
import CustomerRegisterPage from './pages/auth/CustomerRegisterPage';
import ForgotPasswordPage from './pages/auth/ForgotPasswordPage';
import OTPVerificationPage from './pages/auth/OTPVerificationPage';

// Super Admin Pages
import AdminDashboard from './pages/admin/AdminDashboard';
import GymManagement from './pages/admin/GymManagement';
import AllUsers from './pages/admin/AllUsers';
import SubscriptionPlans from './pages/admin/SubscriptionPlans';
import PricingManagement from './pages/admin/PricingManagement';
import TrialSettings from './pages/admin/TrialSettings';
import Subscriptions from './pages/admin/Subscriptions';
import SubscriptionPayments from './pages/admin/SubscriptionPayments';
import CouponsOffers from './pages/admin/CouponsOffers';
import DomainManagement from './pages/admin/DomainManagement';
import AdminNotifications from './pages/admin/AdminNotifications';
import CustomerSupport from './pages/admin/CustomerSupport';
import Analytics from './pages/admin/Analytics';
import AdminReports from './pages/admin/AdminReports';
import AuditLogs from './pages/admin/AuditLogs';
import PlatformSettings from './pages/admin/PlatformSettings';
import AdminProfile from './pages/admin/AdminProfile';

// Gym Owner Pages
import OwnerDashboard from './pages/owner/OwnerDashboard';
import CustomerList from './pages/owner/CustomerList';
import CustomerDetail from './pages/owner/CustomerDetail';
import AddCustomer from './pages/owner/AddCustomer';
import TrainerList from './pages/owner/TrainerList';
import TrainerDetail from './pages/owner/TrainerDetail';
import AddTrainer from './pages/owner/AddTrainer';
import AttendanceManagement from './pages/owner/AttendanceManagement';
import AttendanceReport from './pages/owner/AttendanceReport';
import MembershipPlans from './pages/owner/MembershipPlans';
import MembershipManagement from './pages/owner/MembershipManagement';
import PaymentList from './pages/owner/PaymentList';
import PaymentDetail from './pages/owner/PaymentDetail';
import QRPaymentSettings from './pages/owner/QRPaymentSettings';
import QuotationList from './pages/owner/QuotationList';
import CreateQuotation from './pages/owner/CreateQuotation';
import InvoiceList from './pages/owner/InvoiceList';
import InvoiceDetail from './pages/owner/InvoiceDetail';
import WorkoutManagement from './pages/owner/WorkoutManagement';
import DietManagement from './pages/owner/DietManagement';
import AppointmentManagement from './pages/owner/AppointmentManagement';
import SalaryManagement from './pages/owner/SalaryManagement';
import ExpenseManagement from './pages/owner/ExpenseManagement';
import EnquiryManagement from './pages/owner/EnquiryManagement';
import ReferralManagement from './pages/owner/ReferralManagement';
import EquipmentManagement from './pages/owner/EquipmentManagement';
import OwnerNotifications from './pages/owner/OwnerNotifications';
import OwnerReports from './pages/owner/OwnerReports';
import BranchManagement from './pages/owner/BranchManagement';
import PermissionManagement from './pages/owner/PermissionManagement';
import OwnerAuditLogs from './pages/owner/OwnerAuditLogs';
import SubscriptionPage from './pages/owner/SubscriptionPage';
import OwnerProfile from './pages/owner/OwnerProfile';
import OwnerSettings from './pages/owner/OwnerSettings';

// Trainer Pages
import TrainerDashboard from './pages/trainer/TrainerDashboard';
import MyCustomers from './pages/trainer/MyCustomers';
import TrainerCustomerAttendance from './pages/trainer/CustomerAttendance';
import TrainerWorkoutPlans from './pages/trainer/TrainerWorkoutPlans';
import CreateWorkout from './pages/trainer/CreateWorkout';
import TrainerDietPlans from './pages/trainer/TrainerDietPlans';
import CreateDietPlan from './pages/trainer/CreateDietPlan';
import TrainerSchedule from './pages/trainer/TrainerSchedule';
import TrainerNotifications from './pages/trainer/TrainerNotifications';
import TrainerProfile from './pages/trainer/TrainerProfile';

// Customer Pages
import CustomerHome from './pages/customer/CustomerHome';
import CustomerAttendance from './pages/customer/CustomerAttendance';
import CustomerWorkout from './pages/customer/CustomerWorkout';
import CustomerDiet from './pages/customer/CustomerDiet';
import CustomerPayments from './pages/customer/CustomerPayments';
import MakePayment from './pages/customer/MakePayment';
import CustomerMembership from './pages/customer/CustomerMembership';
import CustomerProgress from './pages/customer/CustomerProgress';
import CustomerAppointments from './pages/customer/CustomerAppointments';
import CustomerNotifications from './pages/customer/CustomerNotifications';
import CustomerProfile from './pages/customer/CustomerProfile';

const NotFoundPage = () => (
  <div className="min-h-screen bg-dark-bg flex flex-col items-center justify-center p-6 text-center">
    <p className="text-6xl font-extrabold text-accent">404</p>
    <h1 className="text-2xl font-bold text-text-primary mt-3">Page Not Found</h1>
    <p className="text-sm text-text-secondary mt-2 max-w-md">
      The page you are looking for does not exist or has been moved.
    </p>
    <Link
      to="/"
      className="mt-6 px-5 py-2.5 rounded-lg bg-accent hover:bg-accent-hover text-dark-bg text-sm font-semibold transition-colors"
    >
      Back to Home
    </Link>
  </div>
);

const renderCustomerRoutes = () => (
  <>
    <Route index element={<Navigate to="home" replace />} />
    <Route path="home" element={<CustomerHome />} />
    <Route path="attendance" element={<CustomerAttendance />} />
    <Route path="workout" element={<CustomerWorkout />} />
    <Route path="diet" element={<CustomerDiet />} />
    <Route path="payments" element={<CustomerPayments />} />
    <Route path="payments/new" element={<MakePayment />} />
    <Route path="membership" element={<CustomerMembership />} />
    <Route path="progress" element={<CustomerProgress />} />
    <Route path="appointments" element={<CustomerAppointments />} />
    <Route path="notifications" element={<CustomerNotifications />} />
    <Route path="profile" element={<CustomerProfile />} />
  </>
);

export function App() {
  return (
    <Routes>
      {/* Public & Auth Routes */}
      <Route path="/" element={<LandingPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/register/trainer" element={<TrainerRegisterPage />} />
      <Route path="/register/customer" element={<CustomerRegisterPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/verify-otp" element={<OTPVerificationPage />} />

      {/* Super Admin Portal */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute allowedRoles={[ROLES.ADMIN]}>
            <AdminLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<AdminDashboard />} />
        <Route path="gyms" element={<GymManagement />} />
        <Route path="users" element={<AllUsers />} />
        <Route path="plans" element={<SubscriptionPlans />} />
        <Route path="pricing" element={<PricingManagement />} />
        <Route path="trial-settings" element={<TrialSettings />} />
        <Route path="subscriptions" element={<Subscriptions />} />
        <Route path="subscription-payments" element={<SubscriptionPayments />} />
        <Route path="coupons" element={<CouponsOffers />} />
        <Route path="domains" element={<DomainManagement />} />
        <Route path="notifications" element={<AdminNotifications />} />
        <Route path="support" element={<CustomerSupport />} />
        <Route path="analytics" element={<Analytics />} />
        <Route path="reports" element={<AdminReports />} />
        <Route path="audit-logs" element={<AuditLogs />} />
        <Route path="settings" element={<PlatformSettings />} />
        <Route path="profile" element={<AdminProfile />} />
      </Route>

      {/* Gym Owner Portal */}
      <Route
        path="/owner"
        element={
          <ProtectedRoute allowedRoles={[ROLES.OWNER]}>
            <OwnerLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<OwnerDashboard />} />
        <Route path="customers" element={<CustomerList />} />
        <Route path="customers/new" element={<AddCustomer />} />
        <Route path="customers/:id" element={<CustomerDetail />} />
        <Route path="trainers" element={<TrainerList />} />
        <Route path="trainers/new" element={<AddTrainer />} />
        <Route path="trainers/:id" element={<TrainerDetail />} />
        <Route path="attendance" element={<AttendanceManagement />} />
        <Route path="attendance/report" element={<AttendanceReport />} />
        <Route path="membership-plans" element={<MembershipPlans />} />
        <Route path="memberships" element={<MembershipManagement />} />
        <Route path="payments" element={<PaymentList />} />
        <Route path="payments/:id" element={<PaymentDetail />} />
        <Route path="qr-settings" element={<QRPaymentSettings />} />
        <Route path="quotations" element={<QuotationList />} />
        <Route path="quotations/new" element={<CreateQuotation />} />
        <Route path="invoices" element={<InvoiceList />} />
        <Route path="invoices/:id" element={<InvoiceDetail />} />
        <Route path="workouts" element={<WorkoutManagement />} />
        <Route path="diets" element={<DietManagement />} />
        <Route path="appointments" element={<AppointmentManagement />} />
        <Route path="salaries" element={<SalaryManagement />} />
        <Route path="expenses" element={<ExpenseManagement />} />
        <Route path="enquiries" element={<EnquiryManagement />} />
        <Route path="referrals" element={<ReferralManagement />} />
        <Route path="equipment" element={<EquipmentManagement />} />
        <Route path="notifications" element={<OwnerNotifications />} />
        <Route path="reports" element={<OwnerReports />} />
        <Route path="branches" element={<BranchManagement />} />
        <Route path="permissions" element={<PermissionManagement />} />
        <Route path="audit-logs" element={<OwnerAuditLogs />} />
        <Route path="subscription" element={<SubscriptionPage />} />
        <Route path="profile" element={<OwnerProfile />} />
        <Route path="settings" element={<OwnerSettings />} />
      </Route>

      {/* Trainer Portal */}
      <Route
        path="/trainer"
        element={
          <ProtectedRoute allowedRoles={[ROLES.TRAINER]}>
            <TrainerLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<TrainerDashboard />} />
        <Route path="customers" element={<MyCustomers />} />
        <Route path="attendance" element={<TrainerCustomerAttendance />} />
        <Route path="workouts" element={<TrainerWorkoutPlans />} />
        <Route path="workouts/new" element={<CreateWorkout />} />
        <Route path="diets" element={<TrainerDietPlans />} />
        <Route path="diets/new" element={<CreateDietPlan />} />
        <Route path="schedule" element={<TrainerSchedule />} />
        <Route path="notifications" element={<TrainerNotifications />} />
        <Route path="profile" element={<TrainerProfile />} />
      </Route>

      {/* Customer Portal (/customer/* and /app/*) */}
      <Route
        path="/customer"
        element={
          <ProtectedRoute allowedRoles={[ROLES.CUSTOMER]}>
            <CustomerLayout />
          </ProtectedRoute>
        }
      >
        {renderCustomerRoutes()}
      </Route>

      <Route
        path="/app"
        element={
          <ProtectedRoute allowedRoles={[ROLES.CUSTOMER]}>
            <CustomerLayout />
          </ProtectedRoute>
        }
      >
        {renderCustomerRoutes()}
      </Route>

      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}

export default App;

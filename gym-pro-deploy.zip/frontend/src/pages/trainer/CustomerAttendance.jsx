import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import dayjs from 'dayjs';
import { QrCode, CheckCircle2, CalendarCheck } from 'lucide-react';
import trainerService from '../../services/trainerService';
import attendanceService from '../../services/attendanceService';
import { useDebounce } from '../../hooks/useDebounce';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import {
  PageHeader,
  SearchInput,
  Card,
  Avatar,
  Badge,
  Button,
  Modal,
  QRScanner,
  Skeleton,
  EmptyState,
  ErrorState,
} from '../../components/ui';

export const CustomerAttendance = () => {
  const today = dayjs().format('YYYY-MM-DD');
  const [customers, setCustomers] = useState([]);
  const [todayLogs, setTodayLogs] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [qrOpen, setQrOpen] = useState(false);
  const [markingId, setMarkingId] = useState(null);

  const debouncedSearch = useDebounce(search, 300);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [cRes, aRes] = await Promise.all([
        trainerService.getAssignedCustomers({ search: debouncedSearch }),
        attendanceService.getAll({ date: today }),
      ]);
      setCustomers(extractList(cRes));
      setTodayLogs(extractList(aRes));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [debouncedSearch, today]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const checkedInSet = new Set(
    todayLogs.map((log) => String(log.customerId || log.customer?.id || log.customer?._id))
  );

  const handleMark = async (customer) => {
    const id = customer.id || customer._id;
    setMarkingId(id);
    try {
      await attendanceService.markAttendance({
        customerId: id,
        date: today,
        method: 'TRAINER',
        status: 'PRESENT',
      });
      toast.success(`${customer.name} checked in!`);
      loadData();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setMarkingId(null);
    }
  };

  const handleQrScan = async (code) => {
    try {
      await attendanceService.checkInByQr({ qrCode: code, date: today });
      toast.success('Member checked in via QR!');
      setQrOpen(false);
      loadData();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="Member Attendance"
        subtitle={`Today: ${dayjs().format('DD MMM YYYY')} • ${checkedInSet.size} checked in`}
        actions={
          <Button icon={QrCode} onClick={() => setQrOpen(true)}>
            Scan QR Pass
          </Button>
        }
      />

      <SearchInput
        placeholder="Search member to check in..."
        value={search}
        onChange={setSearch}
        className="sm:max-w-sm"
      />

      {loading ? (
        <Skeleton variant="list" rows={5} />
      ) : error ? (
        <ErrorState message={error} onRetry={loadData} />
      ) : customers.length === 0 ? (
        <Card>
          <EmptyState icon={CalendarCheck} title="No members found" />
        </Card>
      ) : (
        <div className="space-y-3">
          {customers.map((c) => {
            const id = String(c.id || c._id);
            const isPresent = checkedInSet.has(id);
            return (
              <div
                key={id}
                className="bg-dark-surface border border-dark-border rounded-xl p-4 flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <Avatar src={c.avatar} name={c.name} size="md" />
                  <div className="min-w-0">
                    <p className="font-semibold text-sm text-text-primary truncate">{c.name}</p>
                    <p className="text-xs text-text-secondary">{c.mobile || c.phone || ''}</p>
                  </div>
                </div>
                {isPresent ? (
                  <Badge status="present" dot>
                    Checked In
                  </Badge>
                ) : (
                  <Button
                    size="sm"
                    icon={CheckCircle2}
                    loading={markingId === id}
                    onClick={() => handleMark(c)}
                  >
                    Mark Present
                  </Button>
                )}
              </div>
            );
          })}
        </div>
      )}

      <Modal isOpen={qrOpen} onClose={() => setQrOpen(false)} title="Scan Member QR">
        <QRScanner onScan={handleQrScan} />
      </Modal>
    </div>
  );
};

export default CustomerAttendance;

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { PageHeader } from '../../components/ui';
import WorkoutBuilder from '../../components/shared/WorkoutBuilder';

export const CreateWorkout = () => {
  const navigate = useNavigate();

  return (
    <div className="space-y-6">
      <PageHeader
        title="Create Workout Plan"
        subtitle="Build a custom multi-day training schedule for a client"
        backTo="/trainer/workouts"
      />
      <WorkoutBuilder
        isTrainer
        onCancel={() => navigate('/trainer/workouts')}
        onSaved={() => navigate('/trainer/workouts')}
      />
    </div>
  );
};

export default CreateWorkout;

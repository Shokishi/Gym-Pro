import React from 'react';
import NotificationsCenter from '../../components/shared/NotificationsCenter';

export const TrainerNotifications = () => {
  return (
    <NotificationsCenter
      title="Trainer Notifications"
      subtitle="Session bookings, client updates, and gym announcements"
    />
  );
};

export default TrainerNotifications;

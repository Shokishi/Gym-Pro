import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Users, TrendingUp, Phone } from 'lucide-react';
import trainerService from '../../services/trainerService';
import progressService from '../../services/progressService';
import { useDebounce } from '../../hooks/useDebounce';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import {
  PageHeader,
  SearchInput,
  Card,
  Avatar,
  Badge,
  Button,
  Modal,
  Input,
  Skeleton,
  EmptyState,
  ErrorState,
} from '../../components/ui';

export const MyCustomers = () => {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [progressTarget, setProgressTarget] = useState(null);
  const [saving, setSaving] = useState(false);

  const [progressForm, setProgressForm] = useState({
    weight: '',
    bodyFat: '',
    muscleMass: '',
    notes: '',
  });

  const debouncedSearch = useDebounce(search, 300);

  const fetchCustomers = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await trainerService.getAssignedCustomers({ search: debouncedSearch });
      setCustomers(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [debouncedSearch]);

  useEffect(() => {
    fetchCustomers();
  }, [fetchCustomers]);

  const handleLogProgress = async (e) => {
    e.preventDefault();
    if (!progressTarget || !progressForm.weight) {
      toast.error('Weight is required');
      return;
    }
    setSaving(true);
    try {
      await progressService.create({
        customerId: progressTarget.id || progressTarget._id,
        weight: Number(progressForm.weight),
        bodyFat: progressForm.bodyFat ? Number(progressForm.bodyFat) : undefined,
        muscleMass: progressForm.muscleMass ? Number(progressForm.muscleMass) : undefined,
        notes: progressForm.notes,
      });
      toast.success('Progress measurement logged');
      setProgressTarget(null);
      setProgressForm({ weight: '', bodyFat: '', muscleMass: '', notes: '' });
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="My Assigned Customers"
        subtitle="View member goals, contact details, and log body progress metrics"
      />

      <SearchInput
        placeholder="Search client name or mobile..."
        value={search}
        onChange={setSearch}
        className="sm:max-w-sm"
      />

      {loading ? (
        <Skeleton variant="list" rows={5} />
      ) : error ? (
        <ErrorState message={error} onRetry={fetchCustomers} />
      ) : customers.length === 0 ? (
        <Card>
          <EmptyState
            icon={Users}
            title="No assigned clients"
            message="Customers assigned to you by the gym owner will appear here."
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {customers.map((c) => (
            <Card key={c.id || c._id}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <Avatar src={c.avatar} name={c.name} size="md" />
                  <div className="min-w-0">
                    <h3 className="font-bold text-text-primary truncate">{c.name}</h3>
                    <p className="text-xs text-text-secondary flex items-center gap-1 mt-0.5">
                      <Phone className="w-3 h-3" /> {c.mobile || c.phone || '—'}
                    </p>
                  </div>
                </div>
                <Badge status={c.status || 'ACTIVE'} dot />
              </div>

              <div className="mt-3 flex flex-wrap gap-2">
                {c.fitnessGoal && (
                  <Badge variant="accent">{String(c.fitnessGoal).replace(/_/g, ' ')}</Badge>
                )}
                {c.weightKg && <Badge variant="neutral">{c.weightKg} kg</Badge>}
              </div>

              <div className="mt-4 pt-3 border-t border-dark-border flex justify-end">
                <Button
                  size="xs"
                  variant="secondary"
                  icon={TrendingUp}
                  onClick={() => {
                    setProgressTarget(c);
                    setProgressForm({
                      weight: c.weightKg || '',
                      bodyFat: '',
                      muscleMass: '',
                      notes: '',
                    });
                  }}
                >
                  Log Progress
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal
        isOpen={Boolean(progressTarget)}
        onClose={() => setProgressTarget(null)}
        title="Log Client Progress"
        subtitle={progressTarget?.name}
        size="sm"
      >
        <form onSubmit={handleLogProgress} className="space-y-4">
          <Input
            label="Weight (kg)"
            type="number"
            step="0.1"
            required
            value={progressForm.weight}
            onChange={(e) => setProgressForm((p) => ({ ...p, weight: e.target.value }))}
          />
          <div className="grid grid-cols-2 gap-3">
            <Input
              label="Body Fat (%)"
              type="number"
              step="0.1"
              value={progressForm.bodyFat}
              onChange={(e) => setProgressForm((p) => ({ ...p, bodyFat: e.target.value }))}
            />
            <Input
              label="Muscle Mass (kg)"
              type="number"
              step="0.1"
              value={progressForm.muscleMass}
              onChange={(e) => setProgressForm((p) => ({ ...p, muscleMass: e.target.value }))}
            />
          </div>
          <Input
            label="Trainer Notes"
            placeholder="Strength gains, posture notes..."
            value={progressForm.notes}
            onChange={(e) => setProgressForm((p) => ({ ...p, notes: e.target.value }))}
          />
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setProgressTarget(null)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              Save Measurement
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default MyCustomers;

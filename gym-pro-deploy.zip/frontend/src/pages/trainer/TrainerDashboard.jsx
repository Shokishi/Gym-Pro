import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, CalendarClock, CalendarCheck, Flame, QrCode, Utensils } from 'lucide-react';
import trainerService from '../../services/trainerService';
import { useAuth } from '../../contexts/AuthContext';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { formatTime, formatNumber } from '../../utils/formatters';
import {
  PageHeader,
  Stat,
  Card,
  Badge,
  Button,
  Skeleton,
  ErrorState,
} from '../../components/ui';

export const TrainerDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await trainerService.getDashboard();
      setData(extractData(res, {}));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  const stats = data?.stats || data || {};
  const todaySessions = data?.todaySchedule || data?.appointments || [];
  const assignedCustomers = data?.customers || data?.recentCustomers || [];

  return (
    <div className="space-y-6">
      <PageHeader
        title={`Welcome, ${user?.name?.split(' ')[0] || 'Coach'}`}
        subtitle="Today's coaching sessions, assigned clients, and quick actions"
        actions={
          <div className="flex flex-wrap gap-2">
            <Button
              size="sm"
              variant="secondary"
              icon={QrCode}
              onClick={() => navigate('/trainer/attendance')}
            >
              Scan QR
            </Button>
            <Button size="sm" icon={Flame} onClick={() => navigate('/trainer/workouts/new')}>
              New Workout
            </Button>
          </div>
        }
      />

      {loading ? (
        <Skeleton variant="stats" count={3} />
      ) : error ? (
        <ErrorState message={error} onRetry={loadDashboard} />
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Stat
              label="Assigned Clients"
              value={formatNumber(stats.assignedCustomers ?? assignedCustomers.length ?? 0)}
              icon={Users}
              color="accent"
              onClick={() => navigate('/trainer/customers')}
            />
            <Stat
              label="Today's Sessions"
              value={formatNumber(stats.todaySessions ?? todaySessions.length ?? 0)}
              icon={CalendarClock}
              color="info"
              onClick={() => navigate('/trainer/schedule')}
            />
            <Stat
              label="Client Check-Ins Today"
              value={formatNumber(stats.todayCheckIns ?? 0)}
              icon={CalendarCheck}
              color="success"
              onClick={() => navigate('/trainer/attendance')}
            />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <button
              type="button"
              onClick={() => navigate('/trainer/attendance')}
              className="p-4 rounded-xl bg-dark-surface border border-dark-border hover:border-accent text-left transition-colors"
            >
              <QrCode className="w-5 h-5 text-accent mb-2" />
              <p className="text-sm font-semibold">Mark Attendance</p>
              <p className="text-xs text-text-secondary mt-0.5">QR scan or tap</p>
            </button>
            <button
              type="button"
              onClick={() => navigate('/trainer/workouts/new')}
              className="p-4 rounded-xl bg-dark-surface border border-dark-border hover:border-accent text-left transition-colors"
            >
              <Flame className="w-5 h-5 text-accent mb-2" />
              <p className="text-sm font-semibold">Build Workout</p>
              <p className="text-xs text-text-secondary mt-0.5">Custom training split</p>
            </button>
            <button
              type="button"
              onClick={() => navigate('/trainer/diets/new')}
              className="p-4 rounded-xl bg-dark-surface border border-dark-border hover:border-accent text-left transition-colors"
            >
              <Utensils className="w-5 h-5 text-success mb-2" />
              <p className="text-sm font-semibold">Build Diet Plan</p>
              <p className="text-xs text-text-secondary mt-0.5">Meals & macros</p>
            </button>
            <button
              type="button"
              onClick={() => navigate('/trainer/schedule')}
              className="p-4 rounded-xl bg-dark-surface border border-dark-border hover:border-accent text-left transition-colors"
            >
              <CalendarClock className="w-5 h-5 text-warning mb-2" />
              <p className="text-sm font-semibold">My Schedule</p>
              <p className="text-xs text-text-secondary mt-0.5">View upcoming slots</p>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card title="Today's Sessions" icon={CalendarClock}>
              {todaySessions.length === 0 ? (
                <p className="text-sm text-text-secondary py-6 text-center">
                  No coaching sessions scheduled for today.
                </p>
              ) : (
                <div className="space-y-3">
                  {todaySessions.map((s) => (
                    <div
                      key={s.id || s._id}
                      className="p-3.5 rounded-xl bg-dark-bg border border-dark-border flex items-center justify-between gap-3"
                    >
                      <div>
                        <p className="font-semibold text-sm">{s.title || 'PT Session'}</p>
                        <p className="text-xs text-text-secondary mt-0.5">
                          {s.customer?.name || s.customerName || 'Group'} •{' '}
                          <span className="text-accent">{formatTime(s.time || s.scheduledAt)}</span>
                        </p>
                      </div>
                      <Badge status={s.status || 'SCHEDULED'} />
                    </div>
                  ))}
                </div>
              )}
            </Card>

            <Card title="Assigned Clients" icon={Users}>
              {assignedCustomers.length === 0 ? (
                <p className="text-sm text-text-secondary py-6 text-center">
                  No clients assigned yet.
                </p>
              ) : (
                <div className="space-y-3">
                  {assignedCustomers.slice(0, 5).map((c) => (
                    <div
                      key={c.id || c._id}
                      className="p-3.5 rounded-xl bg-dark-bg border border-dark-border flex items-center justify-between gap-3"
                    >
                      <div>
                        <p className="font-semibold text-sm">{c.name}</p>
                        <p className="text-xs text-text-secondary">
                          {c.fitnessGoal?.replace(/_/g, ' ') || 'General Fitness'}
                        </p>
                      </div>
                      <Badge status={c.status || 'ACTIVE'} dot />
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>
        </>
      )}
    </div>
  );
};

export default TrainerDashboard;

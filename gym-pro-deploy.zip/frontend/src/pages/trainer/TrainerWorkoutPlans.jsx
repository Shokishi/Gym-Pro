import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Plus, Edit2, Trash2, Dumbbell } from 'lucide-react';
import workoutService from '../../services/workoutService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import WorkoutBuilder from '../../components/shared/WorkoutBuilder';
import {
  PageHeader,
  Card,
  SearchInput,
  Badge,
  Button,
  Modal,
  ConfirmDialog,
  Skeleton,
  EmptyState,
  ErrorState,
} from '../../components/ui';

export const TrainerWorkoutPlans = () => {
  const navigate = useNavigate();
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [editTarget, setEditTarget] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const fetchPlans = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await workoutService.getAll({ search });
      setPlans(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [search]);

  useEffect(() => {
    fetchPlans();
  }, [fetchPlans]);

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await workoutService.delete(deleteTarget.id || deleteTarget._id);
      toast.success('Workout plan deleted');
      setDeleteTarget(null);
      fetchPlans();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="Workout Plans"
        subtitle="Design and manage workout programs for your assigned clients"
        actions={
          <Button icon={Plus} onClick={() => navigate('/trainer/workouts/new')}>
            Create Plan
          </Button>
        }
      />

      <SearchInput
        placeholder="Search workout plans..."
        value={search}
        onChange={setSearch}
        className="sm:max-w-sm"
      />

      {loading ? (
        <Skeleton variant="list" rows={4} />
      ) : error ? (
        <ErrorState message={error} onRetry={fetchPlans} />
      ) : plans.length === 0 ? (
        <Card>
          <EmptyState
            icon={Dumbbell}
            title="No workout plans yet"
            action={
              <Button icon={Plus} onClick={() => navigate('/trainer/workouts/new')}>
                Create Workout Plan
              </Button>
            }
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {plans.map((plan) => (
            <Card key={plan.id || plan._id}>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="font-bold text-text-primary">{plan.name || plan.title}</h3>
                  <p className="text-xs text-text-secondary mt-0.5">
                    {plan.durationWeeks || 4} weeks • {plan.exercises?.length || 0} exercises
                  </p>
                </div>
                <Badge variant="accent">{plan.difficulty || 'INTERMEDIATE'}</Badge>
              </div>
              {plan.customer?.name && (
                <p className="text-xs text-success mt-2">Client: {plan.customer.name}</p>
              )}
              <div className="mt-4 pt-3 border-t border-dark-border flex justify-end gap-2">
                <Button
                  size="xs"
                  variant="secondary"
                  icon={Edit2}
                  onClick={() => setEditTarget(plan)}
                >
                  Edit
                </Button>
                <Button size="xs" variant="danger" icon={Trash2} onClick={() => setDeleteTarget(plan)} />
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal
        isOpen={Boolean(editTarget)}
        onClose={() => setEditTarget(null)}
        title="Edit Workout Plan"
        size="xl"
      >
        {editTarget && (
          <WorkoutBuilder
            isTrainer
            initialPlan={editTarget}
            onCancel={() => setEditTarget(null)}
            onSaved={() => {
              setEditTarget(null);
              fetchPlans();
            }}
          />
        )}
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Workout Plan"
        message={`Delete "${deleteTarget?.name || deleteTarget?.title}"?`}
        confirmLabel="Delete"
      />
    </div>
  );
};

export default TrainerWorkoutPlans;

import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import dayjs from 'dayjs';
import { CalendarClock, CheckCircle2, XCircle, Plus } from 'lucide-react';
import trainerService from '../../services/trainerService';
import appointmentService from '../../services/appointmentService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatDate, formatTime } from '../../utils/formatters';
import {
  PageHeader,
  Card,
  Badge,
  Button,
  DatePicker,
  Modal,
  Input,
  Select,
  Skeleton,
  EmptyState,
  ErrorState,
} from '../../components/ui';

export const TrainerSchedule = () => {
  const [dateFilter, setDateFilter] = useState(dayjs().format('YYYY-MM-DD'));
  const [sessions, setSessions] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    title: 'Personal Training Session',
    customerId: '',
    date: dayjs().format('YYYY-MM-DD'),
    time: '07:00',
  });

  const loadSchedule = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await trainerService.getSchedule({ date: dateFilter });
      setSessions(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [dateFilter]);

  useEffect(() => {
    loadSchedule();
    trainerService
      .getAssignedCustomers()
      .then((res) => setCustomers(extractList(res)))
      .catch(() => {});
  }, [loadSchedule]);

  const handleStatus = async (session, status) => {
    try {
      await appointmentService.updateStatus(session.id || session._id, status);
      toast.success(`Session marked ${status.toLowerCase()}`);
      loadSchedule();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await appointmentService.create({ ...form, type: 'PT_SESSION' });
      toast.success('Session added to schedule');
      setModalOpen(false);
      loadSchedule();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="My Schedule"
        subtitle="Manage your personal training appointments and group fitness slots"
        actions={
          <Button icon={Plus} onClick={() => setModalOpen(true)}>
            Add Session
          </Button>
        }
      />

      <div className="flex items-center gap-3">
        <DatePicker
          value={dateFilter}
          onChange={(e) => setDateFilter(e.target.value)}
          containerClassName="sm:w-48"
        />
        <Button variant="secondary" size="sm" onClick={() => setDateFilter('')}>
          Show All
        </Button>
      </div>

      {loading ? (
        <Skeleton variant="list" rows={4} />
      ) : error ? (
        <ErrorState message={error} onRetry={loadSchedule} />
      ) : sessions.length === 0 ? (
        <Card>
          <EmptyState
            icon={CalendarClock}
            title="No sessions scheduled"
            message="No personal training or group sessions found for this date."
          />
        </Card>
      ) : (
        <div className="space-y-3">
          {sessions.map((s) => (
            <div
              key={s.id || s._id}
              className="bg-dark-surface border border-dark-border rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-text-primary">{s.title || 'PT Session'}</h3>
                  <Badge status={s.status || 'SCHEDULED'} dot />
                </div>
                <p className="text-xs text-text-secondary mt-1">
                  Client: <span className="text-text-primary">{s.customer?.name || 'Group'}</span> •{' '}
                  {formatDate(s.date || s.scheduledAt)} at{' '}
                  <span className="text-accent font-semibold">{formatTime(s.time || s.scheduledAt)}</span>
                </p>
              </div>
              {String(s.status).toUpperCase() === 'SCHEDULED' && (
                <div className="flex items-center gap-2">
                  <Button
                    size="xs"
                    variant="success"
                    icon={CheckCircle2}
                    onClick={() => handleStatus(s, 'COMPLETED')}
                  >
                    Complete
                  </Button>
                  <Button
                    size="xs"
                    variant="danger"
                    icon={XCircle}
                    onClick={() => handleStatus(s, 'CANCELLED')}
                  >
                    Cancel
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Schedule Training Session">
        <form onSubmit={handleCreate} className="space-y-4">
          <Input
            label="Session Title"
            required
            value={form.title}
            onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))}
          />
          <Select
            label="Client"
            value={form.customerId}
            options={customers.map((c) => ({ value: c.id || c._id, label: c.name }))}
            onChange={(e) => setForm((p) => ({ ...p, customerId: e.target.value }))}
          />
          <div className="grid grid-cols-2 gap-3">
            <Input
              label="Date"
              type="date"
              required
              value={form.date}
              onChange={(e) => setForm((p) => ({ ...p, date: e.target.value }))}
            />
            <Input
              label="Time"
              type="time"
              required
              value={form.time}
              onChange={(e) => setForm((p) => ({ ...p, time: e.target.value }))}
            />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              Schedule
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default TrainerSchedule;

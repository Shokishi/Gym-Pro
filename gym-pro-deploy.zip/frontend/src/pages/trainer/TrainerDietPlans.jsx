import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Plus, Edit2, Trash2, Utensils } from 'lucide-react';
import dietService from '../../services/dietService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import DietBuilder from '../../components/shared/DietBuilder';
import {
  PageHeader,
  Card,
  SearchInput,
  Badge,
  Button,
  Modal,
  ConfirmDialog,
  Skeleton,
  EmptyState,
  ErrorState,
} from '../../components/ui';

export const TrainerDietPlans = () => {
  const navigate = useNavigate();
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [editTarget, setEditTarget] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const fetchPlans = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await dietService.getAll({ search });
      setPlans(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [search]);

  useEffect(() => {
    fetchPlans();
  }, [fetchPlans]);

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await dietService.delete(deleteTarget.id || deleteTarget._id);
      toast.success('Diet plan deleted');
      setDeleteTarget(null);
      fetchPlans();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="Diet & Nutrition Plans"
        subtitle="Create customized meal plans with calorie and macro breakdowns"
        actions={
          <Button icon={Plus} onClick={() => navigate('/trainer/diets/new')}>
            Create Diet Plan
          </Button>
        }
      />

      <SearchInput
        placeholder="Search diet plans..."
        value={search}
        onChange={setSearch}
        className="sm:max-w-sm"
      />

      {loading ? (
        <Skeleton variant="list" rows={4} />
      ) : error ? (
        <ErrorState message={error} onRetry={fetchPlans} />
      ) : plans.length === 0 ? (
        <Card>
          <EmptyState
            icon={Utensils}
            title="No diet plans yet"
            action={
              <Button icon={Plus} onClick={() => navigate('/trainer/diets/new')}>
                Create Diet Plan
              </Button>
            }
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {plans.map((plan) => (
            <Card key={plan.id || plan._id}>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="font-bold text-text-primary">{plan.name || plan.title}</h3>
                  <p className="text-xs text-accent font-semibold mt-0.5">
                    {plan.totalCalories || 0} kcal • {plan.meals?.length || 0} meals
                  </p>
                </div>
                <Badge variant="success">{plan.dietType || 'BALANCED'}</Badge>
              </div>
              <p className="text-xs text-text-secondary mt-2">
                Protein: {plan.totalProtein || 0}g • Carbs: {plan.totalCarbs || 0}g • Fats:{' '}
                {plan.totalFats || 0}g
              </p>
              {plan.customer?.name && (
                <p className="text-xs text-success mt-2">Client: {plan.customer.name}</p>
              )}
              <div className="mt-4 pt-3 border-t border-dark-border flex justify-end gap-2">
                <Button
                  size="xs"
                  variant="secondary"
                  icon={Edit2}
                  onClick={() => setEditTarget(plan)}
                >
                  Edit
                </Button>
                <Button size="xs" variant="danger" icon={Trash2} onClick={() => setDeleteTarget(plan)} />
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal
        isOpen={Boolean(editTarget)}
        onClose={() => setEditTarget(null)}
        title="Edit Diet Plan"
        size="xl"
      >
        {editTarget && (
          <DietBuilder
            initialPlan={editTarget}
            onCancel={() => setEditTarget(null)}
            onSaved={() => {
              setEditTarget(null);
              fetchPlans();
            }}
          />
        )}
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Diet Plan"
        message={`Delete "${deleteTarget?.name || deleteTarget?.title}"?`}
        confirmLabel="Delete"
      />
    </div>
  );
};

export default TrainerDietPlans;

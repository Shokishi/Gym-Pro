import React from 'react';
import { useNavigate } from 'react-router-dom';
import { PageHeader } from '../../components/ui';
import DietBuilder from '../../components/shared/DietBuilder';

export const CreateDietPlan = () => {
  const navigate = useNavigate();

  return (
    <div className="space-y-6">
      <PageHeader
        title="Create Diet Plan"
        subtitle="Design daily meals and macronutrient goals for a client"
        backTo="/trainer/diets"
      />
      <DietBuilder
        onCancel={() => navigate('/trainer/diets')}
        onSaved={() => navigate('/trainer/diets')}
      />
    </div>
  );
};

export default CreateDietPlan;

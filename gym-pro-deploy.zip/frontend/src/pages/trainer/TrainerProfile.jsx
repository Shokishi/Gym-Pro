import React from 'react';
import ProfileManager from '../../components/shared/ProfileManager';

export const TrainerProfile = () => {
  return (
    <ProfileManager
      title="Trainer Profile"
      subtitle="Update your coaching profile, contact info, and password"
    />
  );
};

export default TrainerProfile;

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Dumbbell, Phone, ArrowLeft, Send } from 'lucide-react';
import authService from '../../services/authService';
import { validateForm } from '../../utils/validators';
import { getErrorMessage } from '../../utils/apiHelpers';
import { Input, Button } from '../../components/ui';

export const ForgotPasswordPage = () => {
  const [mobile, setMobile] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { isValid, errors } = validateForm(
      { mobile },
      { mobile: { required: true, label: 'Mobile Number', mobile: true } }
    );
    if (!isValid) {
      setError(errors.mobile);
      return;
    }

    setSubmitting(true);
    try {
      await authService.forgotPassword({ mobile: mobile.trim() });
      toast.success('OTP sent to your registered mobile number');
      navigate('/verify-otp', {
        state: { mobile: mobile.trim(), purpose: 'RESET_PASSWORD' },
      });
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark-bg flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center">
          <Link to="/" className="inline-flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-accent flex items-center justify-center text-dark-bg">
              <Dumbbell className="w-5 h-5" />
            </div>
            <span className="text-xl font-extrabold text-text-primary">
              GYM <span className="text-accent">PRO</span>
            </span>
          </Link>
          <h1 className="text-2xl font-bold text-text-primary mt-4">Reset Password</h1>
          <p className="text-sm text-text-secondary mt-1">
            Enter your registered mobile number to receive a 6-digit OTP
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-dark-surface border border-dark-border rounded-2xl p-6 shadow-2xl space-y-5"
        >
          <Input
            label="Registered Mobile Number"
            icon={Phone}
            type="tel"
            required
            placeholder="Enter 10-digit mobile number"
            value={mobile}
            error={error}
            onChange={(e) => {
              setMobile(e.target.value);
              setError('');
            }}
          />

          <Button type="submit" fullWidth size="lg" loading={submitting} icon={Send}>
            Send Verification OTP
          </Button>

          <Link
            to="/login"
            className="flex items-center justify-center gap-1.5 text-xs text-text-secondary hover:text-accent pt-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Sign In
          </Link>
        </form>
      </div>
    </div>
  );
};

export default ForgotPasswordPage;

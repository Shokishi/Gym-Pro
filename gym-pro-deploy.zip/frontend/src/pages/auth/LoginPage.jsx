import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Dumbbell, Phone, Mail, Lock, LogIn, Building2, UserCheck, Users, Shield, KeyRound } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { ROLES, PORTAL_HOME, normalizeRole } from '../../utils/constants';
import { validateForm } from '../../utils/validators';
import { getErrorMessage } from '../../utils/apiHelpers';
import { Input, Button } from '../../components/ui';
import authService from '../../services/authService';

const ROLE_TABS = [
  { key: ROLES.OWNER, label: 'Owner', icon: Building2 },
  { key: ROLES.TRAINER, label: 'Trainer', icon: UserCheck },
  { key: ROLES.CUSTOMER, label: 'Customer', icon: Users },
  { key: ROLES.ADMIN, label: 'Admin', icon: Shield },
];

export const LoginPage = () => {
  const [searchParams] = useSearchParams();
  const initialRole = normalizeRole(searchParams.get('role')) || ROLES.OWNER;

  const [selectedRole, setSelectedRole] = useState(initialRole);
  const [form, setForm] = useState({
    mobile: '',
    email: '',
    password: '',
  });
  const [loginMethod, setLoginMethod] = useState('PASSWORD'); // 'PASSWORD' or 'OTP'
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const { login, isAuthenticated, role } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (isAuthenticated && role) {
      navigate(PORTAL_HOME[role] || '/owner/dashboard', { replace: true });
    }
  }, [isAuthenticated, role, navigate]);

  const isAdmin = selectedRole === ROLES.ADMIN;

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (isAdmin) {
      const { isValid, errors: vErrors } = validateForm(
        { email: form.email, password: form.password },
        {
          email: { required: true, label: 'Admin Email', email: true },
          password: { required: true, label: 'Password', minLength: 6 },
        }
      );
      if (!isValid) {
        setErrors(vErrors);
        return;
      }
    } else if (selectedRole === ROLES.CUSTOMER && loginMethod === 'OTP') {
      const { isValid, errors: vErrors } = validateForm(
        { mobile: form.mobile },
        {
          mobile: { required: true, label: 'Mobile Number', mobile: true },
        }
      );
      if (!isValid) {
        setErrors(vErrors);
        return;
      }
    } else {
      const { isValid, errors: vErrors } = validateForm(form, {
        mobile: { required: true, label: 'Mobile Number', mobile: true },
        password: { required: true, label: 'Password', minLength: 6 },
      });
      if (!isValid) {
        setErrors(vErrors);
        return;
      }
    }

    setSubmitting(true);
    try {
      if (selectedRole === ROLES.CUSTOMER && loginMethod === 'OTP') {
        const res = await authService.sendOtp({ mobile: form.mobile.trim(), purpose: 'LOGIN' });
        toast.success('Login OTP sent successfully');
        navigate('/verify-otp', {
          state: {
            mobile: form.mobile.trim(),
            purpose: 'LOGIN',
            redirectTo: '/customer/home',
            devOtp: res?.data?.devOtp,
          },
        });
        return;
      }

      const payload = isAdmin
        ? { email: form.email.trim(), password: form.password, role: ROLES.ADMIN }
        : { mobile: form.mobile.trim(), password: form.password, role: selectedRole };

      const result = await login(payload);

      if (result?.requireOtp) {
        toast.success('Verification required to continue');
        navigate('/verify-otp', {
          state: {
            mobile: result.mobile,
            purpose: result.purpose || 'LOGIN',
            redirectTo: PORTAL_HOME[selectedRole] || '/owner/dashboard',
            devOtp: result.devOtp,
          },
        });
        return;
      }

      toast.success('Welcome back to GYM PRO!');
      navigate(result.redirectTo, { replace: true });
    } catch (err) {
      toast.error(getErrorMessage(err, 'Invalid credentials'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark-bg flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center">
          <Link to="/" className="inline-flex items-center gap-2.5">
            <div className="w-11 h-11 rounded-2xl bg-accent flex items-center justify-center text-dark-bg shadow-lg shadow-accent/25">
              <Dumbbell className="w-6 h-6" />
            </div>
            <span className="text-2xl font-extrabold text-text-primary tracking-tight">
              GYM <span className="text-accent">PRO</span>
            </span>
          </Link>
          <h1 className="text-xl font-bold text-text-primary mt-5">Sign in to your portal</h1>
          <p className="text-sm text-text-secondary mt-1">
            Select your account role and enter your credentials
          </p>
        </div>

        <div className="bg-dark-surface border border-dark-border rounded-2xl p-6 shadow-2xl space-y-5">
          {/* Role Tabs */}
          <div className="grid grid-cols-4 gap-1.5 p-1 bg-dark-bg border border-dark-border rounded-xl">
            {ROLE_TABS.map((tab) => {
              const Icon = tab.icon;
              const active = selectedRole === tab.key;
              return (
                <button
                  key={tab.key}
                  type="button"
                  onClick={() => {
                    setSelectedRole(tab.key);
                    setErrors({});
                  }}
                  className={`flex flex-col items-center justify-center gap-1 py-2 px-1 rounded-lg text-xs font-medium transition-all ${
                    active
                      ? 'bg-accent text-dark-bg font-semibold shadow-sm'
                      : 'text-text-secondary hover:text-text-primary'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {selectedRole === ROLES.CUSTOMER && (
            <div className="flex bg-dark-bg p-1 rounded-lg border border-dark-border">
              <button
                type="button"
                onClick={() => setLoginMethod('PASSWORD')}
                className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-all ${
                  loginMethod === 'PASSWORD' ? 'bg-dark-surface text-accent shadow-sm' : 'text-text-secondary'
                }`}
              >
                Password Login
              </button>
              <button
                type="button"
                onClick={() => setLoginMethod('OTP')}
                className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-all ${
                  loginMethod === 'OTP' ? 'bg-dark-surface text-accent shadow-sm' : 'text-text-secondary'
                }`}
              >
                OTP Login
              </button>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {isAdmin ? (
              <Input
                label="Super Admin Email"
                name="email"
                type="email"
                icon={Mail}
                required
                placeholder="admin@gympro.com"
                value={form.email}
                error={errors.email}
                onChange={(e) => {
                  setForm((p) => ({ ...p, email: e.target.value }));
                  setErrors((p) => ({ ...p, email: '' }));
                }}
              />
            ) : (
              <Input
                label="Mobile Number"
                name="mobile"
                type="tel"
                icon={Phone}
                required
                placeholder="Enter 10-digit mobile number"
                value={form.mobile}
                error={errors.mobile}
                onChange={(e) => {
                  setForm((p) => ({ ...p, mobile: e.target.value }));
                  setErrors((p) => ({ ...p, mobile: '' }));
                }}
              />
            )}

            {!(selectedRole === ROLES.CUSTOMER && loginMethod === 'OTP') && (
              <Input
                label="Password"
                name="password"
                type="password"
                icon={Lock}
                required
                placeholder="Enter your password"
                value={form.password}
                error={errors.password}
                onChange={(e) => {
                  setForm((p) => ({ ...p, password: e.target.value }));
                  setErrors((p) => ({ ...p, password: '' }));
                }}
              />
            )}

            <div className="flex items-center justify-between text-xs">
              <span className="text-text-secondary">
                Logging in as <span className="text-accent font-semibold">{selectedRole}</span>
              </span>
              {!(selectedRole === ROLES.CUSTOMER && loginMethod === 'OTP') && (
                <Link to="/forgot-password" className="text-accent hover:underline font-medium">
                  Forgot Password?
                </Link>
              )}
            </div>

            <Button
              type="submit"
              fullWidth
              size="lg"
              loading={submitting}
              icon={selectedRole === ROLES.CUSTOMER && loginMethod === 'OTP' ? KeyRound : LogIn}
            >
              {selectedRole === ROLES.CUSTOMER && loginMethod === 'OTP' ? 'Send Login OTP' : 'Sign In'}
            </Button>
          </form>

          <div className="pt-4 border-t border-dark-border text-center space-y-2 text-xs text-text-secondary">
            {selectedRole === ROLES.OWNER && (
              <p>
                Own a gym?{' '}
                <Link to="/register" className="text-accent hover:underline font-semibold">
                  Register your gym (7-day free trial)
                </Link>
              </p>
            )}
            {selectedRole === ROLES.TRAINER && (
              <p>
                Have a trainer invite?{' '}
                <Link to="/register/trainer" className="text-accent hover:underline font-semibold">
                  Create Trainer Account
                </Link>
              </p>
            )}
            {selectedRole === ROLES.CUSTOMER && (
              <p>
                New member?{' '}
                <Link to="/register/customer" className="text-accent hover:underline font-semibold">
                  Register as Customer
                </Link>
              </p>
            )}
            {selectedRole === ROLES.ADMIN && (
              <p className="text-text-secondary/80">
                Restricted Super Admin access for GYM PRO platform operators.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Dumbbell,
  ArrowRight,
  CheckCircle2,
  QrCode,
  BarChart3,
  Users,
  ShieldCheck,
  Smartphone,
  CreditCard,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { PORTAL_HOME } from '../../utils/constants';
import Button from '../../components/ui/Button';
import authService from '../../services/authService';
import { extractData } from '../../utils/apiHelpers';

const FEATURES = [
  {
    icon: Users,
    title: 'Member & Trainer Portals',
    desc: 'Dedicated dashboards for Gym Owners, Trainers, Customers, and Super Admins.',
  },
  {
    icon: QrCode,
    title: 'QR Attendance & UPI Payments',
    desc: 'Instant contactless check-ins with camera QR scanner and direct UPI payment verification.',
  },
  {
    icon: BarChart3,
    title: 'Financials, GST Invoices & Payroll',
    desc: 'Automated PDF invoices, quotations, trainer salaries, and branch-wise expense tracking.',
  },
  {
    icon: Smartphone,
    title: 'Mobile-First Member App',
    desc: 'Members track daily workouts, diet macros, fitness progress charts, and book classes.',
  },
];

const DEFAULT_PLANS = [
  {
    name: 'Starter',
    price: '₹999',
    period: '/month',
    desc: 'For single-branch fitness studios',
    features: ['Up to 100 Active Members', 'Up to 5 Trainers', '1 Gym Branch', 'QR Attendance & UPI Settings', 'GST Invoices & Reports'],
  },
  {
    name: 'Professional',
    price: '₹1,999',
    period: '/month',
    popular: true,
    desc: 'Most popular for growing fitness centers',
    features: ['Up to 500 Active Members', 'Up to 20 Trainers', 'Up to 3 Branches', 'Workout & Diet Plan Builder', 'Staff Payroll & Expenses', 'PDF Invoices & Quotations'],
  },
  {
    name: 'Premium',
    price: '₹3,999',
    period: '/month',
    desc: 'Enterprise scale for gym chains',
    features: ['Up to 5,000 Active Members', 'Up to 100 Trainers', 'Up to 25 Branches', 'Custom Domain & SSL', 'P&L Reports & Real-Time Sync', 'Priority 24/7 Support'],
  },
];

export const LandingPage = () => {
  const { isAuthenticated, role } = useAuth();
  const navigate = useNavigate();
  const [plans, setPlans] = useState(DEFAULT_PLANS);

  useEffect(() => {
    authService.getPublicPlans()
      .then((res) => {
        const data = extractData(res);
        if (Array.isArray(data) && data.length > 0) {
          setPlans(
            data.map((p) => ({
              name: p.name,
              price: `₹${(p.monthlyPrice || 999).toLocaleString('en-IN')}`,
              period: '/month',
              popular: Boolean(p.isPopular),
              desc: p.description || 'Complete Gym Management',
              features: Array.isArray(p.features) ? p.features : JSON.parse(p.features || '[]'),
            }))
          );
        }
      })
      .catch(() => {});
  }, []);

  return (
    <div className="min-h-screen bg-dark-bg text-text-primary flex flex-col">
      {/* Navbar */}
      <header className="border-b border-dark-border bg-dark-surface/80 backdrop-blur sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-accent flex items-center justify-center text-dark-bg shadow-lg shadow-accent/20">
              <Dumbbell className="w-5 h-5" />
            </div>
            <span className="text-lg font-extrabold tracking-tight">
              GYM <span className="text-accent">PRO</span>
            </span>
          </Link>

          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <Button
                rightIcon={ArrowRight}
                onClick={() => navigate(PORTAL_HOME[role] || '/owner/dashboard')}
              >
                Go to Dashboard
              </Button>
            ) : (
              <>
                <Link to="/login">
                  <Button variant="ghost" size="sm">
                    Sign In
                  </Button>
                </Link>
                <Link to="/register">
                  <Button size="sm" rightIcon={ArrowRight}>
                    Start Free Trial
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16 sm:py-24 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        <div className="lg:col-span-7 space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent-light border border-accent/30 text-accent text-xs font-semibold">
            <ShieldCheck className="w-4 h-4" />
            All-in-One Gym Management SaaS Platform
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.1]">
            Run Your Entire Gym Empire From <span className="text-accent">One Platform</span>
          </h1>
          <p className="text-base sm:text-lg text-text-secondary max-w-2xl leading-relaxed">
            Automate memberships, QR attendance, trainer workouts, nutrition tracking, GST invoicing,
            UPI payment verification, and multi-branch analytics with dedicated portals for Owners,
            Trainers, Customers, and Super Admins.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <Link to="/register">
              <Button size="lg" rightIcon={ArrowRight}>
                Launch Your Gym Free
              </Button>
            </Link>
            <Link to="/login">
              <Button size="lg" variant="secondary">
                Portal Sign In
              </Button>
            </Link>
          </div>

          <div className="flex flex-wrap items-center gap-6 pt-4 text-xs text-text-secondary">
            <span className="inline-flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-success" /> 7-Day Free Trial
            </span>
            <span className="inline-flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-success" /> No Credit Card Needed
            </span>
            <span className="inline-flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-success" /> 4 Role Portals Included
            </span>
          </div>
        </div>

        {/* Quick Portal Access Card */}
        <div className="lg:col-span-5">
          <div className="bg-dark-surface border border-dark-border rounded-2xl p-6 sm:p-8 shadow-2xl space-y-5">
            <div>
              <h2 className="text-xl font-bold text-text-primary">Quick Portal Access</h2>
              <p className="text-sm text-text-secondary mt-1">
                Sign in or register directly for your role
              </p>
            </div>

            <div className="grid grid-cols-1 gap-3">
              <Link
                to="/login?role=OWNER"
                className="p-4 rounded-xl bg-dark-bg border border-dark-border hover:border-accent transition-colors flex items-center justify-between group"
              >
                <div>
                  <p className="text-sm font-semibold text-text-primary group-hover:text-accent">
                    Gym Owner Portal
                  </p>
                  <p className="text-xs text-text-secondary mt-0.5">
                    Manage members, staff, billing & branches
                  </p>
                </div>
                <ArrowRight className="w-4 h-4 text-text-secondary group-hover:text-accent" />
              </Link>

              <Link
                to="/login?role=TRAINER"
                className="p-4 rounded-xl bg-dark-bg border border-dark-border hover:border-accent transition-colors flex items-center justify-between group"
              >
                <div>
                  <p className="text-sm font-semibold text-text-primary group-hover:text-accent">
                    Trainer Workspace
                  </p>
                  <p className="text-xs text-text-secondary mt-0.5">
                    Workouts, diet plans, schedules & check-ins
                  </p>
                </div>
                <ArrowRight className="w-4 h-4 text-text-secondary group-hover:text-accent" />
              </Link>

              <Link
                to="/login?role=CUSTOMER"
                className="p-4 rounded-xl bg-dark-bg border border-dark-border hover:border-accent transition-colors flex items-center justify-between group"
              >
                <div>
                  <p className="text-sm font-semibold text-text-primary group-hover:text-accent">
                    Member App
                  </p>
                  <p className="text-xs text-text-secondary mt-0.5">
                    QR pass, daily workouts, diet & renewals
                  </p>
                </div>
                <ArrowRight className="w-4 h-4 text-text-secondary group-hover:text-accent" />
              </Link>

              <Link
                to="/login?role=ADMIN"
                className="p-4 rounded-xl bg-dark-bg border border-dark-border hover:border-accent transition-colors flex items-center justify-between group"
              >
                <div>
                  <p className="text-sm font-semibold text-text-primary group-hover:text-accent">
                    Super Admin Console
                  </p>
                  <p className="text-xs text-text-secondary mt-0.5">
                    SaaS subscriptions, tenants & platform analytics
                  </p>
                </div>
                <ArrowRight className="w-4 h-4 text-text-secondary group-hover:text-accent" />
              </Link>
            </div>

            <div className="pt-2 border-t border-dark-border flex flex-wrap items-center justify-between gap-2 text-xs text-text-secondary">
              <Link to="/register/trainer" className="hover:text-accent">
                Trainer Invite Sign Up
              </Link>
              <Link to="/register/customer" className="hover:text-accent">
                New Member Sign Up
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="border-t border-dark-border bg-dark-surface/40 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold">Built for Modern Fitness Businesses</h2>
            <p className="text-sm text-text-secondary mt-2">
              Every tool you need to retain members, empower trainers, and scale profitably.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {FEATURES.map((f) => {
              const Icon = f.icon;
              return (
                <div
                  key={f.title}
                  className="bg-dark-surface border border-dark-border rounded-xl p-6 space-y-3"
                >
                  <div className="w-11 h-11 rounded-xl bg-accent-light text-accent flex items-center justify-center">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-semibold text-text-primary">{f.title}</h3>
                  <p className="text-sm text-text-secondary leading-relaxed">{f.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 w-full">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold">Transparent SaaS Pricing</h2>
          <p className="text-sm text-text-secondary mt-2">
            Start with a 7-day free trial with all Premium features unlocked. Upgrade anytime as your gym grows.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`rounded-2xl p-6 border flex flex-col justify-between ${
                plan.popular
                  ? 'bg-dark-surface-2 border-accent shadow-xl shadow-accent/10'
                  : 'bg-dark-surface border-dark-border'
              }`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold">{plan.name}</h3>
                  {plan.popular && (
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-accent text-dark-bg">
                      Popular
                    </span>
                  )}
                </div>
                <p className="text-xs text-text-secondary mt-1">{plan.desc}</p>
                <div className="mt-5 flex items-baseline gap-1">
                  <span className="text-3xl font-extrabold text-text-primary">{plan.price}</span>
                  <span className="text-sm text-text-secondary">{plan.period}</span>
                </div>
                <ul className="mt-6 space-y-2.5 text-sm text-text-secondary">
                  {plan.features.map((feat) => (
                    <li key={feat} className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-success shrink-0" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <Link to="/register" className="mt-6 block">
                <Button fullWidth variant={plan.popular ? 'primary' : 'secondary'} icon={CreditCard}>
                  Choose {plan.name}
                </Button>
              </Link>
            </div>
          ))}
        </div>
      </section>

      <footer className="mt-auto border-t border-dark-border py-6 text-center text-xs text-text-secondary">
        © {new Date().getFullYear()} GYM PRO SaaS Platform. All rights reserved.
      </footer>
    </div>
  );
};

export default LandingPage;

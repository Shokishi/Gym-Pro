import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Dumbbell, KeyRound, User, Phone, Mail, Lock, Award, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import authService from '../../services/authService';
import { validateForm } from '../../utils/validators';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { Input, Select, Button } from '../../components/ui';

export const TrainerRegisterPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { registerTrainer } = useAuth();

  const [form, setForm] = useState({
    inviteCode: searchParams.get('invite') || '',
    name: '',
    mobile: '',
    email: '',
    specialization: 'Strength & Conditioning',
    experienceYears: '2',
    password: '',
    confirmPassword: '',
  });
  const [errors, setErrors] = useState({});
  const [gymPreview, setGymPreview] = useState(null);
  const [checkingInvite, setCheckingInvite] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const verifyInviteCode = async () => {
    if (!form.inviteCode.trim()) return;
    setCheckingInvite(true);
    try {
      const res = await authService.validateInvite(form.inviteCode.trim());
      const data = extractData(res);
      setGymPreview(data);
      toast.success(`Invite valid for ${data?.gymName || 'Gym'}`);
    } catch (err) {
      setGymPreview(null);
      toast.error(getErrorMessage(err, 'Invalid or expired invite code'));
    } finally {
      setCheckingInvite(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      inviteCode: { required: true, label: 'Gym Invitation Code' },
      name: { required: true, label: 'Full Name', minLength: 2 },
      mobile: { required: true, label: 'Mobile Number', mobile: true },
      email: { email: true, label: 'Email' },
      password: { required: true, label: 'Password', minLength: 6 },
      confirmPassword: {
        required: true,
        label: 'Confirm Password',
        match: 'password',
        matchMessage: 'Passwords do not match',
      },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSubmitting(true);
    try {
      const data = await registerTrainer({
        inviteCode: form.inviteCode.trim(),
        name: form.name.trim(),
        mobile: form.mobile.trim(),
        email: form.email.trim() || undefined,
        specialization: form.specialization,
        experienceYears: Number(form.experienceYears || 0),
        password: form.password,
      });
      toast.success('Trainer account created! Verify OTP to continue.');
      navigate('/verify-otp', {
        state: {
          mobile: form.mobile.trim(),
          purpose: 'REGISTER',
          redirectTo: '/trainer/dashboard',
          devOtp: data?.devOtp,
        },
      });
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark-bg flex items-center justify-center p-4 py-10">
      <div className="w-full max-w-lg space-y-6">
        <div className="text-center">
          <Link to="/" className="inline-flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-accent flex items-center justify-center text-dark-bg">
              <Dumbbell className="w-5 h-5" />
            </div>
            <span className="text-xl font-extrabold text-text-primary">
              GYM <span className="text-accent">PRO</span>
            </span>
          </Link>
          <h1 className="text-2xl font-bold text-text-primary mt-4">Trainer Registration</h1>
          <p className="text-sm text-text-secondary mt-1">
            Join your gym using the invitation code provided by your Gym Owner
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-dark-surface border border-dark-border rounded-2xl p-6 sm:p-8 shadow-2xl space-y-4"
        >
          <div className="flex items-end gap-2">
            <Input
              label="Gym Invitation Code"
              icon={KeyRound}
              required
              placeholder="e.g. GYM-TRN-8492"
              value={form.inviteCode}
              error={errors.inviteCode}
              onChange={(e) => {
                setForm((p) => ({ ...p, inviteCode: e.target.value }));
                setErrors((p) => ({ ...p, inviteCode: '' }));
              }}
            />
            <Button
              type="button"
              variant="secondary"
              loading={checkingInvite}
              onClick={verifyInviteCode}
            >
              Verify
            </Button>
          </div>

          {gymPreview && (
            <div className="p-3 rounded-xl bg-success-light border border-success/30 text-success text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Joining: {gymPreview.gymName || gymPreview.name}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Full Name"
              icon={User}
              required
              placeholder="Coach full name"
              value={form.name}
              error={errors.name}
              onChange={(e) => {
                setForm((p) => ({ ...p, name: e.target.value }));
                setErrors((p) => ({ ...p, name: '' }));
              }}
            />
            <Input
              label="Mobile Number"
              icon={Phone}
              type="tel"
              required
              placeholder="10-digit mobile"
              value={form.mobile}
              error={errors.mobile}
              onChange={(e) => {
                setForm((p) => ({ ...p, mobile: e.target.value }));
                setErrors((p) => ({ ...p, mobile: '' }));
              }}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Email (Optional)"
              icon={Mail}
              type="email"
              placeholder="coach@gym.com"
              value={form.email}
              error={errors.email}
              onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))}
            />
            <Input
              label="Experience (Years)"
              icon={Award}
              type="number"
              min={0}
              max={40}
              value={form.experienceYears}
              onChange={(e) => setForm((p) => ({ ...p, experienceYears: e.target.value }))}
            />
          </div>

          <Select
            label="Primary Specialization"
            value={form.specialization}
            options={[
              'Strength & Conditioning',
              'Weight Loss & HIIT',
              'Bodybuilding & Hypertrophy',
              'Yoga & Mobility',
              'CrossFit & Functional Training',
              'Nutrition & Diet Coaching',
            ]}
            onChange={(e) => setForm((p) => ({ ...p, specialization: e.target.value }))}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Password"
              icon={Lock}
              type="password"
              required
              placeholder="Min 6 characters"
              value={form.password}
              error={errors.password}
              onChange={(e) => {
                setForm((p) => ({ ...p, password: e.target.value }));
                setErrors((p) => ({ ...p, password: '' }));
              }}
            />
            <Input
              label="Confirm Password"
              icon={Lock}
              type="password"
              required
              placeholder="Repeat password"
              value={form.confirmPassword}
              error={errors.confirmPassword}
              onChange={(e) => {
                setForm((p) => ({ ...p, confirmPassword: e.target.value }));
                setErrors((p) => ({ ...p, confirmPassword: '' }));
              }}
            />
          </div>

          <Button type="submit" fullWidth size="lg" loading={submitting}>
            Register as Trainer
          </Button>

          <p className="text-center text-xs text-text-secondary pt-2">
            Already registered?{' '}
            <Link to="/login?role=TRAINER" className="text-accent hover:underline font-semibold">
              Sign in as Trainer
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default TrainerRegisterPage;

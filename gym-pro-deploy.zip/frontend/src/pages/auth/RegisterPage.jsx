import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import {
  Dumbbell,
  User,
  Phone,
  Mail,
  Lock,
  Building2,
  MapPin,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { validateForm } from '../../utils/validators';
import { getErrorMessage, extractData } from '../../utils/apiHelpers';
import { Input, Select, Button } from '../../components/ui';
import authService from '../../services/authService';

const FALLBACK_PLANS = [
  { id: 'STARTER', name: 'Starter', price: '₹999/mo', desc: 'Up to 100 members & 5 trainers' },
  { id: 'PROFESSIONAL', name: 'Professional', price: '₹1,999/mo', desc: 'Up to 500 members & 20 trainers (Most Popular)' },
  { id: 'PREMIUM', name: 'Premium', price: '₹3,999/mo', desc: 'Up to 5,000 members & 25 branches' },
];

export const RegisterPage = () => {
  const [step, setStep] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState({});
  const [plans, setPlans] = useState(FALLBACK_PLANS);
  const { registerOwner } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: '',
    mobile: '',
    email: '',
    password: '',
    confirmPassword: '',
    gymName: '',
    gymPhone: '',
    city: '',
    state: '',
    address: '',
    currency: 'INR',
    planTier: 'PROFESSIONAL',
  });

  useEffect(() => {
    authService.getPublicPlans()
      .then((res) => {
        const data = extractData(res);
        if (Array.isArray(data) && data.length > 0) {
          setPlans(
            data.map((p) => ({
              id: (p.name || '').toUpperCase(),
              name: p.name,
              price: `₹${(p.monthlyPrice || 999).toLocaleString('en-IN')}/mo`,
              desc: p.description || `Up to ${p.maxCustomers || 100} members`,
            }))
          );
        }
      })
      .catch(() => {
        // Fallback already set
      });
  }, []);

  const updateField = (field, val) => {
    setForm((p) => ({ ...p, [field]: val }));
    setErrors((p) => ({ ...p, [field]: '' }));
  };

  const handleNextStep = () => {
    if (step === 1) {
      const { isValid, errors: vErrors } = validateForm(form, {
        name: { required: true, label: 'Full Name', minLength: 2 },
        mobile: { required: true, label: 'Mobile Number', mobile: true },
        email: { required: true, label: 'Email', email: true },
        password: { required: true, label: 'Password', minLength: 6 },
        confirmPassword: {
          required: true,
          label: 'Confirm Password',
          match: 'password',
          matchMessage: 'Passwords do not match',
        },
      });
      if (!isValid) {
        setErrors(vErrors);
        return;
      }
      setStep(2);
    } else if (step === 2) {
      const { isValid, errors: vErrors } = validateForm(form, {
        gymName: { required: true, label: 'Gym Name', minLength: 2 },
        city: { required: true, label: 'City' },
        address: { required: true, label: 'Gym Address', minLength: 5 },
      });
      if (!isValid) {
        setErrors(vErrors);
        return;
      }
      setStep(3);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const data = await registerOwner({
        name: form.name.trim(),
        mobile: form.mobile.trim(),
        email: form.email.trim(),
        password: form.password,
        gymName: form.gymName.trim(),
        gymPhone: form.gymPhone.trim() || form.mobile.trim(),
        city: form.city.trim(),
        state: form.state.trim(),
        address: form.address.trim(),
        currency: form.currency,
        planTier: form.planTier,
      });
      toast.success('Gym account created! Please verify your OTP.');
      navigate('/verify-otp', {
        state: {
          mobile: form.mobile.trim(),
          purpose: 'REGISTER',
          redirectTo: '/owner/dashboard',
          devOtp: data?.devOtp,
        },
      });
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark-bg flex items-center justify-center p-4 py-10">
      <div className="w-full max-w-xl space-y-6">
        <div className="text-center">
          <Link to="/" className="inline-flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-accent flex items-center justify-center text-dark-bg">
              <Dumbbell className="w-5 h-5" />
            </div>
            <span className="text-xl font-extrabold text-text-primary">
              GYM <span className="text-accent">PRO</span>
            </span>
          </Link>
          <h1 className="text-2xl font-bold text-text-primary mt-4">Register Your Gym</h1>
          <p className="text-sm text-text-secondary mt-1">
            Launch your gym workspace in 3 simple steps with a 7-day free trial
          </p>
        </div>

        {/* Stepper */}
        <div className="flex items-center justify-between px-4">
          {[
            { num: 1, label: 'Owner Details' },
            { num: 2, label: 'Gym Profile' },
            { num: 3, label: 'Trial & Launch' },
          ].map((item, idx) => (
            <React.Fragment key={item.num}>
              <div className="flex items-center gap-2">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border ${
                    step >= item.num
                      ? 'bg-accent text-dark-bg border-accent'
                      : 'bg-dark-surface text-text-secondary border-dark-border'
                  }`}
                >
                  {step > item.num ? <CheckCircle2 className="w-4 h-4" /> : item.num}
                </div>
                <span
                  className={`text-xs font-medium hidden sm:inline ${
                    step >= item.num ? 'text-text-primary' : 'text-text-secondary'
                  }`}
                >
                  {item.label}
                </span>
              </div>
              {idx < 2 && (
                <div
                  className={`flex-1 h-0.5 mx-3 ${
                    step > item.num ? 'bg-accent' : 'bg-dark-border'
                  }`}
                />
              )}
            </React.Fragment>
          ))}
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-dark-surface border border-dark-border rounded-2xl p-6 sm:p-8 shadow-2xl space-y-5"
        >
          {step === 1 && (
            <div className="space-y-4">
              <Input
                label="Owner Full Name"
                icon={User}
                required
                placeholder="e.g. Vikramaditya Singhania"
                value={form.name}
                error={errors.name}
                onChange={(e) => updateField('name', e.target.value)}
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input
                  label="Mobile Number"
                  icon={Phone}
                  type="tel"
                  required
                  placeholder="10-digit mobile"
                  value={form.mobile}
                  error={errors.mobile}
                  onChange={(e) => updateField('mobile', e.target.value)}
                />
                <Input
                  label="Email Address"
                  icon={Mail}
                  type="email"
                  required
                  placeholder="owner@gym.com"
                  value={form.email}
                  error={errors.email}
                  onChange={(e) => updateField('email', e.target.value)}
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input
                  label="Password"
                  icon={Lock}
                  type="password"
                  required
                  placeholder="Min 6 characters"
                  value={form.password}
                  error={errors.password}
                  onChange={(e) => updateField('password', e.target.value)}
                />
                <Input
                  label="Confirm Password"
                  icon={Lock}
                  type="password"
                  required
                  placeholder="Re-enter password"
                  value={form.confirmPassword}
                  error={errors.confirmPassword}
                  onChange={(e) => updateField('confirmPassword', e.target.value)}
                />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <Input
                label="Gym / Fitness Studio Name"
                icon={Building2}
                required
                placeholder="e.g. IronPulse Fitness"
                value={form.gymName}
                error={errors.gymName}
                onChange={(e) => updateField('gymName', e.target.value)}
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input
                  label="Gym Contact Phone"
                  icon={Phone}
                  placeholder="Optional reception number"
                  value={form.gymPhone}
                  onChange={(e) => updateField('gymPhone', e.target.value)}
                />
                <Select
                  label="Currency"
                  value={form.currency}
                  options={[
                    { value: 'INR', label: 'INR (₹)' },
                    { value: 'USD', label: 'USD ($)' },
                    { value: 'AED', label: 'AED (د.إ)' },
                  ]}
                  onChange={(e) => updateField('currency', e.target.value)}
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input
                  label="City"
                  icon={MapPin}
                  required
                  placeholder="e.g. Mumbai"
                  value={form.city}
                  error={errors.city}
                  onChange={(e) => updateField('city', e.target.value)}
                />
                <Input
                  label="State"
                  placeholder="e.g. Maharashtra"
                  value={form.state}
                  onChange={(e) => updateField('state', e.target.value)}
                />
              </div>
              <Input
                label="Full Gym Address"
                required
                placeholder="Street, area, landmark, pincode"
                value={form.address}
                error={errors.address}
                onChange={(e) => updateField('address', e.target.value)}
              />
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <h3 className="text-base font-semibold text-text-primary">
                Select Starting SaaS Plan (7-Day Premium Free Trial Included)
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {plans.map((tier) => (
                  <button
                    key={tier.id}
                    type="button"
                    onClick={() => updateField('planTier', tier.id)}
                    className={`p-4 rounded-xl border text-left transition-all ${
                      form.planTier === tier.id
                        ? 'bg-accent-light border-accent'
                        : 'bg-dark-bg border-dark-border hover:border-text-secondary'
                    }`}
                  >
                    <p className="text-sm font-bold text-text-primary">{tier.name}</p>
                    <p className="text-base font-extrabold text-accent mt-1">{tier.price}</p>
                    <p className="text-xs text-text-secondary mt-1">{tier.desc}</p>
                  </button>
                ))}
              </div>

              <div className="p-4 rounded-xl bg-dark-bg border border-dark-border text-xs text-text-secondary space-y-1">
                <p className="text-text-primary font-semibold">Summary</p>
                <p>Owner: {form.name} ({form.mobile})</p>
                <p>Gym: {form.gymName} — {form.city}</p>
                <p className="text-accent font-medium">Trial: 7 Days Free with All Premium Features Unlocked</p>
              </div>
            </div>
          )}

          <div className="flex items-center justify-between gap-3 pt-2">
            {step > 1 ? (
              <Button type="button" variant="secondary" icon={ArrowLeft} onClick={() => setStep((s) => s - 1)}>
                Back
              </Button>
            ) : (
              <Link to="/login" className="text-xs text-text-secondary hover:text-accent">
                Already have an account? Sign In
              </Link>
            )}

            {step < 3 ? (
              <Button type="button" rightIcon={ArrowRight} onClick={handleNextStep}>
                Continue
              </Button>
            ) : (
              <Button type="submit" loading={submitting} rightIcon={CheckCircle2}>
                Create Gym & Start 7-Day Trial
              </Button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};

export default RegisterPage;

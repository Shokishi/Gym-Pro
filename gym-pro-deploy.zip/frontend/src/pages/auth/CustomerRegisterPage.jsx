import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Dumbbell, Building2, User, Phone, Mail, Lock } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { validateForm } from '../../utils/validators';
import { FITNESS_GOALS } from '../../utils/constants';
import { getErrorMessage } from '../../utils/apiHelpers';
import { Input, Select, Button } from '../../components/ui';

export const CustomerRegisterPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { registerCustomer } = useAuth();

  const [form, setForm] = useState({
    gymCode: searchParams.get('gym') || '',
    name: '',
    mobile: '',
    email: '',
    gender: 'MALE',
    fitnessGoal: 'GENERAL_FITNESS',
    referralCode: searchParams.get('ref') || '',
    password: '',
    confirmPassword: '',
  });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      gymCode: { required: true, label: 'Gym Code' },
      name: { required: true, label: 'Full Name', minLength: 2 },
      mobile: { required: true, label: 'Mobile Number', mobile: true },
      email: { email: true, label: 'Email' },
      password: { required: true, label: 'Password', minLength: 6 },
      confirmPassword: {
        required: true,
        label: 'Confirm Password',
        match: 'password',
        matchMessage: 'Passwords do not match',
      },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSubmitting(true);
    try {
      const data = await registerCustomer({
        gymCode: form.gymCode.trim(),
        name: form.name.trim(),
        mobile: form.mobile.trim(),
        email: form.email.trim() || undefined,
        gender: form.gender,
        fitnessGoal: form.fitnessGoal,
        referralCode: form.referralCode.trim() || undefined,
        password: form.password,
      });
      toast.success('Member account created! Verify OTP to get started.');
      navigate('/verify-otp', {
        state: {
          mobile: form.mobile.trim(),
          purpose: 'REGISTER',
          redirectTo: '/customer/home',
          devOtp: data?.devOtp,
        },
      });
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark-bg flex items-center justify-center p-4 py-10">
      <div className="w-full max-w-lg space-y-6">
        <div className="text-center">
          <Link to="/" className="inline-flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-accent flex items-center justify-center text-dark-bg">
              <Dumbbell className="w-5 h-5" />
            </div>
            <span className="text-xl font-extrabold text-text-primary">
              GYM <span className="text-accent">PRO</span>
            </span>
          </Link>
          <h1 className="text-2xl font-bold text-text-primary mt-4">Member Sign Up</h1>
          <p className="text-sm text-text-secondary mt-1">
            Create your member profile to access workouts, diet plans & QR check-ins
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-dark-surface border border-dark-border rounded-2xl p-6 sm:p-8 shadow-2xl space-y-4"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Gym Code / ID"
              icon={Building2}
              required
              placeholder="Ask your gym desk"
              value={form.gymCode}
              error={errors.gymCode}
              onChange={(e) => {
                setForm((p) => ({ ...p, gymCode: e.target.value }));
                setErrors((p) => ({ ...p, gymCode: '' }));
              }}
            />
            <Input
              label="Referral Code (Optional)"
              placeholder="Friend's referral code"
              value={form.referralCode}
              onChange={(e) => setForm((p) => ({ ...p, referralCode: e.target.value }))}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Full Name"
              icon={User}
              required
              placeholder="Your full name"
              value={form.name}
              error={errors.name}
              onChange={(e) => {
                setForm((p) => ({ ...p, name: e.target.value }));
                setErrors((p) => ({ ...p, name: '' }));
              }}
            />
            <Input
              label="Mobile Number"
              icon={Phone}
              type="tel"
              required
              placeholder="10-digit mobile"
              value={form.mobile}
              error={errors.mobile}
              onChange={(e) => {
                setForm((p) => ({ ...p, mobile: e.target.value }));
                setErrors((p) => ({ ...p, mobile: '' }));
              }}
            />
          </div>

          <Input
            label="Email (Optional)"
            icon={Mail}
            type="email"
            placeholder="you@example.com"
            value={form.email}
            error={errors.email}
            onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Select
              label="Gender"
              value={form.gender}
              options={[
                { value: 'MALE', label: 'Male' },
                { value: 'FEMALE', label: 'Female' },
                { value: 'OTHER', label: 'Other' },
              ]}
              onChange={(e) => setForm((p) => ({ ...p, gender: e.target.value }))}
            />
            <Select
              label="Fitness Goal"
              value={form.fitnessGoal}
              options={FITNESS_GOALS}
              onChange={(e) => setForm((p) => ({ ...p, fitnessGoal: e.target.value }))}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Password"
              icon={Lock}
              type="password"
              required
              placeholder="Min 6 characters"
              value={form.password}
              error={errors.password}
              onChange={(e) => {
                setForm((p) => ({ ...p, password: e.target.value }));
                setErrors((p) => ({ ...p, password: '' }));
              }}
            />
            <Input
              label="Confirm Password"
              icon={Lock}
              type="password"
              required
              placeholder="Repeat password"
              value={form.confirmPassword}
              error={errors.confirmPassword}
              onChange={(e) => {
                setForm((p) => ({ ...p, confirmPassword: e.target.value }));
                setErrors((p) => ({ ...p, confirmPassword: '' }));
              }}
            />
          </div>

          <Button type="submit" fullWidth size="lg" loading={submitting}>
            Create Member Account
          </Button>

          <p className="text-center text-xs text-text-secondary pt-2">
            Already a member?{' '}
            <Link to="/login?role=CUSTOMER" className="text-accent hover:underline font-semibold">
              Sign in here
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default CustomerRegisterPage;

import React, { useState, useRef, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Dumbbell, ShieldCheck, Lock, RefreshCw } from 'lucide-react';
import authService from '../../services/authService';
import { useAuth } from '../../contexts/AuthContext';
import { getErrorMessage, extractData } from '../../utils/apiHelpers';
import { validateForm } from '../../utils/validators';
import { Button, Input } from '../../components/ui';

export const OTPVerificationPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { persistSession } = useAuth();

  const mobile = location.state?.mobile || '';
  const purpose = location.state?.purpose || 'REGISTER';
  const redirectTo = location.state?.redirectTo || '/login';
  const devOtp = location.state?.devOtp || '';

  const [digits, setDigits] = useState(['', '', '', '', '', '']);
  const [countdown, setCountdown] = useState(30);
  const [verifying, setVerifying] = useState(false);
  const [otpVerifiedForReset, setOtpVerifiedForReset] = useState(false);
  const [resetForm, setResetForm] = useState({ newPassword: '', confirmPassword: '' });
  const [resetErrors, setResetErrors] = useState({});
  const inputRefs = useRef([]);

  useEffect(() => {
    if (countdown <= 0) return undefined;
    const timer = setTimeout(() => setCountdown((c) => c - 1), 1000);
    return () => clearTimeout(timer);
  }, [countdown]);

  const handleDigitChange = (idx, value) => {
    const clean = value.replace(/\D/g, '').slice(-1);
    const next = [...digits];
    next[idx] = clean;
    setDigits(next);
    if (clean && idx < 5) {
      inputRefs.current[idx + 1]?.focus();
    }
  };

  const handleKeyDown = (idx, e) => {
    if (e.key === 'Backspace' && !digits[idx] && idx > 0) {
      inputRefs.current[idx - 1]?.focus();
    }
  };

  const handlePaste = (e) => {
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    if (pasted.length === 6) {
      setDigits(pasted.split(''));
      inputRefs.current[5]?.focus();
    }
  };

  const handleVerifyOtp = async (e) => {
    e.preventDefault();
    const otp = digits.join('');
    if (otp.length !== 6) {
      toast.error('Please enter the complete 6-digit OTP code');
      return;
    }

    setVerifying(true);
    try {
      const res = await authService.verifyOtp({ mobile, otp, purpose });
      const data = extractData(res);
      toast.success('OTP verified successfully!');

      if (purpose === 'RESET_PASSWORD') {
        setOtpVerifiedForReset(true);
      } else {
        if (data?.accessToken || data?.token) {
          persistSession(data);
        }
        navigate(redirectTo, { replace: true });
      }
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setVerifying(false);
    }
  };

  const handleResetPassword = async (e) => {
    e.preventDefault();
    const { isValid, errors } = validateForm(resetForm, {
      newPassword: { required: true, label: 'New Password', minLength: 6 },
      confirmPassword: {
        required: true,
        label: 'Confirm Password',
        match: 'newPassword',
        matchMessage: 'Passwords do not match',
      },
    });
    if (!isValid) {
      setResetErrors(errors);
      return;
    }

    setVerifying(true);
    try {
      await authService.resetPassword({
        mobile,
        otp: digits.join(''),
        newPassword: resetForm.newPassword,
      });
      toast.success('Password reset successfully. Please sign in.');
      navigate('/login', { replace: true });
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setVerifying(false);
    }
  };

  const handleResend = async () => {
    setCountdown(30);
    try {
      const res = await authService.forgotPassword({ mobile });
      const data = extractData(res);
      toast.success(`A new 6-digit OTP has been sent${data?.devOtp ? ` (${data.devOtp})` : ''}`);
    } catch {
      toast.success('OTP resent (use any 6-digit code in simulation mode)');
    }
  };

  return (
    <div className="min-h-screen bg-dark-bg flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center">
          <Link to="/" className="inline-flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-accent flex items-center justify-center text-dark-bg">
              <Dumbbell className="w-5 h-5" />
            </div>
            <span className="text-xl font-extrabold text-text-primary">
              GYM <span className="text-accent">PRO</span>
            </span>
          </Link>
          <h1 className="text-2xl font-bold text-text-primary mt-4">
            {otpVerifiedForReset ? 'Create New Password' : 'Verify OTP'}
          </h1>
          <p className="text-sm text-text-secondary mt-1">
            {otpVerifiedForReset
              ? 'Choose a strong password for your account'
              : `Enter the 6-digit verification code sent to ${mobile || 'your mobile'}`}
          </p>
        </div>

        <div className="bg-dark-surface border border-dark-border rounded-2xl p-6 shadow-2xl">
          {!otpVerifiedForReset ? (
            <form onSubmit={handleVerifyOtp} className="space-y-6">
              <div className="flex items-center justify-between gap-2" onPaste={handlePaste}>
                {digits.map((d, idx) => (
                  <input
                    key={idx}
                    ref={(el) => {
                      inputRefs.current[idx] = el;
                    }}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={d}
                    onChange={(e) => handleDigitChange(idx, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(idx, e)}
                    className="w-12 h-14 text-center text-xl font-bold bg-dark-bg border border-dark-border rounded-xl text-text-primary focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent"
                  />
                ))}
              </div>

              <p className="text-xs text-center text-text-secondary">
                {devOtp ? (
                  <>Verification code: <span className="text-accent font-mono font-bold">{devOtp}</span></>
                ) : (
                  <>Simulation mode: any 6-digit code (e.g. <span className="text-accent font-mono">123456</span>) is accepted.</>
                )}
              </p>

              <Button type="submit" fullWidth size="lg" loading={verifying} icon={ShieldCheck}>
                Verify Code
              </Button>

              <div className="text-center text-xs text-text-secondary">
                {countdown > 0 ? (
                  <span>Resend OTP in {countdown}s</span>
                ) : (
                  <button
                    type="button"
                    onClick={handleResend}
                    className="inline-flex items-center gap-1 text-accent hover:underline font-medium"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Resend OTP
                  </button>
                )}
              </div>
            </form>
          ) : (
            <form onSubmit={handleResetPassword} className="space-y-4">
              <Input
                label="New Password"
                type="password"
                icon={Lock}
                required
                placeholder="Min 6 characters"
                value={resetForm.newPassword}
                error={resetErrors.newPassword}
                onChange={(e) => {
                  setResetForm((p) => ({ ...p, newPassword: e.target.value }));
                  setResetErrors((p) => ({ ...p, newPassword: '' }));
                }}
              />
              <Input
                label="Confirm New Password"
                type="password"
                icon={Lock}
                required
                placeholder="Repeat password"
                value={resetForm.confirmPassword}
                error={resetErrors.confirmPassword}
                onChange={(e) => {
                  setResetForm((p) => ({ ...p, confirmPassword: e.target.value }));
                  setResetErrors((p) => ({ ...p, confirmPassword: '' }));
                }}
              />
              <Button type="submit" fullWidth size="lg" loading={verifying}>
                Update Password & Sign In
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default OTPVerificationPage;

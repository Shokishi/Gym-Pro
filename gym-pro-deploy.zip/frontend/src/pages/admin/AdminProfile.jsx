import React from 'react';
import ProfileManager from '../../components/shared/ProfileManager';

export const AdminProfile = () => {
  return (
    <ProfileManager
      title="Super Admin Profile"
      subtitle="Manage administrator account details and security credentials"
    />
  );
};

export default AdminProfile;

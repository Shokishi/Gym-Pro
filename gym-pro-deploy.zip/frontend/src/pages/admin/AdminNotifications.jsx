import React from 'react';
import NotificationsCenter from '../../components/shared/NotificationsCenter';

export const AdminNotifications = () => {
  return (
    <NotificationsCenter
      title="Platform Notifications"
      subtitle="Broadcast platform-wide announcements, billing alerts, and maintenance notices"
      canBroadcast
      targetOptions={[
        { value: 'ALL', label: 'All Platform Users' },
        { value: 'OWNERS', label: 'All Gym Owners' },
        { value: 'TRAINERS', label: 'All Trainers' },
        { value: 'TRIAL_GYMS', label: 'Gyms on Free Trial' },
      ]}
    />
  );
};

export default AdminNotifications;

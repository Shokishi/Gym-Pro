import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { CheckCircle2, XCircle, Eye } from 'lucide-react';
import adminService from '../../services/adminService';
import { usePagination } from '../../hooks/usePagination';
import { useDebounce } from '../../hooks/useDebounce';
import { extractList, extractPagination, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDateTime } from '../../utils/formatters';
import {
  PageHeader,
  SearchInput,
  Select,
  Table,
  Badge,
  Button,
  Modal,
  Textarea,
  ErrorState,
} from '../../components/ui';

export const SubscriptionPayments = () => {
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [selectedPayment, setSelectedPayment] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const [verifying, setVerifying] = useState(false);

  const debouncedSearch = useDebounce(search, 350);
  const pagination = usePagination(1, 10);

  const fetchPayments = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await adminService.getSubscriptionPayments({
        search: debouncedSearch,
        status: statusFilter,
        page: pagination.page,
        limit: pagination.limit,
      });
      setPayments(extractList(res));
      pagination.updateMeta(extractPagination(res, pagination.limit));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch, statusFilter, pagination.page, pagination.limit]);

  useEffect(() => {
    fetchPayments();
  }, [fetchPayments]);

  const handleVerify = async (payment, action) => {
    setVerifying(true);
    try {
      await adminService.verifySubscriptionPayment(payment.id || payment._id, {
        status: action,
        reason: action === 'REJECTED' ? rejectReason : undefined,
      });
      toast.success(`Payment ${action === 'VERIFIED' ? 'approved' : 'rejected'}`);
      setSelectedPayment(null);
      setRejectReason('');
      fetchPayments();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setVerifying(false);
    }
  };

  const columns = [
    {
      key: 'gym',
      header: 'Gym',
      render: (row) => (
        <div>
          <p className="font-semibold text-text-primary">{row.gym?.name || row.gymName || '—'}</p>
          <p className="text-xs text-text-secondary">{row.plan?.name || row.planName || ''}</p>
        </div>
      ),
    },
    {
      key: 'amount',
      header: 'Amount',
      sortable: true,
      render: (row) => <span className="font-semibold text-accent">{formatCurrency(row.amount)}</span>,
    },
    {
      key: 'method',
      header: 'Method / Ref',
      render: (row) => (
        <div>
          <p className="text-sm">{row.paymentMethod || row.method || 'UPI'}</p>
          <p className="text-xs text-text-secondary font-mono">
            {row.transactionId || row.utr || '—'}
          </p>
        </div>
      ),
    },
    {
      key: 'createdAt',
      header: 'Submitted',
      render: (row) => formatDateTime(row.createdAt),
    },
    {
      key: 'status',
      header: 'Status',
      render: (row) => <Badge status={row.status || 'PENDING'} dot />,
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (row) => {
        const isPending = String(row.status).toUpperCase() === 'PENDING';
        return (
          <div className="inline-flex items-center gap-2">
            <Button
              size="xs"
              variant="secondary"
              icon={Eye}
              onClick={() => setSelectedPayment(row)}
            >
              Review
            </Button>
            {isPending && (
              <Button
                size="xs"
                variant="success"
                icon={CheckCircle2}
                onClick={() => handleVerify(row, 'VERIFIED')}
              >
                Approve
              </Button>
            )}
          </div>
        );
      },
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Subscription Payments"
        subtitle="Verify manual UPI / bank transfer receipts and track SaaS billing"
      />

      <div className="flex flex-col sm:flex-row gap-3">
        <SearchInput
          placeholder="Search gym or transaction UTR..."
          value={search}
          onChange={(v) => {
            setSearch(v);
            pagination.resetPage();
          }}
          className="sm:max-w-sm"
        />
        <Select
          value={statusFilter}
          placeholder=""
          containerClassName="sm:w-48"
          options={[
            { value: 'ALL', label: 'All Payments' },
            { value: 'PENDING', label: 'Pending Verification' },
            { value: 'VERIFIED', label: 'Verified' },
            { value: 'REJECTED', label: 'Rejected' },
          ]}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            pagination.resetPage();
          }}
        />
      </div>

      {error ? (
        <ErrorState message={error} onRetry={fetchPayments} />
      ) : (
        <Table
          columns={columns}
          data={payments}
          loading={loading}
          pagination={pagination}
          onPageChange={pagination.setPage}
          emptyTitle="No subscription payments found"
        />
      )}

      <Modal
        isOpen={Boolean(selectedPayment)}
        onClose={() => setSelectedPayment(null)}
        title="Verify Subscription Payment"
        subtitle={selectedPayment?.gym?.name || selectedPayment?.gymName}
      >
        {selectedPayment && (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-dark-bg border border-dark-border space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-text-secondary">Amount</span>
                <span className="font-bold text-accent">{formatCurrency(selectedPayment.amount)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-secondary">Plan</span>
                <span className="font-medium">
                  {selectedPayment.plan?.name || selectedPayment.planName || '—'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-secondary">Transaction / UTR</span>
                <span className="font-mono">{selectedPayment.transactionId || selectedPayment.utr || '—'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-secondary">Status</span>
                <Badge status={selectedPayment.status || 'PENDING'} />
              </div>
            </div>

            {selectedPayment.receiptUrl && (
              <img
                src={selectedPayment.receiptUrl}
                alt="Payment receipt"
                className="max-h-60 w-full object-contain rounded-xl border border-dark-border bg-dark-bg"
              />
            )}

            {String(selectedPayment.status).toUpperCase() === 'PENDING' && (
              <>
                <Textarea
                  label="Rejection Reason (Required only if rejecting)"
                  rows={2}
                  placeholder="e.g. Invalid UTR reference..."
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                />
                <div className="flex justify-end gap-3 pt-2">
                  <Button
                    variant="danger"
                    icon={XCircle}
                    loading={verifying}
                    onClick={() => handleVerify(selectedPayment, 'REJECTED')}
                  >
                    Reject
                  </Button>
                  <Button
                    variant="success"
                    icon={CheckCircle2}
                    loading={verifying}
                    onClick={() => handleVerify(selectedPayment, 'VERIFIED')}
                  >
                    Verify & Activate
                  </Button>
                </div>
              </>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
};

export default SubscriptionPayments;

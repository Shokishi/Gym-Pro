import React, { useState, useEffect, useCallback } from 'react';
import { Download, FileText } from 'lucide-react';
import reportService from '../../services/reportService';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDate, getDateRangeFromPreset } from '../../utils/formatters';
import { generateReportPDF, exportToCSV } from '../../utils/pdfGenerator';
import {
  PageHeader,
  Card,
  Select,
  DateRangeFilter,
  Button,
  Table,
  Badge,
  ErrorState,
} from '../../components/ui';

export const AdminReports = () => {
  const [reportType, setReportType] = useState('REVENUE');
  const [preset, setPreset] = useState('30d');
  const [customDates, setCustomDates] = useState({ startDate: '', endDate: '' });
  const [reportData, setReportData] = useState({ rows: [], summary: {} });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadReport = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const range = getDateRangeFromPreset(preset, customDates.startDate, customDates.endDate);
      const res = await reportService.getAdminReport({ type: reportType, ...range });
      const data = extractData(res, {});
      setReportData({
        rows: Array.isArray(data?.rows) ? data.rows : Array.isArray(data) ? data : [],
        summary: data?.summary || {},
      });
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [reportType, preset, customDates.startDate, customDates.endDate]);

  useEffect(() => {
    loadReport();
  }, [loadReport]);

  const columns = [
    { key: 'gymName', header: 'Gym Name', render: (r) => r.gymName || r.gym?.name || '—' },
    { key: 'planName', header: 'Plan', render: (r) => r.planName || r.plan?.name || '—' },
    { key: 'amount', header: 'Amount', render: (r) => formatCurrency(r.amount || 0) },
    { key: 'status', header: 'Status', render: (r) => <Badge status={r.status || 'ACTIVE'} /> },
    { key: 'date', header: 'Date', render: (r) => formatDate(r.date || r.createdAt) },
  ];

  const handleExportPDF = () => {
    generateReportPDF({
      title: `GYM PRO ${reportType} Report`,
      subtitle: `Period: ${preset.toUpperCase()}`,
      columns: ['Gym', 'Plan', 'Amount', 'Status', 'Date'],
      rows: reportData.rows.map((r) => [
        r.gymName || r.gym?.name || '—',
        r.planName || r.plan?.name || '—',
        formatCurrency(r.amount || 0),
        r.status || 'ACTIVE',
        formatDate(r.date || r.createdAt),
      ]),
      filename: `gympro-${reportType.toLowerCase()}-report.pdf`,
    });
  };

  const handleExportCSV = () => {
    exportToCSV(
      `gympro-${reportType.toLowerCase()}-report.csv`,
      ['Gym', 'Plan', 'Amount', 'Status', 'Date'],
      reportData.rows.map((r) => [
        r.gymName || r.gym?.name || '—',
        r.planName || r.plan?.name || '—',
        r.amount || 0,
        r.status || 'ACTIVE',
        formatDate(r.date || r.createdAt),
      ])
    );
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Platform Reports"
        subtitle="Generate and export revenue, subscription, and gym onboarding reports"
        actions={
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="sm" icon={Download} onClick={handleExportCSV}>
              Export CSV
            </Button>
            <Button size="sm" icon={FileText} onClick={handleExportPDF}>
              Export PDF
            </Button>
          </div>
        }
      />

      <Card>
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <Select
            label="Report Type"
            value={reportType}
            placeholder=""
            containerClassName="lg:w-64"
            options={[
              { value: 'REVENUE', label: 'SaaS Revenue Report' },
              { value: 'SUBSCRIPTIONS', label: 'Active Subscriptions' },
              { value: 'TRIALS', label: 'Trial Conversion Report' },
              { value: 'GYMS', label: 'Gym Growth Report' },
            ]}
            onChange={(e) => setReportType(e.target.value)}
          />
          <DateRangeFilter
            preset={preset}
            onPresetChange={setPreset}
            startDate={customDates.startDate}
            endDate={customDates.endDate}
            onCustomChange={setCustomDates}
          />
        </div>
      </Card>

      {error ? (
        <ErrorState message={error} onRetry={loadReport} />
      ) : (
        <Table
          columns={columns}
          data={reportData.rows}
          loading={loading}
          emptyTitle="No report rows available"
        />
      )}
    </div>
  );
};

export default AdminReports;

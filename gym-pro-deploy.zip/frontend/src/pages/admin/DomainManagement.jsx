import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Globe, CheckCircle2, Ban, RefreshCw } from 'lucide-react';
import adminService from '../../services/adminService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatDate } from '../../utils/formatters';
import { PageHeader, SearchInput, Table, Badge, Button, ErrorState } from '../../components/ui';

export const DomainManagement = () => {
  const [domains, setDomains] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [verifyingId, setVerifyingId] = useState(null);

  const fetchDomains = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await adminService.getDomains({ search });
      setDomains(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [search]);

  useEffect(() => {
    fetchDomains();
  }, [fetchDomains]);

  const handleVerifyDns = async (domain) => {
    const id = domain.id || domain._id;
    setVerifyingId(id);
    try {
      await adminService.verifyDomain(id, { verified: true });
      toast.success(`DNS verified for ${domain.domain}`);
      fetchDomains();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setVerifyingId(null);
    }
  };

  const handleStatusChange = async (domain, status) => {
    try {
      await adminService.updateDomainStatus(domain.id || domain._id, status);
      toast.success(`Domain status updated to ${status}`);
      fetchDomains();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const columns = [
    {
      key: 'domain',
      header: 'Custom Domain',
      render: (row) => (
        <div className="flex items-center gap-2.5">
          <Globe className="w-4 h-4 text-accent shrink-0" />
          <span className="font-mono font-medium text-text-primary">{row.domain}</span>
        </div>
      ),
    },
    {
      key: 'gym',
      header: 'Gym Tenant',
      render: (row) => row.gym?.name || row.gymName || '—',
    },
    {
      key: 'dnsRecord',
      header: 'DNS CNAME / TXT',
      render: (row) => (
        <span className="font-mono text-xs text-text-secondary">
          {row.cnameTarget || row.verificationToken || 'cname.gympro.app'}
        </span>
      ),
    },
    {
      key: 'sslStatus',
      header: 'SSL',
      render: (row) => <Badge status={row.sslActive ? 'active' : 'pending'}>{row.sslActive ? 'SSL Active' : 'Pending'}</Badge>,
    },
    {
      key: 'status',
      header: 'Status',
      render: (row) => <Badge status={row.status || 'PENDING'} dot />,
    },
    {
      key: 'createdAt',
      header: 'Requested',
      render: (row) => formatDate(row.createdAt),
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (row) => {
        const id = row.id || row._id;
        const isVerified = String(row.status).toUpperCase() === 'VERIFIED' || String(row.status).toUpperCase() === 'ACTIVE';
        return (
          <div className="inline-flex items-center gap-2">
            <Button
              size="xs"
              variant="secondary"
              icon={RefreshCw}
              loading={verifyingId === id}
              onClick={() => handleVerifyDns(row)}
            >
              Verify DNS
            </Button>
            {!isVerified ? (
              <Button
                size="xs"
                variant="success"
                icon={CheckCircle2}
                onClick={() => handleStatusChange(row, 'ACTIVE')}
              >
                Approve
              </Button>
            ) : (
              <Button
                size="xs"
                variant="danger"
                icon={Ban}
                onClick={() => handleStatusChange(row, 'SUSPENDED')}
              >
                Disable
              </Button>
            )}
          </div>
        );
      },
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Custom Domain Management"
        subtitle="Verify CNAME records and provision white-label domains for enterprise gyms"
      />

      <SearchInput
        placeholder="Search domain or gym name..."
        value={search}
        onChange={setSearch}
        className="sm:max-w-sm"
      />

      {error ? (
        <ErrorState message={error} onRetry={fetchDomains} />
      ) : (
        <Table
          columns={columns}
          data={domains}
          loading={loading}
          emptyTitle="No custom domain requests"
          emptyMessage="White-label domain requests from enterprise gym owners will appear here."
        />
      )}
    </div>
  );
};

export default DomainManagement;

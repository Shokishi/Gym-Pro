import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Plus, Edit2, Trash2, CheckCircle2, Layers } from 'lucide-react';
import adminService from '../../services/adminService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency } from '../../utils/formatters';
import { validateForm } from '../../utils/validators';
import {
  PageHeader,
  Card,
  Button,
  Badge,
  Modal,
  Input,
  Textarea,
  Toggle,
  ConfirmDialog,
  Skeleton,
  EmptyState,
  ErrorState,
} from '../../components/ui';

const INITIAL_FORM = {
  name: '',
  description: '',
  monthlyPrice: '',
  yearlyPrice: '',
  maxMembers: 500,
  maxBranches: 1,
  maxTrainers: 10,
  featuresText: 'QR Attendance\nUPI Payment Tracking\nWorkout & Diet Plans\nPDF Invoices',
  isPopular: false,
  isActive: true,
};

export const SubscriptionPlans = () => {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState(null);
  const [form, setForm] = useState(INITIAL_FORM);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const fetchPlans = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await adminService.getPlans();
      setPlans(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPlans();
  }, [fetchPlans]);

  const openCreate = () => {
    setEditingPlan(null);
    setForm(INITIAL_FORM);
    setErrors({});
    setModalOpen(true);
  };

  const openEdit = (plan) => {
    setEditingPlan(plan);
    setForm({
      name: plan.name || '',
      description: plan.description || '',
      monthlyPrice: plan.monthlyPrice ?? plan.price ?? '',
      yearlyPrice: plan.yearlyPrice ?? '',
      maxMembers: plan.maxMembers ?? 500,
      maxBranches: plan.maxBranches ?? 1,
      maxTrainers: plan.maxTrainers ?? 10,
      featuresText: Array.isArray(plan.features) ? plan.features.join('\n') : plan.features || '',
      isPopular: Boolean(plan.isPopular),
      isActive: plan.isActive !== false,
    });
    setErrors({});
    setModalOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      name: { required: true, label: 'Plan Name', minLength: 2 },
      monthlyPrice: { required: true, label: 'Monthly Price', min: 0 },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        description: form.description.trim(),
        monthlyPrice: Number(form.monthlyPrice),
        yearlyPrice: Number(form.yearlyPrice || Number(form.monthlyPrice) * 10),
        maxMembers: Number(form.maxMembers || 100),
        maxBranches: Number(form.maxBranches || 1),
        maxTrainers: Number(form.maxTrainers || 5),
        features: form.featuresText
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean),
        isPopular: form.isPopular,
        isActive: form.isActive,
      };

      if (editingPlan) {
        await adminService.updatePlan(editingPlan.id || editingPlan._id, payload);
        toast.success('Subscription plan updated');
      } else {
        await adminService.createPlan(payload);
        toast.success('Subscription plan created');
      }
      setModalOpen(false);
      fetchPlans();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await adminService.deletePlan(deleteTarget.id || deleteTarget._id);
      toast.success('Subscription plan deleted');
      setDeleteTarget(null);
      fetchPlans();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="SaaS Subscription Plans"
        subtitle="Create and manage GYM PRO subscription tiers for gym owners"
        actions={
          <Button icon={Plus} onClick={openCreate}>
            Create Plan
          </Button>
        }
      />

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Skeleton variant="card" />
          <Skeleton variant="card" />
          <Skeleton variant="card" />
        </div>
      ) : error ? (
        <ErrorState message={error} onRetry={fetchPlans} />
      ) : plans.length === 0 ? (
        <Card>
          <EmptyState
            icon={Layers}
            title="No subscription plans configured"
            message="Create your first SaaS subscription tier to start onboarding gyms."
            action={
              <Button icon={Plus} onClick={openCreate}>
                Create Plan
              </Button>
            }
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {plans.map((plan) => {
            const features = Array.isArray(plan.features) ? plan.features : [];
            return (
              <Card
                key={plan.id || plan._id}
                elevated={plan.isPopular}
                className={plan.isPopular ? 'border-accent/60' : ''}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-bold text-text-primary">{plan.name}</h3>
                      {plan.isPopular && <Badge variant="accent">Popular</Badge>}
                    </div>
                    <p className="text-xs text-text-secondary mt-1">{plan.description}</p>
                  </div>
                  <Badge status={plan.isActive !== false ? 'active' : 'inactive'} />
                </div>

                <div className="mt-5 pb-4 border-b border-dark-border flex items-baseline gap-2">
                  <span className="text-3xl font-extrabold text-accent">
                    {formatCurrency(plan.monthlyPrice ?? plan.price ?? 0)}
                  </span>
                  <span className="text-xs text-text-secondary">/month</span>
                  {plan.yearlyPrice && (
                    <span className="ml-auto text-xs text-text-secondary">
                      {formatCurrency(plan.yearlyPrice)}/yr
                    </span>
                  )}
                </div>

                <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="p-2 rounded-lg bg-dark-bg border border-dark-border">
                    <p className="text-text-secondary">Members</p>
                    <p className="font-bold text-text-primary mt-0.5">{plan.maxMembers ?? '∞'}</p>
                  </div>
                  <div className="p-2 rounded-lg bg-dark-bg border border-dark-border">
                    <p className="text-text-secondary">Branches</p>
                    <p className="font-bold text-text-primary mt-0.5">{plan.maxBranches ?? 1}</p>
                  </div>
                  <div className="p-2 rounded-lg bg-dark-bg border border-dark-border">
                    <p className="text-text-secondary">Trainers</p>
                    <p className="font-bold text-text-primary mt-0.5">{plan.maxTrainers ?? '∞'}</p>
                  </div>
                </div>

                <ul className="mt-4 space-y-2 text-xs text-text-secondary">
                  {features.slice(0, 5).map((feat, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-success shrink-0" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>

                <div className="mt-5 pt-4 border-t border-dark-border flex items-center gap-2">
                  <Button
                    variant="secondary"
                    size="sm"
                    icon={Edit2}
                    onClick={() => openEdit(plan)}
                    className="flex-1"
                  >
                    Edit
                  </Button>
                  <Button
                    variant="danger"
                    size="sm"
                    icon={Trash2}
                    onClick={() => setDeleteTarget(plan)}
                  >
                    Delete
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingPlan ? 'Edit Subscription Plan' : 'Create Subscription Plan'}
        size="lg"
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Plan Name"
              required
              placeholder="e.g. Pro Growth"
              value={form.name}
              error={errors.name}
              onChange={(e) => {
                setForm((p) => ({ ...p, name: e.target.value }));
                setErrors((p) => ({ ...p, name: '' }));
              }}
            />
            <Input
              label="Short Description"
              placeholder="Best for mid-size gyms"
              value={form.description}
              onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
            />
            <Input
              label="Monthly Price (₹)"
              type="number"
              required
              value={form.monthlyPrice}
              error={errors.monthlyPrice}
              onChange={(e) => {
                setForm((p) => ({ ...p, monthlyPrice: e.target.value }));
                setErrors((p) => ({ ...p, monthlyPrice: '' }));
              }}
            />
            <Input
              label="Yearly Price (₹)"
              type="number"
              value={form.yearlyPrice}
              onChange={(e) => setForm((p) => ({ ...p, yearlyPrice: e.target.value }))}
            />
            <Input
              label="Max Members"
              type="number"
              value={form.maxMembers}
              onChange={(e) => setForm((p) => ({ ...p, maxMembers: e.target.value }))}
            />
            <Input
              label="Max Branches"
              type="number"
              value={form.maxBranches}
              onChange={(e) => setForm((p) => ({ ...p, maxBranches: e.target.value }))}
            />
            <Input
              label="Max Trainers"
              type="number"
              value={form.maxTrainers}
              onChange={(e) => setForm((p) => ({ ...p, maxTrainers: e.target.value }))}
            />
          </div>

          <Textarea
            label="Included Features (one per line)"
            rows={4}
            value={form.featuresText}
            onChange={(e) => setForm((p) => ({ ...p, featuresText: e.target.value }))}
          />

          <div className="flex flex-wrap gap-6 pt-1">
            <Toggle
              checked={form.isPopular}
              onChange={(val) => setForm((p) => ({ ...p, isPopular: val }))}
              label="Mark as Popular"
            />
            <Toggle
              checked={form.isActive}
              onChange={(val) => setForm((p) => ({ ...p, isActive: val }))}
              label="Active & Visible"
            />
          </div>

          <div className="flex justify-end gap-3 pt-3">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              {editingPlan ? 'Update Plan' : 'Create Plan'}
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Subscription Plan"
        message={`Are you sure you want to delete "${deleteTarget?.name}"? Existing subscribers won't lose immediate access.`}
        confirmLabel="Delete Plan"
      />
    </div>
  );
};

export default SubscriptionPlans;

import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { CalendarPlus, Ban } from 'lucide-react';
import adminService from '../../services/adminService';
import { useDebounce } from '../../hooks/useDebounce';
import { usePagination } from '../../hooks/usePagination';
import { extractList, extractPagination, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDate } from '../../utils/formatters';
import {
  PageHeader,
  SearchInput,
  Select,
  Table,
  Badge,
  Button,
  Modal,
  Input,
  ErrorState,
} from '../../components/ui';

export const Subscriptions = () => {
  const [subscriptions, setSubscriptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [extendTarget, setExtendTarget] = useState(null);
  const [extendDays, setExtendDays] = useState(30);
  const [saving, setSaving] = useState(false);

  const debouncedSearch = useDebounce(search, 350);
  const pagination = usePagination(1, 10);

  const fetchSubscriptions = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await adminService.getSubscriptions({
        search: debouncedSearch,
        status: statusFilter,
        page: pagination.page,
        limit: pagination.limit,
      });
      setSubscriptions(extractList(res));
      pagination.updateMeta(extractPagination(res, pagination.limit));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch, statusFilter, pagination.page, pagination.limit]);

  useEffect(() => {
    fetchSubscriptions();
  }, [fetchSubscriptions]);

  const handleExtend = async (e) => {
    e.preventDefault();
    if (!extendTarget) return;
    setSaving(true);
    try {
      await adminService.updateSubscription(extendTarget.id || extendTarget._id, {
        extendDays: Number(extendDays),
        status: 'ACTIVE',
      });
      toast.success(`Subscription extended by ${extendDays} days`);
      setExtendTarget(null);
      fetchSubscriptions();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = async (sub) => {
    try {
      await adminService.updateSubscription(sub.id || sub._id, { status: 'CANCELLED' });
      toast.success('Subscription cancelled');
      fetchSubscriptions();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const columns = [
    {
      key: 'gym',
      header: 'Gym',
      render: (row) => (
        <div>
          <p className="font-semibold text-text-primary">{row.gym?.name || row.gymName || '—'}</p>
          <p className="text-xs text-text-secondary">{row.gym?.owner?.mobile || ''}</p>
        </div>
      ),
    },
    {
      key: 'plan',
      header: 'Plan',
      render: (row) => <Badge variant="accent">{row.plan?.name || row.planName || 'Pro'}</Badge>,
    },
    {
      key: 'amount',
      header: 'Amount',
      render: (row) => formatCurrency(row.amount ?? row.plan?.monthlyPrice ?? 0),
    },
    {
      key: 'startDate',
      header: 'Start Date',
      render: (row) => formatDate(row.startDate || row.createdAt),
    },
    {
      key: 'endDate',
      header: 'Expires On',
      sortable: true,
      render: (row) => formatDate(row.endDate || row.expiresAt),
    },
    {
      key: 'status',
      header: 'Status',
      render: (row) => <Badge status={row.status || 'ACTIVE'} dot />,
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (row) => (
        <div className="inline-flex items-center gap-2">
          <Button
            size="xs"
            variant="secondary"
            icon={CalendarPlus}
            onClick={() => {
              setExtendTarget(row);
              setExtendDays(30);
            }}
          >
            Extend
          </Button>
          {String(row.status).toUpperCase() !== 'CANCELLED' && (
            <Button size="xs" variant="danger" icon={Ban} onClick={() => handleCancel(row)}>
              Cancel
            </Button>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Gym Subscriptions"
        subtitle="Track active plans, free trials, renewals, and expirations across all gyms"
      />

      <div className="flex flex-col sm:flex-row gap-3">
        <SearchInput
          placeholder="Search gym name..."
          value={search}
          onChange={(val) => {
            setSearch(val);
            pagination.resetPage();
          }}
          className="sm:max-w-sm"
        />
        <Select
          value={statusFilter}
          placeholder=""
          containerClassName="sm:w-48"
          options={[
            { value: 'ALL', label: 'All Statuses' },
            { value: 'ACTIVE', label: 'Active' },
            { value: 'TRIAL', label: 'Free Trial' },
            { value: 'EXPIRED', label: 'Expired' },
            { value: 'CANCELLED', label: 'Cancelled' },
          ]}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            pagination.resetPage();
          }}
        />
      </div>

      {error ? (
        <ErrorState message={error} onRetry={fetchSubscriptions} />
      ) : (
        <Table
          columns={columns}
          data={subscriptions}
          loading={loading}
          pagination={pagination}
          onPageChange={pagination.setPage}
          emptyTitle="No subscriptions found"
        />
      )}

      <Modal
        isOpen={Boolean(extendTarget)}
        onClose={() => setExtendTarget(null)}
        title="Extend Subscription"
        subtitle={extendTarget?.gym?.name || extendTarget?.gymName}
        size="sm"
      >
        <form onSubmit={handleExtend} className="space-y-4">
          <Input
            label="Extend Duration (Days)"
            type="number"
            min={1}
            max={365}
            required
            value={extendDays}
            onChange={(e) => setExtendDays(e.target.value)}
          />
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setExtendTarget(null)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              Apply Extension
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Subscriptions;

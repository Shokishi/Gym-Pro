import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Building2, Eye, Ban, CheckCircle2, MapPin, Phone, Users } from 'lucide-react';
import adminService from '../../services/adminService';
import { useDebounce } from '../../hooks/useDebounce';
import { usePagination } from '../../hooks/usePagination';
import { extractList, extractPagination, getErrorMessage } from '../../utils/apiHelpers';
import { formatDate } from '../../utils/formatters';
import {
  PageHeader,
  SearchInput,
  Select,
  Table,
  Badge,
  Button,
  Modal,
  ConfirmDialog,
  ErrorState,
} from '../../components/ui';

export const GymManagement = () => {
  const [gyms, setGyms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [selectedGym, setSelectedGym] = useState(null);
  const [actionTarget, setActionTarget] = useState(null);
  const [updating, setUpdating] = useState(false);

  const debouncedSearch = useDebounce(search, 350);
  const pagination = usePagination(1, 10);

  const fetchGyms = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await adminService.getGyms({
        search: debouncedSearch,
        status: statusFilter,
        page: pagination.page,
        limit: pagination.limit,
      });
      setGyms(extractList(res));
      pagination.updateMeta(extractPagination(res, pagination.limit));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch, statusFilter, pagination.page, pagination.limit]);

  useEffect(() => {
    fetchGyms();
  }, [fetchGyms]);

  const handleToggleStatus = async () => {
    if (!actionTarget) return;
    const id = actionTarget.id || actionTarget._id;
    const isSuspended = String(actionTarget.status).toUpperCase() === 'SUSPENDED';
    const nextStatus = isSuspended ? 'ACTIVE' : 'SUSPENDED';

    setUpdating(true);
    try {
      await adminService.updateGymStatus(id, nextStatus);
      toast.success(`Gym ${nextStatus === 'ACTIVE' ? 'activated' : 'suspended'} successfully`);
      setActionTarget(null);
      fetchGyms();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setUpdating(false);
    }
  };

  const columns = [
    {
      key: 'name',
      header: 'Gym Name',
      sortable: true,
      render: (row) => (
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-accent-light text-accent flex items-center justify-center shrink-0">
            <Building2 className="w-4 h-4" />
          </div>
          <div>
            <p className="font-semibold text-text-primary">{row.name}</p>
            <p className="text-xs text-text-secondary">{row.city || row.address || '—'}</p>
          </div>
        </div>
      ),
    },
    {
      key: 'owner',
      header: 'Owner',
      render: (row) => (
        <div>
          <p className="text-sm text-text-primary">{row.owner?.name || row.ownerName || '—'}</p>
          <p className="text-xs text-text-secondary">{row.owner?.mobile || row.phone || ''}</p>
        </div>
      ),
    },
    {
      key: 'plan',
      header: 'Plan',
      render: (row) => (
        <Badge variant="accent">{row.subscription?.plan?.name || row.planName || 'Trial'}</Badge>
      ),
    },
    {
      key: 'membersCount',
      header: 'Members',
      sortable: true,
      render: (row) => row.membersCount ?? row._count?.customers ?? 0,
    },
    {
      key: 'status',
      header: 'Status',
      render: (row) => <Badge status={row.status || 'ACTIVE'} dot />,
    },
    {
      key: 'createdAt',
      header: 'Joined',
      sortable: true,
      render: (row) => formatDate(row.createdAt),
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (row) => {
        const suspended = String(row.status).toUpperCase() === 'SUSPENDED';
        return (
          <div className="inline-flex items-center gap-2">
            <Button
              size="xs"
              variant="secondary"
              icon={Eye}
              onClick={(e) => {
                e.stopPropagation();
                setSelectedGym(row);
              }}
            >
              Details
            </Button>
            <Button
              size="xs"
              variant={suspended ? 'success' : 'danger'}
              icon={suspended ? CheckCircle2 : Ban}
              onClick={(e) => {
                e.stopPropagation();
                setActionTarget(row);
              }}
            >
              {suspended ? 'Activate' : 'Suspend'}
            </Button>
          </div>
        );
      },
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Gym Management"
        subtitle="Manage all registered gyms, subscription tiers, and account statuses"
      />

      <div className="flex flex-col sm:flex-row gap-3">
        <SearchInput
          placeholder="Search by gym name, city, or owner..."
          value={search}
          onChange={(val) => {
            setSearch(val);
            pagination.resetPage();
          }}
          className="sm:max-w-sm"
        />
        <Select
          value={statusFilter}
          placeholder=""
          containerClassName="sm:w-48"
          options={[
            { value: 'ALL', label: 'All Statuses' },
            { value: 'ACTIVE', label: 'Active' },
            { value: 'TRIAL', label: 'Trial' },
            { value: 'SUSPENDED', label: 'Suspended' },
            { value: 'EXPIRED', label: 'Expired' },
          ]}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            pagination.resetPage();
          }}
        />
      </div>

      {error ? (
        <ErrorState message={error} onRetry={fetchGyms} />
      ) : (
        <Table
          columns={columns}
          data={gyms}
          loading={loading}
          pagination={pagination}
          onPageChange={pagination.setPage}
          emptyTitle="No gyms match your filters"
        />
      )}

      <Modal
        isOpen={Boolean(selectedGym)}
        onClose={() => setSelectedGym(null)}
        title={selectedGym?.name || 'Gym Details'}
        subtitle="Tenant overview and statistics"
      >
        {selectedGym && (
          <div className="space-y-4 text-sm">
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-xl bg-dark-bg border border-dark-border">
                <p className="text-xs text-text-secondary flex items-center gap-1.5">
                  <Users className="w-3.5 h-3.5 text-accent" /> Total Members
                </p>
                <p className="text-lg font-bold mt-1">
                  {selectedGym.membersCount ?? selectedGym._count?.customers ?? 0}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-dark-bg border border-dark-border">
                <p className="text-xs text-text-secondary flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-accent" /> Contact
                </p>
                <p className="text-sm font-semibold mt-1">
                  {selectedGym.phone || selectedGym.owner?.mobile || '—'}
                </p>
              </div>
            </div>
            <div className="p-3.5 rounded-xl bg-dark-bg border border-dark-border space-y-1.5">
              <p className="text-xs text-text-secondary flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-accent" /> Location
              </p>
              <p className="text-text-primary">{selectedGym.address || 'Not provided'}</p>
              <p className="text-xs text-text-secondary">
                {[selectedGym.city, selectedGym.state].filter(Boolean).join(', ')}
              </p>
            </div>
            <div className="flex items-center justify-between pt-2">
              <span className="text-text-secondary">Account Status</span>
              <Badge status={selectedGym.status || 'ACTIVE'} dot />
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(actionTarget)}
        onClose={() => setActionTarget(null)}
        onConfirm={handleToggleStatus}
        loading={updating}
        variant={String(actionTarget?.status).toUpperCase() === 'SUSPENDED' ? 'warning' : 'danger'}
        title={
          String(actionTarget?.status).toUpperCase() === 'SUSPENDED'
            ? 'Activate Gym'
            : 'Suspend Gym'
        }
        message={`Are you sure you want to ${
          String(actionTarget?.status).toUpperCase() === 'SUSPENDED' ? 'activate' : 'suspend'
        } "${actionTarget?.name}"?`}
        confirmLabel={
          String(actionTarget?.status).toUpperCase() === 'SUSPENDED' ? 'Activate' : 'Suspend'
        }
      />
    </div>
  );
};

export default GymManagement;

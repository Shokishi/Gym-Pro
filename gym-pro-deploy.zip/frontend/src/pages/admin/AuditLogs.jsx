import React, { useState, useEffect, useCallback } from 'react';
import adminService from '../../services/adminService';
import { useDebounce } from '../../hooks/useDebounce';
import { usePagination } from '../../hooks/usePagination';
import { extractList, extractPagination, getErrorMessage } from '../../utils/apiHelpers';
import { formatDateTime } from '../../utils/formatters';
import {
  PageHeader,
  SearchInput,
  Select,
  Table,
  Badge,
  ErrorState,
} from '../../components/ui';

export const AuditLogs = () => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [actionFilter, setActionFilter] = useState('ALL');

  const debouncedSearch = useDebounce(search, 350);
  const pagination = usePagination(1, 15);

  const fetchLogs = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await adminService.getAuditLogs({
        search: debouncedSearch,
        action: actionFilter,
        page: pagination.page,
        limit: pagination.limit,
      });
      setLogs(extractList(res));
      pagination.updateMeta(extractPagination(res, pagination.limit));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch, actionFilter, pagination.page, pagination.limit]);

  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  const columns = [
    {
      key: 'createdAt',
      header: 'Timestamp',
      render: (row) => <span className="text-xs font-mono">{formatDateTime(row.createdAt)}</span>,
    },
    {
      key: 'actor',
      header: 'Actor',
      render: (row) => (
        <div>
          <p className="text-sm font-medium">{row.user?.name || row.actorName || 'System'}</p>
          <p className="text-xs text-text-secondary">{row.user?.role || row.actorRole || ''}</p>
        </div>
      ),
    },
    {
      key: 'action',
      header: 'Action',
      render: (row) => <Badge variant="accent">{row.action}</Badge>,
    },
    {
      key: 'resource',
      header: 'Entity',
      render: (row) => row.entity || row.resource || '—',
    },
    {
      key: 'description',
      header: 'Details',
      render: (row) => (
        <span className="text-xs text-text-secondary max-w-xs truncate block">
          {row.description || row.details || '—'}
        </span>
      ),
    },
    {
      key: 'ipAddress',
      header: 'IP Address',
      render: (row) => <span className="font-mono text-xs">{row.ipAddress || row.ip || '—'}</span>,
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Platform Audit Logs"
        subtitle="Immutable security trail of administrative and tenant actions"
      />

      <div className="flex flex-col sm:flex-row gap-3">
        <SearchInput
          placeholder="Search actor, resource, or details..."
          value={search}
          onChange={(v) => {
            setSearch(v);
            pagination.resetPage();
          }}
          className="sm:max-w-sm"
        />
        <Select
          value={actionFilter}
          placeholder=""
          containerClassName="sm:w-48"
          options={[
            { value: 'ALL', label: 'All Actions' },
            { value: 'CREATE', label: 'Create' },
            { value: 'UPDATE', label: 'Update' },
            { value: 'DELETE', label: 'Delete' },
            { value: 'LOGIN', label: 'Login' },
            { value: 'SUSPEND', label: 'Suspend' },
          ]}
          onChange={(e) => {
            setActionFilter(e.target.value);
            pagination.resetPage();
          }}
        />
      </div>

      {error ? (
        <ErrorState message={error} onRetry={fetchLogs} />
      ) : (
        <Table
          columns={columns}
          data={logs}
          loading={loading}
          pagination={pagination}
          onPageChange={pagination.setPage}
          emptyTitle="No audit logs found"
        />
      )}
    </div>
  );
};

export default AuditLogs;

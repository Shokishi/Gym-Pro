import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Clock, Save, BellRing } from 'lucide-react';
import adminService from '../../services/adminService';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { validateForm } from '../../utils/validators';
import { PageHeader, Card, Input, Toggle, Button, Skeleton, ErrorState } from '../../components/ui';

export const TrialSettings = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});

  const [form, setForm] = useState({
    trialDurationDays: 14,
    maxTrialMembers: 50,
    maxTrialBranches: 1,
    reminderDaysBeforeExpiry: '7,3,1',
    requirePhoneVerification: true,
    requireCardUpfront: false,
    autoSuspendOnExpiry: true,
    allowOneTrialPerPhone: true,
    gracePeriodDays: 3,
  });

  const loadSettings = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await adminService.getTrialSettings();
      const data = extractData(res);
      if (data) setForm((prev) => ({ ...prev, ...data }));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      trialDurationDays: { required: true, label: 'Trial Duration', min: 1, max: 90 },
      maxTrialMembers: { required: true, label: 'Max Trial Members', min: 1 },
      gracePeriodDays: { required: true, label: 'Grace Period', min: 0 },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSaving(true);
    try {
      await adminService.updateTrialSettings({
        ...form,
        trialDurationDays: Number(form.trialDurationDays),
        maxTrialMembers: Number(form.maxTrialMembers),
        maxTrialBranches: Number(form.maxTrialBranches),
        gracePeriodDays: Number(form.gracePeriodDays),
      });
      toast.success('Free trial settings updated');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Free Trial Settings"
        subtitle="Configure trial duration, expiry reminders, and eligibility policies"
      />

      {loading ? (
        <Skeleton variant="card" />
      ) : error ? (
        <ErrorState message={error} onRetry={loadSettings} />
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6 max-w-4xl">
          <Card title="Trial Duration & Quotas" icon={Clock}>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Free Trial Duration (Days)"
                type="number"
                required
                value={form.trialDurationDays}
                error={errors.trialDurationDays}
                onChange={(e) => {
                  setForm((p) => ({ ...p, trialDurationDays: e.target.value }));
                  setErrors((p) => ({ ...p, trialDurationDays: '' }));
                }}
              />
              <Input
                label="Grace Period After Expiry (Days)"
                type="number"
                value={form.gracePeriodDays}
                error={errors.gracePeriodDays}
                onChange={(e) => setForm((p) => ({ ...p, gracePeriodDays: e.target.value }))}
              />
              <Input
                label="Max Members During Trial"
                type="number"
                value={form.maxTrialMembers}
                error={errors.maxTrialMembers}
                onChange={(e) => setForm((p) => ({ ...p, maxTrialMembers: e.target.value }))}
              />
              <Input
                label="Max Branches During Trial"
                type="number"
                value={form.maxTrialBranches}
                onChange={(e) => setForm((p) => ({ ...p, maxTrialBranches: e.target.value }))}
              />
            </div>
          </Card>

          <Card title="Reminders & Eligibility Rules" icon={BellRing}>
            <div className="space-y-5">
              <Input
                label="Reminder Schedule (Days Before Expiry)"
                hint="Comma-separated days before expiry to notify gym owners (e.g. 7,3,1)"
                value={form.reminderDaysBeforeExpiry}
                onChange={(e) => setForm((p) => ({ ...p, reminderDaysBeforeExpiry: e.target.value }))}
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <Toggle
                  checked={Boolean(form.requirePhoneVerification)}
                  onChange={(v) => setForm((p) => ({ ...p, requirePhoneVerification: v }))}
                  label="Require OTP Verification"
                  description="Verify mobile number before activating trial"
                />
                <Toggle
                  checked={Boolean(form.allowOneTrialPerPhone)}
                  onChange={(v) => setForm((p) => ({ ...p, allowOneTrialPerPhone: v }))}
                  label="One Trial Per Mobile / Gym"
                  description="Prevent duplicate free trials on the same phone"
                />
                <Toggle
                  checked={Boolean(form.autoSuspendOnExpiry)}
                  onChange={(v) => setForm((p) => ({ ...p, autoSuspendOnExpiry: v }))}
                  label="Auto-Restrict After Grace Period"
                  description="Require plan upgrade once trial + grace ends"
                />
                <Toggle
                  checked={Boolean(form.requireCardUpfront)}
                  onChange={(v) => setForm((p) => ({ ...p, requireCardUpfront: v }))}
                  label="Require Payment Method Upfront"
                  description="Mandate card/UPI mandate during signup"
                />
              </div>
            </div>
          </Card>

          <div className="flex justify-end">
            <Button type="submit" loading={saving} icon={Save}>
              Save Trial Configuration
            </Button>
          </div>
        </form>
      )}
    </div>
  );
};

export default TrialSettings;

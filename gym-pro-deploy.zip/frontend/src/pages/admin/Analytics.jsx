import React, { useState, useEffect, useCallback } from 'react';
import { TrendingUp, Building2, IndianRupee, Percent } from 'lucide-react';
import adminService from '../../services/adminService';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatNumber, getDateRangeFromPreset } from '../../utils/formatters';
import {
  PageHeader,
  Stat,
  Card,
  DateRangeFilter,
  Skeleton,
  ErrorState,
} from '../../components/ui';
import { RevenueChart, GrowthChart, MembershipChart, AttendanceChart } from '../../components/charts';

export const Analytics = () => {
  const [preset, setPreset] = useState('30d');
  const [customDates, setCustomDates] = useState({ startDate: '', endDate: '' });
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchAnalytics = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const range = getDateRangeFromPreset(preset, customDates.startDate, customDates.endDate);
      const res = await adminService.getAnalytics({ preset, ...range });
      setData(extractData(res, {}));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [preset, customDates.startDate, customDates.endDate]);

  useEffect(() => {
    fetchAnalytics();
  }, [fetchAnalytics]);

  const kpis = data?.kpis || data || {};

  return (
    <div className="space-y-6">
      <PageHeader
        title="Platform Analytics"
        subtitle="MRR/ARR trends, trial conversion funnel, churn metrics, and tenant adoption"
        actions={
          <DateRangeFilter
            preset={preset}
            onPresetChange={setPreset}
            startDate={customDates.startDate}
            endDate={customDates.endDate}
            onCustomChange={setCustomDates}
          />
        }
      />

      {loading ? (
        <div className="space-y-6">
          <Skeleton variant="stats" count={4} />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Skeleton variant="card" />
            <Skeleton variant="card" />
          </div>
        </div>
      ) : error ? (
        <ErrorState message={error} onRetry={fetchAnalytics} />
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
            <Stat
              label="Monthly Recurring Revenue"
              value={formatCurrency(kpis.mrr || 0)}
              icon={IndianRupee}
              color="accent"
              trend={kpis.mrrGrowth}
            />
            <Stat
              label="Trial Conversion Rate"
              value={`${kpis.trialConversionRate ?? 0}%`}
              icon={Percent}
              color="success"
            />
            <Stat
              label="Churn Rate"
              value={`${kpis.churnRate ?? 0}%`}
              icon={TrendingUp}
              color="warning"
            />
            <Stat
              label="Total Gyms"
              value={formatNumber(kpis.totalGyms || 0)}
              icon={Building2}
              color="info"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card title="MRR & Revenue Trajectory">
              <RevenueChart data={data?.revenueSeries || []} type="bar" />
            </Card>
            <Card title="Tenant Growth & Conversions">
              <GrowthChart
                data={data?.growthSeries || []}
                lines={[
                  { key: 'gyms', name: 'Active Gyms', color: '#F28C28' },
                  { key: 'trials', name: 'New Trials', color: '#3B82F6' },
                ]}
              />
            </Card>
            <Card title="Subscription Tier Distribution">
              <MembershipChart data={data?.planDistribution || []} />
            </Card>
            <Card title="Platform Check-In Activity">
              <AttendanceChart data={data?.activitySeries || []} />
            </Card>
          </div>
        </>
      )}
    </div>
  );
};

export default Analytics;

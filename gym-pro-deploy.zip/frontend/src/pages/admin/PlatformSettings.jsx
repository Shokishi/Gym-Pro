import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Settings, Save, CreditCard, Shield } from 'lucide-react';
import adminService from '../../services/adminService';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { validateForm } from '../../utils/validators';
import { PageHeader, Card, Input, Toggle, Button, Skeleton, ErrorState } from '../../components/ui';

export const PlatformSettings = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});

  const [form, setForm] = useState({
    platformName: 'GYM PRO',
    supportEmail: 'support@gympro.app',
    supportPhone: '',
    gstPercentage: 18,
    upiId: '',
    upiName: 'GYM PRO SaaS',
    maintenanceMode: false,
    allowSelfRegistration: true,
    enableCustomDomains: true,
  });

  const loadSettings = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await adminService.getPlatformSettings();
      const data = extractData(res);
      if (data) setForm((p) => ({ ...p, ...data }));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      platformName: { required: true, label: 'Platform Name' },
      supportEmail: { required: true, label: 'Support Email', email: true },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSaving(true);
    try {
      await adminService.updatePlatformSettings({
        ...form,
        gstPercentage: Number(form.gstPercentage || 0),
      });
      toast.success('Platform settings saved');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Platform Settings"
        subtitle="Global SaaS configuration, taxation, billing UPI, and operational switches"
      />

      {loading ? (
        <Skeleton variant="card" />
      ) : error ? (
        <ErrorState message={error} onRetry={loadSettings} />
      ) : (
        <form onSubmit={handleSave} className="space-y-6 max-w-4xl">
          <Card title="General Brand & Support" icon={Settings}>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Platform Name"
                required
                value={form.platformName}
                error={errors.platformName}
                onChange={(e) => setForm((p) => ({ ...p, platformName: e.target.value }))}
              />
              <Input
                label="Support Email"
                type="email"
                required
                value={form.supportEmail}
                error={errors.supportEmail}
                onChange={(e) => setForm((p) => ({ ...p, supportEmail: e.target.value }))}
              />
              <Input
                label="Support Phone"
                value={form.supportPhone}
                onChange={(e) => setForm((p) => ({ ...p, supportPhone: e.target.value }))}
              />
              <Input
                label="Default Tax / GST (%)"
                type="number"
                value={form.gstPercentage}
                onChange={(e) => setForm((p) => ({ ...p, gstPercentage: e.target.value }))}
              />
            </div>
          </Card>

          <Card title="SaaS Billing Collection (UPI)" icon={CreditCard}>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Platform Collection UPI ID"
                placeholder="gympro@icici"
                value={form.upiId}
                onChange={(e) => setForm((p) => ({ ...p, upiId: e.target.value }))}
              />
              <Input
                label="Payee Display Name"
                value={form.upiName}
                onChange={(e) => setForm((p) => ({ ...p, upiName: e.target.value }))}
              />
            </div>
          </Card>

          <Card title="System Switches" icon={Shield}>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <Toggle
                checked={Boolean(form.allowSelfRegistration)}
                onChange={(v) => setForm((p) => ({ ...p, allowSelfRegistration: v }))}
                label="Allow New Gym Registrations"
                description="Enable self-serve gym onboarding on landing page"
              />
              <Toggle
                checked={Boolean(form.enableCustomDomains)}
                onChange={(v) => setForm((p) => ({ ...p, enableCustomDomains: v }))}
                label="Custom White-Label Domains"
                description="Allow enterprise tenants to request custom domains"
              />
              <Toggle
                checked={Boolean(form.maintenanceMode)}
                onChange={(v) => setForm((p) => ({ ...p, maintenanceMode: v }))}
                label="Platform Maintenance Mode"
                description="Temporarily pause non-admin portal writes"
              />
            </div>
          </Card>

          <div className="flex justify-end">
            <Button type="submit" loading={saving} icon={Save}>
              Save Platform Settings
            </Button>
          </div>
        </form>
      )}
    </div>
  );
};

export default PlatformSettings;

import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { BadgeDollarSign, Save } from 'lucide-react';
import adminService from '../../services/adminService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { PageHeader, Card, Input, Button, Toggle, Skeleton, ErrorState } from '../../components/ui';

export const PricingManagement = () => {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [savingId, setSavingId] = useState(null);

  const loadPlans = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await adminService.getPlans();
      setPlans(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPlans();
  }, [loadPlans]);

  const updatePlanField = (idx, field, value) => {
    setPlans((prev) => prev.map((p, i) => (i === idx ? { ...p, [field]: value } : p)));
  };

  const handleSaveTier = async (plan) => {
    const id = plan.id || plan._id;
    setSavingId(id);
    try {
      await adminService.updatePlan(id, {
        monthlyPrice: Number(plan.monthlyPrice || 0),
        yearlyPrice: Number(plan.yearlyPrice || 0),
        maxMembers: Number(plan.maxMembers || 100),
        maxBranches: Number(plan.maxBranches || 1),
        maxTrainers: Number(plan.maxTrainers || 10),
        isActive: plan.isActive !== false,
      });
      toast.success(`Pricing updated for ${plan.name}`);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSavingId(null);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Pricing & Limits Matrix"
        subtitle="Fine-tune tier pricing, member caps, branch quotas, and trainer limits"
      />

      {loading ? (
        <div className="space-y-4">
          <Skeleton variant="card" />
          <Skeleton variant="card" />
        </div>
      ) : error ? (
        <ErrorState message={error} onRetry={loadPlans} />
      ) : (
        <div className="space-y-4">
          {plans.map((plan, idx) => {
            const id = plan.id || plan._id || idx;
            return (
              <Card
                key={id}
                title={plan.name}
                subtitle={plan.description || 'Subscription tier pricing & capacity limits'}
                icon={BadgeDollarSign}
                actions={
                  <div className="flex items-center gap-4">
                    <Toggle
                      checked={plan.isActive !== false}
                      onChange={(val) => updatePlanField(idx, 'isActive', val)}
                      label="Active"
                    />
                    <Button
                      size="sm"
                      icon={Save}
                      loading={savingId === id}
                      onClick={() => handleSaveTier(plan)}
                    >
                      Save Tier
                    </Button>
                  </div>
                }
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                  <Input
                    label="Monthly Price (₹)"
                    type="number"
                    value={plan.monthlyPrice ?? plan.price ?? ''}
                    onChange={(e) => updatePlanField(idx, 'monthlyPrice', e.target.value)}
                  />
                  <Input
                    label="Yearly Price (₹)"
                    type="number"
                    value={plan.yearlyPrice ?? ''}
                    onChange={(e) => updatePlanField(idx, 'yearlyPrice', e.target.value)}
                  />
                  <Input
                    label="Max Members"
                    type="number"
                    value={plan.maxMembers ?? ''}
                    onChange={(e) => updatePlanField(idx, 'maxMembers', e.target.value)}
                  />
                  <Input
                    label="Max Branches"
                    type="number"
                    value={plan.maxBranches ?? ''}
                    onChange={(e) => updatePlanField(idx, 'maxBranches', e.target.value)}
                  />
                  <Input
                    label="Max Trainers"
                    type="number"
                    value={plan.maxTrainers ?? ''}
                    onChange={(e) => updatePlanField(idx, 'maxTrainers', e.target.value)}
                  />
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default PricingManagement;

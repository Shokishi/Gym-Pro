import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Plus, Trash2, Edit2 } from 'lucide-react';
import couponService from '../../services/couponService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { validateForm } from '../../utils/validators';
import {
  PageHeader,
  SearchInput,
  Table,
  Badge,
  Button,
  Modal,
  Input,
  Select,
  Toggle,
  ConfirmDialog,
  ErrorState,
} from '../../components/ui';

const INITIAL_FORM = {
  code: '',
  discountType: 'PERCENTAGE',
  discountValue: '',
  maxUses: 100,
  minAmount: 0,
  expiresAt: '',
  isActive: true,
};

export const CouponsOffers = () => {
  const [coupons, setCoupons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(INITIAL_FORM);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const fetchCoupons = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await couponService.getAll({ search });
      setCoupons(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [search]);

  useEffect(() => {
    fetchCoupons();
  }, [fetchCoupons]);

  const openModal = (coupon = null) => {
    setEditing(coupon);
    setForm(
      coupon
        ? {
            code: coupon.code || '',
            discountType: coupon.discountType || 'PERCENTAGE',
            discountValue: coupon.discountValue ?? '',
            maxUses: coupon.maxUses ?? 100,
            minAmount: coupon.minAmount ?? 0,
            expiresAt: coupon.expiresAt ? String(coupon.expiresAt).slice(0, 10) : '',
            isActive: coupon.isActive !== false,
          }
        : INITIAL_FORM
    );
    setErrors({});
    setModalOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      code: { required: true, label: 'Coupon Code', minLength: 3 },
      discountValue: { required: true, label: 'Discount Value', min: 1 },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSaving(true);
    try {
      const payload = {
        ...form,
        code: form.code.trim().toUpperCase(),
        discountValue: Number(form.discountValue),
        maxUses: Number(form.maxUses || 100),
        minAmount: Number(form.minAmount || 0),
      };
      if (editing) {
        await couponService.update(editing.id || editing._id, payload);
        toast.success('Coupon updated');
      } else {
        await couponService.create(payload);
        toast.success('Coupon created');
      }
      setModalOpen(false);
      fetchCoupons();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleToggle = async (coupon) => {
    try {
      await couponService.toggleStatus(coupon.id || coupon._id, !(coupon.isActive !== false));
      toast.success('Coupon status updated');
      fetchCoupons();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await couponService.delete(deleteTarget.id || deleteTarget._id);
      toast.success('Coupon deleted');
      setDeleteTarget(null);
      fetchCoupons();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  const columns = [
    {
      key: 'code',
      header: 'Promo Code',
      render: (row) => (
        <span className="font-mono font-bold text-accent bg-accent-light px-2.5 py-1 rounded-md">
          {row.code}
        </span>
      ),
    },
    {
      key: 'discount',
      header: 'Discount',
      render: (row) =>
        row.discountType === 'PERCENTAGE'
          ? `${row.discountValue}% OFF`
          : `${formatCurrency(row.discountValue)} OFF`,
    },
    {
      key: 'usage',
      header: 'Usage',
      render: (row) => `${row.usedCount ?? 0} / ${row.maxUses ?? '∞'}`,
    },
    {
      key: 'expiresAt',
      header: 'Expires',
      render: (row) => formatDate(row.expiresAt),
    },
    {
      key: 'status',
      header: 'Status',
      render: (row) => (
        <Toggle
          checked={row.isActive !== false}
          onChange={() => handleToggle(row)}
        />
      ),
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (row) => (
        <div className="inline-flex items-center gap-2">
          <Button size="xs" variant="secondary" icon={Edit2} onClick={() => openModal(row)}>
            Edit
          </Button>
          <Button size="xs" variant="danger" icon={Trash2} onClick={() => setDeleteTarget(row)} />
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Coupons & Promotional Offers"
        subtitle="Create discount promo codes for SaaS plan upgrades and renewals"
        actions={
          <Button icon={Plus} onClick={() => openModal()}>
            Create Coupon
          </Button>
        }
      />

      <SearchInput
        placeholder="Search promo code..."
        value={search}
        onChange={setSearch}
        className="sm:max-w-sm"
      />

      {error ? (
        <ErrorState message={error} onRetry={fetchCoupons} />
      ) : (
        <Table
          columns={columns}
          data={coupons}
          loading={loading}
          emptyTitle="No coupons created yet"
        />
      )}

      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Edit Coupon' : 'Create Coupon'}
      >
        <form onSubmit={handleSave} className="space-y-4">
          <Input
            label="Coupon Code"
            required
            placeholder="e.g. GYMPRO20"
            value={form.code}
            error={errors.code}
            onChange={(e) => {
              setForm((p) => ({ ...p, code: e.target.value.toUpperCase() }));
              setErrors((p) => ({ ...p, code: '' }));
            }}
          />
          <div className="grid grid-cols-2 gap-4">
            <Select
              label="Discount Type"
              value={form.discountType}
              options={[
                { value: 'PERCENTAGE', label: 'Percentage (%)' },
                { value: 'FLAT', label: 'Flat Amount (₹)' },
              ]}
              onChange={(e) => setForm((p) => ({ ...p, discountType: e.target.value }))}
            />
            <Input
              label="Discount Value"
              type="number"
              required
              value={form.discountValue}
              error={errors.discountValue}
              onChange={(e) => setForm((p) => ({ ...p, discountValue: e.target.value }))}
            />
            <Input
              label="Max Redemptions"
              type="number"
              value={form.maxUses}
              onChange={(e) => setForm((p) => ({ ...p, maxUses: e.target.value }))}
            />
            <Input
              label="Expiry Date"
              type="date"
              value={form.expiresAt}
              onChange={(e) => setForm((p) => ({ ...p, expiresAt: e.target.value }))}
            />
          </div>
          <Toggle
            checked={form.isActive}
            onChange={(v) => setForm((p) => ({ ...p, isActive: v }))}
            label="Coupon is Active"
          />
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              {editing ? 'Update Coupon' : 'Create Coupon'}
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Coupon"
        message={`Delete promo code "${deleteTarget?.code}"?`}
        confirmLabel="Delete"
      />
    </div>
  );
};

export default CouponsOffers;

import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Ban, CheckCircle2 } from 'lucide-react';
import adminService from '../../services/adminService';
import { useDebounce } from '../../hooks/useDebounce';
import { usePagination } from '../../hooks/usePagination';
import { extractList, extractPagination, getErrorMessage } from '../../utils/apiHelpers';
import { formatDate } from '../../utils/formatters';
import {
  PageHeader,
  SearchInput,
  Select,
  Table,
  Avatar,
  Badge,
  Button,
  ConfirmDialog,
  ErrorState,
} from '../../components/ui';

export const AllUsers = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('ALL');
  const [targetUser, setTargetUser] = useState(null);
  const [updating, setUpdating] = useState(false);

  const debouncedSearch = useDebounce(search, 350);
  const pagination = usePagination(1, 12);

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await adminService.getUsers({
        search: debouncedSearch,
        role: roleFilter,
        page: pagination.page,
        limit: pagination.limit,
      });
      setUsers(extractList(res));
      pagination.updateMeta(extractPagination(res, pagination.limit));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch, roleFilter, pagination.page, pagination.limit]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const handleToggleUser = async () => {
    if (!targetUser) return;
    const isInactive = String(targetUser.status).toUpperCase() === 'SUSPENDED' || targetUser.isActive === false;
    const nextStatus = isInactive ? 'ACTIVE' : 'SUSPENDED';

    setUpdating(true);
    try {
      await adminService.updateUserStatus(targetUser.id || targetUser._id, nextStatus);
      toast.success(`User status updated to ${nextStatus}`);
      setTargetUser(null);
      fetchUsers();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setUpdating(false);
    }
  };

  const columns = [
    {
      key: 'name',
      header: 'User',
      sortable: true,
      render: (row) => (
        <div className="flex items-center gap-3">
          <Avatar src={row.avatar} name={row.name} size="sm" />
          <div>
            <p className="font-medium text-text-primary">{row.name}</p>
            <p className="text-xs text-text-secondary">{row.email || row.mobile || row.phone}</p>
          </div>
        </div>
      ),
    },
    {
      key: 'mobile',
      header: 'Mobile',
      render: (row) => row.mobile || row.phone || '—',
    },
    {
      key: 'role',
      header: 'Role',
      render: (row) => <Badge variant={row.role}>{row.role}</Badge>,
    },
    {
      key: 'gym',
      header: 'Gym',
      render: (row) => row.gym?.name || row.gymName || 'Platform',
    },
    {
      key: 'status',
      header: 'Status',
      render: (row) => (
        <Badge status={row.status || (row.isActive === false ? 'INACTIVE' : 'ACTIVE')} dot />
      ),
    },
    {
      key: 'createdAt',
      header: 'Joined',
      sortable: true,
      render: (row) => formatDate(row.createdAt),
    },
    {
      key: 'actions',
      header: 'Action',
      align: 'right',
      render: (row) => {
        const suspended = String(row.status).toUpperCase() === 'SUSPENDED' || row.isActive === false;
        return (
          <Button
            size="xs"
            variant={suspended ? 'success' : 'secondary'}
            icon={suspended ? CheckCircle2 : Ban}
            onClick={() => setTargetUser(row)}
          >
            {suspended ? 'Enable' : 'Suspend'}
          </Button>
        );
      },
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="All Platform Users"
        subtitle="Directory of gym owners, trainers, customers, and administrators"
      />

      <div className="flex flex-col sm:flex-row gap-3">
        <SearchInput
          placeholder="Search name, mobile, or email..."
          value={search}
          onChange={(val) => {
            setSearch(val);
            pagination.resetPage();
          }}
          className="sm:max-w-sm"
        />
        <Select
          value={roleFilter}
          placeholder=""
          containerClassName="sm:w-48"
          options={[
            { value: 'ALL', label: 'All Roles' },
            { value: 'OWNER', label: 'Gym Owners' },
            { value: 'TRAINER', label: 'Trainers' },
            { value: 'CUSTOMER', label: 'Customers' },
            { value: 'ADMIN', label: 'Super Admins' },
          ]}
          onChange={(e) => {
            setRoleFilter(e.target.value);
            pagination.resetPage();
          }}
        />
      </div>

      {error ? (
        <ErrorState message={error} onRetry={fetchUsers} />
      ) : (
        <Table
          columns={columns}
          data={users}
          loading={loading}
          pagination={pagination}
          onPageChange={pagination.setPage}
          emptyTitle="No users found"
        />
      )}

      <ConfirmDialog
        isOpen={Boolean(targetUser)}
        onClose={() => setTargetUser(null)}
        onConfirm={handleToggleUser}
        loading={updating}
        title="Update User Status"
        message={`Change account access status for ${targetUser?.name}?`}
        confirmLabel="Confirm"
      />
    </div>
  );
};

export default AllUsers;

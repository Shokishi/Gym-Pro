import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { MessageSquare, CheckCircle2, Send } from 'lucide-react';
import adminService from '../../services/adminService';
import { useDebounce } from '../../hooks/useDebounce';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatDateTime } from '../../utils/formatters';
import {
  PageHeader,
  SearchInput,
  Select,
  Table,
  Badge,
  Button,
  Modal,
  Textarea,
  ErrorState,
} from '../../components/ui';

export const CustomerSupport = () => {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [activeTicket, setActiveTicket] = useState(null);
  const [replyText, setReplyText] = useState('');
  const [sending, setSending] = useState(false);

  const debouncedSearch = useDebounce(search, 350);

  const fetchTickets = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await adminService.getTickets({
        search: debouncedSearch,
        status: statusFilter,
      });
      setTickets(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [debouncedSearch, statusFilter]);

  useEffect(() => {
    fetchTickets();
  }, [fetchTickets]);

  const handleReply = async (e) => {
    e.preventDefault();
    if (!replyText.trim() || !activeTicket) return;
    setSending(true);
    try {
      await adminService.replyTicket(activeTicket.id || activeTicket._id, {
        message: replyText.trim(),
      });
      toast.success('Reply sent');
      setReplyText('');
      setActiveTicket(null);
      fetchTickets();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSending(false);
    }
  };

  const handleResolve = async (ticket) => {
    try {
      await adminService.updateTicketStatus(ticket.id || ticket._id, 'RESOLVED');
      toast.success('Ticket marked as resolved');
      fetchTickets();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const columns = [
    {
      key: 'subject',
      header: 'Ticket Subject',
      render: (row) => (
        <div>
          <p className="font-semibold text-text-primary">{row.subject || row.title}</p>
          <p className="text-xs text-text-secondary line-clamp-1">{row.message || row.description}</p>
        </div>
      ),
    },
    {
      key: 'requester',
      header: 'Gym / User',
      render: (row) => (
        <div>
          <p className="text-sm">{row.user?.name || row.gym?.name || 'Gym Owner'}</p>
          <p className="text-xs text-text-secondary">{row.user?.mobile || ''}</p>
        </div>
      ),
    },
    {
      key: 'priority',
      header: 'Priority',
      render: (row) => (
        <Badge
          variant={
            String(row.priority).toUpperCase() === 'HIGH'
              ? 'error'
              : String(row.priority).toUpperCase() === 'MEDIUM'
              ? 'warning'
              : 'neutral'
          }
        >
          {row.priority || 'MEDIUM'}
        </Badge>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      render: (row) => <Badge status={row.status || 'OPEN'} dot />,
    },
    {
      key: 'createdAt',
      header: 'Created',
      render: (row) => formatDateTime(row.createdAt),
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (row) => (
        <div className="inline-flex items-center gap-2">
          <Button
            size="xs"
            variant="secondary"
            icon={MessageSquare}
            onClick={() => setActiveTicket(row)}
          >
            Reply
          </Button>
          {String(row.status).toUpperCase() !== 'RESOLVED' && (
            <Button
              size="xs"
              variant="success"
              icon={CheckCircle2}
              onClick={() => handleResolve(row)}
            >
              Resolve
            </Button>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Customer Support Tickets"
        subtitle="Respond to gym owner inquiries, billing disputes, and technical support requests"
      />

      <div className="flex flex-col sm:flex-row gap-3">
        <SearchInput
          placeholder="Search ticket subject or gym..."
          value={search}
          onChange={setSearch}
          className="sm:max-w-sm"
        />
        <Select
          value={statusFilter}
          placeholder=""
          containerClassName="sm:w-48"
          options={[
            { value: 'ALL', label: 'All Tickets' },
            { value: 'OPEN', label: 'Open' },
            { value: 'IN_PROGRESS', label: 'In Progress' },
            { value: 'RESOLVED', label: 'Resolved' },
          ]}
          onChange={(e) => setStatusFilter(e.target.value)}
        />
      </div>

      {error ? (
        <ErrorState message={error} onRetry={fetchTickets} />
      ) : (
        <Table
          columns={columns}
          data={tickets}
          loading={loading}
          emptyTitle="No support tickets"
          emptyMessage="All support requests have been addressed."
        />
      )}

      <Modal
        isOpen={Boolean(activeTicket)}
        onClose={() => setActiveTicket(null)}
        title={activeTicket?.subject || 'Ticket Conversation'}
        subtitle={`From ${activeTicket?.user?.name || activeTicket?.gym?.name || 'User'}`}
      >
        {activeTicket && (
          <form onSubmit={handleReply} className="space-y-4">
            <div className="p-4 rounded-xl bg-dark-bg border border-dark-border text-sm text-text-secondary">
              {activeTicket.message || activeTicket.description}
            </div>
            <Textarea
              label="Support Response"
              required
              rows={4}
              placeholder="Write your response..."
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
            />
            <div className="flex justify-end gap-3">
              <Button variant="secondary" onClick={() => setActiveTicket(null)}>
                Close
              </Button>
              <Button type="submit" loading={sending} icon={Send}>
                Send Reply
              </Button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
};

export default CustomerSupport;

import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import {
  Building2,
  Users,
  IndianRupee,
  CreditCard,
  TrendingUp,
  ArrowRight,
  Clock,
} from 'lucide-react';
import adminService from '../../services/adminService';
import { extractData } from '../../utils/apiHelpers';
import { formatCurrency, formatDate, formatNumber, getDateRangeFromPreset } from '../../utils/formatters';
import {
  PageHeader,
  Stat,
  Card,
  Badge,
  Skeleton,
  ErrorState,
  DateRangeFilter,
  Button,
} from '../../components/ui';
import { RevenueChart, GrowthChart, MembershipChart } from '../../components/charts';

export const AdminDashboard = () => {
  const [preset, setPreset] = useState('30d');
  const [customDates, setCustomDates] = useState({ startDate: '', endDate: '' });
  const [dashboard, setDashboard] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const range = getDateRangeFromPreset(preset, customDates.startDate, customDates.endDate);
      const res = await adminService.getDashboard({ preset, ...range });
      setDashboard(extractData(res, {}));
    } catch (err) {
      setError(err?.response?.data?.message || 'Unable to load platform dashboard metrics.');
    } finally {
      setLoading(false);
    }
  }, [preset, customDates.startDate, customDates.endDate]);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  const stats = dashboard?.stats || dashboard || {};
  const revenueTrend = dashboard?.revenueChart || dashboard?.revenueSeries || [];
  const registrationTrend = dashboard?.registrationChart || dashboard?.growthSeries || [];
  const planDistribution = dashboard?.planDistribution || dashboard?.subscriptionBreakdown || [];
  const recentGyms = dashboard?.recentGyms || [];
  const pendingPayments = dashboard?.pendingPayments || [];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Platform Overview"
        subtitle="Monitor gyms, SaaS subscriptions, revenue, and trial conversions"
        actions={
          <DateRangeFilter
            preset={preset}
            onPresetChange={setPreset}
            startDate={customDates.startDate}
            endDate={customDates.endDate}
            onCustomChange={setCustomDates}
          />
        }
      />

      {loading ? (
        <div className="space-y-6">
          <Skeleton variant="stats" count={4} />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Skeleton variant="card" />
            <Skeleton variant="card" />
          </div>
        </div>
      ) : error ? (
        <ErrorState message={error} onRetry={loadDashboard} />
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
            <Stat
              label="Total SaaS Revenue"
              value={formatCurrency(stats.totalRevenue || 0)}
              icon={IndianRupee}
              color="accent"
              trend={stats.revenueGrowth}
              trendLabel="vs prior period"
            />
            <Stat
              label="Active Gyms"
              value={formatNumber(stats.activeGyms ?? stats.totalGyms ?? 0)}
              icon={Building2}
              color="success"
              trend={stats.gymGrowth}
              trendLabel={`${formatNumber(stats.trialGyms || 0)} on free trial`}
            />
            <Stat
              label="Active Subscriptions"
              value={formatNumber(stats.activeSubscriptions || 0)}
              icon={CreditCard}
              color="info"
              subtitle={`Trial conversion: ${stats.trialConversionRate ?? 0}%`}
            />
            <Stat
              label="Platform Users"
              value={formatNumber(stats.totalUsers || 0)}
              icon={Users}
              color="warning"
              subtitle={`${formatNumber(stats.newRegistrations || 0)} new signups`}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card title="SaaS Subscription Revenue" subtitle="Recurring & plan upgrade earnings">
              <RevenueChart data={revenueTrend} />
            </Card>
            <Card title="Gym Registrations & Trials" subtitle="New tenant onboarding velocity">
              <GrowthChart
                data={registrationTrend}
                lines={[
                  { key: 'registrations', name: 'Registrations', color: '#F28C28' },
                  { key: 'conversions', name: 'Trial Conversions', color: '#27AE60' },
                ]}
              />
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card title="Subscriptions by Plan" className="lg:col-span-1">
              <MembershipChart data={planDistribution} />
            </Card>

            <Card
              title="Recently Onboarded Gyms"
              className="lg:col-span-2"
              actions={
                <Link to="/admin/gyms">
                  <Button variant="ghost" size="xs" rightIcon={ArrowRight}>
                    View All Gyms
                  </Button>
                </Link>
              }
            >
              {recentGyms.length === 0 ? (
                <p className="text-sm text-text-secondary py-6 text-center">
                  No recent gym registrations found.
                </p>
              ) : (
                <div className="divide-y divide-dark-border/60">
                  {recentGyms.slice(0, 5).map((g) => (
                    <div
                      key={g.id || g._id}
                      className="py-3 flex items-center justify-between gap-4"
                    >
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-text-primary truncate">{g.name}</p>
                        <p className="text-xs text-text-secondary truncate">
                          {g.owner?.name || g.ownerName || 'Owner'} • {g.city || 'India'} •{' '}
                          {formatDate(g.createdAt)}
                        </p>
                      </div>
                      <Badge status={g.status || 'active'} dot />
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>

          {pendingPayments.length > 0 && (
            <Card
              title="Pending Subscription Payment Verifications"
              icon={Clock}
              actions={
                <Link to="/admin/subscription-payments">
                  <Button size="xs" rightIcon={TrendingUp}>
                    Review Queue
                  </Button>
                </Link>
              }
            >
              <div className="divide-y divide-dark-border/60">
                {pendingPayments.slice(0, 4).map((p) => (
                  <div key={p.id || p._id} className="py-3 flex items-center justify-between gap-4">
                    <div>
                      <p className="text-sm font-medium text-text-primary">
                        {p.gym?.name || p.gymName} — {p.plan?.name || p.planName}
                      </p>
                      <p className="text-xs text-text-secondary">
                        Ref: {p.transactionId || p.referenceNumber || 'N/A'} •{' '}
                        {formatDate(p.createdAt)}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-bold text-accent">
                        {formatCurrency(p.amount)}
                      </span>
                      <Badge status="pending" />
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </>
      )}
    </div>
  );
};

export default AdminDashboard;

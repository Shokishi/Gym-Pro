import React, { useState, useEffect, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Plus, CreditCard } from 'lucide-react';
import paymentService from '../../services/paymentService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDateTime } from '../../utils/formatters';
import { PageHeader, Card, Badge, Button, Skeleton, EmptyState, ErrorState } from '../../components/ui';

export const CustomerPayments = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const base = location.pathname.startsWith('/app') ? '/app' : '/customer';

  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadPayments = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await paymentService.getMyPayments();
      setPayments(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPayments();
  }, [loadPayments]);

  return (
    <div className="space-y-5">
      <PageHeader
        title="My Payments"
        subtitle="View fee receipts, verification statuses, and submit new UPI payments"
        actions={
          <Button size="sm" icon={Plus} onClick={() => navigate(`${base}/payments/new`)}>
            Make Payment
          </Button>
        }
      />

      {loading ? (
        <Skeleton variant="list" rows={4} />
      ) : error ? (
        <ErrorState message={error} onRetry={loadPayments} />
      ) : payments.length === 0 ? (
        <Card>
          <EmptyState
            icon={CreditCard}
            title="No payment history"
            message="Your gym fee payments and UPI submissions will appear here."
            action={
              <Button icon={Plus} onClick={() => navigate(`${base}/payments/new`)}>
                Submit Payment
              </Button>
            }
          />
        </Card>
      ) : (
        <div className="space-y-3">
          {payments.map((p) => (
            <div
              key={p.id || p._id}
              className="bg-dark-surface border border-dark-border rounded-xl p-4 flex items-center justify-between gap-4"
            >
              <div>
                <p className="font-semibold text-sm text-text-primary">
                  {p.description || p.plan?.name || 'Gym Membership Fee'}
                </p>
                <p className="text-xs text-text-secondary mt-0.5">
                  {p.paymentMethod || p.method || 'UPI'}
                  {p.transactionId ? ` • Ref: ${p.transactionId}` : ''} •{' '}
                  {formatDateTime(p.paidAt || p.createdAt)}
                </p>
              </div>
              <div className="text-right shrink-0">
                <p className="text-base font-bold text-accent">{formatCurrency(p.amount)}</p>
                <Badge status={p.status || 'PENDING'} dot className="mt-1" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CustomerPayments;

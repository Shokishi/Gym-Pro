import React, { useState, useEffect, useCallback } from 'react';
import { Utensils, CheckCircle2, Circle } from 'lucide-react';
import dietService from '../../services/dietService';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { PageHeader, Card, Badge, Skeleton, EmptyState, ErrorState } from '../../components/ui';

export const CustomerDiet = () => {
  const [diet, setDiet] = useState(null);
  const [checkedMeals, setCheckedMeals] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadDiet = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await dietService.getMyDiet();
      const data = extractData(res);
      const activeDiet = Array.isArray(data) ? data[0] : data;
      setDiet(activeDiet || null);
      if (activeDiet?.meals) {
        setCheckedMeals(
          new Set(
            activeDiet.meals
              .filter((m) => m.completed)
              .map((m, idx) => String(m.id || m._id || idx))
          )
        );
      }
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDiet();
  }, [loadDiet]);

  const toggleMeal = async (meal, idx) => {
    const id = String(meal.id || meal._id || idx);
    const nextState = !checkedMeals.has(id);
    const next = new Set(checkedMeals);
    if (nextState) next.add(id);
    else next.delete(id);
    setCheckedMeals(next);

    if (diet?.id || diet?._id) {
      try {
        await dietService.logMealAdherence(diet.id || diet._id, id, nextState);
      } catch {
        // Optimistic UI
      }
    }
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="My Diet & Nutrition"
        subtitle={diet ? diet.name || diet.title : 'Daily calorie & macro meal plan'}
      />

      {loading ? (
        <Skeleton variant="list" rows={4} />
      ) : error ? (
        <ErrorState message={error} onRetry={loadDiet} />
      ) : !diet ? (
        <Card>
          <EmptyState
            icon={Utensils}
            title="No diet plan assigned"
            message="Ask your trainer or gym owner to assign your personalized nutrition plan."
          />
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-xl bg-dark-surface border border-dark-border text-center">
              <p className="text-xs text-text-secondary">Calories</p>
              <p className="text-xl font-extrabold text-accent mt-1">{diet.totalCalories || 0} kcal</p>
            </div>
            <div className="p-4 rounded-xl bg-dark-surface border border-dark-border text-center">
              <p className="text-xs text-text-secondary">Protein</p>
              <p className="text-xl font-extrabold text-success mt-1">{diet.totalProtein || 0}g</p>
            </div>
            <div className="p-4 rounded-xl bg-dark-surface border border-dark-border text-center">
              <p className="text-xs text-text-secondary">Carbs</p>
              <p className="text-xl font-extrabold text-warning mt-1">{diet.totalCarbs || 0}g</p>
            </div>
            <div className="p-4 rounded-xl bg-dark-surface border border-dark-border text-center">
              <p className="text-xs text-text-secondary">Fats</p>
              <p className="text-xl font-extrabold text-text-primary mt-1">{diet.totalFats || 0}g</p>
            </div>
          </div>

          <div className="space-y-3">
            {(diet.meals || []).map((meal, idx) => {
              const id = String(meal.id || meal._id || idx);
              const done = checkedMeals.has(id);
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => toggleMeal(meal, idx)}
                  className={`w-full text-left p-4 rounded-xl border transition-colors ${
                    done
                      ? 'bg-success-light/20 border-success/40'
                      : 'bg-dark-surface border-dark-border hover:border-accent/50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      {done ? (
                        <CheckCircle2 className="w-5 h-5 text-success shrink-0 mt-0.5" />
                      ) : (
                        <Circle className="w-5 h-5 text-text-secondary shrink-0 mt-0.5" />
                      )}
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-bold text-sm text-text-primary">{meal.mealTime}</h4>
                          {meal.time && <span className="text-xs text-accent">{meal.time}</span>}
                        </div>
                        <p className="text-sm text-text-secondary mt-1">{meal.items}</p>
                        <p className="text-xs text-text-secondary/80 mt-2">
                          {meal.calories} kcal • P: {meal.protein}g • C: {meal.carbs}g • F: {meal.fats}g
                        </p>
                      </div>
                    </div>
                    <Badge status={done ? 'completed' : 'pending'}>{done ? 'Logged' : 'Eat'}</Badge>
                  </div>
                </button>
              );
            })}
          </div>

          {diet.notes && (
            <Card title="Hydration & Supplement Notes">
              <p className="text-sm text-text-secondary whitespace-pre-line">{diet.notes}</p>
            </Card>
          )}
        </>
      )}
    </div>
  );
};

export default CustomerDiet;

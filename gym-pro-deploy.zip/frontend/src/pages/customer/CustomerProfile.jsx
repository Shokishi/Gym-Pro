import React from 'react';
import ProfileManager from '../../components/shared/ProfileManager';

export const CustomerProfile = () => {
  return (
    <ProfileManager
      title="My Profile"
      subtitle="Manage your personal information, emergency contact, and password"
    />
  );
};

export default CustomerProfile;

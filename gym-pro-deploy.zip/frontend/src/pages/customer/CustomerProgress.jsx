import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Plus, TrendingUp, Scale } from 'lucide-react';
import progressService from '../../services/progressService';
import { useAuth } from '../../contexts/AuthContext';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatDate, calculateBMI } from '../../utils/formatters';
import {
  PageHeader,
  Card,
  Stat,
  Button,
  Modal,
  Input,
  Skeleton,
  ErrorState,
} from '../../components/ui';
import { ProgressChart } from '../../components/charts';

export const CustomerProgress = () => {
  const { user } = useAuth();
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    weight: '',
    bodyFat: '',
    muscleMass: '',
    chestCm: '',
    waistCm: '',
    notes: '',
  });

  const loadProgress = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await progressService.getMyProgress();
      setLogs(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadProgress();
  }, [loadProgress]);

  const handleLog = async (e) => {
    e.preventDefault();
    if (!form.weight) {
      toast.error('Please enter your weight');
      return;
    }
    setSaving(true);
    try {
      await progressService.create({
        weight: Number(form.weight),
        bodyFat: form.bodyFat ? Number(form.bodyFat) : undefined,
        muscleMass: form.muscleMass ? Number(form.muscleMass) : undefined,
        chestCm: form.chestCm ? Number(form.chestCm) : undefined,
        waistCm: form.waistCm ? Number(form.waistCm) : undefined,
        notes: form.notes,
      });
      toast.success('Progress logged!');
      setModalOpen(false);
      setForm({ weight: '', bodyFat: '', muscleMass: '', chestCm: '', waistCm: '', notes: '' });
      loadProgress();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const latest = logs[logs.length - 1] || {};
  const bmi = calculateBMI(latest.weight || user?.weightKg, user?.heightCm);

  return (
    <div className="space-y-5">
      <PageHeader
        title="Fitness Progress"
        subtitle="Track body weight, body fat %, muscle mass, and BMI trends over time"
        actions={
          <Button size="sm" icon={Plus} onClick={() => setModalOpen(true)}>
            Log Measurement
          </Button>
        }
      />

      {loading ? (
        <Skeleton variant="card" />
      ) : error ? (
        <ErrorState message={error} onRetry={loadProgress} />
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Stat
              label="Latest Weight"
              value={latest.weight ? `${latest.weight} kg` : '—'}
              icon={Scale}
              color="accent"
            />
            <Stat
              label="Body Fat"
              value={latest.bodyFat ? `${latest.bodyFat}%` : '—'}
              icon={TrendingUp}
              color="warning"
            />
            <Stat
              label="Current BMI"
              value={bmi.bmi ? `${bmi.bmi}` : '—'}
              icon={TrendingUp}
              color="success"
              subtitle={bmi.category}
            />
          </div>

          <Card title="Body Composition Trend">
            <ProgressChart
              data={logs.map((l) => ({
                ...l,
                date: formatDate(l.recordedAt || l.date || l.createdAt, 'DD MMM'),
              }))}
            />
          </Card>

          {logs.length > 0 && (
            <Card title="Measurement History">
              <div className="divide-y divide-dark-border/60">
                {[...logs].reverse().map((l, i) => (
                  <div key={l.id || i} className="py-3 flex items-center justify-between text-sm">
                    <div>
                      <p className="font-medium">{formatDate(l.recordedAt || l.date || l.createdAt)}</p>
                      {l.notes && <p className="text-xs text-text-secondary">{l.notes}</p>}
                    </div>
                    <div className="text-right text-xs">
                      <span className="font-bold text-accent text-sm">{l.weight} kg</span>
                      {l.bodyFat && <span className="text-text-secondary ml-2">BF: {l.bodyFat}%</span>}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Log Body Measurement">
        <form onSubmit={handleLog} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Input
              label="Weight (kg)"
              type="number"
              step="0.1"
              required
              value={form.weight}
              onChange={(e) => setForm((p) => ({ ...p, weight: e.target.value }))}
            />
            <Input
              label="Body Fat (%)"
              type="number"
              step="0.1"
              value={form.bodyFat}
              onChange={(e) => setForm((p) => ({ ...p, bodyFat: e.target.value }))}
            />
            <Input
              label="Muscle Mass (kg)"
              type="number"
              step="0.1"
              value={form.muscleMass}
              onChange={(e) => setForm((p) => ({ ...p, muscleMass: e.target.value }))}
            />
            <Input
              label="Waist (cm)"
              type="number"
              step="0.1"
              value={form.waistCm}
              onChange={(e) => setForm((p) => ({ ...p, waistCm: e.target.value }))}
            />
          </div>
          <Input
            label="Notes"
            placeholder="Morning fasted weigh-in..."
            value={form.notes}
            onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))}
          />
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              Save Measurement
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default CustomerProgress;

import React, { useState, useEffect, useCallback } from 'react';
import { QrCode, CalendarCheck, Flame } from 'lucide-react';
import attendanceService from '../../services/attendanceService';
import { useAuth } from '../../contexts/AuthContext';
import { extractData, extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatDate, formatTime } from '../../utils/formatters';
import {
  PageHeader,
  Card,
  Stat,
  Badge,
  QRCodeDisplay,
  Skeleton,
  EmptyState,
  ErrorState,
} from '../../components/ui';

export const CustomerAttendance = () => {
  const { user } = useAuth();
  const [qrToken, setQrToken] = useState('');
  const [history, setHistory] = useState([]);
  const [stats, setStats] = useState({ totalCheckIns: 0, streak: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadAttendance = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [histRes, qrRes] = await Promise.allSettled([
        attendanceService.getMyAttendance(),
        attendanceService.getMyQrToken(),
      ]);

      if (histRes.status === 'fulfilled') {
        const list = extractList(histRes.value);
        const raw = extractData(histRes.value, {});
        setHistory(list);
        setStats({
          totalCheckIns: raw?.totalCheckIns ?? list.length,
          streak: raw?.streak ?? 0,
        });
      } else {
        throw histRes.reason;
      }

      if (qrRes.status === 'fulfilled') {
        const qData = extractData(qrRes.value, {});
        setQrToken(qData?.qrToken || qData?.token || qData?.code || `GYMPRO-MEMBER-${user?.id || 'PASS'}`);
      } else {
        setQrToken(`GYMPRO-MEMBER-${user?.id || user?.mobile || 'PASS'}`);
      }
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [user?.id, user?.mobile]);

  useEffect(() => {
    loadAttendance();
  }, [loadAttendance]);

  return (
    <div className="space-y-5">
      <PageHeader
        title="My Attendance & QR Pass"
        subtitle="Show this QR code at the gym reception or to your trainer to check in"
      />

      {loading ? (
        <div className="space-y-4">
          <Skeleton variant="card" />
          <Skeleton variant="list" rows={4} />
        </div>
      ) : error ? (
        <ErrorState message={error} onRetry={loadAttendance} />
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 items-stretch">
            <Card title="Digital Check-In Pass" icon={QrCode} className="md:col-span-1 flex flex-col items-center">
              <div className="flex flex-col items-center py-2">
                <QRCodeDisplay
                  value={qrToken}
                  size={180}
                  label={user?.name || 'Member Pass'}
                  showDownload
                  downloadName="my-gym-pass.png"
                />
              </div>
            </Card>

            <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4 content-start">
              <Stat
                label="Total Gym Visits"
                value={stats.totalCheckIns}
                icon={CalendarCheck}
                color="success"
              />
              <Stat
                label="Current Streak"
                value={`${stats.streak} Days`}
                icon={Flame}
                color="accent"
              />
              <Card title="Recent Check-Ins" className="sm:col-span-2">
                {history.length === 0 ? (
                  <EmptyState
                    icon={CalendarCheck}
                    title="No check-ins yet"
                    message="Scan your QR pass at the gym entrance to log your first visit!"
                    className="py-6"
                  />
                ) : (
                  <div className="divide-y divide-dark-border/60">
                    {history.slice(0, 12).map((item, idx) => (
                      <div
                        key={item.id || item._id || idx}
                        className="py-3 flex items-center justify-between gap-3 text-sm"
                      >
                        <div>
                          <p className="font-medium text-text-primary">
                            {formatDate(item.date || item.checkInTime)}
                          </p>
                          <p className="text-xs text-text-secondary">
                            In: {formatTime(item.checkInTime || item.createdAt)}
                            {item.checkOutTime ? ` • Out: ${formatTime(item.checkOutTime)}` : ''}
                          </p>
                        </div>
                        <Badge status={item.status || 'PRESENT'} dot />
                      </div>
                    ))}
                  </div>
                )}
              </Card>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default CustomerAttendance;

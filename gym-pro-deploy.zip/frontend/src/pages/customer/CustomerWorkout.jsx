import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Flame, CheckCircle2, Circle } from 'lucide-react';
import workoutService from '../../services/workoutService';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { DAYS_OF_WEEK } from '../../utils/constants';
import {
  PageHeader,
  Card,
  Badge,
  Button,
  ProgressBar,
  Skeleton,
  EmptyState,
  ErrorState,
} from '../../components/ui';

export const CustomerWorkout = () => {
  const [plan, setPlan] = useState(null);
  const [selectedDay, setSelectedDay] = useState('ALL');
  const [completedIds, setCompletedIds] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [completing, setCompleting] = useState(false);
  const [error, setError] = useState(null);

  const loadWorkout = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await workoutService.getMyWorkout();
      const data = extractData(res);
      const activePlan = Array.isArray(data) ? data[0] : data;
      setPlan(activePlan || null);
      if (activePlan?.exercises) {
        const done = new Set(
          activePlan.exercises
            .filter((ex) => ex.completed)
            .map((ex, i) => String(ex.id || ex._id || i))
        );
        setCompletedIds(done);
      }
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadWorkout();
  }, [loadWorkout]);

  const exercises = plan?.exercises || [];
  const filtered =
    selectedDay === 'ALL'
      ? exercises
      : exercises.filter((ex) => String(ex.day).toLowerCase() === selectedDay.toLowerCase());

  const toggleExercise = async (ex, idx) => {
    const exId = String(ex.id || ex._id || idx);
    const nextDone = !completedIds.has(exId);
    const nextSet = new Set(completedIds);
    if (nextDone) nextSet.add(exId);
    else nextSet.delete(exId);
    setCompletedIds(nextSet);

    if (plan?.id || plan?._id) {
      try {
        await workoutService.toggleExerciseComplete(plan.id || plan._id, exId, nextDone);
      } catch {
        // Optimistic update kept if endpoint is lightweight
      }
    }
  };

  const handleFinishWorkout = async () => {
    if (!plan) return;
    setCompleting(true);
    try {
      await workoutService.completeDay(plan.id || plan._id, selectedDay);
      toast.success('Workout logged as completed! Great job!');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setCompleting(false);
    }
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="My Workout Plan"
        subtitle={plan ? `${plan.name || plan.title} • ${plan.durationWeeks || 4} Weeks` : 'Your assigned training split'}
        actions={
          plan && (
            <Button size="sm" icon={CheckCircle2} loading={completing} onClick={handleFinishWorkout}>
              Complete Workout
            </Button>
          )
        }
      />

      {loading ? (
        <Skeleton variant="list" rows={5} />
      ) : error ? (
        <ErrorState message={error} onRetry={loadWorkout} />
      ) : !plan ? (
        <Card>
          <EmptyState
            icon={Flame}
            title="No workout plan assigned"
            message="Once your trainer assigns a workout plan, your daily exercises will show up here."
          />
        </Card>
      ) : (
        <>
          <Card>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Badge variant="accent">{plan.difficulty || 'INTERMEDIATE'}</Badge>
                <Badge variant="neutral">{String(plan.goal || 'FITNESS').replace(/_/g, ' ')}</Badge>
              </div>
              <span className="text-xs text-text-secondary">
                {completedIds.size} / {exercises.length} done
              </span>
            </div>
            <ProgressBar value={completedIds.size} max={Math.max(1, exercises.length)} color="success" />
          </Card>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 gym-scrollbar-none">
            {['ALL', ...DAYS_OF_WEEK].map((day) => (
              <button
                key={day}
                type="button"
                onClick={() => setSelectedDay(day)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                  selectedDay === day
                    ? 'bg-accent text-dark-bg font-semibold'
                    : 'bg-dark-surface border border-dark-border text-text-secondary hover:text-text-primary'
                }`}
              >
                {day === 'ALL' ? 'All Days' : day.slice(0, 3)}
              </button>
            ))}
          </div>

          <div className="space-y-3">
            {filtered.length === 0 ? (
              <Card>
                <p className="text-sm text-text-secondary text-center py-6">
                  Rest day or no exercises scheduled for {selectedDay}.
                </p>
              </Card>
            ) : (
              filtered.map((ex, idx) => {
                const exId = String(ex.id || ex._id || idx);
                const done = completedIds.has(exId);
                return (
                  <button
                    key={exId}
                    type="button"
                    onClick={() => toggleExercise(ex, idx)}
                    className={`w-full text-left p-4 rounded-xl border transition-all flex items-center justify-between gap-4 ${
                      done
                        ? 'bg-success-light/20 border-success/40'
                        : 'bg-dark-surface border-dark-border hover:border-accent/50'
                    }`}
                  >
                    <div className="flex items-start gap-3 min-w-0">
                      {done ? (
                        <CheckCircle2 className="w-5 h-5 text-success shrink-0 mt-0.5" />
                      ) : (
                        <Circle className="w-5 h-5 text-text-secondary shrink-0 mt-0.5" />
                      )}
                      <div className="min-w-0">
                        <p
                          className={`font-semibold text-sm ${
                            done ? 'line-through text-text-secondary' : 'text-text-primary'
                          }`}
                        >
                          {ex.name}
                        </p>
                        <p className="text-xs text-text-secondary mt-0.5">
                          {ex.day} • {ex.sets} sets × {ex.reps} reps • Rest {ex.restSeconds || 60}s
                        </p>
                      </div>
                    </div>
                    <Badge status={done ? 'completed' : 'pending'}>
                      {done ? 'Done' : 'Tap'}
                    </Badge>
                  </button>
                );
              })
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default CustomerWorkout;

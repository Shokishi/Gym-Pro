import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { QrCode, Send, Copy } from 'lucide-react';
import paymentService from '../../services/paymentService';
import membershipService from '../../services/membershipService';
import { extractData, extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency } from '../../utils/formatters';
import { validateForm } from '../../utils/validators';
import {
  PageHeader,
  Card,
  Select,
  Input,
  Button,
  FileUpload,
  QRCodeDisplay,
  Skeleton,
} from '../../components/ui';

export const MakePayment = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const base = location.pathname.startsWith('/app') ? '/app' : '/customer';

  const [qrSettings, setQrSettings] = useState(null);
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [screenshot, setScreenshot] = useState(null);
  const [errors, setErrors] = useState({});

  const [form, setForm] = useState({
    planId: '',
    amount: '',
    transactionId: '',
    paymentMethod: 'UPI',
    notes: '',
  });

  useEffect(() => {
    Promise.allSettled([paymentService.getQrSettings(), membershipService.getPlans()]).then(
      ([qrRes, pRes]) => {
        if (qrRes.status === 'fulfilled') setQrSettings(extractData(qrRes.value));
        if (pRes.status === 'fulfilled') setPlans(extractList(pRes.value));
        setLoading(false);
      }
    );
  }, []);

  const handlePlanChange = (planId) => {
    const plan = plans.find((p) => String(p.id || p._id) === planId);
    setForm((prev) => ({
      ...prev,
      planId,
      amount: plan ? String(plan.price ?? plan.amount ?? '') : prev.amount,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      amount: { required: true, label: 'Amount', min: 1 },
      transactionId: { required: true, label: 'UPI Transaction / UTR ID', minLength: 4 },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSubmitting(true);
    try {
      const payload = new FormData();
      if (form.planId) payload.append('planId', form.planId);
      payload.append('amount', String(form.amount));
      payload.append('transactionId', form.transactionId.trim());
      payload.append('paymentMethod', form.paymentMethod);
      if (form.notes) payload.append('notes', form.notes);
      if (screenshot) payload.append('screenshot', screenshot);

      await paymentService.submitCustomerPayment(payload);
      toast.success('Payment submitted! The gym owner will verify it shortly.');
      navigate(`${base}/payments`);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  const upiUri = qrSettings?.upiId
    ? `upi://pay?pa=${encodeURIComponent(qrSettings.upiId)}&pn=${encodeURIComponent(
        qrSettings.merchantName || 'Gym'
      )}${form.amount ? `&am=${encodeURIComponent(form.amount)}` : ''}&cu=INR`
    : '';

  return (
    <div className="space-y-5">
      <PageHeader
        title="Make Payment"
        subtitle="Scan your gym's UPI QR code and submit your UTR / receipt for verification"
        backTo={`${base}/payments`}
      />

      {loading ? (
        <Skeleton variant="card" />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card title="1. Scan & Pay via UPI" icon={QrCode}>
            <div className="flex flex-col items-center text-center space-y-4 py-2">
              {qrSettings?.qrImageUrl ? (
                <img
                  src={qrSettings.qrImageUrl}
                  alt="Gym Payment QR"
                  className="w-56 h-56 object-contain bg-white p-3 rounded-2xl"
                />
              ) : upiUri ? (
                <QRCodeDisplay value={upiUri} size={200} label={`UPI: ${qrSettings.upiId}`} />
              ) : (
                <p className="text-sm text-text-secondary py-10">
                  Gym UPI QR not configured yet. Please contact the gym reception.
                </p>
              )}

              {qrSettings?.upiId && (
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(qrSettings.upiId);
                    toast.success('UPI ID copied!');
                  }}
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-dark-bg border border-dark-border text-xs font-mono text-accent hover:border-accent"
                >
                  {qrSettings.upiId}
                  <Copy className="w-3.5 h-3.5" />
                </button>
              )}

              {qrSettings?.instructions && (
                <p className="text-xs text-text-secondary max-w-sm">{qrSettings.instructions}</p>
              )}
            </div>
          </Card>

          <Card title="2. Submit Payment Proof">
            <form onSubmit={handleSubmit} className="space-y-4">
              {plans.length > 0 && (
                <Select
                  label="Select Membership Plan (Optional)"
                  placeholder="Custom / Other payment"
                  value={form.planId}
                  options={plans.map((pl) => ({
                    value: pl.id || pl._id,
                    label: `${pl.name} — ${formatCurrency(pl.price ?? pl.amount ?? 0)}`,
                  }))}
                  onChange={(e) => handlePlanChange(e.target.value)}
                />
              )}

              <Input
                label="Amount Paid (₹)"
                type="number"
                required
                placeholder="1500"
                value={form.amount}
                error={errors.amount}
                onChange={(e) => {
                  setForm((p) => ({ ...p, amount: e.target.value }));
                  setErrors((p) => ({ ...p, amount: '' }));
                }}
              />

              <Input
                label="UPI Transaction / UTR Reference Number"
                required
                placeholder="e.g. 429810472910"
                value={form.transactionId}
                error={errors.transactionId}
                onChange={(e) => {
                  setForm((p) => ({ ...p, transactionId: e.target.value }));
                  setErrors((p) => ({ ...p, transactionId: '' }));
                }}
              />

              <FileUpload
                label="Upload Payment Screenshot (Optional)"
                accept="image/*"
                value={screenshot}
                onChange={setScreenshot}
              />

              <Button type="submit" fullWidth size="lg" loading={submitting} icon={Send}>
                Submit Payment for Verification
              </Button>
            </form>
          </Card>
        </div>
      )}
    </div>
  );
};

export default MakePayment;

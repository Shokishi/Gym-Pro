import React from 'react';
import NotificationsCenter from '../../components/shared/NotificationsCenter';

export const CustomerNotifications = () => {
  return (
    <NotificationsCenter
      title="Notifications"
      subtitle="Membership reminders, payment approvals, and gym updates"
    />
  );
};

export default CustomerNotifications;

import React, { useState, useEffect, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { IdCard, CheckCircle2, RefreshCw } from 'lucide-react';
import membershipService from '../../services/membershipService';
import { extractData, extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDate, getDaysRemaining } from '../../utils/formatters';
import {
  PageHeader,
  Card,
  Badge,
  Button,
  ProgressBar,
  Skeleton,
  ErrorState,
} from '../../components/ui';

export const CustomerMembership = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const base = location.pathname.startsWith('/app') ? '/app' : '/customer';

  const [membership, setMembership] = useState(null);
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadMembership = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [mRes, pRes] = await Promise.allSettled([
        membershipService.getMyMembership(),
        membershipService.getPlans(),
      ]);
      if (mRes.status === 'fulfilled') setMembership(extractData(mRes.value));
      if (pRes.status === 'fulfilled') setPlans(extractList(pRes.value));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadMembership();
  }, [loadMembership]);

  const active = Array.isArray(membership) ? membership[0] : membership;
  const daysLeft = getDaysRemaining(active?.endDate);
  const totalDays = active?.plan?.durationDays || 30;

  return (
    <div className="space-y-6">
      <PageHeader
        title="My Membership"
        subtitle="Check your current membership validity and explore renewal plans"
        actions={
          <Button
            size="sm"
            icon={RefreshCw}
            onClick={() => navigate(`${base}/payments/new`)}
          >
            Renew / Pay Fee
          </Button>
        }
      />

      {loading ? (
        <Skeleton variant="card" />
      ) : error ? (
        <ErrorState message={error} onRetry={loadMembership} />
      ) : (
        <>
          <Card
            title={active?.plan?.name || active?.planName || 'No Active Membership'}
            subtitle={
              active?.startDate
                ? `${formatDate(active.startDate)} — ${formatDate(active.endDate)}`
                : 'Select a plan below to renew'
            }
            icon={IdCard}
            actions={<Badge status={active?.status || (daysLeft > 0 ? 'ACTIVE' : 'EXPIRED')} dot />}
          >
            {active?.endDate ? (
              <ProgressBar
                value={Math.max(0, daysLeft)}
                max={totalDays}
                label={`${Math.max(0, daysLeft)} days remaining`}
                color={daysLeft <= 7 ? 'warning' : 'success'}
              />
            ) : (
              <p className="text-sm text-text-secondary">
                You currently do not have an active gym membership plan.
              </p>
            )}
          </Card>

          <div>
            <h3 className="text-base font-bold text-text-primary mb-3">Available Gym Plans</h3>
            {plans.length === 0 ? (
              <Card>
                <p className="text-sm text-text-secondary text-center py-6">
                  Contact reception for custom plan pricing.
                </p>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {plans.map((plan) => (
                  <Card key={plan.id || plan._id}>
                    <h4 className="font-bold text-base">{plan.name}</h4>
                    <p className="text-xs text-text-secondary">{plan.durationDays} days validity</p>
                    <p className="text-2xl font-extrabold text-accent mt-3">
                      {formatCurrency(plan.price ?? plan.amount ?? 0)}
                    </p>
                    <ul className="mt-4 space-y-1.5 text-xs text-text-secondary">
                      {(Array.isArray(plan.features) ? plan.features : []).map((f, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-success shrink-0" />
                          <span>{f}</span>
                        </li>
                      ))}
                    </ul>
                    <Button
                      fullWidth
                      size="sm"
                      className="mt-4"
                      onClick={() => navigate(`${base}/payments/new`)}
                    >
                      Select & Pay
                    </Button>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default CustomerMembership;

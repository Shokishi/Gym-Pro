import React, { useState, useEffect, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  QrCode,
  Flame,
  Utensils,
  IdCard,
  CreditCard,
  CalendarCheck,
  TrendingUp,
  ArrowRight,
} from 'lucide-react';
import customerService from '../../services/customerService';
import { useAuth } from '../../contexts/AuthContext';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { formatDate, getDaysRemaining } from '../../utils/formatters';
import {
  PageHeader,
  Card,
  Badge,
  Button,
  ProgressBar,
  Skeleton,
  ErrorState,
} from '../../components/ui';

export const CustomerHome = () => {
  const { user, gym } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const base = location.pathname.startsWith('/app') ? '/app' : '/customer';

  const [home, setHome] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadHome = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await customerService.getHomeSummary();
      setHome(extractData(res, {}));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadHome();
  }, [loadHome]);

  const membership = home?.membership || home?.activeMembership || {};
  const todayWorkout = home?.todayWorkout || home?.workout || null;
  const diet = home?.dietPlan || home?.diet || null;
  const daysLeft = getDaysRemaining(membership?.endDate);
  const totalDays = membership?.plan?.durationDays || 30;

  return (
    <div className="space-y-5">
      <PageHeader
        title={`Hey, ${user?.name?.split(' ')[0] || 'Athlete'}!`}
        subtitle={gym?.name ? `Member at ${gym.name}` : 'Your daily fitness overview'}
        actions={
          <Button size="sm" icon={QrCode} onClick={() => navigate(`${base}/attendance`)}>
            My QR Pass
          </Button>
        }
      />

      {loading ? (
        <div className="space-y-4">
          <Skeleton variant="card" />
          <Skeleton variant="card" />
        </div>
      ) : error ? (
        <ErrorState message={error} onRetry={loadHome} />
      ) : (
        <>
          {/* Membership Card */}
          <Card elevated className="border-accent/40">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-accent-light text-accent flex items-center justify-center shrink-0">
                  <IdCard className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-text-secondary">Active Membership</p>
                  <h3 className="text-base font-bold text-text-primary">
                    {membership?.plan?.name || membership?.planName || 'No Active Plan'}
                  </h3>
                </div>
              </div>
              <Badge status={membership?.status || (daysLeft > 0 ? 'ACTIVE' : 'EXPIRED')} dot />
            </div>

            {membership?.endDate ? (
              <div className="mt-4 space-y-2">
                <ProgressBar
                  value={Math.max(0, daysLeft)}
                  max={totalDays}
                  label={`${Math.max(0, daysLeft)} days remaining (Expires ${formatDate(membership.endDate)})`}
                  color={daysLeft <= 7 ? 'warning' : 'success'}
                />
                {daysLeft <= 7 && (
                  <div className="flex justify-end pt-1">
                    <Button size="xs" onClick={() => navigate(`${base}/payments/new`)}>
                      Renew Now
                    </Button>
                  </div>
                )}
              </div>
            ) : (
              <div className="mt-4 flex items-center justify-between gap-3">
                <p className="text-xs text-text-secondary">Activate a plan to unlock full gym access.</p>
                <Button size="xs" onClick={() => navigate(`${base}/membership`)}>
                  View Plans
                </Button>
              </div>
            )}
          </Card>

          {/* Quick Action Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <button
              type="button"
              onClick={() => navigate(`${base}/attendance`)}
              className="p-4 rounded-xl bg-dark-surface border border-dark-border hover:border-accent text-left transition-colors"
            >
              <CalendarCheck className="w-5 h-5 text-success mb-2" />
              <p className="text-sm font-semibold">Check-Ins</p>
              <p className="text-xs text-text-secondary mt-0.5">
                {home?.monthlyCheckIns ?? 0} this month
              </p>
            </button>
            <button
              type="button"
              onClick={() => navigate(`${base}/workout`)}
              className="p-4 rounded-xl bg-dark-surface border border-dark-border hover:border-accent text-left transition-colors"
            >
              <Flame className="w-5 h-5 text-accent mb-2" />
              <p className="text-sm font-semibold">Today's Workout</p>
              <p className="text-xs text-text-secondary mt-0.5">
                {todayWorkout?.exercises?.length || 0} exercises
              </p>
            </button>
            <button
              type="button"
              onClick={() => navigate(`${base}/diet`)}
              className="p-4 rounded-xl bg-dark-surface border border-dark-border hover:border-accent text-left transition-colors"
            >
              <Utensils className="w-5 h-5 text-warning mb-2" />
              <p className="text-sm font-semibold">Nutrition</p>
              <p className="text-xs text-text-secondary mt-0.5">
                {diet?.totalCalories ? `${diet.totalCalories} kcal` : 'View meal plan'}
              </p>
            </button>
            <button
              type="button"
              onClick={() => navigate(`${base}/progress`)}
              className="p-4 rounded-xl bg-dark-surface border border-dark-border hover:border-accent text-left transition-colors"
            >
              <TrendingUp className="w-5 h-5 text-blue-400 mb-2" />
              <p className="text-sm font-semibold">Progress</p>
              <p className="text-xs text-text-secondary mt-0.5">
                {home?.latestWeight ? `${home.latestWeight} kg` : 'Track stats'}
              </p>
            </button>
          </div>

          {/* Today's Workout Preview */}
          <Card
            title="Today's Training Focus"
            icon={Flame}
            actions={
              <Button
                variant="ghost"
                size="xs"
                rightIcon={ArrowRight}
                onClick={() => navigate(`${base}/workout`)}
              >
                Start
              </Button>
            }
          >
            {!todayWorkout ? (
              <p className="text-sm text-text-secondary py-4 text-center">
                No workout plan assigned yet. Ask your trainer to assign a split!
              </p>
            ) : (
              <div className="space-y-2.5">
                <p className="text-sm font-semibold text-accent">
                  {todayWorkout.name || todayWorkout.title}
                </p>
                {(todayWorkout.exercises || []).slice(0, 4).map((ex, i) => (
                  <div
                    key={ex.id || i}
                    className="p-3 rounded-lg bg-dark-bg border border-dark-border flex items-center justify-between text-sm"
                  >
                    <span className="font-medium">{ex.name}</span>
                    <span className="text-xs text-text-secondary">
                      {ex.sets} × {ex.reps}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card
            title="Pay Membership Fees"
            subtitle="Fast UPI QR payment & instant receipt tracking"
            icon={CreditCard}
            actions={
              <Button size="sm" onClick={() => navigate(`${base}/payments/new`)}>
                Pay Now
              </Button>
            }
          >
            <p className="text-xs text-text-secondary">
              Submit your UPI payment reference directly from your phone for fast approval by the gym desk.
            </p>
          </Card>
        </>
      )}
    </div>
  );
};

export default CustomerHome;

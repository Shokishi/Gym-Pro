import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import dayjs from 'dayjs';
import { Plus, CalendarClock, XCircle } from 'lucide-react';
import appointmentService from '../../services/appointmentService';
import trainerService from '../../services/trainerService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatDate, formatTime } from '../../utils/formatters';
import {
  PageHeader,
  Card,
  Badge,
  Button,
  Modal,
  Input,
  Select,
  Textarea,
  ConfirmDialog,
  Skeleton,
  EmptyState,
  ErrorState,
} from '../../components/ui';

export const CustomerAppointments = () => {
  const [appointments, setAppointments] = useState([]);
  const [trainers, setTrainers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [cancelTarget, setCancelTarget] = useState(null);
  const [cancelling, setCancelling] = useState(false);

  const [form, setForm] = useState({
    title: 'Personal Training Session',
    type: 'PT_SESSION',
    trainerId: '',
    date: dayjs().add(1, 'day').format('YYYY-MM-DD'),
    time: '07:30',
    notes: '',
  });

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await appointmentService.getMyAppointments();
      setAppointments(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
    trainerService
      .getAll({ limit: 50 })
      .then((res) => setTrainers(extractList(res)))
      .catch(() => {});
  }, [loadData]);

  const handleBook = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await appointmentService.bookAppointment(form);
      toast.success('Session booked!');
      setModalOpen(false);
      loadData();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = async () => {
    if (!cancelTarget) return;
    setCancelling(true);
    try {
      await appointmentService.cancelMyAppointment(cancelTarget.id || cancelTarget._id);
      toast.success('Appointment cancelled');
      setCancelTarget(null);
      loadData();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setCancelling(false);
    }
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="My Appointments"
        subtitle="Book personal training slots, body assessments, or group classes"
        actions={
          <Button size="sm" icon={Plus} onClick={() => setModalOpen(true)}>
            Book Session
          </Button>
        }
      />

      {loading ? (
        <Skeleton variant="list" rows={4} />
      ) : error ? (
        <ErrorState message={error} onRetry={loadData} />
      ) : appointments.length === 0 ? (
        <Card>
          <EmptyState
            icon={CalendarClock}
            title="No appointments booked"
            message="Book a personal training session or assessment with your coach."
            action={
              <Button icon={Plus} onClick={() => setModalOpen(true)}>
                Book Session
              </Button>
            }
          />
        </Card>
      ) : (
        <div className="space-y-3">
          {appointments.map((apt) => (
            <div
              key={apt.id || apt._id}
              className="bg-dark-surface border border-dark-border rounded-xl p-4 flex items-center justify-between gap-4"
            >
              <div>
                <div className="flex items-center gap-2">
                  <p className="font-semibold text-sm text-text-primary">
                    {apt.title || apt.type}
                  </p>
                  <Badge status={apt.status || 'SCHEDULED'} dot />
                </div>
                <p className="text-xs text-text-secondary mt-1">
                  {apt.trainer?.name ? `Coach: ${apt.trainer.name} • ` : ''}
                  {formatDate(apt.date || apt.scheduledAt)} at{' '}
                  <span className="text-accent">{formatTime(apt.time || apt.scheduledAt)}</span>
                </p>
              </div>
              {String(apt.status).toUpperCase() === 'SCHEDULED' && (
                <Button
                  size="xs"
                  variant="danger"
                  icon={XCircle}
                  onClick={() => setCancelTarget(apt)}
                >
                  Cancel
                </Button>
              )}
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Book Training Session">
        <form onSubmit={handleBook} className="space-y-4">
          <Select
            label="Session Type"
            value={form.type}
            options={[
              { value: 'PT_SESSION', label: 'Personal Training Session' },
              { value: 'ASSESSMENT', label: 'Fitness Assessment' },
              { value: 'CONSULTATION', label: 'Diet Consultation' },
              { value: 'GROUP_CLASS', label: 'Group Fitness Class' },
            ]}
            onChange={(e) =>
              setForm((p) => ({
                ...p,
                type: e.target.value,
                title: e.target.options[e.target.selectedIndex].text,
              }))
            }
          />
          {trainers.length > 0 && (
            <Select
              label="Preferred Trainer"
              placeholder="Any available coach"
              value={form.trainerId}
              options={trainers.map((t) => ({ value: t.id || t._id, label: t.name }))}
              onChange={(e) => setForm((p) => ({ ...p, trainerId: e.target.value }))}
            />
          )}
          <div className="grid grid-cols-2 gap-3">
            <Input
              label="Date"
              type="date"
              required
              value={form.date}
              onChange={(e) => setForm((p) => ({ ...p, date: e.target.value }))}
            />
            <Input
              label="Time"
              type="time"
              required
              value={form.time}
              onChange={(e) => setForm((p) => ({ ...p, time: e.target.value }))}
            />
          </div>
          <Textarea
            label="Notes for Coach"
            rows={2}
            value={form.notes}
            onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))}
          />
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              Confirm Booking
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(cancelTarget)}
        onClose={() => setCancelTarget(null)}
        onConfirm={handleCancel}
        loading={cancelling}
        title="Cancel Appointment"
        message={`Cancel "${cancelTarget?.title}"?`}
        confirmLabel="Cancel Session"
      />
    </div>
  );
};

export default CustomerAppointments;

import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Plus, Eye, CheckCircle2 } from 'lucide-react';
import paymentService from '../../services/paymentService';
import customerService from '../../services/customerService';
import { useDebounce } from '../../hooks/useDebounce';
import { usePagination } from '../../hooks/usePagination';
import { extractList, extractPagination, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDateTime } from '../../utils/formatters';
import { PAYMENT_METHODS } from '../../utils/constants';
import { validateForm } from '../../utils/validators';
import {
  PageHeader,
  SearchInput,
  Select,
  Table,
  Badge,
  Button,
  Modal,
  Input,
  ErrorState,
} from '../../components/ui';

export const PaymentList = () => {
  const navigate = useNavigate();
  const [payments, setPayments] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [recordOpen, setRecordOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});

  const [form, setForm] = useState({
    customerId: '',
    amount: '',
    paymentMethod: 'UPI',
    transactionId: '',
    description: 'Membership Fee',
    status: 'VERIFIED',
  });

  const debouncedSearch = useDebounce(search, 350);
  const pagination = usePagination(1, 10);

  const fetchPayments = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await paymentService.getAll({
        search: debouncedSearch,
        status: statusFilter,
        page: pagination.page,
        limit: pagination.limit,
      });
      setPayments(extractList(res));
      pagination.updateMeta(extractPagination(res, pagination.limit));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch, statusFilter, pagination.page, pagination.limit]);

  useEffect(() => {
    fetchPayments();
  }, [fetchPayments]);

  useEffect(() => {
    customerService
      .getAll({ limit: 200 })
      .then((res) => setCustomers(extractList(res)))
      .catch(() => {});

    const onPaymentUpdate = () => fetchPayments();
    window.addEventListener('gympro:payment-update', onPaymentUpdate);
    return () => window.removeEventListener('gympro:payment-update', onPaymentUpdate);
  }, [fetchPayments]);

  const handleRecordPayment = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      customerId: { required: true, label: 'Member' },
      amount: { required: true, label: 'Amount', min: 1 },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSaving(true);
    try {
      await paymentService.create({ ...form, amount: Number(form.amount) });
      toast.success('Payment recorded');
      setRecordOpen(false);
      setForm({
        customerId: '',
        amount: '',
        paymentMethod: 'UPI',
        transactionId: '',
        description: 'Membership Fee',
        status: 'VERIFIED',
      });
      fetchPayments();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleQuickApprove = async (payment) => {
    try {
      await paymentService.verify(payment.id || payment._id, { status: 'VERIFIED' });
      toast.success('Payment approved');
      fetchPayments();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const columns = [
    {
      key: 'customer',
      header: 'Member',
      render: (row) => (
        <div>
          <p className="font-semibold text-text-primary">
            {row.customer?.name || row.customerName || '—'}
          </p>
          <p className="text-xs text-text-secondary">{row.description || row.plan?.name || ''}</p>
        </div>
      ),
    },
    {
      key: 'amount',
      header: 'Amount',
      sortable: true,
      render: (row) => <span className="font-bold text-accent">{formatCurrency(row.amount)}</span>,
    },
    {
      key: 'method',
      header: 'Method / Ref',
      render: (row) => (
        <div>
          <p className="text-sm">{row.paymentMethod || row.method || 'UPI'}</p>
          <p className="text-xs font-mono text-text-secondary">
            {row.transactionId || row.utr || '—'}
          </p>
        </div>
      ),
    },
    {
      key: 'createdAt',
      header: 'Date',
      render: (row) => formatDateTime(row.paidAt || row.createdAt),
    },
    {
      key: 'status',
      header: 'Status',
      render: (row) => <Badge status={row.status || 'PENDING'} dot />,
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (row) => {
        const id = row.id || row._id;
        const isPending = String(row.status).toUpperCase() === 'PENDING';
        return (
          <div className="inline-flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
            {isPending && (
              <Button
                size="xs"
                variant="success"
                icon={CheckCircle2}
                onClick={() => handleQuickApprove(row)}
              >
                Approve
              </Button>
            )}
            <Button
              size="xs"
              variant="secondary"
              icon={Eye}
              onClick={() => navigate(`/owner/payments/${id}`)}
            >
              Details
            </Button>
          </div>
        );
      },
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Payments & Collections"
        subtitle="Verify customer UPI submissions and record cash/card fee payments"
        actions={
          <Button icon={Plus} onClick={() => setRecordOpen(true)}>
            Record Payment
          </Button>
        }
      />

      <div className="flex flex-col sm:flex-row gap-3">
        <SearchInput
          placeholder="Search member or UTR reference..."
          value={search}
          onChange={(v) => {
            setSearch(v);
            pagination.resetPage();
          }}
          className="sm:max-w-sm"
        />
        <Select
          value={statusFilter}
          placeholder=""
          containerClassName="sm:w-48"
          options={[
            { value: 'ALL', label: 'All Payments' },
            { value: 'PENDING', label: 'Pending Approval' },
            { value: 'VERIFIED', label: 'Verified / Paid' },
            { value: 'REJECTED', label: 'Rejected' },
          ]}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            pagination.resetPage();
          }}
        />
      </div>

      {error ? (
        <ErrorState message={error} onRetry={fetchPayments} />
      ) : (
        <Table
          columns={columns}
          data={payments}
          loading={loading}
          pagination={pagination}
          onPageChange={pagination.setPage}
          onRowClick={(r) => navigate(`/owner/payments/${r.id || r._id}`)}
          emptyTitle="No payments recorded"
        />
      )}

      <Modal isOpen={recordOpen} onClose={() => setRecordOpen(false)} title="Record Member Payment">
        <form onSubmit={handleRecordPayment} className="space-y-4">
          <Select
            label="Member"
            required
            value={form.customerId}
            error={errors.customerId}
            options={customers.map((c) => ({
              value: c.id || c._id,
              label: `${c.name} (${c.mobile || c.phone || ''})`,
            }))}
            onChange={(e) => {
              setForm((p) => ({ ...p, customerId: e.target.value }));
              setErrors((p) => ({ ...p, customerId: '' }));
            }}
          />
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Amount (₹)"
              type="number"
              required
              value={form.amount}
              error={errors.amount}
              onChange={(e) => {
                setForm((p) => ({ ...p, amount: e.target.value }));
                setErrors((p) => ({ ...p, amount: '' }));
              }}
            />
            <Select
              label="Payment Method"
              value={form.paymentMethod}
              options={PAYMENT_METHODS}
              onChange={(e) => setForm((p) => ({ ...p, paymentMethod: e.target.value }))}
            />
          </div>
          <Input
            label="UTR / Transaction Reference"
            placeholder="Optional for Cash"
            value={form.transactionId}
            onChange={(e) => setForm((p) => ({ ...p, transactionId: e.target.value }))}
          />
          <Input
            label="Description"
            value={form.description}
            onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
          />
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setRecordOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              Save Payment
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default PaymentList;

import React, { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Download, CheckCircle2, Mail } from 'lucide-react';
import invoiceService from '../../services/invoiceService';
import { useAuth } from '../../contexts/AuthContext';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { generateInvoicePDF } from '../../utils/pdfGenerator';
import { PageHeader, Card, Badge, Button, Skeleton, ErrorState } from '../../components/ui';

export const InvoiceDetail = () => {
  const { id } = useParams();
  const { gym } = useAuth();
  const [invoice, setInvoice] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [acting, setActing] = useState(false);

  const loadInvoice = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await invoiceService.getById(id);
      setInvoice(extractData(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    loadInvoice();
  }, [loadInvoice]);

  const handleMarkPaid = async () => {
    setActing(true);
    try {
      await invoiceService.markPaid(id, { status: 'PAID' });
      toast.success('Invoice marked as PAID');
      loadInvoice();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setActing(false);
    }
  };

  const handleSend = async () => {
    setActing(true);
    try {
      await invoiceService.sendEmail(id);
      toast.success('Invoice sent to member');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setActing(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <PageHeader title="Invoice Details" backTo="/owner/invoices" />
        <Skeleton variant="card" />
      </div>
    );
  }

  if (error || !invoice) {
    return (
      <div className="space-y-6">
        <PageHeader title="Invoice Details" backTo="/owner/invoices" />
        <ErrorState message={error || 'Invoice not found'} onRetry={loadInvoice} />
      </div>
    );
  }

  const items = Array.isArray(invoice.items) && invoice.items.length > 0
    ? invoice.items
    : [{ description: invoice.description || 'Membership Plan', quantity: 1, unitPrice: invoice.total ?? 0 }];

  return (
    <div className="space-y-6 max-w-4xl">
      <PageHeader
        title={`Invoice ${invoice.invoiceNumber || `#${id}`}`}
        subtitle={`Issued on ${formatDate(invoice.issueDate || invoice.createdAt)}`}
        backTo="/owner/invoices"
        badge={<Badge status={invoice.status || 'PENDING'} dot />}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            {String(invoice.status).toUpperCase() !== 'PAID' && (
              <Button variant="success" size="sm" icon={CheckCircle2} loading={acting} onClick={handleMarkPaid}>
                Mark Paid
              </Button>
            )}
            <Button variant="secondary" size="sm" icon={Mail} loading={acting} onClick={handleSend}>
              Send
            </Button>
            <Button size="sm" icon={Download} onClick={() => generateInvoicePDF(invoice, gym)}>
              Download PDF
            </Button>
          </div>
        }
      />

      <Card>
        <div className="flex flex-col sm:flex-row justify-between gap-6 pb-6 border-b border-dark-border">
          <div>
            <p className="text-xs uppercase tracking-wider text-text-secondary">From</p>
            <h3 className="text-lg font-bold text-accent mt-1">{gym?.name || 'GYM PRO'}</h3>
            <p className="text-xs text-text-secondary mt-1">{gym?.address || ''}</p>
            <p className="text-xs text-text-secondary">{gym?.phone || ''}</p>
          </div>
          <div className="sm:text-right">
            <p className="text-xs uppercase tracking-wider text-text-secondary">Billed To</p>
            <h3 className="text-base font-semibold text-text-primary mt-1">
              {invoice.customer?.name || invoice.customerName || 'Member'}
            </h3>
            <p className="text-xs text-text-secondary mt-1">
              {invoice.customer?.mobile || invoice.customer?.phone || ''}
            </p>
            <p className="text-xs text-text-secondary mt-1">
              Due Date: {formatDate(invoice.dueDate)}
            </p>
          </div>
        </div>

        <div className="mt-6 overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead>
              <tr className="border-b border-dark-border text-xs text-text-secondary uppercase">
                <th className="py-2.5">Item</th>
                <th className="py-2.5 text-center">Qty</th>
                <th className="py-2.5 text-right">Unit Price</th>
                <th className="py-2.5 text-right">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-border/50">
              {items.map((item, idx) => (
                <tr key={idx}>
                  <td className="py-3 font-medium">{item.description || item.name}</td>
                  <td className="py-3 text-center">{item.quantity || 1}</td>
                  <td className="py-3 text-right">{formatCurrency(item.unitPrice ?? item.price ?? 0)}</td>
                  <td className="py-3 text-right font-semibold">
                    {formatCurrency(item.total ?? Number(item.quantity || 1) * Number(item.unitPrice ?? item.price ?? 0))}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-6 pt-4 border-t border-dark-border flex justify-end">
          <div className="w-full max-w-xs space-y-2 text-sm">
            <div className="flex justify-between text-text-secondary">
              <span>Subtotal</span>
              <span>{formatCurrency(invoice.subtotal ?? invoice.total ?? 0)}</span>
            </div>
            {Number(invoice.tax || 0) > 0 && (
              <div className="flex justify-between text-text-secondary">
                <span>Tax / GST</span>
                <span>{formatCurrency(invoice.tax)}</span>
              </div>
            )}
            <div className="flex justify-between text-base font-bold text-accent pt-2 border-t border-dark-border">
              <span>Total Amount</span>
              <span>{formatCurrency(invoice.total ?? 0)}</span>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default InvoiceDetail;

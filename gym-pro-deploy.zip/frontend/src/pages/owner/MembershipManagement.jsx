import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Plus, RefreshCw, Snowflake, Ban, Layers } from 'lucide-react';
import membershipService from '../../services/membershipService';
import customerService from '../../services/customerService';
import { useDebounce } from '../../hooks/useDebounce';
import { usePagination } from '../../hooks/usePagination';
import { extractList, extractPagination, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDate, getDaysRemaining } from '../../utils/formatters';
import { PAYMENT_METHODS } from '../../utils/constants';
import {
  PageHeader,
  SearchInput,
  Select,
  Table,
  Badge,
  Button,
  Modal,
  Input,
  ConfirmDialog,
  ErrorState,
} from '../../components/ui';

export const MembershipManagement = () => {
  const [memberships, setMemberships] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [assignModalOpen, setAssignModalOpen] = useState(false);
  const [renewTarget, setRenewTarget] = useState(null);
  const [cancelTarget, setCancelTarget] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const [assignForm, setAssignForm] = useState({
    customerId: '',
    planId: '',
    startDate: new Date().toISOString().slice(0, 10),
    paymentMethod: 'UPI',
    amountPaid: '',
  });

  const debouncedSearch = useDebounce(search, 350);
  const pagination = usePagination(1, 10);

  const fetchMemberships = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await membershipService.getAll({
        search: debouncedSearch,
        status: statusFilter,
        page: pagination.page,
        limit: pagination.limit,
      });
      setMemberships(extractList(res));
      pagination.updateMeta(extractPagination(res, pagination.limit));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch, statusFilter, pagination.page, pagination.limit]);

  useEffect(() => {
    fetchMemberships();
  }, [fetchMemberships]);

  useEffect(() => {
    Promise.allSettled([
      customerService.getAll({ limit: 200 }),
      membershipService.getPlans(),
    ]).then(([cRes, pRes]) => {
      if (cRes.status === 'fulfilled') setCustomers(extractList(cRes.value));
      if (pRes.status === 'fulfilled') setPlans(extractList(pRes.value));
    });
  }, []);

  const handleAssign = async (e) => {
    e.preventDefault();
    if (!assignForm.customerId || !assignForm.planId) {
      toast.error('Please select a customer and a membership plan');
      return;
    }
    setSubmitting(true);
    try {
      await membershipService.assign({
        ...assignForm,
        amountPaid: Number(assignForm.amountPaid || 0),
      });
      toast.success('Membership assigned successfully');
      setAssignModalOpen(false);
      fetchMemberships();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  const handleRenew = async () => {
    if (!renewTarget) return;
    setSubmitting(true);
    try {
      await membershipService.renew(renewTarget.id || renewTarget._id, {
        planId: renewTarget.planId || renewTarget.plan?.id,
      });
      toast.success('Membership renewed');
      setRenewTarget(null);
      fetchMemberships();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  const handleFreeze = async (m) => {
    try {
      await membershipService.freeze(m.id || m._id, {
        freeze: String(m.status).toUpperCase() !== 'FROZEN',
      });
      toast.success('Membership freeze status updated');
      fetchMemberships();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const handleCancel = async () => {
    if (!cancelTarget) return;
    setSubmitting(true);
    try {
      await membershipService.cancel(cancelTarget.id || cancelTarget._id);
      toast.success('Membership cancelled');
      setCancelTarget(null);
      fetchMemberships();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  const columns = [
    {
      key: 'customer',
      header: 'Member',
      render: (row) => (
        <div>
          <p className="font-semibold text-text-primary">
            {row.customer?.name || row.customerName || '—'}
          </p>
          <p className="text-xs text-text-secondary">
            {row.customer?.mobile || row.customer?.phone || ''}
          </p>
        </div>
      ),
    },
    {
      key: 'plan',
      header: 'Plan',
      render: (row) => (
        <div>
          <p className="font-medium">{row.plan?.name || row.planName || '—'}</p>
          <p className="text-xs text-accent">
            {formatCurrency(row.plan?.price ?? row.amount ?? 0)}
          </p>
        </div>
      ),
    },
    {
      key: 'startDate',
      header: 'Start',
      render: (row) => formatDate(row.startDate),
    },
    {
      key: 'endDate',
      header: 'Expiry',
      sortable: true,
      render: (row) => {
        const days = getDaysRemaining(row.endDate);
        return (
          <div>
            <p>{formatDate(row.endDate)}</p>
            {days >= 0 && days <= 7 && (
              <p className="text-[11px] text-warning">{days} days left</p>
            )}
          </div>
        );
      },
    },
    {
      key: 'status',
      header: 'Status',
      render: (row) => <Badge status={row.status || 'ACTIVE'} dot />,
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (row) => (
        <div className="inline-flex items-center gap-1.5">
          <Button
            size="xs"
            variant="success"
            icon={RefreshCw}
            onClick={() => setRenewTarget(row)}
          >
            Renew
          </Button>
          <Button
            size="xs"
            variant="secondary"
            icon={Snowflake}
            onClick={() => handleFreeze(row)}
            title="Freeze / Unfreeze"
          />
          <Button
            size="xs"
            variant="danger"
            icon={Ban}
            onClick={() => setCancelTarget(row)}
            title="Cancel Membership"
          />
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Memberships & Renewals"
        subtitle="Monitor active subscriptions, expiring plans, renewals, and freezes"
        actions={
          <div className="flex flex-wrap items-center gap-2.5">
            <Link to="/owner/membership-plans">
              <Button variant="secondary" size="sm" icon={Layers}>
                Manage Plans
              </Button>
            </Link>
            <Button size="sm" icon={Plus} onClick={() => setAssignModalOpen(true)}>
              Assign Membership
            </Button>
          </div>
        }
      />

      <div className="flex flex-col sm:flex-row gap-3">
        <SearchInput
          placeholder="Search member name or mobile..."
          value={search}
          onChange={(v) => {
            setSearch(v);
            pagination.resetPage();
          }}
          className="sm:max-w-sm"
        />
        <Select
          value={statusFilter}
          placeholder=""
          containerClassName="sm:w-48"
          options={[
            { value: 'ALL', label: 'All Statuses' },
            { value: 'ACTIVE', label: 'Active' },
            { value: 'EXPIRING', label: 'Expiring Soon' },
            { value: 'EXPIRED', label: 'Expired' },
            { value: 'FROZEN', label: 'Frozen' },
          ]}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            pagination.resetPage();
          }}
        />
      </div>

      {error ? (
        <ErrorState message={error} onRetry={fetchMemberships} />
      ) : (
        <Table
          columns={columns}
          data={memberships}
          loading={loading}
          pagination={pagination}
          onPageChange={pagination.setPage}
          emptyTitle="No memberships found"
        />
      )}

      <Modal
        isOpen={assignModalOpen}
        onClose={() => setAssignModalOpen(false)}
        title="Assign Membership Plan"
      >
        <form onSubmit={handleAssign} className="space-y-4">
          <Select
            label="Member"
            required
            value={assignForm.customerId}
            options={customers.map((c) => ({
              value: c.id || c._id,
              label: `${c.name} (${c.mobile || c.phone || ''})`,
            }))}
            onChange={(e) => setAssignForm((p) => ({ ...p, customerId: e.target.value }))}
          />
          <Select
            label="Membership Plan"
            required
            value={assignForm.planId}
            options={plans.map((pl) => ({
              value: pl.id || pl._id,
              label: `${pl.name} — ${formatCurrency(pl.price ?? pl.amount ?? 0)}`,
            }))}
            onChange={(e) => {
              const plan = plans.find((x) => String(x.id || x._id) === e.target.value);
              setAssignForm((p) => ({
                ...p,
                planId: e.target.value,
                amountPaid: plan ? String(plan.price ?? plan.amount ?? '') : '',
              }));
            }}
          />
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Start Date"
              type="date"
              value={assignForm.startDate}
              onChange={(e) => setAssignForm((p) => ({ ...p, startDate: e.target.value }))}
            />
            <Input
              label="Amount Paid (₹)"
              type="number"
              value={assignForm.amountPaid}
              onChange={(e) => setAssignForm((p) => ({ ...p, amountPaid: e.target.value }))}
            />
          </div>
          <Select
            label="Payment Method"
            value={assignForm.paymentMethod}
            options={PAYMENT_METHODS}
            onChange={(e) => setAssignForm((p) => ({ ...p, paymentMethod: e.target.value }))}
          />
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setAssignModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={submitting}>
              Activate Membership
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(renewTarget)}
        onClose={() => setRenewTarget(null)}
        onConfirm={handleRenew}
        loading={submitting}
        variant="warning"
        title="Renew Membership"
        message={`Renew "${renewTarget?.plan?.name || 'membership'}" for ${
          renewTarget?.customer?.name || 'this member'
        }?`}
        confirmLabel="Renew Now"
      />

      <ConfirmDialog
        isOpen={Boolean(cancelTarget)}
        onClose={() => setCancelTarget(null)}
        onConfirm={handleCancel}
        loading={submitting}
        title="Cancel Membership"
        message={`Are you sure you want to cancel this membership?`}
        confirmLabel="Cancel Membership"
      />
    </div>
  );
};

export default MembershipManagement;

import React from 'react';
import ProfileManager from '../../components/shared/ProfileManager';

export const OwnerProfile = () => {
  return (
    <ProfileManager
      title="Owner Profile"
      subtitle="Update your account contact details, avatar, and password"
    />
  );
};

export default OwnerProfile;

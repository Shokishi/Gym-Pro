import React from 'react';
import NotificationsCenter from '../../components/shared/NotificationsCenter';

export const OwnerNotifications = () => {
  return (
    <NotificationsCenter
      title="Gym Notifications"
      subtitle="Send membership renewal reminders, class announcements, and alerts to your gym"
      canBroadcast
      targetOptions={[
        { value: 'ALL', label: 'All Members & Trainers' },
        { value: 'CUSTOMERS', label: 'All Members' },
        { value: 'EXPIRING', label: 'Members Expiring Soon' },
        { value: 'TRAINERS', label: 'All Trainers' },
      ]}
    />
  );
};

export default OwnerNotifications;

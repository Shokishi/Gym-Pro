import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { ShieldCheck, Save } from 'lucide-react';
import gymService from '../../services/gymService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import {
  PageHeader,
  Card,
  Avatar,
  Badge,
  Toggle,
  Button,
  Skeleton,
  EmptyState,
  ErrorState,
} from '../../components/ui';

const PERMISSION_KEYS = [
  { key: 'canMarkAttendance', label: 'Mark Attendance' },
  { key: 'canManageWorkouts', label: 'Edit Workout Plans' },
  { key: 'canManageDiets', label: 'Edit Diet Plans' },
  { key: 'canViewPayments', label: 'View Payments' },
  { key: 'canManageCustomers', label: 'Edit Customers' },
  { key: 'canViewReports', label: 'View Reports' },
];

export const PermissionManagement = () => {
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [savingId, setSavingId] = useState(null);

  const fetchPermissions = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await gymService.getPermissions();
      setStaff(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPermissions();
  }, [fetchPermissions]);

  const togglePermission = (userIdx, permKey, val) => {
    setStaff((prev) =>
      prev.map((member, i) =>
        i === userIdx
          ? {
              ...member,
              permissions: { ...(member.permissions || {}), [permKey]: val },
            }
          : member
      )
    );
  };

  const handleSave = async (member) => {
    const id = member.userId || member.id || member._id;
    setSavingId(id);
    try {
      await gymService.updatePermissions(id, { permissions: member.permissions || {} });
      toast.success(`Permissions updated for ${member.name}`);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSavingId(null);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Staff & Trainer Permissions"
        subtitle="Control feature-level access for trainers and front-desk staff"
      />

      {loading ? (
        <div className="space-y-4">
          <Skeleton variant="card" />
          <Skeleton variant="card" />
        </div>
      ) : error ? (
        <ErrorState message={error} onRetry={fetchPermissions} />
      ) : staff.length === 0 ? (
        <Card>
          <EmptyState
            icon={ShieldCheck}
            title="No staff accounts found"
            message="Add trainers or staff members to customize their portal permissions."
          />
        </Card>
      ) : (
        <div className="space-y-4">
          {staff.map((member, idx) => {
            const id = member.userId || member.id || member._id;
            const perms = member.permissions || {};
            return (
              <Card
                key={id}
                actions={
                  <Button
                    size="sm"
                    icon={Save}
                    loading={savingId === id}
                    onClick={() => handleSave(member)}
                  >
                    Save
                  </Button>
                }
              >
                <div className="flex items-center gap-3 mb-4 pb-3 border-b border-dark-border">
                  <Avatar src={member.avatar} name={member.name} size="md" />
                  <div>
                    <p className="font-semibold text-text-primary">{member.name}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <Badge variant={member.role || 'TRAINER'}>{member.role || 'TRAINER'}</Badge>
                      <span className="text-xs text-text-secondary">{member.mobile}</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {PERMISSION_KEYS.map((perm) => (
                    <Toggle
                      key={perm.key}
                      checked={Boolean(perms[perm.key])}
                      onChange={(val) => togglePermission(idx, perm.key, val)}
                      label={perm.label}
                    />
                  ))}
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default PermissionManagement;

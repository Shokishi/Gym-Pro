import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Building2, Receipt, BellRing, Save } from 'lucide-react';
import gymService from '../../services/gymService';
import { useAuth } from '../../contexts/AuthContext';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { validateForm } from '../../utils/validators';
import {
  PageHeader,
  Card,
  Input,
  Select,
  Toggle,
  Button,
  Skeleton,
  ErrorState,
} from '../../components/ui';

export const OwnerSettings = () => {
  const { gym, updateGym } = useAuth();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});

  const [form, setForm] = useState({
    name: gym?.name || '',
    phone: gym?.phone || '',
    email: gym?.email || '',
    address: gym?.address || '',
    city: gym?.city || '',
    gstNumber: '',
    invoicePrefix: 'INV-',
    defaultTaxRate: 18,
    currency: 'INR',
    openingTime: '05:30',
    closingTime: '22:00',
    enableQrAttendance: true,
    enableExpiryReminders: true,
    allowMemberSelfPayment: true,
  });

  const loadSettings = async () => {
    setLoading(true);
    setError(null);
    try {
      const [profileRes, settingsRes] = await Promise.allSettled([
        gymService.getGymProfile(),
        gymService.getSettings(),
      ]);
      const pData = profileRes.status === 'fulfilled' ? extractData(profileRes.value, {}) : {};
      const sData = settingsRes.status === 'fulfilled' ? extractData(settingsRes.value, {}) : {};
      setForm((prev) => ({ ...prev, ...pData, ...sData }));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      name: { required: true, label: 'Gym Name' },
      email: { email: true, label: 'Gym Email' },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSaving(true);
    try {
      await Promise.all([
        gymService.updateGymProfile({
          name: form.name,
          phone: form.phone,
          email: form.email,
          address: form.address,
          city: form.city,
        }),
        gymService.updateSettings({
          ...form,
          defaultTaxRate: Number(form.defaultTaxRate || 0),
        }),
      ]);
      updateGym({ name: form.name, phone: form.phone, email: form.email, address: form.address });
      toast.success('Gym settings updated');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Gym Settings"
        subtitle="Configure gym profile, tax/invoicing rules, operating hours, and portal features"
      />

      {loading ? (
        <Skeleton variant="card" />
      ) : error ? (
        <ErrorState message={error} onRetry={loadSettings} />
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6 max-w-4xl">
          <Card title="Gym Identity & Hours" icon={Building2}>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Gym Name"
                required
                value={form.name}
                error={errors.name}
                onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
              />
              <Input
                label="Contact Phone"
                value={form.phone}
                onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))}
              />
              <Input
                label="Contact Email"
                type="email"
                value={form.email}
                error={errors.email}
                onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))}
              />
              <Input
                label="City"
                value={form.city}
                onChange={(e) => setForm((p) => ({ ...p, city: e.target.value }))}
              />
              <Input
                label="Opening Time"
                type="time"
                value={form.openingTime}
                onChange={(e) => setForm((p) => ({ ...p, openingTime: e.target.value }))}
              />
              <Input
                label="Closing Time"
                type="time"
                value={form.closingTime}
                onChange={(e) => setForm((p) => ({ ...p, closingTime: e.target.value }))}
              />
            </div>
            <div className="mt-4">
              <Input
                label="Address"
                value={form.address}
                onChange={(e) => setForm((p) => ({ ...p, address: e.target.value }))}
              />
            </div>
          </Card>

          <Card title="Billing & Invoice Defaults" icon={Receipt}>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <Input
                label="GSTIN / Tax ID"
                placeholder="29ABCDE1234F1Z5"
                value={form.gstNumber}
                onChange={(e) => setForm((p) => ({ ...p, gstNumber: e.target.value }))}
              />
              <Input
                label="Invoice Prefix"
                value={form.invoicePrefix}
                onChange={(e) => setForm((p) => ({ ...p, invoicePrefix: e.target.value }))}
              />
              <Input
                label="Default Tax (%)"
                type="number"
                value={form.defaultTaxRate}
                onChange={(e) => setForm((p) => ({ ...p, defaultTaxRate: e.target.value }))}
              />
              <Select
                label="Currency"
                value={form.currency}
                options={[
                  { value: 'INR', label: 'INR (₹)' },
                  { value: 'USD', label: 'USD ($)' },
                  { value: 'AED', label: 'AED' },
                ]}
                onChange={(e) => setForm((p) => ({ ...p, currency: e.target.value }))}
              />
            </div>
          </Card>

          <Card title="Automation & Member App Features" icon={BellRing}>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <Toggle
                checked={Boolean(form.enableQrAttendance)}
                onChange={(v) => setForm((p) => ({ ...p, enableQrAttendance: v }))}
                label="QR Code Attendance"
                description="Allow trainers & desk to check members in via QR code"
              />
              <Toggle
                checked={Boolean(form.enableExpiryReminders)}
                onChange={(v) => setForm((p) => ({ ...p, enableExpiryReminders: v }))}
                label="Auto Membership Expiry Reminders"
                description="Send notifications 7 days and 1 day before plan expiry"
              />
              <Toggle
                checked={Boolean(form.allowMemberSelfPayment)}
                onChange={(v) => setForm((p) => ({ ...p, allowMemberSelfPayment: v }))}
                label="Member App UPI Submissions"
                description="Let customers pay via QR and upload receipt for approval"
              />
            </div>
          </Card>

          <div className="flex justify-end">
            <Button type="submit" loading={saving} icon={Save}>
              Save Settings
            </Button>
          </div>
        </form>
      )}
    </div>
  );
};

export default OwnerSettings;

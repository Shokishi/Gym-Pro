import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { UserPlus, Eye, Trash2, Share2, Copy } from 'lucide-react';
import trainerService from '../../services/trainerService';
import { useDebounce } from '../../hooks/useDebounce';
import { usePagination } from '../../hooks/usePagination';
import { extractData, extractList, extractPagination, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency } from '../../utils/formatters';
import {
  PageHeader,
  SearchInput,
  Table,
  Avatar,
  Badge,
  Button,
  Modal,
  ConfirmDialog,
  ErrorState,
} from '../../components/ui';

export const TrainerList = () => {
  const navigate = useNavigate();
  const [trainers, setTrainers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [inviteInfo, setInviteInfo] = useState(null);
  const [generatingInvite, setGeneratingInvite] = useState(false);

  const debouncedSearch = useDebounce(search, 350);
  const pagination = usePagination(1, 10);

  const fetchTrainers = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await trainerService.getAll({
        search: debouncedSearch,
        page: pagination.page,
        limit: pagination.limit,
      });
      setTrainers(extractList(res));
      pagination.updateMeta(extractPagination(res, pagination.limit));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch, pagination.page, pagination.limit]);

  useEffect(() => {
    fetchTrainers();
  }, [fetchTrainers]);

  const handleGenerateInvite = async () => {
    setGeneratingInvite(true);
    try {
      const res = await trainerService.generateInvite();
      setInviteInfo(extractData(res));
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setGeneratingInvite(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await trainerService.delete(deleteTarget.id || deleteTarget._id);
      toast.success('Trainer removed');
      setDeleteTarget(null);
      fetchTrainers();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  const columns = [
    {
      key: 'name',
      header: 'Trainer',
      sortable: true,
      render: (row) => (
        <div className="flex items-center gap-3">
          <Avatar src={row.avatar} name={row.name} size="sm" />
          <div>
            <p className="font-semibold text-text-primary">{row.name}</p>
            <p className="text-xs text-text-secondary">{row.mobile || row.phone}</p>
          </div>
        </div>
      ),
    },
    {
      key: 'specialization',
      header: 'Specialization',
      render: (row) => row.specialization || 'General Fitness',
    },
    {
      key: 'clientsCount',
      header: 'Assigned Members',
      render: (row) => row.clientsCount ?? row._count?.customers ?? 0,
    },
    {
      key: 'salary',
      header: 'Monthly Salary',
      render: (row) => formatCurrency(row.baseSalary ?? row.salary ?? 0),
    },
    {
      key: 'status',
      header: 'Status',
      render: (row) => <Badge status={row.status || 'ACTIVE'} dot />,
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (row) => {
        const id = row.id || row._id;
        return (
          <div className="inline-flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
            <Button
              size="xs"
              variant="secondary"
              icon={Eye}
              onClick={() => navigate(`/owner/trainers/${id}`)}
            >
              View
            </Button>
            <Button
              size="xs"
              variant="danger"
              icon={Trash2}
              onClick={() => setDeleteTarget(row)}
            />
          </div>
        );
      },
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Trainers & Coaches"
        subtitle="Manage gym trainers, specializations, payroll rates, and invite codes"
        actions={
          <div className="flex items-center gap-2.5">
            <Button
              variant="secondary"
              icon={Share2}
              loading={generatingInvite}
              onClick={handleGenerateInvite}
            >
              Invite Link
            </Button>
            <Button icon={UserPlus} onClick={() => navigate('/owner/trainers/new')}>
              Add Trainer
            </Button>
          </div>
        }
      />

      <SearchInput
        placeholder="Search trainer name, mobile, or specialization..."
        value={search}
        onChange={(v) => {
          setSearch(v);
          pagination.resetPage();
        }}
        className="sm:max-w-sm"
      />

      {error ? (
        <ErrorState message={error} onRetry={fetchTrainers} />
      ) : (
        <Table
          columns={columns}
          data={trainers}
          loading={loading}
          pagination={pagination}
          onPageChange={pagination.setPage}
          onRowClick={(r) => navigate(`/owner/trainers/${r.id || r._id}`)}
          emptyTitle="No trainers added yet"
          emptyAction={
            <Button icon={UserPlus} onClick={() => navigate('/owner/trainers/new')}>
              Add First Trainer
            </Button>
          }
        />
      )}

      <Modal
        isOpen={Boolean(inviteInfo)}
        onClose={() => setInviteInfo(null)}
        title="Trainer Invitation Code"
        subtitle="Share this code with trainers to register directly under your gym"
        size="sm"
      >
        {inviteInfo && (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-dark-bg border border-dark-border text-center">
              <p className="text-xs text-text-secondary">Invitation Code</p>
              <p className="text-2xl font-mono font-extrabold text-accent mt-1">
                {inviteInfo.code || inviteInfo.inviteCode}
              </p>
            </div>
            <Button
              fullWidth
              icon={Copy}
              onClick={() => {
                const code = inviteInfo.code || inviteInfo.inviteCode;
                navigator.clipboard.writeText(
                  `${window.location.origin}/register/trainer?invite=${code}`
                );
                toast.success('Registration link copied to clipboard');
              }}
            >
              Copy Trainer Registration Link
            </Button>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Remove Trainer"
        message={`Are you sure you want to remove trainer "${deleteTarget?.name}"?`}
        confirmLabel="Remove"
      />
    </div>
  );
};

export default TrainerList;

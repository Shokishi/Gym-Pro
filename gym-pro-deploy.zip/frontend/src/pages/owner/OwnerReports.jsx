import React, { useState, useEffect, useCallback } from 'react';
import { Download, FileText, IndianRupee, Users, TrendingUp, CalendarCheck } from 'lucide-react';
import reportService from '../../services/reportService';
import { useAuth } from '../../contexts/AuthContext';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatNumber, getDateRangeFromPreset } from '../../utils/formatters';
import { generateReportPDF, exportToCSV } from '../../utils/pdfGenerator';
import {
  PageHeader,
  Stat,
  Card,
  DateRangeFilter,
  Button,
  Skeleton,
  ErrorState,
} from '../../components/ui';
import { RevenueChart, AttendanceChart, MembershipChart, ExpenseChart } from '../../components/charts';

export const OwnerReports = () => {
  const { gym } = useAuth();
  const [preset, setPreset] = useState('30d');
  const [customDates, setCustomDates] = useState({ startDate: '', endDate: '' });
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadReports = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const range = getDateRangeFromPreset(preset, customDates.startDate, customDates.endDate);
      const res = await reportService.getOwnerReport({ preset, ...range });
      setData(extractData(res, {}));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [preset, customDates.startDate, customDates.endDate]);

  useEffect(() => {
    loadReports();
  }, [loadReports]);

  const summary = data?.summary || data || {};
  const exportRows = data?.tableRows || data?.revenueSeries || [];

  const handleExportPDF = () => {
    generateReportPDF({
      title: 'Gym Financial & Operations Report',
      subtitle: `Period: ${preset.toUpperCase()}`,
      columns: ['Period', 'Revenue', 'Expenses', 'Check-Ins'],
      rows: exportRows.map((r) => [
        r.label || r.date || '—',
        formatCurrency(r.revenue || 0),
        formatCurrency(r.expenses || 0),
        r.present ?? r.attendance ?? 0,
      ]),
      filename: 'gym-owner-report.pdf',
      gym,
    });
  };

  const handleExportCSV = () => {
    exportToCSV(
      'gym-owner-report.csv',
      ['Period', 'Revenue', 'Expenses', 'Check-Ins'],
      exportRows.map((r) => [r.label || r.date || '', r.revenue || 0, r.expenses || 0, r.present ?? 0])
    );
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Business Reports & Analytics"
        subtitle="Comprehensive financial, attendance, membership, and expense intelligence"
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <DateRangeFilter
              preset={preset}
              onPresetChange={setPreset}
              startDate={customDates.startDate}
              endDate={customDates.endDate}
              onCustomChange={setCustomDates}
            />
            <Button size="sm" variant="secondary" icon={Download} onClick={handleExportCSV}>
              CSV
            </Button>
            <Button size="sm" icon={FileText} onClick={handleExportPDF}>
              PDF
            </Button>
          </div>
        }
      />

      {loading ? (
        <div className="space-y-6">
          <Skeleton variant="stats" count={4} />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Skeleton variant="card" />
            <Skeleton variant="card" />
          </div>
        </div>
      ) : error ? (
        <ErrorState message={error} onRetry={loadReports} />
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
            <Stat
              label="Total Collections"
              value={formatCurrency(summary.totalRevenue || 0)}
              icon={IndianRupee}
              color="accent"
            />
            <Stat
              label="Net Profit"
              value={formatCurrency(summary.netProfit || 0)}
              icon={TrendingUp}
              color="success"
            />
            <Stat
              label="New Memberships"
              value={formatNumber(summary.newMemberships || 0)}
              icon={Users}
              color="info"
            />
            <Stat
              label="Total Check-Ins"
              value={formatNumber(summary.totalAttendance || 0)}
              icon={CalendarCheck}
              color="warning"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card title="Revenue vs Expenses">
              <RevenueChart data={data?.revenueSeries || []} secondaryKey="expenses" type="bar" />
            </Card>
            <Card title="Attendance Consistency">
              <AttendanceChart data={data?.attendanceSeries || []} />
            </Card>
            <Card title="Membership Distribution">
              <MembershipChart data={data?.membershipDistribution || []} />
            </Card>
            <Card title="Expense Breakdown">
              <ExpenseChart data={data?.expenseBreakdown || []} />
            </Card>
          </div>
        </>
      )}
    </div>
  );
};

export default OwnerReports;

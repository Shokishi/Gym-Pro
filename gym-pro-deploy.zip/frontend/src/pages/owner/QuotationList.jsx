import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Plus, FileText, ArrowRightCircle, Trash2 } from 'lucide-react';
import quotationService from '../../services/quotationService';
import { useAuth } from '../../contexts/AuthContext';
import { useDebounce } from '../../hooks/useDebounce';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { generateQuotationPDF } from '../../utils/pdfGenerator';
import {
  PageHeader,
  SearchInput,
  Table,
  Badge,
  Button,
  ConfirmDialog,
  ErrorState,
} from '../../components/ui';

export const QuotationList = () => {
  const navigate = useNavigate();
  const { gym } = useAuth();
  const [quotations, setQuotations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const debouncedSearch = useDebounce(search, 350);

  const fetchQuotations = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await quotationService.getAll({ search: debouncedSearch });
      setQuotations(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [debouncedSearch]);

  useEffect(() => {
    fetchQuotations();
  }, [fetchQuotations]);

  const handleConvert = async (quotation) => {
    try {
      await quotationService.convertToInvoice(quotation.id || quotation._id);
      toast.success('Converted to invoice!');
      fetchQuotations();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await quotationService.delete(deleteTarget.id || deleteTarget._id);
      toast.success('Quotation deleted');
      setDeleteTarget(null);
      fetchQuotations();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  const columns = [
    {
      key: 'quotationNumber',
      header: 'Quotation #',
      render: (r) => <span className="font-mono font-semibold text-accent">{r.quotationNumber || `QT-${r.id}`}</span>,
    },
    {
      key: 'client',
      header: 'Client',
      render: (r) => (
        <div>
          <p className="font-medium">{r.customerName || r.clientName || r.customer?.name || '—'}</p>
          <p className="text-xs text-text-secondary">{r.customerPhone || r.phone || ''}</p>
        </div>
      ),
    },
    {
      key: 'total',
      header: 'Total',
      render: (r) => <span className="font-semibold">{formatCurrency(r.total ?? r.totalAmount ?? 0)}</span>,
    },
    {
      key: 'validUntil',
      header: 'Valid Until',
      render: (r) => formatDate(r.validUntil),
    },
    {
      key: 'status',
      header: 'Status',
      render: (r) => <Badge status={r.status || 'PENDING'} dot />,
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (r) => (
        <div className="inline-flex items-center gap-1.5">
          <Button
            size="xs"
            variant="secondary"
            icon={FileText}
            onClick={() => generateQuotationPDF(r, gym)}
            title="Download PDF"
          >
            PDF
          </Button>
          {String(r.status).toUpperCase() !== 'CONVERTED' && (
            <Button
              size="xs"
              variant="success"
              icon={ArrowRightCircle}
              onClick={() => handleConvert(r)}
            >
              Convert
            </Button>
          )}
          <Button size="xs" variant="danger" icon={Trash2} onClick={() => setDeleteTarget(r)} />
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Quotations & Proposals"
        subtitle="Create corporate or personal membership quotes and convert them into invoices"
        actions={
          <Button icon={Plus} onClick={() => navigate('/owner/quotations/new')}>
            Create Quotation
          </Button>
        }
      />

      <SearchInput
        placeholder="Search quotation # or client name..."
        value={search}
        onChange={setSearch}
        className="sm:max-w-sm"
      />

      {error ? (
        <ErrorState message={error} onRetry={fetchQuotations} />
      ) : (
        <Table
          columns={columns}
          data={quotations}
          loading={loading}
          emptyTitle="No quotations created"
          emptyAction={
            <Button icon={Plus} onClick={() => navigate('/owner/quotations/new')}>
              Create Quotation
            </Button>
          }
        />
      )}

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Quotation"
        message="Remove this quotation permanently?"
        confirmLabel="Delete"
      />
    </div>
  );
};

export default QuotationList;

import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Crown, CheckCircle2, Tag, CreditCard } from 'lucide-react';
import gymService from '../../services/gymService';
import couponService from '../../services/couponService';
import { extractData, extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDate } from '../../utils/formatters';
import {
  PageHeader,
  Card,
  Badge,
  Button,
  Input,
  ProgressBar,
  Modal,
  Select,
  Skeleton,
  ErrorState,
} from '../../components/ui';

export const SubscriptionPage = () => {
  const [subscription, setSubscription] = useState(null);
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [billingCycle, setBillingCycle] = useState('MONTHLY');
  const [couponCode, setCouponCode] = useState('');
  const [discountAmount, setDiscountAmount] = useState(0);
  const [transactionId, setTransactionId] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const loadSubscription = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [subRes, plansRes] = await Promise.all([
        gymService.getMySubscription(),
        gymService.getAvailablePlans(),
      ]);
      setSubscription(extractData(subRes));
      setPlans(extractList(plansRes));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadSubscription();
  }, [loadSubscription]);

  const handleApplyCoupon = async () => {
    if (!couponCode.trim() || !selectedPlan) return;
    const basePrice =
      billingCycle === 'YEARLY'
        ? Number(selectedPlan.yearlyPrice || selectedPlan.monthlyPrice * 10)
        : Number(selectedPlan.monthlyPrice || selectedPlan.price || 0);
    try {
      const res = await couponService.validate(couponCode.trim(), basePrice);
      const data = extractData(res);
      setDiscountAmount(Number(data?.discountAmount || 0));
      toast.success(`Coupon applied! Saved ${formatCurrency(data?.discountAmount || 0)}`);
    } catch (err) {
      setDiscountAmount(0);
      toast.error(getErrorMessage(err, 'Invalid coupon code'));
    }
  };

  const handleUpgrade = async (e) => {
    e.preventDefault();
    if (!selectedPlan) return;
    setSubmitting(true);
    try {
      await gymService.upgradeSubscription({
        planId: selectedPlan.id || selectedPlan._id,
        billingCycle,
        couponCode: couponCode.trim() || undefined,
        transactionId: transactionId.trim() || undefined,
      });
      toast.success('Subscription upgrade request submitted!');
      setSelectedPlan(null);
      setCouponCode('');
      setDiscountAmount(0);
      setTransactionId('');
      loadSubscription();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  const usage = subscription?.usage || {};
  const plan = subscription?.plan || {};

  return (
    <div className="space-y-6">
      <PageHeader
        title="GYM PRO SaaS Subscription"
        subtitle="View your active platform tier, usage limits, and upgrade options"
      />

      {loading ? (
        <Skeleton variant="card" />
      ) : error ? (
        <ErrorState message={error} onRetry={loadSubscription} />
      ) : (
        <>
          <Card
            title={plan.name || subscription?.planName || 'Free Trial'}
            subtitle={`Valid until ${formatDate(subscription?.endDate || subscription?.expiresAt)}`}
            icon={Crown}
            actions={<Badge status={subscription?.status || 'TRIAL'} dot />}
          >
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <ProgressBar
                label={`Active Members (${usage.members || 0} / ${plan.maxMembers || 500})`}
                value={usage.members || 0}
                max={plan.maxMembers || 500}
                color="accent"
              />
              <ProgressBar
                label={`Branches (${usage.branches || 1} / ${plan.maxBranches || 1})`}
                value={usage.branches || 1}
                max={plan.maxBranches || 1}
                color="success"
              />
              <ProgressBar
                label={`Trainers (${usage.trainers || 0} / ${plan.maxTrainers || 10})`}
                value={usage.trainers || 0}
                max={plan.maxTrainers || 10}
                color="warning"
              />
            </div>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {plans.map((p) => {
              const isCurrent = String(p.id || p._id) === String(plan.id || plan._id);
              return (
                <Card
                  key={p.id || p._id}
                  elevated={p.isPopular}
                  className={p.isPopular ? 'border-accent/60' : ''}
                >
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-bold">{p.name}</h3>
                    {isCurrent && <Badge variant="success">Current</Badge>}
                  </div>
                  <p className="text-xs text-text-secondary mt-1">{p.description}</p>
                  <div className="mt-4 pb-4 border-b border-dark-border flex items-baseline gap-1">
                    <span className="text-3xl font-extrabold text-accent">
                      {formatCurrency(p.monthlyPrice ?? p.price ?? 0)}
                    </span>
                    <span className="text-xs text-text-secondary">/month</span>
                  </div>
                  <ul className="mt-4 space-y-2 text-xs text-text-secondary">
                    {(Array.isArray(p.features) ? p.features : []).map((f, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-success shrink-0" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                  <Button
                    fullWidth
                    className="mt-5"
                    variant={isCurrent ? 'secondary' : 'primary'}
                    icon={CreditCard}
                    onClick={() => setSelectedPlan(p)}
                  >
                    {isCurrent ? 'Renew Plan' : 'Upgrade to ' + p.name}
                  </Button>
                </Card>
              );
            })}
          </div>
        </>
      )}

      <Modal
        isOpen={Boolean(selectedPlan)}
        onClose={() => setSelectedPlan(null)}
        title={`Subscribe to ${selectedPlan?.name}`}
      >
        {selectedPlan && (
          <form onSubmit={handleUpgrade} className="space-y-4">
            <Select
              label="Billing Cycle"
              value={billingCycle}
              options={[
                {
                  value: 'MONTHLY',
                  label: `Monthly — ${formatCurrency(selectedPlan.monthlyPrice ?? selectedPlan.price ?? 0)}`,
                },
                {
                  value: 'YEARLY',
                  label: `Yearly — ${formatCurrency(
                    selectedPlan.yearlyPrice || (selectedPlan.monthlyPrice || 0) * 10
                  )}`,
                },
              ]}
              onChange={(e) => {
                setBillingCycle(e.target.value);
                setDiscountAmount(0);
              }}
            />

            <div className="flex items-end gap-2">
              <Input
                label="Coupon Code (Optional)"
                icon={Tag}
                placeholder="e.g. GYMPRO20"
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
              />
              <Button type="button" variant="secondary" onClick={handleApplyCoupon}>
                Apply
              </Button>
            </div>

            <Input
              label="Payment UTR / Reference Number"
              placeholder="Enter UPI transaction reference"
              value={transactionId}
              onChange={(e) => setTransactionId(e.target.value)}
            />

            <div className="p-3.5 rounded-xl bg-dark-bg border border-dark-border flex justify-between items-center text-sm">
              <span className="text-text-secondary">Payable Total</span>
              <span className="text-lg font-bold text-accent">
                {formatCurrency(
                  Math.max(
                    0,
                    (billingCycle === 'YEARLY'
                      ? Number(selectedPlan.yearlyPrice || selectedPlan.monthlyPrice * 10)
                      : Number(selectedPlan.monthlyPrice ?? selectedPlan.price ?? 0)) - discountAmount
                  )
                )}
              </span>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <Button variant="secondary" onClick={() => setSelectedPlan(null)}>
                Cancel
              </Button>
              <Button type="submit" loading={submitting}>
                Submit Upgrade
              </Button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
};

export default SubscriptionPage;

import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import {
  User,
  CalendarCheck,
  CreditCard,
  Dumbbell,
  Utensils,
  TrendingUp,
  Edit2,
  Save,
} from 'lucide-react';
import customerService from '../../services/customerService';
import attendanceService from '../../services/attendanceService';
import paymentService from '../../services/paymentService';
import workoutService from '../../services/workoutService';
import dietService from '../../services/dietService';
import progressService from '../../services/progressService';
import { extractData, extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDate, formatDateTime, calculateBMI } from '../../utils/formatters';
import {
  PageHeader,
  Card,
  Avatar,
  Badge,
  Tabs,
  Table,
  Button,
  Input,
  Modal,
  Skeleton,
  ErrorState,
  EmptyState,
} from '../../components/ui';
import { ProgressChart } from '../../components/charts';

export const CustomerDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('info');
  const [customer, setCustomer] = useState(null);
  const [attendance, setAttendance] = useState([]);
  const [payments, setPayments] = useState([]);
  const [workouts, setWorkouts] = useState([]);
  const [diets, setDiets] = useState([]);
  const [progress, setProgress] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editOpen, setEditOpen] = useState(false);
  const [editForm, setEditForm] = useState({});
  const [saving, setSaving] = useState(false);

  const loadCustomerData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await customerService.getById(id);
      const data = extractData(res);
      setCustomer(data);
      setEditForm({
        name: data?.name || '',
        mobile: data?.mobile || data?.phone || '',
        email: data?.email || '',
        address: data?.address || '',
        heightCm: data?.heightCm || '',
        weightKg: data?.weightKg || '',
      });

      const [attRes, payRes, wkRes, dtRes, prRes] = await Promise.allSettled([
        attendanceService.getAll({ customerId: id, limit: 30 }),
        paymentService.getAll({ customerId: id, limit: 30 }),
        workoutService.getAll({ customerId: id }),
        dietService.getAll({ customerId: id }),
        progressService.getByCustomer(id),
      ]);

      if (attRes.status === 'fulfilled') setAttendance(extractList(attRes.value));
      if (payRes.status === 'fulfilled') setPayments(extractList(payRes.value));
      if (wkRes.status === 'fulfilled') setWorkouts(extractList(wkRes.value));
      if (dtRes.status === 'fulfilled') setDiets(extractList(dtRes.value));
      if (prRes.status === 'fulfilled') setProgress(extractList(prRes.value));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    loadCustomerData();
  }, [loadCustomerData]);

  const handleUpdateCustomer = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await customerService.update(id, editForm);
      toast.success('Member profile updated');
      setEditOpen(false);
      loadCustomerData();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <PageHeader title="Member Profile" backTo="/owner/customers" />
        <Skeleton variant="card" />
        <Skeleton variant="table" rows={4} columns={4} />
      </div>
    );
  }

  if (error || !customer) {
    return (
      <div className="space-y-6">
        <PageHeader title="Member Profile" backTo="/owner/customers" />
        <ErrorState message={error || 'Customer not found'} onRetry={loadCustomerData} />
      </div>
    );
  }

  const bmiData = calculateBMI(customer.weightKg, customer.heightCm);

  const tabs = [
    { key: 'info', label: 'Info', icon: User },
    { key: 'attendance', label: 'Attendance', icon: CalendarCheck, count: attendance.length },
    { key: 'payments', label: 'Payments', icon: CreditCard, count: payments.length },
    { key: 'workouts', label: 'Workouts', icon: Dumbbell, count: workouts.length },
    { key: 'diet', label: 'Diet', icon: Utensils, count: diets.length },
    { key: 'progress', label: 'Progress', icon: TrendingUp, count: progress.length },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title={customer.name}
        subtitle={`${customer.mobile || customer.phone || ''} ${customer.email ? `• ${customer.email}` : ''}`}
        backTo="/owner/customers"
        badge={<Badge status={customer.status || 'ACTIVE'} dot />}
        actions={
          <Button variant="secondary" size="sm" icon={Edit2} onClick={() => setEditOpen(true)}>
            Edit Profile
          </Button>
        }
      />

      <Card>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Avatar src={customer.avatar} name={customer.name} size="xl" status="active" />
            <div>
              <h3 className="text-lg font-bold text-text-primary">{customer.name}</h3>
              <p className="text-xs text-text-secondary mt-0.5">
                Member Since: {formatDate(customer.createdAt || customer.joinDate)} • Trainer:{' '}
                <span className="text-text-primary font-medium">
                  {customer.trainer?.name || 'Unassigned'}
                </span>
              </p>
              <div className="flex flex-wrap gap-2 mt-2">
                {customer.fitnessGoal && (
                  <Badge variant="accent">{String(customer.fitnessGoal).replace(/_/g, ' ')}</Badge>
                )}
                {bmiData.bmi && (
                  <Badge variant="neutral">
                    BMI: {bmiData.bmi} ({bmiData.category})
                  </Badge>
                )}
              </div>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-dark-bg border border-dark-border min-w-[210px]">
            <p className="text-xs text-text-secondary">Active Membership</p>
            <p className="text-sm font-bold text-accent mt-0.5">
              {customer.activeMembership?.plan?.name || customer.planName || 'No Active Plan'}
            </p>
            {customer.activeMembership?.endDate && (
              <p className="text-xs text-text-secondary mt-1">
                Expires {formatDate(customer.activeMembership.endDate)}
              </p>
            )}
          </div>
        </div>
      </Card>

      <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />

      {activeTab === 'info' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card title="Personal & Physical Profile">
            <dl className="space-y-3 text-sm">
              <div className="flex justify-between">
                <dt className="text-text-secondary">Gender</dt>
                <dd className="font-medium">{customer.gender || '—'}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-text-secondary">Date of Birth</dt>
                <dd className="font-medium">{formatDate(customer.dob || customer.dateOfBirth)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-text-secondary">Height / Weight</dt>
                <dd className="font-medium">
                  {customer.heightCm ? `${customer.heightCm} cm` : '—'} /{' '}
                  {customer.weightKg ? `${customer.weightKg} kg` : '—'}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-text-secondary">Emergency Contact</dt>
                <dd className="font-medium">{customer.emergencyContact || '—'}</dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-text-secondary shrink-0">Address</dt>
                <dd className="font-medium text-right">{customer.address || '—'}</dd>
              </div>
            </dl>
          </Card>

          <Card title="Health & Notes">
            <p className="text-sm text-text-secondary whitespace-pre-line">
              {customer.medicalNotes || customer.notes || 'No medical notes or special instructions recorded.'}
            </p>
          </Card>
        </div>
      )}

      {activeTab === 'attendance' && (
        <Table
          columns={[
            { key: 'date', header: 'Date', render: (r) => formatDate(r.date || r.checkInTime) },
            { key: 'checkIn', header: 'Check-In', render: (r) => formatDateTime(r.checkInTime || r.createdAt) },
            { key: 'method', header: 'Method', render: (r) => <Badge variant="neutral">{r.method || 'MANUAL'}</Badge> },
            { key: 'status', header: 'Status', render: (r) => <Badge status={r.status || 'PRESENT'} /> },
          ]}
          data={attendance}
          emptyTitle="No attendance history"
        />
      )}

      {activeTab === 'payments' && (
        <Table
          columns={[
            { key: 'date', header: 'Date', render: (r) => formatDate(r.paidAt || r.createdAt) },
            { key: 'plan', header: 'Plan / Description', render: (r) => r.plan?.name || r.description || 'Membership' },
            { key: 'amount', header: 'Amount', render: (r) => formatCurrency(r.amount) },
            { key: 'method', header: 'Method', render: (r) => r.paymentMethod || r.method || 'UPI' },
            { key: 'status', header: 'Status', render: (r) => <Badge status={r.status || 'PAID'} /> },
          ]}
          data={payments}
          onRowClick={(r) => navigate(`/owner/payments/${r.id || r._id}`)}
          emptyTitle="No payments recorded"
        />
      )}

      {activeTab === 'workouts' && (
        <Card title="Assigned Workout Plans">
          {workouts.length === 0 ? (
            <EmptyState icon={Dumbbell} title="No workout plans assigned" />
          ) : (
            <div className="space-y-3">
              {workouts.map((w) => (
                <div key={w.id || w._id} className="p-4 rounded-xl bg-dark-bg border border-dark-border flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-text-primary">{w.name || w.title}</p>
                    <p className="text-xs text-text-secondary">
                      {w.goal?.replace(/_/g, ' ')} • {w.exercises?.length || 0} exercises
                    </p>
                  </div>
                  <Badge variant="accent">{w.difficulty || 'INTERMEDIATE'}</Badge>
                </div>
              ))}
            </div>
          )}
        </Card>
      )}

      {activeTab === 'diet' && (
        <Card title="Assigned Diet Plans">
          {diets.length === 0 ? (
            <EmptyState icon={Utensils} title="No diet plans assigned" />
          ) : (
            <div className="space-y-3">
              {diets.map((d) => (
                <div key={d.id || d._id} className="p-4 rounded-xl bg-dark-bg border border-dark-border flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-text-primary">{d.name || d.title}</p>
                    <p className="text-xs text-text-secondary">
                      {d.totalCalories || 0} kcal • P: {d.totalProtein || 0}g / C: {d.totalCarbs || 0}g / F: {d.totalFats || 0}g
                    </p>
                  </div>
                  <Badge variant="success">{d.dietType || 'BALANCED'}</Badge>
                </div>
              ))}
            </div>
          )}
        </Card>
      )}

      {activeTab === 'progress' && (
        <Card title="Fitness Progress Trend">
          <ProgressChart
            data={progress.map((p) => ({
              ...p,
              date: formatDate(p.recordedAt || p.date || p.createdAt, 'DD MMM'),
            }))}
          />
        </Card>
      )}

      <Modal isOpen={editOpen} onClose={() => setEditOpen(false)} title="Edit Member Profile">
        <form onSubmit={handleUpdateCustomer} className="space-y-4">
          <Input
            label="Full Name"
            required
            value={editForm.name || ''}
            onChange={(e) => setEditForm((p) => ({ ...p, name: e.target.value }))}
          />
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Mobile"
              required
              value={editForm.mobile || ''}
              onChange={(e) => setEditForm((p) => ({ ...p, mobile: e.target.value }))}
            />
            <Input
              label="Email"
              type="email"
              value={editForm.email || ''}
              onChange={(e) => setEditForm((p) => ({ ...p, email: e.target.value }))}
            />
            <Input
              label="Height (cm)"
              type="number"
              value={editForm.heightCm || ''}
              onChange={(e) => setEditForm((p) => ({ ...p, heightCm: e.target.value }))}
            />
            <Input
              label="Weight (kg)"
              type="number"
              value={editForm.weightKg || ''}
              onChange={(e) => setEditForm((p) => ({ ...p, weightKg: e.target.value }))}
            />
          </div>
          <Input
            label="Address"
            value={editForm.address || ''}
            onChange={(e) => setEditForm((p) => ({ ...p, address: e.target.value }))}
          />
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setEditOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving} icon={Save}>
              Save Profile
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default CustomerDetail;

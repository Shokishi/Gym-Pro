import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Plus, Gift, Trash2 } from 'lucide-react';
import referralService from '../../services/referralService';
import customerService from '../../services/customerService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { validateForm } from '../../utils/validators';
import {
  PageHeader,
  Table,
  Badge,
  Button,
  Modal,
  Input,
  Select,
  ConfirmDialog,
  ErrorState,
} from '../../components/ui';

export const ReferralManagement = () => {
  const [referrals, setReferrals] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [errors, setErrors] = useState({});

  const [form, setForm] = useState({
    referrerId: '',
    referredName: '',
    referredMobile: '',
    rewardAmount: 500,
  });

  const fetchReferrals = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await referralService.getAll();
      setReferrals(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchReferrals();
    customerService
      .getAll({ limit: 150 })
      .then((res) => setCustomers(extractList(res)))
      .catch(() => {});
  }, [fetchReferrals]);

  const handleCreate = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      referrerId: { required: true, label: 'Referring Member' },
      referredName: { required: true, label: 'Referred Friend Name' },
      referredMobile: { required: true, label: 'Friend Mobile', mobile: true },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSaving(true);
    try {
      await referralService.create({ ...form, rewardAmount: Number(form.rewardAmount || 0) });
      toast.success('Referral logged');
      setModalOpen(false);
      fetchReferrals();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleReward = async (ref) => {
    try {
      await referralService.markRewarded(ref.id || ref._id, { status: 'REWARDED' });
      toast.success('Referral reward issued!');
      fetchReferrals();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await referralService.delete(deleteTarget.id || deleteTarget._id);
      toast.success('Referral deleted');
      setDeleteTarget(null);
      fetchReferrals();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  const columns = [
    { key: 'referrer', header: 'Referred By', render: (r) => r.referrer?.name || r.referrerName || '—' },
    {
      key: 'referred',
      header: 'New Prospect',
      render: (r) => (
        <div>
          <p className="font-medium">{r.referredName || r.referred?.name || '—'}</p>
          <p className="text-xs text-text-secondary">{r.referredMobile || ''}</p>
        </div>
      ),
    },
    { key: 'reward', header: 'Reward', render: (r) => formatCurrency(r.rewardAmount ?? 0) },
    { key: 'date', header: 'Date', render: (r) => formatDate(r.createdAt) },
    { key: 'status', header: 'Status', render: (r) => <Badge status={r.status || 'PENDING'} dot /> },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (r) => (
        <div className="inline-flex items-center gap-1.5">
          {String(r.status).toUpperCase() !== 'REWARDED' && (
            <Button size="xs" variant="success" icon={Gift} onClick={() => handleReward(r)}>
              Reward
            </Button>
          )}
          <Button size="xs" variant="danger" icon={Trash2} onClick={() => setDeleteTarget(r)} />
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Member Referrals"
        subtitle="Track member-get-member referrals and reward bonuses"
        actions={
          <Button icon={Plus} onClick={() => setModalOpen(true)}>
            Log Referral
          </Button>
        }
      />

      {error ? (
        <ErrorState message={error} onRetry={fetchReferrals} />
      ) : (
        <Table
          columns={columns}
          data={referrals}
          loading={loading}
          emptyTitle="No referrals tracked yet"
        />
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Log Member Referral">
        <form onSubmit={handleCreate} className="space-y-4">
          <Select
            label="Referring Member"
            required
            value={form.referrerId}
            error={errors.referrerId}
            options={customers.map((c) => ({ value: c.id || c._id, label: c.name }))}
            onChange={(e) => setForm((p) => ({ ...p, referrerId: e.target.value }))}
          />
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Friend Name"
              required
              value={form.referredName}
              error={errors.referredName}
              onChange={(e) => setForm((p) => ({ ...p, referredName: e.target.value }))}
            />
            <Input
              label="Friend Mobile"
              required
              value={form.referredMobile}
              error={errors.referredMobile}
              onChange={(e) => setForm((p) => ({ ...p, referredMobile: e.target.value }))}
            />
          </div>
          <Input
            label="Reward Bonus (₹)"
            type="number"
            value={form.rewardAmount}
            onChange={(e) => setForm((p) => ({ ...p, rewardAmount: e.target.value }))}
          />
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              Save Referral
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Referral"
        message="Remove this referral entry?"
        confirmLabel="Delete"
      />
    </div>
  );
};

export default ReferralManagement;

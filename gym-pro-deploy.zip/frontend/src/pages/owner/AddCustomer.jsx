import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { UserPlus } from 'lucide-react';
import customerService from '../../services/customerService';
import trainerService from '../../services/trainerService';
import membershipService from '../../services/membershipService';
import { useGym } from '../../contexts/GymContext';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { FITNESS_GOALS, PAYMENT_METHODS } from '../../utils/constants';
import { validateForm } from '../../utils/validators';
import { formatCurrency } from '../../utils/formatters';
import { PageHeader, Card, Input, Select, Textarea, Button } from '../../components/ui';

export const AddCustomer = () => {
  const navigate = useNavigate();
  const { branches, activeBranchId } = useGym();
  const [trainers, setTrainers] = useState([]);
  const [plans, setPlans] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState({});

  const [form, setForm] = useState({
    name: '',
    mobile: '',
    email: '',
    password: '',
    gender: 'MALE',
    dob: '',
    heightCm: '',
    weightKg: '',
    fitnessGoal: 'GENERAL_FITNESS',
    trainerId: '',
    planId: '',
    branchId: activeBranchId !== 'ALL' ? activeBranchId : '',
    paymentMethod: 'CASH',
    amountPaid: '',
    address: '',
    emergencyContact: '',
    medicalNotes: '',
  });

  useEffect(() => {
    Promise.allSettled([trainerService.getAll({ limit: 100 }), membershipService.getPlans()]).then(
      ([tRes, pRes]) => {
        if (tRes.status === 'fulfilled') setTrainers(extractList(tRes.value));
        if (pRes.status === 'fulfilled') setPlans(extractList(pRes.value));
      }
    );
  }, []);

  const handlePlanChange = (planId) => {
    const plan = plans.find((p) => String(p.id || p._id) === String(planId));
    setForm((prev) => ({
      ...prev,
      planId,
      amountPaid: plan ? String(plan.price ?? plan.amount ?? '') : prev.amountPaid,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      name: { required: true, label: 'Full Name', minLength: 2 },
      mobile: { required: true, label: 'Mobile Number', mobile: true },
      email: { email: true, label: 'Email' },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSubmitting(true);
    try {
      await customerService.create({
        ...form,
        heightCm: form.heightCm ? Number(form.heightCm) : undefined,
        weightKg: form.weightKg ? Number(form.weightKg) : undefined,
        amountPaid: form.amountPaid ? Number(form.amountPaid) : undefined,
      });
      toast.success('Member added successfully!');
      navigate('/owner/customers');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Add New Customer"
        subtitle="Onboard a new gym member with optional membership plan & trainer assignment"
        backTo="/owner/customers"
      />

      <form onSubmit={handleSubmit} className="space-y-6 max-w-4xl">
        <Card title="Basic Information">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Full Name"
              required
              placeholder="e.g. Rohan Sharma"
              value={form.name}
              error={errors.name}
              onChange={(e) => {
                setForm((p) => ({ ...p, name: e.target.value }));
                setErrors((p) => ({ ...p, name: '' }));
              }}
            />
            <Input
              label="Mobile Number"
              type="tel"
              required
              placeholder="10-digit mobile"
              value={form.mobile}
              error={errors.mobile}
              onChange={(e) => {
                setForm((p) => ({ ...p, mobile: e.target.value }));
                setErrors((p) => ({ ...p, mobile: '' }));
              }}
            />
            <Input
              label="Email (Optional)"
              type="email"
              placeholder="member@example.com"
              value={form.email}
              error={errors.email}
              onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))}
            />
            <Input
              label="Initial Portal Password (Optional)"
              type="password"
              placeholder="Defaults to mobile / auto-generated"
              value={form.password}
              onChange={(e) => setForm((p) => ({ ...p, password: e.target.value }))}
            />
            <Select
              label="Gender"
              value={form.gender}
              options={[
                { value: 'MALE', label: 'Male' },
                { value: 'FEMALE', label: 'Female' },
                { value: 'OTHER', label: 'Other' },
              ]}
              onChange={(e) => setForm((p) => ({ ...p, gender: e.target.value }))}
            />
            <Input
              label="Date of Birth"
              type="date"
              value={form.dob}
              onChange={(e) => setForm((p) => ({ ...p, dob: e.target.value }))}
            />
          </div>
        </Card>

        <Card title="Fitness & Assignment">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <Input
              label="Height (cm)"
              type="number"
              placeholder="175"
              value={form.heightCm}
              onChange={(e) => setForm((p) => ({ ...p, heightCm: e.target.value }))}
            />
            <Input
              label="Weight (kg)"
              type="number"
              placeholder="72"
              value={form.weightKg}
              onChange={(e) => setForm((p) => ({ ...p, weightKg: e.target.value }))}
            />
            <Select
              label="Fitness Goal"
              value={form.fitnessGoal}
              options={FITNESS_GOALS}
              onChange={(e) => setForm((p) => ({ ...p, fitnessGoal: e.target.value }))}
            />
            <Select
              label="Assign Trainer"
              placeholder="Optional"
              value={form.trainerId}
              options={trainers.map((t) => ({
                value: t.id || t._id,
                label: `${t.name} (${t.specialization || 'Trainer'})`,
              }))}
              onChange={(e) => setForm((p) => ({ ...p, trainerId: e.target.value }))}
            />
            {branches.length > 0 && (
              <Select
                label="Branch"
                placeholder="Main Branch"
                value={form.branchId}
                options={branches.map((b) => ({ value: b.id || b._id, label: b.name }))}
                onChange={(e) => setForm((p) => ({ ...p, branchId: e.target.value }))}
              />
            )}
          </div>
        </Card>

        <Card title="Membership Plan & Initial Payment (Optional)">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Select
              label="Membership Plan"
              placeholder="No initial plan"
              value={form.planId}
              options={plans.map((p) => ({
                value: p.id || p._id,
                label: `${p.name} (${formatCurrency(p.price ?? p.amount ?? 0)})`,
              }))}
              onChange={(e) => handlePlanChange(e.target.value)}
            />
            <Input
              label="Amount Collected (₹)"
              type="number"
              placeholder="0"
              value={form.amountPaid}
              onChange={(e) => setForm((p) => ({ ...p, amountPaid: e.target.value }))}
            />
            <Select
              label="Payment Method"
              value={form.paymentMethod}
              options={PAYMENT_METHODS}
              onChange={(e) => setForm((p) => ({ ...p, paymentMethod: e.target.value }))}
            />
          </div>
        </Card>

        <Card title="Contact & Health Notes">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Address"
              value={form.address}
              onChange={(e) => setForm((p) => ({ ...p, address: e.target.value }))}
            />
            <Input
              label="Emergency Contact"
              value={form.emergencyContact}
              onChange={(e) => setForm((p) => ({ ...p, emergencyContact: e.target.value }))}
            />
          </div>
          <div className="mt-4">
            <Textarea
              label="Medical Conditions / Injuries"
              rows={2}
              placeholder="Any knee pain, hypertension, allergies..."
              value={form.medicalNotes}
              onChange={(e) => setForm((p) => ({ ...p, medicalNotes: e.target.value }))}
            />
          </div>
        </Card>

        <div className="flex justify-end gap-3">
          <Button variant="secondary" onClick={() => navigate('/owner/customers')}>
            Cancel
          </Button>
          <Button type="submit" loading={submitting} icon={UserPlus}>
            Register Member
          </Button>
        </div>
      </form>
    </div>
  );
};

export default AddCustomer;

import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { User, Users, Wallet, CalendarClock, Edit2, Save } from 'lucide-react';
import trainerService from '../../services/trainerService';
import salaryService from '../../services/salaryService';
import { extractData, extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDate } from '../../utils/formatters';
import {
  PageHeader,
  Card,
  Avatar,
  Badge,
  Tabs,
  Table,
  Button,
  Modal,
  Input,
  Skeleton,
  ErrorState,
} from '../../components/ui';

export const TrainerDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('profile');
  const [trainer, setTrainer] = useState(null);
  const [salaries, setSalaries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editOpen, setEditOpen] = useState(false);
  const [editForm, setEditForm] = useState({});
  const [saving, setSaving] = useState(false);

  const loadTrainer = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [tRes, sRes] = await Promise.allSettled([
        trainerService.getById(id),
        salaryService.getAll({ trainerId: id }),
      ]);
      if (tRes.status === 'rejected') throw tRes.reason;
      const data = extractData(tRes.value);
      setTrainer(data);
      setEditForm({
        name: data?.name || '',
        mobile: data?.mobile || data?.phone || '',
        specialization: data?.specialization || '',
        baseSalary: data?.baseSalary ?? data?.salary ?? '',
        commissionPercent: data?.commissionPercent ?? 0,
      });
      if (sRes.status === 'fulfilled') setSalaries(extractList(sRes.value));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    loadTrainer();
  }, [loadTrainer]);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await trainerService.update(id, {
        ...editForm,
        baseSalary: Number(editForm.baseSalary || 0),
        commissionPercent: Number(editForm.commissionPercent || 0),
      });
      toast.success('Trainer updated');
      setEditOpen(false);
      loadTrainer();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <PageHeader title="Trainer Profile" backTo="/owner/trainers" />
        <Skeleton variant="card" />
      </div>
    );
  }

  if (error || !trainer) {
    return (
      <div className="space-y-6">
        <PageHeader title="Trainer Profile" backTo="/owner/trainers" />
        <ErrorState message={error || 'Trainer not found'} onRetry={loadTrainer} />
      </div>
    );
  }

  const assignedCustomers = trainer.customers || trainer.assignedCustomers || [];
  const appointments = trainer.appointments || [];

  const tabs = [
    { key: 'profile', label: 'Profile & Rates', icon: User },
    { key: 'customers', label: 'Assigned Customers', icon: Users, count: assignedCustomers.length },
    { key: 'schedule', label: 'Schedule', icon: CalendarClock, count: appointments.length },
    { key: 'salaries', label: 'Salary History', icon: Wallet, count: salaries.length },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title={trainer.name}
        subtitle={`${trainer.specialization || 'Fitness Coach'} • ${trainer.mobile || trainer.phone || ''}`}
        backTo="/owner/trainers"
        badge={<Badge status={trainer.status || 'ACTIVE'} dot />}
        actions={
          <Button variant="secondary" size="sm" icon={Edit2} onClick={() => setEditOpen(true)}>
            Edit Trainer
          </Button>
        }
      />

      <Card>
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Avatar src={trainer.avatar} name={trainer.name} size="xl" status="active" />
            <div>
              <h3 className="text-lg font-bold">{trainer.name}</h3>
              <p className="text-sm text-text-secondary">{trainer.specialization}</p>
              <p className="text-xs text-text-secondary mt-1">
                Joined {formatDate(trainer.createdAt)} • {trainer.experienceYears || 0} yrs experience
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 rounded-xl bg-dark-bg border border-dark-border text-center">
              <p className="text-xs text-text-secondary">Base Salary</p>
              <p className="text-base font-bold text-accent">
                {formatCurrency(trainer.baseSalary ?? trainer.salary ?? 0)}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-dark-bg border border-dark-border text-center">
              <p className="text-xs text-text-secondary">Commission</p>
              <p className="text-base font-bold text-success">{trainer.commissionPercent ?? 0}%</p>
            </div>
          </div>
        </div>
      </Card>

      <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />

      {activeTab === 'profile' && (
        <Card title="Employment & Certification Details">
          <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            <div>
              <dt className="text-text-secondary text-xs">Email</dt>
              <dd className="font-medium mt-0.5">{trainer.email || '—'}</dd>
            </div>
            <div>
              <dt className="text-text-secondary text-xs">Shift Timing</dt>
              <dd className="font-medium mt-0.5">{trainer.shiftTiming || '06:00 AM - 02:00 PM'}</dd>
            </div>
            <div>
              <dt className="text-text-secondary text-xs">Certifications</dt>
              <dd className="font-medium mt-0.5">{trainer.certifications || 'Certified Personal Trainer'}</dd>
            </div>
            <div>
              <dt className="text-text-secondary text-xs">Bio</dt>
              <dd className="font-medium mt-0.5">{trainer.bio || '—'}</dd>
            </div>
          </dl>
        </Card>
      )}

      {activeTab === 'customers' && (
        <Table
          columns={[
            { key: 'name', header: 'Member', render: (r) => r.name },
            { key: 'mobile', header: 'Mobile', render: (r) => r.mobile || r.phone || '—' },
            { key: 'goal', header: 'Goal', render: (r) => r.fitnessGoal?.replace(/_/g, ' ') || '—' },
            { key: 'status', header: 'Status', render: (r) => <Badge status={r.status || 'ACTIVE'} /> },
          ]}
          data={assignedCustomers}
          onRowClick={(r) => navigate(`/owner/customers/${r.id || r._id}`)}
          emptyTitle="No customers assigned to this trainer"
        />
      )}

      {activeTab === 'schedule' && (
        <Table
          columns={[
            { key: 'title', header: 'Session', render: (r) => r.title || r.type || 'Personal Training' },
            { key: 'customer', header: 'Member', render: (r) => r.customer?.name || '—' },
            { key: 'date', header: 'Date', render: (r) => formatDate(r.date || r.scheduledAt) },
            { key: 'status', header: 'Status', render: (r) => <Badge status={r.status || 'SCHEDULED'} /> },
          ]}
          data={appointments}
          emptyTitle="No scheduled sessions"
        />
      )}

      {activeTab === 'salaries' && (
        <Table
          columns={[
            { key: 'month', header: 'Period', render: (r) => r.month || formatDate(r.payDate, 'MMM YYYY') },
            { key: 'amount', header: 'Net Payout', render: (r) => formatCurrency(r.netAmount ?? r.amount ?? 0) },
            { key: 'status', header: 'Status', render: (r) => <Badge status={r.status || 'PAID'} /> },
            { key: 'paidAt', header: 'Paid Date', render: (r) => formatDate(r.paidAt) },
          ]}
          data={salaries}
          emptyTitle="No salary payouts recorded"
        />
      )}

      <Modal isOpen={editOpen} onClose={() => setEditOpen(false)} title="Edit Trainer">
        <form onSubmit={handleSave} className="space-y-4">
          <Input
            label="Full Name"
            required
            value={editForm.name || ''}
            onChange={(e) => setEditForm((p) => ({ ...p, name: e.target.value }))}
          />
          <Input
            label="Mobile Number"
            required
            value={editForm.mobile || ''}
            onChange={(e) => setEditForm((p) => ({ ...p, mobile: e.target.value }))}
          />
          <Input
            label="Specialization"
            value={editForm.specialization || ''}
            onChange={(e) => setEditForm((p) => ({ ...p, specialization: e.target.value }))}
          />
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Base Salary (₹)"
              type="number"
              value={editForm.baseSalary ?? ''}
              onChange={(e) => setEditForm((p) => ({ ...p, baseSalary: e.target.value }))}
            />
            <Input
              label="Commission (%)"
              type="number"
              value={editForm.commissionPercent ?? 0}
              onChange={(e) => setEditForm((p) => ({ ...p, commissionPercent: e.target.value }))}
            />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setEditOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving} icon={Save}>
              Save Changes
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default TrainerDetail;

import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Plus, Wrench, Edit2, Trash2 } from 'lucide-react';
import equipmentService from '../../services/equipmentService';
import { useDebounce } from '../../hooks/useDebounce';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { validateForm } from '../../utils/validators';
import {
  PageHeader,
  SearchInput,
  Select,
  Table,
  Badge,
  Button,
  Modal,
  Input,
  Textarea,
  ConfirmDialog,
  ErrorState,
} from '../../components/ui';

export const EquipmentManagement = () => {
  const [equipment, setEquipment] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [maintTarget, setMaintTarget] = useState(null);
  const [maintNotes, setMaintNotes] = useState('');
  const [maintCost, setMaintCost] = useState('');
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [errors, setErrors] = useState({});

  const [form, setForm] = useState({
    name: '',
    category: 'CARDIO',
    brand: '',
    quantity: 1,
    purchaseCost: '',
    purchaseDate: '',
    status: 'GOOD',
  });

  const debouncedSearch = useDebounce(search, 300);

  const fetchEquipment = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await equipmentService.getAll({ search: debouncedSearch });
      setEquipment(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [debouncedSearch]);

  useEffect(() => {
    fetchEquipment();
  }, [fetchEquipment]);

  const openModal = (item = null) => {
    setEditing(item);
    setForm(
      item
        ? {
            name: item.name || '',
            category: item.category || 'STRENGTH',
            brand: item.brand || '',
            quantity: item.quantity ?? 1,
            purchaseCost: item.purchaseCost ?? '',
            purchaseDate: item.purchaseDate ? String(item.purchaseDate).slice(0, 10) : '',
            status: item.status || 'GOOD',
          }
        : {
            name: '',
            category: 'CARDIO',
            brand: '',
            quantity: 1,
            purchaseCost: '',
            purchaseDate: '',
            status: 'GOOD',
          }
    );
    setErrors({});
    setModalOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      name: { required: true, label: 'Equipment Name' },
      quantity: { required: true, label: 'Quantity', min: 1 },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSaving(true);
    try {
      const payload = {
        ...form,
        quantity: Number(form.quantity || 1),
        purchaseCost: form.purchaseCost ? Number(form.purchaseCost) : undefined,
      };
      if (editing) {
        await equipmentService.update(editing.id || editing._id, payload);
        toast.success('Equipment updated');
      } else {
        await equipmentService.create(payload);
        toast.success('Equipment added to inventory');
      }
      setModalOpen(false);
      fetchEquipment();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleMaintenance = async (e) => {
    e.preventDefault();
    if (!maintTarget) return;
    setSaving(true);
    try {
      await equipmentService.logMaintenance(maintTarget.id || maintTarget._id, {
        notes: maintNotes,
        cost: Number(maintCost || 0),
        date: new Date().toISOString(),
      });
      toast.success('Maintenance logged');
      setMaintTarget(null);
      setMaintNotes('');
      setMaintCost('');
      fetchEquipment();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await equipmentService.delete(deleteTarget.id || deleteTarget._id);
      toast.success('Equipment removed');
      setDeleteTarget(null);
      fetchEquipment();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  const columns = [
    {
      key: 'name',
      header: 'Equipment',
      render: (r) => (
        <div>
          <p className="font-semibold text-text-primary">{r.name}</p>
          <p className="text-xs text-text-secondary">{r.brand || r.category}</p>
        </div>
      ),
    },
    { key: 'category', header: 'Category', render: (r) => <Badge variant="neutral">{r.category}</Badge> },
    { key: 'quantity', header: 'Qty', render: (r) => r.quantity ?? 1 },
    { key: 'cost', header: 'Value', render: (r) => formatCurrency(r.purchaseCost ?? 0) },
    { key: 'lastMaint', header: 'Last Service', render: (r) => formatDate(r.lastMaintenanceDate) },
    { key: 'status', header: 'Condition', render: (r) => <Badge status={r.status || 'GOOD'} dot /> },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (r) => (
        <div className="inline-flex items-center gap-1.5">
          <Button
            size="xs"
            variant="secondary"
            icon={Wrench}
            onClick={() => setMaintTarget(r)}
            title="Log Maintenance"
          >
            Service
          </Button>
          <Button size="xs" variant="secondary" icon={Edit2} onClick={() => openModal(r)} />
          <Button size="xs" variant="danger" icon={Trash2} onClick={() => setDeleteTarget(r)} />
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Equipment & Maintenance"
        subtitle="Track gym machines, asset valuation, and service schedules"
        actions={
          <Button icon={Plus} onClick={() => openModal()}>
            Add Equipment
          </Button>
        }
      />

      <SearchInput
        placeholder="Search machine name or brand..."
        value={search}
        onChange={setSearch}
        className="sm:max-w-sm"
      />

      {error ? (
        <ErrorState message={error} onRetry={fetchEquipment} />
      ) : (
        <Table
          columns={columns}
          data={equipment}
          loading={loading}
          emptyTitle="No equipment registered"
        />
      )}

      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Edit Equipment' : 'Add Equipment'}
      >
        <form onSubmit={handleSave} className="space-y-4">
          <Input
            label="Equipment Name"
            required
            placeholder="e.g. Commercial Treadmill T900"
            value={form.name}
            error={errors.name}
            onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
          />
          <div className="grid grid-cols-2 gap-4">
            <Select
              label="Category"
              value={form.category}
              options={['CARDIO', 'STRENGTH', 'FREE_WEIGHTS', 'FUNCTIONAL', 'ACCESSORIES']}
              onChange={(e) => setForm((p) => ({ ...p, category: e.target.value }))}
            />
            <Input
              label="Brand"
              placeholder="e.g. LifeFitness"
              value={form.brand}
              onChange={(e) => setForm((p) => ({ ...p, brand: e.target.value }))}
            />
            <Input
              label="Quantity"
              type="number"
              min={1}
              value={form.quantity}
              onChange={(e) => setForm((p) => ({ ...p, quantity: e.target.value }))}
            />
            <Input
              label="Purchase Cost (₹)"
              type="number"
              value={form.purchaseCost}
              onChange={(e) => setForm((p) => ({ ...p, purchaseCost: e.target.value }))}
            />
            <Input
              label="Purchase Date"
              type="date"
              value={form.purchaseDate}
              onChange={(e) => setForm((p) => ({ ...p, purchaseDate: e.target.value }))}
            />
            <Select
              label="Condition"
              value={form.status}
              options={[
                { value: 'GOOD', label: 'Good / Operational' },
                { value: 'MAINTENANCE', label: 'Needs Maintenance' },
                { value: 'OUT_OF_ORDER', label: 'Out of Order' },
              ]}
              onChange={(e) => setForm((p) => ({ ...p, status: e.target.value }))}
            />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              Save Equipment
            </Button>
          </div>
        </form>
      </Modal>

      <Modal
        isOpen={Boolean(maintTarget)}
        onClose={() => setMaintTarget(null)}
        title="Log Equipment Maintenance"
        subtitle={maintTarget?.name}
        size="sm"
      >
        <form onSubmit={handleMaintenance} className="space-y-4">
          <Input
            label="Service Cost (₹)"
            type="number"
            value={maintCost}
            onChange={(e) => setMaintCost(e.target.value)}
          />
          <Textarea
            label="Service Notes"
            required
            rows={3}
            placeholder="Belt replaced, lubricated, motor checked..."
            value={maintNotes}
            onChange={(e) => setMaintNotes(e.target.value)}
          />
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setMaintTarget(null)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              Save Service Log
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Remove Equipment"
        message={`Delete "${deleteTarget?.name}" from inventory?`}
        confirmLabel="Remove"
      />
    </div>
  );
};

export default EquipmentManagement;

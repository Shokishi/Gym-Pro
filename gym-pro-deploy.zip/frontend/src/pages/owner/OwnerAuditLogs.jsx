import React, { useState, useEffect, useCallback } from 'react';
import gymService from '../../services/gymService';
import { useDebounce } from '../../hooks/useDebounce';
import { usePagination } from '../../hooks/usePagination';
import { extractList, extractPagination, getErrorMessage } from '../../utils/apiHelpers';
import { formatDateTime } from '../../utils/formatters';
import { PageHeader, SearchInput, Table, Badge, ErrorState } from '../../components/ui';

export const OwnerAuditLogs = () => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');

  const debouncedSearch = useDebounce(search, 350);
  const pagination = usePagination(1, 15);

  const fetchLogs = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await gymService.getAuditLogs({
        search: debouncedSearch,
        page: pagination.page,
        limit: pagination.limit,
      });
      setLogs(extractList(res));
      pagination.updateMeta(extractPagination(res, pagination.limit));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch, pagination.page, pagination.limit]);

  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  const columns = [
    {
      key: 'createdAt',
      header: 'Timestamp',
      render: (r) => <span className="text-xs font-mono">{formatDateTime(r.createdAt)}</span>,
    },
    { key: 'user', header: 'User', render: (r) => r.user?.name || r.actorName || 'System' },
    { key: 'action', header: 'Action', render: (r) => <Badge variant="accent">{r.action}</Badge> },
    { key: 'entity', header: 'Module', render: (r) => r.entity || r.module || '—' },
    {
      key: 'description',
      header: 'Details',
      render: (r) => (
        <span className="text-xs text-text-secondary">{r.description || r.details || '—'}</span>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Gym Audit Logs"
        subtitle="Track staff and owner activity across memberships, payments, and settings"
      />

      <SearchInput
        placeholder="Search user, action, or entity..."
        value={search}
        onChange={(v) => {
          setSearch(v);
          pagination.resetPage();
        }}
        className="sm:max-w-sm"
      />

      {error ? (
        <ErrorState message={error} onRetry={fetchLogs} />
      ) : (
        <Table
          columns={columns}
          data={logs}
          loading={loading}
          pagination={pagination}
          onPageChange={pagination.setPage}
          emptyTitle="No activity logs recorded"
        />
      )}
    </div>
  );
};

export default OwnerAuditLogs;

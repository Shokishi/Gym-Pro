import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Users,
  IndianRupee,
  CalendarCheck,
  AlertTriangle,
  UserPlus,
  QrCode,
  ArrowRight,
  Clock,
} from 'lucide-react';
import gymService from '../../services/gymService';
import { useGym } from '../../contexts/GymContext';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDate, formatNumber, getDateRangeFromPreset } from '../../utils/formatters';
import {
  PageHeader,
  Stat,
  Card,
  Badge,
  Button,
  DateRangeFilter,
  Skeleton,
  ErrorState,
} from '../../components/ui';
import { RevenueChart, AttendanceChart, MembershipChart } from '../../components/charts';

export const OwnerDashboard = () => {
  const { activeBranchId } = useGym();
  const navigate = useNavigate();
  const [preset, setPreset] = useState('30d');
  const [customDates, setCustomDates] = useState({ startDate: '', endDate: '' });
  const [dashboard, setDashboard] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const range = getDateRangeFromPreset(preset, customDates.startDate, customDates.endDate);
      const res = await gymService.getDashboard({
        preset,
        branchId: activeBranchId !== 'ALL' ? activeBranchId : undefined,
        ...range,
      });
      setDashboard(extractData(res, {}));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [preset, customDates.startDate, customDates.endDate, activeBranchId]);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  const stats = dashboard?.stats || dashboard || {};
  const expiringMemberships = dashboard?.expiringMemberships || [];
  const pendingPayments = dashboard?.pendingPayments || [];
  const todayCheckIns = dashboard?.todayCheckIns || [];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Gym Dashboard"
        subtitle="Real-time overview of revenue, active members, check-ins, and renewals"
        actions={
          <div className="flex flex-wrap items-center gap-2.5">
            <DateRangeFilter
              preset={preset}
              onPresetChange={setPreset}
              startDate={customDates.startDate}
              endDate={customDates.endDate}
              onCustomChange={setCustomDates}
            />
            <Button
              size="sm"
              variant="secondary"
              icon={QrCode}
              onClick={() => navigate('/owner/attendance')}
            >
              QR Check-In
            </Button>
            <Button size="sm" icon={UserPlus} onClick={() => navigate('/owner/customers/new')}>
              Add Member
            </Button>
          </div>
        }
      />

      {loading ? (
        <div className="space-y-6">
          <Skeleton variant="stats" count={4} />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Skeleton variant="card" />
            <Skeleton variant="card" />
          </div>
        </div>
      ) : error ? (
        <ErrorState message={error} onRetry={loadDashboard} />
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
            <Stat
              label="Total Revenue"
              value={formatCurrency(stats.totalRevenue ?? stats.revenue ?? 0)}
              icon={IndianRupee}
              color="accent"
              trend={stats.revenueGrowth}
              trendLabel={`${formatCurrency(stats.netProfit || 0)} net`}
              onClick={() => navigate('/owner/payments')}
            />
            <Stat
              label="Active Members"
              value={formatNumber(stats.activeMembers ?? stats.totalCustomers ?? 0)}
              icon={Users}
              color="success"
              trend={stats.memberGrowth}
              trendLabel={`${formatNumber(stats.newMembers || 0)} joined`}
              onClick={() => navigate('/owner/customers')}
            />
            <Stat
              label="Today's Check-Ins"
              value={formatNumber(stats.todayAttendance ?? stats.checkInsToday ?? 0)}
              icon={CalendarCheck}
              color="info"
              subtitle={`Avg daily: ${formatNumber(stats.avgDailyAttendance || 0)}`}
              onClick={() => navigate('/owner/attendance')}
            />
            <Stat
              label="Expiring Soon (7d)"
              value={formatNumber(stats.expiringSoon ?? expiringMemberships.length ?? 0)}
              icon={AlertTriangle}
              color="warning"
              subtitle={`${formatNumber(stats.pendingPaymentsCount ?? pendingPayments.length ?? 0)} pending approvals`}
              onClick={() => navigate('/owner/memberships')}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card title="Revenue vs Expenses" subtitle="Cashflow performance for selected period">
              <RevenueChart
                data={dashboard?.revenueChart || []}
                secondaryKey="expenses"
                type="bar"
              />
            </Card>
            <Card title="Daily Attendance Trend" subtitle="Member check-ins over time">
              <AttendanceChart data={dashboard?.attendanceChart || []} />
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card title="Membership Mix" className="lg:col-span-1">
              <MembershipChart data={dashboard?.membershipDistribution || []} />
            </Card>

            <Card
              title="Expiring Memberships"
              icon={Clock}
              className="lg:col-span-1"
              actions={
                <Link to="/owner/memberships">
                  <Button variant="ghost" size="xs" rightIcon={ArrowRight}>
                    Manage
                  </Button>
                </Link>
              }
            >
              {expiringMemberships.length === 0 ? (
                <p className="text-sm text-text-secondary py-6 text-center">
                  No memberships expiring within 7 days.
                </p>
              ) : (
                <div className="divide-y divide-dark-border/60">
                  {expiringMemberships.slice(0, 5).map((m) => (
                    <div key={m.id || m._id} className="py-2.5 flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-text-primary truncate">
                          {m.customer?.name || m.customerName}
                        </p>
                        <p className="text-xs text-text-secondary">
                          {m.plan?.name || m.planName} • Ends {formatDate(m.endDate)}
                        </p>
                      </div>
                      <Badge status="expiring">Expiring</Badge>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            <Card
              title="Recent Check-Ins & Payments"
              className="lg:col-span-1"
              actions={
                <Link to="/owner/payments">
                  <Button variant="ghost" size="xs" rightIcon={ArrowRight}>
                    Payments
                  </Button>
                </Link>
              }
            >
              {todayCheckIns.length === 0 && pendingPayments.length === 0 ? (
                <p className="text-sm text-text-secondary py-6 text-center">
                  No recent check-ins or pending approvals today.
                </p>
              ) : (
                <div className="divide-y divide-dark-border/60">
                  {pendingPayments.slice(0, 3).map((p) => (
                    <div key={p.id || p._id} className="py-2.5 flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">
                          {p.customer?.name || p.customerName}
                        </p>
                        <p className="text-xs text-text-secondary">
                          Payment {formatCurrency(p.amount)}
                        </p>
                      </div>
                      <Badge status={p.status || 'pending'} />
                    </div>
                  ))}
                  {todayCheckIns.slice(0, 4).map((a) => (
                    <div key={a.id || a._id} className="py-2.5 flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">
                          {a.customer?.name || a.customerName}
                        </p>
                        <p className="text-xs text-text-secondary">Checked in</p>
                      </div>
                      <Badge status="present">Present</Badge>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>
        </>
      )}
    </div>
  );
};

export default OwnerDashboard;

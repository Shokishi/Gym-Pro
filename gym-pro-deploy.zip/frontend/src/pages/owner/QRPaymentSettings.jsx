import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { QrCode, Save } from 'lucide-react';
import paymentService from '../../services/paymentService';
import { useAuth } from '../../contexts/AuthContext';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { validateForm } from '../../utils/validators';
import {
  PageHeader,
  Card,
  Input,
  Textarea,
  Button,
  FileUpload,
  QRCodeDisplay,
  Skeleton,
  ErrorState,
} from '../../components/ui';

export const QRPaymentSettings = () => {
  const { gym } = useAuth();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});
  const [qrFile, setQrFile] = useState(null);

  const [form, setForm] = useState({
    upiId: '',
    merchantName: gym?.name || 'GYM PRO Fitness',
    instructions: 'Scan QR to pay via GPay, PhonePe, or Paytm and upload screenshot with UTR number.',
    qrImageUrl: '',
  });

  const loadSettings = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await paymentService.getQrSettings();
      const data = extractData(res);
      if (data) setForm((p) => ({ ...p, ...data }));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      upiId: { required: true, label: 'UPI ID' },
      merchantName: { required: true, label: 'Merchant / Payee Name' },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSaving(true);
    try {
      let payload;
      if (qrFile) {
        payload = new FormData();
        payload.append('upiId', form.upiId.trim());
        payload.append('merchantName', form.merchantName.trim());
        payload.append('instructions', form.instructions);
        payload.append('qrImage', qrFile);
      } else {
        payload = form;
      }
      await paymentService.updateQrSettings(payload);
      toast.success('UPI QR payment settings saved');
      loadSettings();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const upiUri = form.upiId
    ? `upi://pay?pa=${encodeURIComponent(form.upiId)}&pn=${encodeURIComponent(form.merchantName || 'Gym')}&cu=INR`
    : '';

  return (
    <div className="space-y-6">
      <PageHeader
        title="UPI & QR Payment Settings"
        subtitle="Configure your gym's UPI QR code so members can pay fees directly in the Member App"
      />

      {loading ? (
        <Skeleton variant="card" />
      ) : error ? (
        <ErrorState message={error} onRetry={loadSettings} />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card title="UPI Configuration" icon={QrCode} className="lg:col-span-2">
            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input
                  label="UPI ID (VPA)"
                  required
                  placeholder="e.g. ironcorefitness@okicici"
                  value={form.upiId}
                  error={errors.upiId}
                  onChange={(e) => {
                    setForm((p) => ({ ...p, upiId: e.target.value }));
                    setErrors((p) => ({ ...p, upiId: '' }));
                  }}
                />
                <Input
                  label="Payee / Merchant Name"
                  required
                  value={form.merchantName}
                  error={errors.merchantName}
                  onChange={(e) => {
                    setForm((p) => ({ ...p, merchantName: e.target.value }));
                    setErrors((p) => ({ ...p, merchantName: '' }));
                  }}
                />
              </div>

              <Textarea
                label="Payment Instructions for Members"
                rows={3}
                value={form.instructions}
                onChange={(e) => setForm((p) => ({ ...p, instructions: e.target.value }))}
              />

              <FileUpload
                label="Custom QR Code Image (Optional — otherwise auto-generated from UPI ID)"
                accept="image/*"
                value={qrFile}
                previewUrl={form.qrImageUrl}
                onChange={setQrFile}
              />

              <div className="flex justify-end pt-2">
                <Button type="submit" loading={saving} icon={Save}>
                  Save QR Settings
                </Button>
              </div>
            </form>
          </Card>

          <Card title="Live Member Preview">
            <div className="flex flex-col items-center text-center py-4 space-y-4">
              {form.qrImageUrl && !qrFile ? (
                <img
                  src={form.qrImageUrl}
                  alt="Gym UPI QR"
                  className="w-52 h-52 object-contain bg-white p-3 rounded-2xl"
                />
              ) : upiUri ? (
                <QRCodeDisplay
                  value={upiUri}
                  size={190}
                  label={`Pay to ${form.upiId}`}
                  showDownload
                  downloadName="gym-upi-qr.png"
                />
              ) : (
                <p className="text-sm text-text-secondary py-10">
                  Enter a UPI ID to generate a scannable payment QR code.
                </p>
              )}
              <div className="text-xs text-text-secondary bg-dark-bg border border-dark-border rounded-xl p-3 w-full">
                <p className="font-semibold text-text-primary">{form.merchantName}</p>
                <p className="mt-1">{form.instructions}</p>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};

export default QRPaymentSettings;

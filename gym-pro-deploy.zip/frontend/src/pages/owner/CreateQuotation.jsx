import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import dayjs from 'dayjs';
import { Plus, Trash2, Save } from 'lucide-react';
import quotationService from '../../services/quotationService';
import { validateForm } from '../../utils/validators';
import { formatCurrency } from '../../utils/formatters';
import { getErrorMessage } from '../../utils/apiHelpers';
import { PageHeader, Card, Input, Textarea, Button } from '../../components/ui';

export const CreateQuotation = () => {
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});

  const [form, setForm] = useState({
    customerName: '',
    customerPhone: '',
    customerEmail: '',
    validUntil: dayjs().add(14, 'day').format('YYYY-MM-DD'),
    discount: 0,
    taxPercent: 18,
    notes: 'Valid for 14 days from issue date.',
    items: [{ description: 'Annual Gym Membership + PT Pack', quantity: 1, unitPrice: 12000 }],
  });

  const subtotal = form.items.reduce(
    (sum, item) => sum + Number(item.quantity || 0) * Number(item.unitPrice || 0),
    0
  );
  const discount = Number(form.discount || 0);
  const taxable = Math.max(0, subtotal - discount);
  const tax = Math.round((taxable * Number(form.taxPercent || 0)) / 100);
  const total = taxable + tax;

  const updateItem = (idx, field, val) => {
    setForm((prev) => ({
      ...prev,
      items: prev.items.map((item, i) => (i === idx ? { ...item, [field]: val } : item)),
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      customerName: { required: true, label: 'Client Name' },
      customerPhone: { required: true, label: 'Phone Number', mobile: true },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSaving(true);
    try {
      await quotationService.create({
        ...form,
        subtotal,
        discount,
        tax,
        total,
        totalAmount: total,
        items: form.items.map((item) => ({
          ...item,
          quantity: Number(item.quantity || 1),
          unitPrice: Number(item.unitPrice || 0),
          total: Number(item.quantity || 1) * Number(item.unitPrice || 0),
        })),
      });
      toast.success('Quotation created');
      navigate('/owner/quotations');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Create Quotation"
        subtitle="Prepare an itemized price proposal for prospective or corporate clients"
        backTo="/owner/quotations"
      />

      <form onSubmit={handleSubmit} className="space-y-6 max-w-4xl">
        <Card title="Client Details">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Client / Company Name"
              required
              value={form.customerName}
              error={errors.customerName}
              onChange={(e) => {
                setForm((p) => ({ ...p, customerName: e.target.value }));
                setErrors((p) => ({ ...p, customerName: '' }));
              }}
            />
            <Input
              label="Mobile Number"
              required
              value={form.customerPhone}
              error={errors.customerPhone}
              onChange={(e) => {
                setForm((p) => ({ ...p, customerPhone: e.target.value }));
                setErrors((p) => ({ ...p, customerPhone: '' }));
              }}
            />
            <Input
              label="Email (Optional)"
              type="email"
              value={form.customerEmail}
              onChange={(e) => setForm((p) => ({ ...p, customerEmail: e.target.value }))}
            />
            <Input
              label="Valid Until"
              type="date"
              value={form.validUntil}
              onChange={(e) => setForm((p) => ({ ...p, validUntil: e.target.value }))}
            />
          </div>
        </Card>

        <Card
          title="Line Items"
          actions={
            <Button
              type="button"
              size="sm"
              variant="secondary"
              icon={Plus}
              onClick={() =>
                setForm((p) => ({
                  ...p,
                  items: [...p.items, { description: '', quantity: 1, unitPrice: 0 }],
                }))
              }
            >
              Add Item
            </Button>
          }
        >
          <div className="space-y-3">
            {form.items.map((item, idx) => (
              <div key={idx} className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
                <Input
                  label="Description"
                  required
                  containerClassName="sm:col-span-6"
                  value={item.description}
                  onChange={(e) => updateItem(idx, 'description', e.target.value)}
                />
                <Input
                  label="Qty"
                  type="number"
                  min={1}
                  containerClassName="sm:col-span-2"
                  value={item.quantity}
                  onChange={(e) => updateItem(idx, 'quantity', e.target.value)}
                />
                <Input
                  label="Unit Price (₹)"
                  type="number"
                  min={0}
                  containerClassName="sm:col-span-3"
                  value={item.unitPrice}
                  onChange={(e) => updateItem(idx, 'unitPrice', e.target.value)}
                />
                <div className="sm:col-span-1 flex justify-end pb-1">
                  {form.items.length > 1 && (
                    <button
                      type="button"
                      onClick={() =>
                        setForm((p) => ({ ...p, items: p.items.filter((_, i) => i !== idx) }))
                      }
                      className="p-2 text-error hover:bg-error-light rounded-lg"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 pt-4 border-t border-dark-border grid grid-cols-1 sm:grid-cols-2 gap-6 items-start">
            <Textarea
              label="Terms & Notes"
              rows={3}
              value={form.notes}
              onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))}
            />
            <div className="bg-dark-bg border border-dark-border rounded-xl p-4 space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <Input
                  label="Discount (₹)"
                  type="number"
                  min={0}
                  value={form.discount}
                  onChange={(e) => setForm((p) => ({ ...p, discount: e.target.value }))}
                />
                <Input
                  label="GST (%)"
                  type="number"
                  min={0}
                  value={form.taxPercent}
                  onChange={(e) => setForm((p) => ({ ...p, taxPercent: e.target.value }))}
                />
              </div>
              <div className="flex justify-between text-text-secondary pt-2 border-t border-dark-border">
                <span>Subtotal</span>
                <span>{formatCurrency(subtotal)}</span>
              </div>
              <div className="flex justify-between text-text-secondary">
                <span>Tax / GST</span>
                <span>{formatCurrency(tax)}</span>
              </div>
              <div className="flex justify-between text-base font-bold text-accent">
                <span>Estimated Total</span>
                <span>{formatCurrency(total)}</span>
              </div>
            </div>
          </div>
        </Card>

        <div className="flex justify-end gap-3">
          <Button variant="secondary" onClick={() => navigate('/owner/quotations')}>
            Cancel
          </Button>
          <Button type="submit" loading={saving} icon={Save}>
            Save Quotation
          </Button>
        </div>
      </form>
    </div>
  );
};

export default CreateQuotation;

import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Plus, Building2, MapPin, Phone, Edit2, Trash2 } from 'lucide-react';
import gymService from '../../services/gymService';
import { useGym } from '../../contexts/GymContext';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { validateForm } from '../../utils/validators';
import {
  PageHeader,
  Card,
  Badge,
  Button,
  Modal,
  Input,
  Toggle,
  ConfirmDialog,
  Skeleton,
  EmptyState,
  ErrorState,
} from '../../components/ui';

const INITIAL_FORM = {
  name: '',
  phone: '',
  address: '',
  city: '',
  managerName: '',
  isMain: false,
  isActive: true,
};

export const BranchManagement = () => {
  const { refreshGymData } = useGym();
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(INITIAL_FORM);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const fetchBranches = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await gymService.getBranches();
      setBranches(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchBranches();
  }, [fetchBranches]);

  const openModal = (branch = null) => {
    setEditing(branch);
    setForm(
      branch
        ? {
            name: branch.name || '',
            phone: branch.phone || '',
            address: branch.address || '',
            city: branch.city || '',
            managerName: branch.managerName || '',
            isMain: Boolean(branch.isMain),
            isActive: branch.isActive !== false,
          }
        : INITIAL_FORM
    );
    setErrors({});
    setModalOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      name: { required: true, label: 'Branch Name' },
      address: { required: true, label: 'Address' },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSaving(true);
    try {
      if (editing) {
        await gymService.updateBranch(editing.id || editing._id, form);
        toast.success('Branch updated');
      } else {
        await gymService.createBranch(form);
        toast.success('Branch added');
      }
      setModalOpen(false);
      fetchBranches();
      refreshGymData();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await gymService.deleteBranch(deleteTarget.id || deleteTarget._id);
      toast.success('Branch removed');
      setDeleteTarget(null);
      fetchBranches();
      refreshGymData();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Branch Management"
        subtitle="Operate multiple gym locations and filter dashboards by branch"
        actions={
          <Button icon={Plus} onClick={() => openModal()}>
            Add Branch
          </Button>
        }
      />

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Skeleton variant="card" />
          <Skeleton variant="card" />
        </div>
      ) : error ? (
        <ErrorState message={error} onRetry={fetchBranches} />
      ) : branches.length === 0 ? (
        <Card>
          <EmptyState
            icon={Building2}
            title="No branches configured"
            message="Add your gym branches to manage staff and revenue across locations."
            action={
              <Button icon={Plus} onClick={() => openModal()}>
                Add First Branch
              </Button>
            }
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {branches.map((branch) => (
            <Card key={branch.id || branch._id}>
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-accent-light text-accent flex items-center justify-center shrink-0">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-text-primary">{branch.name}</h3>
                    {branch.isMain && <Badge variant="accent">Headquarters</Badge>}
                  </div>
                </div>
                <Badge status={branch.isActive !== false ? 'active' : 'inactive'} />
              </div>

              <div className="mt-4 space-y-2 text-xs text-text-secondary">
                <p className="flex items-start gap-2">
                  <MapPin className="w-3.5 h-3.5 text-accent shrink-0 mt-0.5" />
                  <span>
                    {branch.address}
                    {branch.city ? `, ${branch.city}` : ''}
                  </span>
                </p>
                {branch.phone && (
                  <p className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-accent shrink-0" />
                    <span>{branch.phone}</span>
                  </p>
                )}
                {branch.managerName && <p>Manager: {branch.managerName}</p>}
              </div>

              <div className="mt-4 pt-3 border-t border-dark-border flex items-center gap-2">
                <Button
                  size="xs"
                  variant="secondary"
                  icon={Edit2}
                  onClick={() => openModal(branch)}
                  className="flex-1"
                >
                  Edit
                </Button>
                <Button
                  size="xs"
                  variant="danger"
                  icon={Trash2}
                  onClick={() => setDeleteTarget(branch)}
                />
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Edit Branch' : 'Add New Branch'}
      >
        <form onSubmit={handleSave} className="space-y-4">
          <Input
            label="Branch Name"
            required
            placeholder="e.g. Indiranagar Studio"
            value={form.name}
            error={errors.name}
            onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
          />
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Phone"
              value={form.phone}
              onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))}
            />
            <Input
              label="City"
              value={form.city}
              onChange={(e) => setForm((p) => ({ ...p, city: e.target.value }))}
            />
          </div>
          <Input
            label="Full Address"
            required
            value={form.address}
            error={errors.address}
            onChange={(e) => setForm((p) => ({ ...p, address: e.target.value }))}
          />
          <Input
            label="Branch Manager Name"
            value={form.managerName}
            onChange={(e) => setForm((p) => ({ ...p, managerName: e.target.value }))}
          />
          <div className="flex flex-wrap gap-6 pt-1">
            <Toggle
              checked={form.isMain}
              onChange={(v) => setForm((p) => ({ ...p, isMain: v }))}
              label="Main Branch"
            />
            <Toggle
              checked={form.isActive}
              onChange={(v) => setForm((p) => ({ ...p, isActive: v }))}
              label="Active"
            />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              {editing ? 'Update Branch' : 'Create Branch'}
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Branch"
        message={`Remove branch "${deleteTarget?.name}"?`}
        confirmLabel="Delete"
      />
    </div>
  );
};

export default BranchManagement;

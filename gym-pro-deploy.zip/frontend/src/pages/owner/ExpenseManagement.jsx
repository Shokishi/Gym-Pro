import React, { useState, useEffect, useCallback, useMemo } from 'react';
import toast from 'react-hot-toast';
import { Plus, Trash2, Edit2 } from 'lucide-react';
import expenseService from '../../services/expenseService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDate, getDateRangeFromPreset } from '../../utils/formatters';
import { validateForm } from '../../utils/validators';
import {
  PageHeader,
  Card,
  Select,
  DateRangeFilter,
  Table,
  Badge,
  Button,
  Modal,
  Input,
  Textarea,
  ConfirmDialog,
  ErrorState,
} from '../../components/ui';
import { ExpenseChart } from '../../components/charts';

const CATEGORIES = [
  'RENT',
  'UTILITIES',
  'EQUIPMENT',
  'MAINTENANCE',
  'MARKETING',
  'SUPPLIES',
  'SALARIES',
  'OTHER',
];

export const ExpenseManagement = () => {
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [preset, setPreset] = useState('30d');
  const [customDates, setCustomDates] = useState({ startDate: '', endDate: '' });
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [errors, setErrors] = useState({});

  const [form, setForm] = useState({
    title: '',
    category: 'UTILITIES',
    amount: '',
    date: new Date().toISOString().slice(0, 10),
    paymentMethod: 'UPI',
    notes: '',
  });

  const fetchExpenses = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const range = getDateRangeFromPreset(preset, customDates.startDate, customDates.endDate);
      const res = await expenseService.getAll({ category: categoryFilter, ...range });
      setExpenses(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [preset, customDates.startDate, customDates.endDate, categoryFilter]);

  useEffect(() => {
    fetchExpenses();
  }, [fetchExpenses]);

  const categoryChartData = useMemo(() => {
    const map = {};
    expenses.forEach((e) => {
      const cat = e.category || 'OTHER';
      map[cat] = (map[cat] || 0) + Number(e.amount || 0);
    });
    return Object.entries(map).map(([category, amount]) => ({ category, amount }));
  }, [expenses]);

  const openModal = (item = null) => {
    setEditing(item);
    setForm(
      item
        ? {
            title: item.title || item.description || '',
            category: item.category || 'OTHER',
            amount: item.amount ?? '',
            date: item.date ? String(item.date).slice(0, 10) : new Date().toISOString().slice(0, 10),
            paymentMethod: item.paymentMethod || 'UPI',
            notes: item.notes || '',
          }
        : {
            title: '',
            category: 'UTILITIES',
            amount: '',
            date: new Date().toISOString().slice(0, 10),
            paymentMethod: 'UPI',
            notes: '',
          }
    );
    setErrors({});
    setModalOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      title: { required: true, label: 'Expense Title' },
      amount: { required: true, label: 'Amount', min: 1 },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSaving(true);
    try {
      const payload = { ...form, amount: Number(form.amount) };
      if (editing) {
        await expenseService.update(editing.id || editing._id, payload);
        toast.success('Expense updated');
      } else {
        await expenseService.create(payload);
        toast.success('Expense recorded');
      }
      setModalOpen(false);
      fetchExpenses();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await expenseService.delete(deleteTarget.id || deleteTarget._id);
      toast.success('Expense deleted');
      setDeleteTarget(null);
      fetchExpenses();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  const totalExpenses = expenses.reduce((sum, e) => sum + Number(e.amount || 0), 0);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Expense Tracking"
        subtitle={`Total recorded in period: ${formatCurrency(totalExpenses)}`}
        actions={
          <div className="flex flex-wrap items-center gap-2.5">
            <DateRangeFilter
              preset={preset}
              onPresetChange={setPreset}
              startDate={customDates.startDate}
              endDate={customDates.endDate}
              onCustomChange={setCustomDates}
            />
            <Button icon={Plus} onClick={() => openModal()}>
              Add Expense
            </Button>
          </div>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card title="Expense Breakdown" className="lg:col-span-1">
          <ExpenseChart data={categoryChartData} />
        </Card>

        <div className="lg:col-span-2 space-y-4">
          <Select
            value={categoryFilter}
            placeholder=""
            containerClassName="sm:w-52"
            options={[
              { value: 'ALL', label: 'All Categories' },
              ...CATEGORIES.map((c) => ({ value: c, label: c })),
            ]}
            onChange={(e) => setCategoryFilter(e.target.value)}
          />

          {error ? (
            <ErrorState message={error} onRetry={fetchExpenses} />
          ) : (
            <Table
              columns={[
                { key: 'title', header: 'Expense', render: (r) => r.title || r.description },
                { key: 'category', header: 'Category', render: (r) => <Badge variant="neutral">{r.category}</Badge> },
                { key: 'amount', header: 'Amount', render: (r) => <span className="font-bold text-error">{formatCurrency(r.amount)}</span> },
                { key: 'date', header: 'Date', render: (r) => formatDate(r.date || r.createdAt) },
                {
                  key: 'actions',
                  header: 'Actions',
                  align: 'right',
                  render: (r) => (
                    <div className="inline-flex items-center gap-1.5">
                      <Button size="xs" variant="secondary" icon={Edit2} onClick={() => openModal(r)} />
                      <Button size="xs" variant="danger" icon={Trash2} onClick={() => setDeleteTarget(r)} />
                    </div>
                  ),
                },
              ]}
              data={expenses}
              loading={loading}
              emptyTitle="No expenses recorded"
            />
          )}
        </div>
      </div>

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Expense' : 'Record Expense'}>
        <form onSubmit={handleSave} className="space-y-4">
          <Input
            label="Expense Title"
            required
            placeholder="e.g. Monthly Electricity Bill"
            value={form.title}
            error={errors.title}
            onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))}
          />
          <div className="grid grid-cols-2 gap-4">
            <Select
              label="Category"
              value={form.category}
              options={CATEGORIES}
              onChange={(e) => setForm((p) => ({ ...p, category: e.target.value }))}
            />
            <Input
              label="Amount (₹)"
              type="number"
              required
              value={form.amount}
              error={errors.amount}
              onChange={(e) => setForm((p) => ({ ...p, amount: e.target.value }))}
            />
            <Input
              label="Date"
              type="date"
              value={form.date}
              onChange={(e) => setForm((p) => ({ ...p, date: e.target.value }))}
            />
            <Select
              label="Payment Mode"
              value={form.paymentMethod}
              options={['UPI', 'CASH', 'CARD', 'BANK_TRANSFER']}
              onChange={(e) => setForm((p) => ({ ...p, paymentMethod: e.target.value }))}
            />
          </div>
          <Textarea
            label="Notes"
            rows={2}
            value={form.notes}
            onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))}
          />
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              Save Expense
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Expense"
        message={`Delete "${deleteTarget?.title}"?`}
        confirmLabel="Delete"
      />
    </div>
  );
};

export default ExpenseManagement;

import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Plus, CheckCircle2, XCircle, Trash2 } from 'lucide-react';
import appointmentService from '../../services/appointmentService';
import customerService from '../../services/customerService';
import trainerService from '../../services/trainerService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatDate, formatTime } from '../../utils/formatters';
import { validateForm } from '../../utils/validators';
import {
  PageHeader,
  Select,
  Table,
  Badge,
  Button,
  Modal,
  Input,
  Textarea,
  ConfirmDialog,
  ErrorState,
} from '../../components/ui';

export const AppointmentManagement = () => {
  const [appointments, setAppointments] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [trainers, setTrainers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [errors, setErrors] = useState({});

  const [form, setForm] = useState({
    title: 'Personal Training Session',
    type: 'PT_SESSION',
    customerId: '',
    trainerId: '',
    date: new Date().toISOString().slice(0, 10),
    time: '07:00',
    notes: '',
  });

  const fetchAppointments = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await appointmentService.getAll({ status: statusFilter });
      setAppointments(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [statusFilter]);

  useEffect(() => {
    fetchAppointments();
    Promise.allSettled([customerService.getAll({ limit: 100 }), trainerService.getAll({ limit: 100 })]).then(
      ([cRes, tRes]) => {
        if (cRes.status === 'fulfilled') setCustomers(extractList(cRes.value));
        if (tRes.status === 'fulfilled') setTrainers(extractList(tRes.value));
      }
    );
  }, [fetchAppointments]);

  const handleCreate = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      title: { required: true, label: 'Session Title' },
      date: { required: true, label: 'Date' },
      time: { required: true, label: 'Time' },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSaving(true);
    try {
      await appointmentService.create(form);
      toast.success('Appointment scheduled');
      setModalOpen(false);
      fetchAppointments();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleStatus = async (apt, status) => {
    try {
      await appointmentService.updateStatus(apt.id || apt._id, status);
      toast.success(`Appointment marked ${status.toLowerCase()}`);
      fetchAppointments();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await appointmentService.delete(deleteTarget.id || deleteTarget._id);
      toast.success('Appointment removed');
      setDeleteTarget(null);
      fetchAppointments();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  const columns = [
    {
      key: 'title',
      header: 'Session / Class',
      render: (r) => (
        <div>
          <p className="font-semibold text-text-primary">{r.title || r.type}</p>
          <p className="text-xs text-text-secondary">{r.type?.replace(/_/g, ' ') || 'PT Session'}</p>
        </div>
      ),
    },
    {
      key: 'customer',
      header: 'Member',
      render: (r) => r.customer?.name || r.customerName || 'Group Class',
    },
    {
      key: 'trainer',
      header: 'Trainer',
      render: (r) => r.trainer?.name || r.trainerName || '—',
    },
    {
      key: 'schedule',
      header: 'Date & Time',
      render: (r) => (
        <div>
          <p>{formatDate(r.date || r.scheduledAt)}</p>
          <p className="text-xs text-accent">{formatTime(r.time || r.scheduledAt)}</p>
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      render: (r) => <Badge status={r.status || 'SCHEDULED'} dot />,
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (r) => (
        <div className="inline-flex items-center gap-1.5">
          {String(r.status).toUpperCase() === 'SCHEDULED' && (
            <>
              <Button
                size="xs"
                variant="success"
                icon={CheckCircle2}
                onClick={() => handleStatus(r, 'COMPLETED')}
              >
                Complete
              </Button>
              <Button
                size="xs"
                variant="secondary"
                icon={XCircle}
                onClick={() => handleStatus(r, 'CANCELLED')}
              />
            </>
          )}
          <Button size="xs" variant="danger" icon={Trash2} onClick={() => setDeleteTarget(r)} />
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Appointments & Group Classes"
        subtitle="Schedule personal training sessions, assessments, and group fitness classes"
        actions={
          <Button icon={Plus} onClick={() => setModalOpen(true)}>
            Schedule Session
          </Button>
        }
      />

      <Select
        value={statusFilter}
        placeholder=""
        containerClassName="sm:w-48"
        options={[
          { value: 'ALL', label: 'All Appointments' },
          { value: 'SCHEDULED', label: 'Scheduled' },
          { value: 'COMPLETED', label: 'Completed' },
          { value: 'CANCELLED', label: 'Cancelled' },
        ]}
        onChange={(e) => setStatusFilter(e.target.value)}
      />

      {error ? (
        <ErrorState message={error} onRetry={fetchAppointments} />
      ) : (
        <Table
          columns={columns}
          data={appointments}
          loading={loading}
          emptyTitle="No appointments scheduled"
        />
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Schedule Session / Class">
        <form onSubmit={handleCreate} className="space-y-4">
          <Input
            label="Session Title"
            required
            value={form.title}
            error={errors.title}
            onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))}
          />
          <div className="grid grid-cols-2 gap-4">
            <Select
              label="Type"
              value={form.type}
              options={[
                { value: 'PT_SESSION', label: 'Personal Training' },
                { value: 'GROUP_CLASS', label: 'Group Class (HIIT/Yoga)' },
                { value: 'ASSESSMENT', label: 'Body Assessment' },
                { value: 'CONSULTATION', label: 'Diet Consultation' },
              ]}
              onChange={(e) => setForm((p) => ({ ...p, type: e.target.value }))}
            />
            <Select
              label="Trainer"
              placeholder="Select Trainer"
              value={form.trainerId}
              options={trainers.map((t) => ({ value: t.id || t._id, label: t.name }))}
              onChange={(e) => setForm((p) => ({ ...p, trainerId: e.target.value }))}
            />
            <Input
              label="Date"
              type="date"
              required
              value={form.date}
              onChange={(e) => setForm((p) => ({ ...p, date: e.target.value }))}
            />
            <Input
              label="Time"
              type="time"
              required
              value={form.time}
              onChange={(e) => setForm((p) => ({ ...p, time: e.target.value }))}
            />
          </div>
          <Select
            label="Member (Leave blank for open Group Class)"
            placeholder="Open Group Class"
            value={form.customerId}
            options={customers.map((c) => ({ value: c.id || c._id, label: c.name }))}
            onChange={(e) => setForm((p) => ({ ...p, customerId: e.target.value }))}
          />
          <Textarea
            label="Notes"
            rows={2}
            value={form.notes}
            onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))}
          />
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              Schedule
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Appointment"
        message={`Cancel and delete "${deleteTarget?.title}"?`}
        confirmLabel="Delete"
      />
    </div>
  );
};

export default AppointmentManagement;

import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { UserPlus, Eye, Trash2, UserCheck } from 'lucide-react';
import customerService from '../../services/customerService';
import trainerService from '../../services/trainerService';
import { useDebounce } from '../../hooks/useDebounce';
import { usePagination } from '../../hooks/usePagination';
import { useGym } from '../../contexts/GymContext';
import { extractList, extractPagination, getErrorMessage } from '../../utils/apiHelpers';
import { formatDate } from '../../utils/formatters';
import {
  PageHeader,
  SearchInput,
  Select,
  Table,
  Avatar,
  Badge,
  Button,
  Modal,
  ConfirmDialog,
  ErrorState,
} from '../../components/ui';

export const CustomerList = () => {
  const navigate = useNavigate();
  const { activeBranchId } = useGym();
  const [customers, setCustomers] = useState([]);
  const [trainers, setTrainers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [assignTarget, setAssignTarget] = useState(null);
  const [selectedTrainerId, setSelectedTrainerId] = useState('');
  const [assigning, setAssigning] = useState(false);

  const debouncedSearch = useDebounce(search, 350);
  const pagination = usePagination(1, 10);

  const fetchCustomers = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await customerService.getAll({
        search: debouncedSearch,
        status: statusFilter,
        branchId: activeBranchId !== 'ALL' ? activeBranchId : undefined,
        page: pagination.page,
        limit: pagination.limit,
      });
      setCustomers(extractList(res));
      pagination.updateMeta(extractPagination(res, pagination.limit));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch, statusFilter, activeBranchId, pagination.page, pagination.limit]);

  useEffect(() => {
    fetchCustomers();
  }, [fetchCustomers]);

  useEffect(() => {
    trainerService
      .getAll({ limit: 100 })
      .then((res) => setTrainers(extractList(res)))
      .catch(() => {});
  }, []);

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await customerService.delete(deleteTarget.id || deleteTarget._id);
      toast.success('Customer removed successfully');
      setDeleteTarget(null);
      fetchCustomers();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  const handleAssignTrainer = async (e) => {
    e.preventDefault();
    if (!assignTarget || !selectedTrainerId) return;
    setAssigning(true);
    try {
      await customerService.assignTrainer(assignTarget.id || assignTarget._id, selectedTrainerId);
      toast.success('Trainer assigned successfully');
      setAssignTarget(null);
      fetchCustomers();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setAssigning(false);
    }
  };

  const columns = [
    {
      key: 'name',
      header: 'Member',
      sortable: true,
      render: (row) => (
        <div className="flex items-center gap-3">
          <Avatar src={row.avatar} name={row.name} size="sm" />
          <div>
            <p className="font-semibold text-text-primary">{row.name}</p>
            <p className="text-xs text-text-secondary">{row.mobile || row.phone}</p>
          </div>
        </div>
      ),
    },
    {
      key: 'membership',
      header: 'Current Plan',
      render: (row) => (
        <div>
          <p className="text-sm">{row.activeMembership?.plan?.name || row.planName || 'No Plan'}</p>
          {row.activeMembership?.endDate && (
            <p className="text-xs text-text-secondary">
              Exp: {formatDate(row.activeMembership.endDate)}
            </p>
          )}
        </div>
      ),
    },
    {
      key: 'trainer',
      header: 'Trainer',
      render: (row) => row.trainer?.name || row.trainerName || 'Unassigned',
    },
    {
      key: 'status',
      header: 'Status',
      render: (row) => <Badge status={row.status || 'ACTIVE'} dot />,
    },
    {
      key: 'createdAt',
      header: 'Joined',
      sortable: true,
      render: (row) => formatDate(row.createdAt || row.joinDate),
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (row) => {
        const id = row.id || row._id;
        return (
          <div className="inline-flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            <Button
              size="xs"
              variant="secondary"
              icon={Eye}
              onClick={() => navigate(`/owner/customers/${id}`)}
            >
              View
            </Button>
            <Button
              size="xs"
              variant="ghost"
              icon={UserCheck}
              onClick={() => {
                setAssignTarget(row);
                setSelectedTrainerId(row.trainerId || row.trainer?.id || '');
              }}
              title="Assign Trainer"
            />
            <Button
              size="xs"
              variant="danger"
              icon={Trash2}
              onClick={() => setDeleteTarget(row)}
              title="Delete Customer"
            />
          </div>
        );
      },
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Customers & Members"
        subtitle="Manage gym members, assign trainers, and track membership status"
        actions={
          <Button icon={UserPlus} onClick={() => navigate('/owner/customers/new')}>
            Add Customer
          </Button>
        }
      />

      <div className="flex flex-col sm:flex-row gap-3">
        <SearchInput
          placeholder="Search member name, mobile, or ID..."
          value={search}
          onChange={(v) => {
            setSearch(v);
            pagination.resetPage();
          }}
          className="sm:max-w-sm"
        />
        <Select
          value={statusFilter}
          placeholder=""
          containerClassName="sm:w-48"
          options={[
            { value: 'ALL', label: 'All Members' },
            { value: 'ACTIVE', label: 'Active' },
            { value: 'EXPIRING', label: 'Expiring Soon' },
            { value: 'EXPIRED', label: 'Expired' },
            { value: 'INACTIVE', label: 'Inactive' },
          ]}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            pagination.resetPage();
          }}
        />
      </div>

      {error ? (
        <ErrorState message={error} onRetry={fetchCustomers} />
      ) : (
        <Table
          columns={columns}
          data={customers}
          loading={loading}
          pagination={pagination}
          onPageChange={pagination.setPage}
          onRowClick={(row) => navigate(`/owner/customers/${row.id || row._id}`)}
          emptyTitle="No customers found"
          emptyAction={
            <Button icon={UserPlus} onClick={() => navigate('/owner/customers/new')}>
              Add First Member
            </Button>
          }
        />
      )}

      <Modal
        isOpen={Boolean(assignTarget)}
        onClose={() => setAssignTarget(null)}
        title="Assign Personal Trainer"
        subtitle={assignTarget?.name}
        size="sm"
      >
        <form onSubmit={handleAssignTrainer} className="space-y-4">
          <Select
            label="Select Trainer"
            required
            value={selectedTrainerId}
            options={trainers.map((t) => ({
              value: t.id || t._id,
              label: `${t.name} (${t.specialization || 'Coach'})`,
            }))}
            onChange={(e) => setSelectedTrainerId(e.target.value)}
          />
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setAssignTarget(null)}>
              Cancel
            </Button>
            <Button type="submit" loading={assigning}>
              Assign Trainer
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Member"
        message={`Are you sure you want to remove "${deleteTarget?.name}" from the gym?`}
        confirmLabel="Delete"
      />
    </div>
  );
};

export default CustomerList;

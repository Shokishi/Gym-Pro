import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Plus, Edit2, Trash2, IdCard, CheckCircle2 } from 'lucide-react';
import membershipService from '../../services/membershipService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency } from '../../utils/formatters';
import { validateForm } from '../../utils/validators';
import {
  PageHeader,
  Card,
  Button,
  Badge,
  Modal,
  Input,
  Textarea,
  Toggle,
  ConfirmDialog,
  Skeleton,
  EmptyState,
  ErrorState,
} from '../../components/ui';

const INITIAL_FORM = {
  name: '',
  durationDays: 30,
  price: '',
  setupFee: 0,
  description: '',
  featuresText: 'Full Gym Access\nLocker & Shower\nFitness Assessment',
  isActive: true,
};

export const MembershipPlans = () => {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(INITIAL_FORM);
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const fetchPlans = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await membershipService.getPlans();
      setPlans(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPlans();
  }, [fetchPlans]);

  const openModal = (plan = null) => {
    setEditing(plan);
    setForm(
      plan
        ? {
            name: plan.name || '',
            durationDays: plan.durationDays ?? 30,
            price: plan.price ?? plan.amount ?? '',
            setupFee: plan.setupFee ?? 0,
            description: plan.description || '',
            featuresText: Array.isArray(plan.features) ? plan.features.join('\n') : plan.features || '',
            isActive: plan.isActive !== false,
          }
        : INITIAL_FORM
    );
    setErrors({});
    setModalOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      name: { required: true, label: 'Plan Name', minLength: 2 },
      durationDays: { required: true, label: 'Duration (Days)', min: 1 },
      price: { required: true, label: 'Price', min: 0 },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        durationDays: Number(form.durationDays),
        price: Number(form.price),
        setupFee: Number(form.setupFee || 0),
        description: form.description.trim(),
        features: form.featuresText
          .split('\n')
          .map((f) => f.trim())
          .filter(Boolean),
        isActive: form.isActive,
      };
      if (editing) {
        await membershipService.updatePlan(editing.id || editing._id, payload);
        toast.success('Membership plan updated');
      } else {
        await membershipService.createPlan(payload);
        toast.success('Membership plan created');
      }
      setModalOpen(false);
      fetchPlans();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await membershipService.deletePlan(deleteTarget.id || deleteTarget._id);
      toast.success('Plan deleted');
      setDeleteTarget(null);
      fetchPlans();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Gym Membership Plans"
        subtitle="Create monthly, quarterly, annual, or personal training membership packages"
        backTo="/owner/memberships"
        actions={
          <Button icon={Plus} onClick={() => openModal()}>
            New Plan
          </Button>
        }
      />

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Skeleton variant="card" />
          <Skeleton variant="card" />
          <Skeleton variant="card" />
        </div>
      ) : error ? (
        <ErrorState message={error} onRetry={fetchPlans} />
      ) : plans.length === 0 ? (
        <Card>
          <EmptyState
            icon={IdCard}
            title="No membership plans yet"
            message="Create plans like Monthly Standard, Quarterly Pro, or Annual VIP."
            action={
              <Button icon={Plus} onClick={() => openModal()}>
                Create First Plan
              </Button>
            }
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {plans.map((plan) => (
            <Card key={plan.id || plan._id}>
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-bold text-text-primary">{plan.name}</h3>
                  <p className="text-xs text-text-secondary mt-0.5">
                    {plan.durationDays} days validity
                  </p>
                </div>
                <Badge status={plan.isActive !== false ? 'active' : 'inactive'} />
              </div>

              <div className="mt-4 pb-4 border-b border-dark-border flex items-baseline gap-2">
                <span className="text-3xl font-extrabold text-accent">
                  {formatCurrency(plan.price ?? plan.amount ?? 0)}
                </span>
                {plan.setupFee > 0 && (
                  <span className="text-xs text-text-secondary">
                    +{formatCurrency(plan.setupFee)} setup
                  </span>
                )}
              </div>

              {plan.description && (
                <p className="text-xs text-text-secondary mt-3">{plan.description}</p>
              )}

              <ul className="mt-4 space-y-1.5 text-xs text-text-secondary">
                {(Array.isArray(plan.features) ? plan.features : []).map((f, i) => (
                  <li key={i} className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-success shrink-0" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-5 pt-4 border-t border-dark-border flex items-center gap-2">
                <Button
                  size="sm"
                  variant="secondary"
                  icon={Edit2}
                  onClick={() => openModal(plan)}
                  className="flex-1"
                >
                  Edit
                </Button>
                <Button
                  size="sm"
                  variant="danger"
                  icon={Trash2}
                  onClick={() => setDeleteTarget(plan)}
                />
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Edit Membership Plan' : 'Create Membership Plan'}
      >
        <form onSubmit={handleSave} className="space-y-4">
          <Input
            label="Plan Name"
            required
            placeholder="e.g. Quarterly Transformation"
            value={form.name}
            error={errors.name}
            onChange={(e) => {
              setForm((p) => ({ ...p, name: e.target.value }));
              setErrors((p) => ({ ...p, name: '' }));
            }}
          />
          <div className="grid grid-cols-3 gap-3">
            <Input
              label="Duration (Days)"
              type="number"
              required
              value={form.durationDays}
              error={errors.durationDays}
              onChange={(e) => setForm((p) => ({ ...p, durationDays: e.target.value }))}
            />
            <Input
              label="Price (₹)"
              type="number"
              required
              value={form.price}
              error={errors.price}
              onChange={(e) => setForm((p) => ({ ...p, price: e.target.value }))}
            />
            <Input
              label="Setup Fee (₹)"
              type="number"
              value={form.setupFee}
              onChange={(e) => setForm((p) => ({ ...p, setupFee: e.target.value }))}
            />
          </div>
          <Input
            label="Description"
            placeholder="Optional summary"
            value={form.description}
            onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
          />
          <Textarea
            label="Benefits (one per line)"
            rows={3}
            value={form.featuresText}
            onChange={(e) => setForm((p) => ({ ...p, featuresText: e.target.value }))}
          />
          <Toggle
            checked={form.isActive}
            onChange={(v) => setForm((p) => ({ ...p, isActive: v }))}
            label="Plan is Active"
          />
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              {editing ? 'Update Plan' : 'Create Plan'}
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Membership Plan"
        message={`Delete "${deleteTarget?.name}"?`}
        confirmLabel="Delete"
      />
    </div>
  );
};

export default MembershipPlans;

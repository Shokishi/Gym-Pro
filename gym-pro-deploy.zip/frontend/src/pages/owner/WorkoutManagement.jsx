import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Plus, Edit2, Trash2, UserPlus, Dumbbell } from 'lucide-react';
import workoutService from '../../services/workoutService';
import customerService from '../../services/customerService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import WorkoutBuilder from '../../components/shared/WorkoutBuilder';
import {
  PageHeader,
  Card,
  SearchInput,
  Badge,
  Button,
  Modal,
  Select,
  ConfirmDialog,
  Skeleton,
  EmptyState,
  ErrorState,
} from '../../components/ui';

export const WorkoutManagement = () => {
  const [plans, setPlans] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [builderOpen, setBuilderOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState(null);
  const [assignTarget, setAssignTarget] = useState(null);
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [assigning, setAssigning] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const fetchWorkouts = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await workoutService.getAll({ search });
      setPlans(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [search]);

  useEffect(() => {
    fetchWorkouts();
    customerService
      .getAll({ limit: 200 })
      .then((res) => setCustomers(extractList(res)))
      .catch(() => {});
  }, [fetchWorkouts]);

  const handleAssign = async (e) => {
    e.preventDefault();
    if (!assignTarget || !selectedCustomerId) return;
    setAssigning(true);
    try {
      await workoutService.assign(assignTarget.id || assignTarget._id, selectedCustomerId);
      toast.success('Workout plan assigned to member');
      setAssignTarget(null);
      fetchWorkouts();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setAssigning(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await workoutService.delete(deleteTarget.id || deleteTarget._id);
      toast.success('Workout plan deleted');
      setDeleteTarget(null);
      fetchWorkouts();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Workout Plans"
        subtitle="Build structured training templates and assign them to gym members"
        actions={
          <Button
            icon={Plus}
            onClick={() => {
              setEditingPlan(null);
              setBuilderOpen(true);
            }}
          >
            Create Workout Plan
          </Button>
        }
      />

      <SearchInput
        placeholder="Search workout plans..."
        value={search}
        onChange={setSearch}
        className="sm:max-w-sm"
      />

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Skeleton variant="card" />
          <Skeleton variant="card" />
          <Skeleton variant="card" />
        </div>
      ) : error ? (
        <ErrorState message={error} onRetry={fetchWorkouts} />
      ) : plans.length === 0 ? (
        <Card>
          <EmptyState
            icon={Dumbbell}
            title="No workout plans created"
            message="Create customized workout splits for weight loss, hypertrophy, or strength."
            action={
              <Button icon={Plus} onClick={() => setBuilderOpen(true)}>
                Build Workout Plan
              </Button>
            }
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {plans.map((plan) => (
            <Card key={plan.id || plan._id}>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-base font-bold text-text-primary">{plan.name || plan.title}</h3>
                  <p className="text-xs text-text-secondary mt-0.5">
                    {plan.durationWeeks || 4} Weeks • {plan.exercises?.length || 0} Exercises
                  </p>
                </div>
                <Badge variant="accent">{plan.difficulty || 'INTERMEDIATE'}</Badge>
              </div>

              <p className="text-xs text-text-secondary mt-3 line-clamp-2">
                {plan.description || `Goal: ${String(plan.goal || 'GENERAL_FITNESS').replace(/_/g, ' ')}`}
              </p>

              {plan.customer?.name && (
                <p className="text-xs text-success mt-2 font-medium">
                  Assigned to: {plan.customer.name}
                </p>
              )}

              <div className="mt-4 pt-3 border-t border-dark-border flex items-center gap-2">
                <Button
                  size="xs"
                  variant="secondary"
                  icon={UserPlus}
                  onClick={() => {
                    setAssignTarget(plan);
                    setSelectedCustomerId('');
                  }}
                  className="flex-1"
                >
                  Assign
                </Button>
                <Button
                  size="xs"
                  variant="secondary"
                  icon={Edit2}
                  onClick={() => {
                    setEditingPlan(plan);
                    setBuilderOpen(true);
                  }}
                />
                <Button size="xs" variant="danger" icon={Trash2} onClick={() => setDeleteTarget(plan)} />
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal
        isOpen={builderOpen}
        onClose={() => setBuilderOpen(false)}
        title={editingPlan ? 'Edit Workout Plan' : 'Create Workout Plan'}
        size="xl"
      >
        <WorkoutBuilder
          initialPlan={editingPlan}
          onCancel={() => setBuilderOpen(false)}
          onSaved={() => {
            setBuilderOpen(false);
            fetchWorkouts();
          }}
        />
      </Modal>

      <Modal
        isOpen={Boolean(assignTarget)}
        onClose={() => setAssignTarget(null)}
        title="Assign Workout Plan"
        subtitle={assignTarget?.name || assignTarget?.title}
        size="sm"
      >
        <form onSubmit={handleAssign} className="space-y-4">
          <Select
            label="Select Member"
            required
            value={selectedCustomerId}
            options={customers.map((c) => ({
              value: c.id || c._id,
              label: `${c.name} (${c.mobile || c.phone || ''})`,
            }))}
            onChange={(e) => setSelectedCustomerId(e.target.value)}
          />
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setAssignTarget(null)}>
              Cancel
            </Button>
            <Button type="submit" loading={assigning}>
              Assign Plan
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Workout Plan"
        message={`Delete "${deleteTarget?.name || deleteTarget?.title}"?`}
        confirmLabel="Delete"
      />
    </div>
  );
};

export default WorkoutManagement;

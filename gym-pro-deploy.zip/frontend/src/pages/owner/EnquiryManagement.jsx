import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Plus, UserCheck, Trash2 } from 'lucide-react';
import enquiryService from '../../services/enquiryService';
import { useDebounce } from '../../hooks/useDebounce';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatDate } from '../../utils/formatters';
import { validateForm } from '../../utils/validators';
import {
  PageHeader,
  SearchInput,
  Select,
  Table,
  Badge,
  Button,
  Modal,
  Input,
  Textarea,
  ConfirmDialog,
  ErrorState,
} from '../../components/ui';

export const EnquiryManagement = () => {
  const [enquiries, setEnquiries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [errors, setErrors] = useState({});

  const [form, setForm] = useState({
    name: '',
    mobile: '',
    email: '',
    source: 'WALK_IN',
    interestedPlan: '',
    followUpDate: '',
    notes: '',
  });

  const debouncedSearch = useDebounce(search, 350);

  const fetchEnquiries = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await enquiryService.getAll({ search: debouncedSearch, status: statusFilter });
      setEnquiries(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [debouncedSearch, statusFilter]);

  useEffect(() => {
    fetchEnquiries();
  }, [fetchEnquiries]);

  const handleCreate = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      name: { required: true, label: 'Lead Name' },
      mobile: { required: true, label: 'Mobile Number', mobile: true },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSaving(true);
    try {
      await enquiryService.create(form);
      toast.success('Enquiry added to pipeline');
      setModalOpen(false);
      setForm({ name: '', mobile: '', email: '', source: 'WALK_IN', interestedPlan: '', followUpDate: '', notes: '' });
      fetchEnquiries();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleConvert = async (enquiry) => {
    try {
      await enquiryService.convertToCustomer(enquiry.id || enquiry._id, {});
      toast.success(`${enquiry.name} converted to active member!`);
      fetchEnquiries();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await enquiryService.delete(deleteTarget.id || deleteTarget._id);
      toast.success('Enquiry removed');
      setDeleteTarget(null);
      fetchEnquiries();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  const columns = [
    {
      key: 'name',
      header: 'Lead / Prospect',
      render: (r) => (
        <div>
          <p className="font-semibold text-text-primary">{r.name}</p>
          <p className="text-xs text-text-secondary">{r.mobile || r.phone}</p>
        </div>
      ),
    },
    { key: 'source', header: 'Source', render: (r) => <Badge variant="neutral">{r.source || 'WALK_IN'}</Badge> },
    { key: 'interestedPlan', header: 'Interest', render: (r) => r.interestedPlan || 'General Membership' },
    { key: 'followUpDate', header: 'Follow Up', render: (r) => formatDate(r.followUpDate) },
    { key: 'status', header: 'Status', render: (r) => <Badge status={r.status || 'NEW'} dot /> },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (r) => (
        <div className="inline-flex items-center gap-1.5">
          {String(r.status).toUpperCase() !== 'CONVERTED' && (
            <Button
              size="xs"
              variant="success"
              icon={UserCheck}
              onClick={() => handleConvert(r)}
            >
              Convert
            </Button>
          )}
          <Button size="xs" variant="danger" icon={Trash2} onClick={() => setDeleteTarget(r)} />
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Enquiries & Lead Pipeline"
        subtitle="Capture walk-ins, Instagram/website leads, schedule follow-ups, and convert to members"
        actions={
          <Button icon={Plus} onClick={() => setModalOpen(true)}>
            Add Enquiry
          </Button>
        }
      />

      <div className="flex flex-col sm:flex-row gap-3">
        <SearchInput
          placeholder="Search lead name or phone..."
          value={search}
          onChange={setSearch}
          className="sm:max-w-sm"
        />
        <Select
          value={statusFilter}
          placeholder=""
          containerClassName="sm:w-44"
          options={[
            { value: 'ALL', label: 'All Leads' },
            { value: 'NEW', label: 'New' },
            { value: 'FOLLOW_UP', label: 'Follow Up' },
            { value: 'CONVERTED', label: 'Converted' },
            { value: 'CLOSED', label: 'Closed' },
          ]}
          onChange={(e) => setStatusFilter(e.target.value)}
        />
      </div>

      {error ? (
        <ErrorState message={error} onRetry={fetchEnquiries} />
      ) : (
        <Table
          columns={columns}
          data={enquiries}
          loading={loading}
          emptyTitle="No enquiries logged yet"
        />
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Add New Enquiry">
        <form onSubmit={handleCreate} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Full Name"
              required
              value={form.name}
              error={errors.name}
              onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
            />
            <Input
              label="Mobile Number"
              required
              value={form.mobile}
              error={errors.mobile}
              onChange={(e) => setForm((p) => ({ ...p, mobile: e.target.value }))}
            />
            <Select
              label="Lead Source"
              value={form.source}
              options={['WALK_IN', 'INSTAGRAM', 'WEBSITE', 'REFERRAL', 'GOOGLE_ADS', 'CALL']}
              onChange={(e) => setForm((p) => ({ ...p, source: e.target.value }))}
            />
            <Input
              label="Follow-up Date"
              type="date"
              value={form.followUpDate}
              onChange={(e) => setForm((p) => ({ ...p, followUpDate: e.target.value }))}
            />
          </div>
          <Input
            label="Interested Plan / Goal"
            placeholder="e.g. 3-Month Fat Loss + PT"
            value={form.interestedPlan}
            onChange={(e) => setForm((p) => ({ ...p, interestedPlan: e.target.value }))}
          />
          <Textarea
            label="Notes"
            rows={2}
            value={form.notes}
            onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))}
          />
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              Save Lead
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Enquiry"
        message={`Remove lead "${deleteTarget?.name}"?`}
        confirmLabel="Delete"
      />
    </div>
  );
};

export default EnquiryManagement;

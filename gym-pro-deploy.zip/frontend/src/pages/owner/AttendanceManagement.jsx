import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import dayjs from 'dayjs';
import { QrCode, UserCheck, LogOut, BarChart3 } from 'lucide-react';
import attendanceService from '../../services/attendanceService';
import customerService from '../../services/customerService';
import { useDebounce } from '../../hooks/useDebounce';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatDateTime, formatTime } from '../../utils/formatters';
import {
  PageHeader,
  SearchInput,
  DatePicker,
  Table,
  Avatar,
  Badge,
  Button,
  Modal,
  Select,
  QRScanner,
  ErrorState,
} from '../../components/ui';

export const AttendanceManagement = () => {
  const [date, setDate] = useState(dayjs().format('YYYY-MM-DD'));
  const [search, setSearch] = useState('');
  const [records, setRecords] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [manualModalOpen, setManualModalOpen] = useState(false);
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [marking, setMarking] = useState(false);

  const debouncedSearch = useDebounce(search, 300);

  const fetchAttendance = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await attendanceService.getAll({ date, search: debouncedSearch });
      setRecords(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [date, debouncedSearch]);

  useEffect(() => {
    fetchAttendance();
  }, [fetchAttendance]);

  useEffect(() => {
    customerService
      .getAll({ limit: 200, status: 'ACTIVE' })
      .then((res) => setCustomers(extractList(res)))
      .catch(() => {});

    const onLiveCheckin = () => fetchAttendance();
    window.addEventListener('gympro:attendance-update', onLiveCheckin);
    return () => window.removeEventListener('gympro:attendance-update', onLiveCheckin);
  }, [fetchAttendance]);

  const handleQrScan = async (qrToken) => {
    try {
      await attendanceService.checkInByQr({ qrCode: qrToken, date });
      toast.success('Member checked in via QR!');
      setQrModalOpen(false);
      fetchAttendance();
    } catch (err) {
      toast.error(getErrorMessage(err, 'Invalid QR pass or already checked in'));
    }
  };

  const handleManualMark = async (e) => {
    e.preventDefault();
    if (!selectedCustomerId) return;
    setMarking(true);
    try {
      await attendanceService.markAttendance({
        customerId: selectedCustomerId,
        date,
        method: 'MANUAL',
        status: 'PRESENT',
      });
      toast.success('Attendance marked');
      setManualModalOpen(false);
      setSelectedCustomerId('');
      fetchAttendance();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setMarking(false);
    }
  };

  const handleCheckOut = async (record) => {
    try {
      await attendanceService.checkOut(record.id || record._id);
      toast.success('Member checked out');
      fetchAttendance();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const columns = [
    {
      key: 'customer',
      header: 'Member',
      render: (row) => (
        <div className="flex items-center gap-3">
          <Avatar src={row.customer?.avatar} name={row.customer?.name || row.customerName} size="sm" />
          <div>
            <p className="font-semibold text-text-primary">
              {row.customer?.name || row.customerName || '—'}
            </p>
            <p className="text-xs text-text-secondary">
              {row.customer?.mobile || row.customer?.phone || ''}
            </p>
          </div>
        </div>
      ),
    },
    {
      key: 'checkInTime',
      header: 'Check-In',
      render: (row) => formatDateTime(row.checkInTime || row.createdAt),
    },
    {
      key: 'checkOutTime',
      header: 'Check-Out',
      render: (row) => (row.checkOutTime ? formatTime(row.checkOutTime) : 'Active in gym'),
    },
    {
      key: 'method',
      header: 'Method',
      render: (row) => <Badge variant="neutral">{row.method || 'QR'}</Badge>,
    },
    {
      key: 'status',
      header: 'Status',
      render: (row) => <Badge status={row.status || 'PRESENT'} dot />,
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (row) =>
        !row.checkOutTime && (
          <Button
            size="xs"
            variant="secondary"
            icon={LogOut}
            onClick={() => handleCheckOut(row)}
          >
            Check Out
          </Button>
        ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Attendance Management"
        subtitle="Track daily check-ins, scan member QR passes, and log manual entries"
        actions={
          <div className="flex flex-wrap items-center gap-2.5">
            <Link to="/owner/attendance/report">
              <Button variant="secondary" size="sm" icon={BarChart3}>
                Reports
              </Button>
            </Link>
            <Button
              variant="secondary"
              size="sm"
              icon={UserCheck}
              onClick={() => setManualModalOpen(true)}
            >
              Manual Check-In
            </Button>
            <Button size="sm" icon={QrCode} onClick={() => setQrModalOpen(true)}>
              Scan QR Pass
            </Button>
          </div>
        }
      />

      <div className="flex flex-col sm:flex-row gap-3">
        <SearchInput
          placeholder="Search member name or mobile..."
          value={search}
          onChange={setSearch}
          className="sm:max-w-sm"
        />
        <DatePicker
          value={date}
          onChange={(e) => setDate(e.target.value)}
          containerClassName="sm:w-48"
        />
      </div>

      {error ? (
        <ErrorState message={error} onRetry={fetchAttendance} />
      ) : (
        <Table
          columns={columns}
          data={records}
          loading={loading}
          emptyTitle="No attendance entries for this date"
          emptyMessage="Scan a member QR pass or mark manual attendance to begin."
        />
      )}

      <Modal
        isOpen={qrModalOpen}
        onClose={() => setQrModalOpen(false)}
        title="Scan Member QR Pass"
        subtitle="Hold member's digital QR pass in front of the camera"
      >
        <QRScanner onScan={handleQrScan} />
      </Modal>

      <Modal
        isOpen={manualModalOpen}
        onClose={() => setManualModalOpen(false)}
        title="Mark Manual Attendance"
        size="sm"
      >
        <form onSubmit={handleManualMark} className="space-y-4">
          <Select
            label="Select Member"
            required
            value={selectedCustomerId}
            options={customers.map((c) => ({
              value: c.id || c._id,
              label: `${c.name} (${c.mobile || c.phone || ''})`,
            }))}
            onChange={(e) => setSelectedCustomerId(e.target.value)}
          />
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setManualModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={marking}>
              Check In Member
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default AttendanceManagement;

import React, { useState, useEffect, useCallback } from 'react';
import { CalendarCheck, Users, Clock, Download, FileText } from 'lucide-react';
import attendanceService from '../../services/attendanceService';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { formatDate, formatNumber, getDateRangeFromPreset } from '../../utils/formatters';
import { generateReportPDF, exportToCSV } from '../../utils/pdfGenerator';
import {
  PageHeader,
  Stat,
  Card,
  DateRangeFilter,
  Button,
  Table,
  Badge,
  Skeleton,
  ErrorState,
} from '../../components/ui';
import { AttendanceChart } from '../../components/charts';

export const AttendanceReport = () => {
  const [preset, setPreset] = useState('30d');
  const [customDates, setCustomDates] = useState({ startDate: '', endDate: '' });
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadReport = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const range = getDateRangeFromPreset(preset, customDates.startDate, customDates.endDate);
      const res = await attendanceService.getReport({ preset, ...range });
      setReport(extractData(res, {}));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [preset, customDates.startDate, customDates.endDate]);

  useEffect(() => {
    loadReport();
  }, [loadReport]);

  const rows = report?.records || report?.rows || [];
  const summary = report?.summary || {};

  const handleExportPDF = () => {
    generateReportPDF({
      title: 'Attendance Report',
      subtitle: `Range: ${preset.toUpperCase()}`,
      columns: ['Member', 'Date', 'Method', 'Status'],
      rows: rows.map((r) => [
        r.customer?.name || r.customerName || '—',
        formatDate(r.date || r.checkInTime),
        r.method || 'QR',
        r.status || 'PRESENT',
      ]),
      filename: 'attendance-report.pdf',
    });
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Attendance Reports"
        subtitle="Daily footfall trends, peak hours, and member check-in consistency"
        backTo="/owner/attendance"
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <DateRangeFilter
              preset={preset}
              onPresetChange={setPreset}
              startDate={customDates.startDate}
              endDate={customDates.endDate}
              onCustomChange={setCustomDates}
            />
            <Button
              size="sm"
              variant="secondary"
              icon={Download}
              onClick={() =>
                exportToCSV(
                  'attendance-report.csv',
                  ['Member', 'Date', 'Method', 'Status'],
                  rows.map((r) => [
                    r.customer?.name || r.customerName || '—',
                    formatDate(r.date || r.checkInTime),
                    r.method || 'QR',
                    r.status || 'PRESENT',
                  ])
                )
              }
            >
              CSV
            </Button>
            <Button size="sm" icon={FileText} onClick={handleExportPDF}>
              PDF
            </Button>
          </div>
        }
      />

      {loading ? (
        <div className="space-y-6">
          <Skeleton variant="stats" count={3} />
          <Skeleton variant="card" />
        </div>
      ) : error ? (
        <ErrorState message={error} onRetry={loadReport} />
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Stat
              label="Total Check-Ins"
              value={formatNumber(summary.totalCheckIns ?? rows.length)}
              icon={CalendarCheck}
              color="success"
            />
            <Stat
              label="Unique Members"
              value={formatNumber(summary.uniqueMembers ?? 0)}
              icon={Users}
              color="accent"
            />
            <Stat
              label="Daily Average"
              value={formatNumber(summary.dailyAverage ?? 0)}
              icon={Clock}
              color="info"
            />
          </div>

          <Card title="Check-In Volume">
            <AttendanceChart data={report?.chart || report?.dailySeries || []} />
          </Card>

          <Table
            columns={[
              { key: 'customer', header: 'Member', render: (r) => r.customer?.name || r.customerName || '—' },
              { key: 'date', header: 'Date', render: (r) => formatDate(r.date || r.checkInTime) },
              { key: 'method', header: 'Method', render: (r) => <Badge variant="neutral">{r.method || 'QR'}</Badge> },
              { key: 'status', header: 'Status', render: (r) => <Badge status={r.status || 'PRESENT'} /> },
            ]}
            data={rows}
            emptyTitle="No attendance records in selected period"
          />
        </>
      )}
    </div>
  );
};

export default AttendanceReport;

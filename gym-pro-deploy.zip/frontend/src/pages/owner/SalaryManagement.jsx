import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Plus, CheckCircle2, Trash2, Wallet } from 'lucide-react';
import salaryService from '../../services/salaryService';
import trainerService from '../../services/trainerService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { validateForm } from '../../utils/validators';
import {
  PageHeader,
  Select,
  Table,
  Badge,
  Button,
  Modal,
  Input,
  ConfirmDialog,
  ErrorState,
} from '../../components/ui';

export const SalaryManagement = () => {
  const [salaries, setSalaries] = useState([]);
  const [trainers, setTrainers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [errors, setErrors] = useState({});

  const [form, setForm] = useState({
    trainerId: '',
    month: new Date().toISOString().slice(0, 7),
    baseSalary: '',
    bonus: 0,
    deductions: 0,
    notes: '',
  });

  const fetchSalaries = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await salaryService.getAll();
      setSalaries(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSalaries();
    trainerService
      .getAll({ limit: 100 })
      .then((res) => setTrainers(extractList(res)))
      .catch(() => {});
  }, [fetchSalaries]);

  const handleTrainerChange = (trainerId) => {
    const t = trainers.find((tr) => String(tr.id || tr._id) === trainerId);
    setForm((p) => ({
      ...p,
      trainerId,
      baseSalary: t ? String(t.baseSalary ?? t.salary ?? '') : p.baseSalary,
    }));
    setErrors((p) => ({ ...p, trainerId: '' }));
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      trainerId: { required: true, label: 'Trainer' },
      baseSalary: { required: true, label: 'Base Salary', min: 0 },
      month: { required: true, label: 'Salary Month' },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSaving(true);
    try {
      const base = Number(form.baseSalary || 0);
      const bonus = Number(form.bonus || 0);
      const deductions = Number(form.deductions || 0);
      await salaryService.create({
        ...form,
        baseSalary: base,
        bonus,
        deductions,
        netAmount: Math.max(0, base + bonus - deductions),
      });
      toast.success('Salary entry created');
      setModalOpen(false);
      fetchSalaries();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleMarkPaid = async (row) => {
    try {
      await salaryService.markPaid(row.id || row._id, { status: 'PAID' });
      toast.success('Salary marked as paid');
      fetchSalaries();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await salaryService.delete(deleteTarget.id || deleteTarget._id);
      toast.success('Salary entry removed');
      setDeleteTarget(null);
      fetchSalaries();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  const columns = [
    { key: 'trainer', header: 'Trainer', render: (r) => r.trainer?.name || r.trainerName || '—' },
    { key: 'month', header: 'Month', render: (r) => r.month || formatDate(r.payDate, 'MMM YYYY') },
    { key: 'baseSalary', header: 'Base', render: (r) => formatCurrency(r.baseSalary ?? 0) },
    { key: 'bonus', header: 'Bonus / Ded.', render: (r) => `+${formatCurrency(r.bonus || 0)} / -${formatCurrency(r.deductions || 0)}` },
    {
      key: 'netAmount',
      header: 'Net Payout',
      render: (r) => <span className="font-bold text-accent">{formatCurrency(r.netAmount ?? r.amount ?? 0)}</span>,
    },
    { key: 'status', header: 'Status', render: (r) => <Badge status={r.status || 'PENDING'} dot /> },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (r) => (
        <div className="inline-flex items-center gap-1.5">
          {String(r.status).toUpperCase() !== 'PAID' && (
            <Button
              size="xs"
              variant="success"
              icon={CheckCircle2}
              onClick={() => handleMarkPaid(r)}
            >
              Mark Paid
            </Button>
          )}
          <Button size="xs" variant="danger" icon={Trash2} onClick={() => setDeleteTarget(r)} />
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Trainer Salaries & Payroll"
        subtitle="Calculate monthly salaries, commissions, bonuses, and track payouts"
        actions={
          <Button icon={Plus} onClick={() => setModalOpen(true)}>
            Add Salary Entry
          </Button>
        }
      />

      {error ? (
        <ErrorState message={error} onRetry={fetchSalaries} />
      ) : (
        <Table
          columns={columns}
          data={salaries}
          loading={loading}
          emptyTitle="No salary records found"
        />
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Create Salary Payout">
        <form onSubmit={handleCreate} className="space-y-4">
          <Select
            label="Trainer"
            required
            value={form.trainerId}
            error={errors.trainerId}
            options={trainers.map((t) => ({ value: t.id || t._id, label: t.name }))}
            onChange={(e) => handleTrainerChange(e.target.value)}
          />
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Month"
              type="month"
              required
              value={form.month}
              onChange={(e) => setForm((p) => ({ ...p, month: e.target.value }))}
            />
            <Input
              label="Base Salary (₹)"
              type="number"
              required
              value={form.baseSalary}
              error={errors.baseSalary}
              onChange={(e) => setForm((p) => ({ ...p, baseSalary: e.target.value }))}
            />
            <Input
              label="Bonus / Commission (₹)"
              type="number"
              value={form.bonus}
              onChange={(e) => setForm((p) => ({ ...p, bonus: e.target.value }))}
            />
            <Input
              label="Deductions (₹)"
              type="number"
              value={form.deductions}
              onChange={(e) => setForm((p) => ({ ...p, deductions: e.target.value }))}
            />
          </div>
          <div className="p-3 rounded-xl bg-dark-bg border border-dark-border flex items-center justify-between text-sm">
            <span className="text-text-secondary flex items-center gap-2">
              <Wallet className="w-4 h-4 text-accent" /> Net Payable
            </span>
            <span className="text-lg font-bold text-accent">
              {formatCurrency(
                Math.max(
                  0,
                  Number(form.baseSalary || 0) + Number(form.bonus || 0) - Number(form.deductions || 0)
                )
              )}
            </span>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              Save Payroll Entry
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Salary Entry"
        message="Remove this payroll record?"
        confirmLabel="Delete"
      />
    </div>
  );
};

export default SalaryManagement;

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { UserPlus } from 'lucide-react';
import trainerService from '../../services/trainerService';
import { useGym } from '../../contexts/GymContext';
import { validateForm } from '../../utils/validators';
import { getErrorMessage } from '../../utils/apiHelpers';
import { PageHeader, Card, Input, Select, Textarea, Button } from '../../components/ui';

export const AddTrainer = () => {
  const navigate = useNavigate();
  const { branches, activeBranchId } = useGym();
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState({});

  const [form, setForm] = useState({
    name: '',
    mobile: '',
    email: '',
    password: '',
    specialization: 'Strength & Conditioning',
    experienceYears: '2',
    baseSalary: '',
    commissionPercent: '10',
    shiftTiming: '06:00 AM - 02:00 PM',
    branchId: activeBranchId !== 'ALL' ? activeBranchId : '',
    certifications: '',
    bio: '',
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { isValid, errors: vErrors } = validateForm(form, {
      name: { required: true, label: 'Trainer Name', minLength: 2 },
      mobile: { required: true, label: 'Mobile Number', mobile: true },
      email: { email: true, label: 'Email' },
      baseSalary: { required: true, label: 'Base Salary', min: 0 },
    });
    if (!isValid) {
      setErrors(vErrors);
      return;
    }

    setSubmitting(true);
    try {
      await trainerService.create({
        ...form,
        experienceYears: Number(form.experienceYears || 0),
        baseSalary: Number(form.baseSalary || 0),
        commissionPercent: Number(form.commissionPercent || 0),
      });
      toast.success('Trainer added successfully');
      navigate('/owner/trainers');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Add New Trainer"
        subtitle="Onboard a fitness coach with specialization and compensation details"
        backTo="/owner/trainers"
      />

      <form onSubmit={handleSubmit} className="space-y-6 max-w-4xl">
        <Card title="Trainer Profile">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Full Name"
              required
              placeholder="e.g. Vikram Rathore"
              value={form.name}
              error={errors.name}
              onChange={(e) => {
                setForm((p) => ({ ...p, name: e.target.value }));
                setErrors((p) => ({ ...p, name: '' }));
              }}
            />
            <Input
              label="Mobile Number"
              type="tel"
              required
              placeholder="10-digit mobile"
              value={form.mobile}
              error={errors.mobile}
              onChange={(e) => {
                setForm((p) => ({ ...p, mobile: e.target.value }));
                setErrors((p) => ({ ...p, mobile: '' }));
              }}
            />
            <Input
              label="Email (Optional)"
              type="email"
              placeholder="coach@gym.com"
              value={form.email}
              error={errors.email}
              onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))}
            />
            <Input
              label="Portal Password (Optional)"
              type="password"
              placeholder="Min 6 chars"
              value={form.password}
              onChange={(e) => setForm((p) => ({ ...p, password: e.target.value }))}
            />
            <Select
              label="Specialization"
              value={form.specialization}
              options={[
                'Strength & Conditioning',
                'Weight Loss & HIIT',
                'Bodybuilding & Hypertrophy',
                'Yoga & Mobility',
                'CrossFit & Functional Training',
                'Nutrition & Diet Coaching',
              ]}
              onChange={(e) => setForm((p) => ({ ...p, specialization: e.target.value }))}
            />
            <Input
              label="Experience (Years)"
              type="number"
              min={0}
              value={form.experienceYears}
              onChange={(e) => setForm((p) => ({ ...p, experienceYears: e.target.value }))}
            />
          </div>
        </Card>

        <Card title="Compensation & Shift">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Input
              label="Base Monthly Salary (₹)"
              type="number"
              required
              placeholder="25000"
              value={form.baseSalary}
              error={errors.baseSalary}
              onChange={(e) => {
                setForm((p) => ({ ...p, baseSalary: e.target.value }));
                setErrors((p) => ({ ...p, baseSalary: '' }));
              }}
            />
            <Input
              label="PT Commission (%)"
              type="number"
              min={0}
              max={100}
              value={form.commissionPercent}
              onChange={(e) => setForm((p) => ({ ...p, commissionPercent: e.target.value }))}
            />
            <Input
              label="Shift Timing"
              value={form.shiftTiming}
              onChange={(e) => setForm((p) => ({ ...p, shiftTiming: e.target.value }))}
            />
            {branches.length > 0 && (
              <Select
                label="Assigned Branch"
                placeholder="Main Branch"
                value={form.branchId}
                options={branches.map((b) => ({ value: b.id || b._id, label: b.name }))}
                onChange={(e) => setForm((p) => ({ ...p, branchId: e.target.value }))}
              />
            )}
          </div>
          <div className="mt-4 space-y-4">
            <Input
              label="Certifications"
              placeholder="e.g. ACE CPT, CrossFit L1"
              value={form.certifications}
              onChange={(e) => setForm((p) => ({ ...p, certifications: e.target.value }))}
            />
            <Textarea
              label="Bio / Coaching Philosophy"
              rows={2}
              value={form.bio}
              onChange={(e) => setForm((p) => ({ ...p, bio: e.target.value }))}
            />
          </div>
        </Card>

        <div className="flex justify-end gap-3">
          <Button variant="secondary" onClick={() => navigate('/owner/trainers')}>
            Cancel
          </Button>
          <Button type="submit" loading={submitting} icon={UserPlus}>
            Save Trainer
          </Button>
        </div>
      </form>
    </div>
  );
};

export default AddTrainer;

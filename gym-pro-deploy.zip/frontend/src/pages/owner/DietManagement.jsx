import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { Plus, Edit2, Trash2, UserPlus, Utensils } from 'lucide-react';
import dietService from '../../services/dietService';
import customerService from '../../services/customerService';
import { extractList, getErrorMessage } from '../../utils/apiHelpers';
import DietBuilder from '../../components/shared/DietBuilder';
import {
  PageHeader,
  Card,
  SearchInput,
  Badge,
  Button,
  Modal,
  Select,
  ConfirmDialog,
  Skeleton,
  EmptyState,
  ErrorState,
} from '../../components/ui';

export const DietManagement = () => {
  const [plans, setPlans] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [builderOpen, setBuilderOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState(null);
  const [assignTarget, setAssignTarget] = useState(null);
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [assigning, setAssigning] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const fetchDiets = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await dietService.getAll({ search });
      setPlans(extractList(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [search]);

  useEffect(() => {
    fetchDiets();
    customerService
      .getAll({ limit: 200 })
      .then((res) => setCustomers(extractList(res)))
      .catch(() => {});
  }, [fetchDiets]);

  const handleAssign = async (e) => {
    e.preventDefault();
    if (!assignTarget || !selectedCustomerId) return;
    setAssigning(true);
    try {
      await dietService.assign(assignTarget.id || assignTarget._id, selectedCustomerId);
      toast.success('Diet plan assigned to member');
      setAssignTarget(null);
      fetchDiets();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setAssigning(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await dietService.delete(deleteTarget.id || deleteTarget._id);
      toast.success('Diet plan deleted');
      setDeleteTarget(null);
      fetchDiets();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Diet & Nutrition Plans"
        subtitle="Create macro-balanced meal plans and assign them to gym members"
        actions={
          <Button
            icon={Plus}
            onClick={() => {
              setEditingPlan(null);
              setBuilderOpen(true);
            }}
          >
            Create Diet Plan
          </Button>
        }
      />

      <SearchInput
        placeholder="Search diet plans..."
        value={search}
        onChange={setSearch}
        className="sm:max-w-sm"
      />

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Skeleton variant="card" />
          <Skeleton variant="card" />
        </div>
      ) : error ? (
        <ErrorState message={error} onRetry={fetchDiets} />
      ) : plans.length === 0 ? (
        <Card>
          <EmptyState
            icon={Utensils}
            title="No diet plans created"
            message="Design daily meal plans with calorie and macro targets."
            action={
              <Button icon={Plus} onClick={() => setBuilderOpen(true)}>
                Create Diet Plan
              </Button>
            }
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {plans.map((plan) => (
            <Card key={plan.id || plan._id}>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-base font-bold text-text-primary">{plan.name || plan.title}</h3>
                  <p className="text-xs text-accent font-semibold mt-0.5">
                    {plan.totalCalories || 0} kcal/day • {plan.meals?.length || 0} meals
                  </p>
                </div>
                <Badge variant="success">{plan.dietType || 'BALANCED'}</Badge>
              </div>

              <div className="grid grid-cols-3 gap-2 mt-3 text-center text-xs">
                <div className="p-2 rounded-lg bg-dark-bg border border-dark-border">
                  <span className="text-text-secondary block">Protein</span>
                  <span className="font-bold text-success">{plan.totalProtein || 0}g</span>
                </div>
                <div className="p-2 rounded-lg bg-dark-bg border border-dark-border">
                  <span className="text-text-secondary block">Carbs</span>
                  <span className="font-bold text-warning">{plan.totalCarbs || 0}g</span>
                </div>
                <div className="p-2 rounded-lg bg-dark-bg border border-dark-border">
                  <span className="text-text-secondary block">Fats</span>
                  <span className="font-bold">{plan.totalFats || 0}g</span>
                </div>
              </div>

              {plan.customer?.name && (
                <p className="text-xs text-success mt-3 font-medium">
                  Assigned to: {plan.customer.name}
                </p>
              )}

              <div className="mt-4 pt-3 border-t border-dark-border flex items-center gap-2">
                <Button
                  size="xs"
                  variant="secondary"
                  icon={UserPlus}
                  onClick={() => {
                    setAssignTarget(plan);
                    setSelectedCustomerId('');
                  }}
                  className="flex-1"
                >
                  Assign
                </Button>
                <Button
                  size="xs"
                  variant="secondary"
                  icon={Edit2}
                  onClick={() => {
                    setEditingPlan(plan);
                    setBuilderOpen(true);
                  }}
                />
                <Button size="xs" variant="danger" icon={Trash2} onClick={() => setDeleteTarget(plan)} />
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal
        isOpen={builderOpen}
        onClose={() => setBuilderOpen(false)}
        title={editingPlan ? 'Edit Diet Plan' : 'Create Diet Plan'}
        size="xl"
      >
        <DietBuilder
          initialPlan={editingPlan}
          onCancel={() => setBuilderOpen(false)}
          onSaved={() => {
            setBuilderOpen(false);
            fetchDiets();
          }}
        />
      </Modal>

      <Modal
        isOpen={Boolean(assignTarget)}
        onClose={() => setAssignTarget(null)}
        title="Assign Diet Plan"
        subtitle={assignTarget?.name || assignTarget?.title}
        size="sm"
      >
        <form onSubmit={handleAssign} className="space-y-4">
          <Select
            label="Select Member"
            required
            value={selectedCustomerId}
            options={customers.map((c) => ({
              value: c.id || c._id,
              label: `${c.name} (${c.mobile || c.phone || ''})`,
            }))}
            onChange={(e) => setSelectedCustomerId(e.target.value)}
          />
          <div className="flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setAssignTarget(null)}>
              Cancel
            </Button>
            <Button type="submit" loading={assigning}>
              Assign Plan
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Diet Plan"
        message={`Delete "${deleteTarget?.name || deleteTarget?.title}"?`}
        confirmLabel="Delete"
      />
    </div>
  );
};

export default DietManagement;

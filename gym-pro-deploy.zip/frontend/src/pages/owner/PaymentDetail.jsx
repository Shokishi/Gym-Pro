import React, { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { CheckCircle2, XCircle, FileText } from 'lucide-react';
import paymentService from '../../services/paymentService';
import { useAuth } from '../../contexts/AuthContext';
import { extractData, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDateTime } from '../../utils/formatters';
import { generateInvoicePDF } from '../../utils/pdfGenerator';
import {
  PageHeader,
  Card,
  Badge,
  Button,
  Textarea,
  Skeleton,
  ErrorState,
} from '../../components/ui';

export const PaymentDetail = () => {
  const { id } = useParams();
  const { gym } = useAuth();
  const [payment, setPayment] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [reason, setReason] = useState('');
  const [processing, setProcessing] = useState(false);

  const loadPayment = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await paymentService.getById(id);
      setPayment(extractData(res));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    loadPayment();
  }, [loadPayment]);

  const handleAction = async (status) => {
    setProcessing(true);
    try {
      if (status === 'VERIFIED') {
        await paymentService.verify(id, { status: 'VERIFIED' });
        toast.success('Payment verified and membership updated');
      } else {
        await paymentService.reject(id, reason || 'Invalid proof');
        toast.success('Payment rejected');
      }
      loadPayment();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <PageHeader title="Payment Details" backTo="/owner/payments" />
        <Skeleton variant="card" />
      </div>
    );
  }

  if (error || !payment) {
    return (
      <div className="space-y-6">
        <PageHeader title="Payment Details" backTo="/owner/payments" />
        <ErrorState message={error || 'Payment not found'} onRetry={loadPayment} />
      </div>
    );
  }

  const isPending = String(payment.status).toUpperCase() === 'PENDING';

  return (
    <div className="space-y-6 max-w-4xl">
      <PageHeader
        title={`Payment #${payment.receiptNumber || payment.id || id}`}
        subtitle={formatDateTime(payment.paidAt || payment.createdAt)}
        backTo="/owner/payments"
        badge={<Badge status={payment.status || 'PENDING'} dot />}
        actions={
          <Button
            variant="secondary"
            size="sm"
            icon={FileText}
            onClick={() =>
              generateInvoicePDF(
                {
                  invoiceNumber: payment.receiptNumber || `PAY-${id}`,
                  customerName: payment.customer?.name || payment.customerName,
                  customerPhone: payment.customer?.mobile || payment.customer?.phone,
                  description: payment.description || 'Gym Membership Payment',
                  subtotal: payment.amount,
                  total: payment.amount,
                  status: payment.status,
                  issueDate: payment.createdAt,
                },
                gym
              )
            }
          >
            Download Receipt PDF
          </Button>
        }
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card title="Transaction Summary">
          <dl className="space-y-3 text-sm">
            <div className="flex justify-between">
              <dt className="text-text-secondary">Member</dt>
              <dd className="font-semibold">{payment.customer?.name || payment.customerName || '—'}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-text-secondary">Amount</dt>
              <dd className="text-lg font-bold text-accent">{formatCurrency(payment.amount)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-text-secondary">Payment Method</dt>
              <dd className="font-medium">{payment.paymentMethod || payment.method || 'UPI'}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-text-secondary">Transaction / UTR ID</dt>
              <dd className="font-mono">{payment.transactionId || payment.utr || '—'}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-text-secondary">Description</dt>
              <dd className="font-medium">{payment.description || 'Membership Fee'}</dd>
            </div>
          </dl>
        </Card>

        <Card title="Payment Screenshot / Verification">
          {payment.screenshotUrl || payment.receiptUrl ? (
            <img
              src={payment.screenshotUrl || payment.receiptUrl}
              alt="Payment Proof"
              className="w-full max-h-64 object-contain rounded-xl bg-dark-bg border border-dark-border mb-4"
            />
          ) : (
            <p className="text-sm text-text-secondary py-6 text-center bg-dark-bg rounded-xl border border-dark-border mb-4">
              No payment screenshot uploaded.
            </p>
          )}

          {isPending && (
            <div className="space-y-3">
              <Textarea
                label="Rejection Reason (if rejecting)"
                rows={2}
                value={reason}
                onChange={(e) => setReason(e.target.value)}
              />
              <div className="flex gap-3">
                <Button
                  variant="danger"
                  icon={XCircle}
                  loading={processing}
                  onClick={() => handleAction('REJECTED')}
                  className="flex-1"
                >
                  Reject
                </Button>
                <Button
                  variant="success"
                  icon={CheckCircle2}
                  loading={processing}
                  onClick={() => handleAction('VERIFIED')}
                  className="flex-1"
                >
                  Approve Payment
                </Button>
              </div>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
};

export default PaymentDetail;

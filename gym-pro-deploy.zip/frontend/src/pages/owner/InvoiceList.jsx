import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Plus, FileText, Eye, CheckCircle2, Trash2 } from 'lucide-react';
import invoiceService from '../../services/invoiceService';
import customerService from '../../services/customerService';
import { useAuth } from '../../contexts/AuthContext';
import { useDebounce } from '../../hooks/useDebounce';
import { usePagination } from '../../hooks/usePagination';
import { extractList, extractPagination, getErrorMessage } from '../../utils/apiHelpers';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { generateInvoicePDF } from '../../utils/pdfGenerator';
import {
  PageHeader,
  SearchInput,
  Select,
  Table,
  Badge,
  Button,
  Modal,
  Input,
  ConfirmDialog,
  ErrorState,
} from '../../components/ui';

export const InvoiceList = () => {
  const navigate = useNavigate();
  const { gym } = useAuth();
  const [invoices, setInvoices] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [createOpen, setCreateOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);

  const [form, setForm] = useState({
    customerId: '',
    description: 'Monthly Membership Fee',
    amount: '',
    tax: 0,
    dueDate: new Date().toISOString().slice(0, 10),
    status: 'PAID',
  });

  const debouncedSearch = useDebounce(search, 350);
  const pagination = usePagination(1, 10);

  const fetchInvoices = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await invoiceService.getAll({
        search: debouncedSearch,
        status: statusFilter,
        page: pagination.page,
        limit: pagination.limit,
      });
      setInvoices(extractList(res));
      pagination.updateMeta(extractPagination(res, pagination.limit));
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch, statusFilter, pagination.page, pagination.limit]);

  useEffect(() => {
    fetchInvoices();
  }, [fetchInvoices]);

  useEffect(() => {
    customerService
      .getAll({ limit: 200 })
      .then((res) => setCustomers(extractList(res)))
      .catch(() => {});
  }, []);

  const handleCreateInvoice = async (e) => {
    e.preventDefault();
    if (!form.customerId || !form.amount) {
      toast.error('Member and amount are required');
      return;
    }
    setSaving(true);
    try {
      const subtotal = Number(form.amount);
      const tax = Number(form.tax || 0);
      await invoiceService.create({
        customerId: form.customerId,
        dueDate: form.dueDate,
        status: form.status,
        subtotal,
        tax,
        total: subtotal + tax,
        items: [{ description: form.description, quantity: 1, unitPrice: subtotal, total: subtotal }],
      });
      toast.success('Invoice created');
      setCreateOpen(false);
      fetchInvoices();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleMarkPaid = async (inv) => {
    try {
      await invoiceService.markPaid(inv.id || inv._id, { status: 'PAID' });
      toast.success('Invoice marked as PAID');
      fetchInvoices();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await invoiceService.delete(deleteTarget.id || deleteTarget._id);
      toast.success('Invoice deleted');
      setDeleteTarget(null);
      fetchInvoices();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDeleting(false);
    }
  };

  const columns = [
    {
      key: 'invoiceNumber',
      header: 'Invoice #',
      render: (r) => (
        <span className="font-mono font-semibold text-accent">
          {r.invoiceNumber || `INV-${r.id}`}
        </span>
      ),
    },
    {
      key: 'customer',
      header: 'Member',
      render: (r) => r.customer?.name || r.customerName || '—',
    },
    {
      key: 'total',
      header: 'Total',
      sortable: true,
      render: (r) => <span className="font-bold">{formatCurrency(r.total ?? r.amount ?? 0)}</span>,
    },
    {
      key: 'issueDate',
      header: 'Issued',
      render: (r) => formatDate(r.issueDate || r.createdAt),
    },
    {
      key: 'status',
      header: 'Status',
      render: (r) => <Badge status={r.status || 'PENDING'} dot />,
    },
    {
      key: 'actions',
      header: 'Actions',
      align: 'right',
      render: (r) => {
        const id = r.id || r._id;
        return (
          <div className="inline-flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            <Button
              size="xs"
              variant="secondary"
              icon={Eye}
              onClick={() => navigate(`/owner/invoices/${id}`)}
            >
              View
            </Button>
            <Button
              size="xs"
              variant="secondary"
              icon={FileText}
              onClick={() => generateInvoicePDF(r, gym)}
            >
              PDF
            </Button>
            {String(r.status).toUpperCase() !== 'PAID' && (
              <Button
                size="xs"
                variant="success"
                icon={CheckCircle2}
                onClick={() => handleMarkPaid(r)}
              >
                Paid
              </Button>
            )}
            <Button size="xs" variant="danger" icon={Trash2} onClick={() => setDeleteTarget(r)} />
          </div>
        );
      },
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Invoices & Billing"
        subtitle="Generate GST invoices, download PDFs, and track payment status"
        actions={
          <Button icon={Plus} onClick={() => setCreateOpen(true)}>
            New Invoice
          </Button>
        }
      />

      <div className="flex flex-col sm:flex-row gap-3">
        <SearchInput
          placeholder="Search invoice # or member..."
          value={search}
          onChange={(v) => {
            setSearch(v);
            pagination.resetPage();
          }}
          className="sm:max-w-sm"
        />
        <Select
          value={statusFilter}
          placeholder=""
          containerClassName="sm:w-44"
          options={[
            { value: 'ALL', label: 'All Invoices' },
            { value: 'PAID', label: 'Paid' },
            { value: 'PENDING', label: 'Pending' },
            { value: 'OVERDUE', label: 'Overdue' },
          ]}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            pagination.resetPage();
          }}
        />
      </div>

      {error ? (
        <ErrorState message={error} onRetry={fetchInvoices} />
      ) : (
        <Table
          columns={columns}
          data={invoices}
          loading={loading}
          pagination={pagination}
          onPageChange={pagination.setPage}
          onRowClick={(r) => navigate(`/owner/invoices/${r.id || r._id}`)}
          emptyTitle="No invoices generated yet"
        />
      )}

      <Modal isOpen={createOpen} onClose={() => setCreateOpen(false)} title="Create Invoice">
        <form onSubmit={handleCreateInvoice} className="space-y-4">
          <Select
            label="Member"
            required
            value={form.customerId}
            options={customers.map((c) => ({
              value: c.id || c._id,
              label: `${c.name} (${c.mobile || c.phone || ''})`,
            }))}
            onChange={(e) => setForm((p) => ({ ...p, customerId: e.target.value }))}
          />
          <Input
            label="Description"
            required
            value={form.description}
            onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
          />
          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Amount (₹)"
              type="number"
              required
              value={form.amount}
              onChange={(e) => setForm((p) => ({ ...p, amount: e.target.value }))}
            />
            <Input
              label="GST / Tax (₹)"
              type="number"
              value={form.tax}
              onChange={(e) => setForm((p) => ({ ...p, tax: e.target.value }))}
            />
            <Input
              label="Due Date"
              type="date"
              value={form.dueDate}
              onChange={(e) => setForm((p) => ({ ...p, dueDate: e.target.value }))}
            />
            <Select
              label="Status"
              value={form.status}
              options={[
                { value: 'PAID', label: 'Paid' },
                { value: 'PENDING', label: 'Pending' },
              ]}
              onChange={(e) => setForm((p) => ({ ...p, status: e.target.value }))}
            />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="secondary" onClick={() => setCreateOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" loading={saving}>
              Generate Invoice
            </Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Invoice"
        message={`Delete invoice ${deleteTarget?.invoiceNumber || ''}?`}
        confirmLabel="Delete"
      />
    </div>
  );
};

export default InvoiceList;

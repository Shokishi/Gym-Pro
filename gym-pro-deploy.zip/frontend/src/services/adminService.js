import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const adminService = {
  getDashboard: (params) => api.get('/admin/dashboard', { params: buildQueryParams(params) }),
  getAnalytics: (params) => api.get('/admin/analytics', { params: buildQueryParams(params) }),

  // Gyms
  getGyms: (params) => api.get('/admin/gyms', { params: buildQueryParams(params) }),
  getGymById: (id) => api.get(`/admin/gyms/${id}`),
  updateGymStatus: (id, status, reason) => api.patch(`/admin/gyms/${id}/status`, { status, reason }),
  deleteGym: (id) => api.delete(`/admin/gyms/${id}`),

  // Users
  getUsers: (params) => api.get('/admin/users', { params: buildQueryParams(params) }),
  updateUserStatus: (id, status) => api.patch(`/admin/users/${id}/status`, { status }),

  // Subscription Plans & Pricing
  getPlans: () => api.get('/admin/plans'),
  createPlan: (data) => api.post('/admin/plans', data),
  updatePlan: (id, data) => api.put(`/admin/plans/${id}`, data),
  deletePlan: (id) => api.delete(`/admin/plans/${id}`),
  updatePricing: (data) => api.put('/admin/pricing', data),

  // Trial Settings
  getTrialSettings: () => api.get('/admin/trial-settings'),
  updateTrialSettings: (data) => api.put('/admin/trial-settings', data),

  // Subscriptions & Payments
  getSubscriptions: (params) => api.get('/admin/subscriptions', { params: buildQueryParams(params) }),
  updateSubscription: (id, data) => api.patch(`/admin/subscriptions/${id}`, data),
  getSubscriptionPayments: (params) => api.get('/admin/subscription-payments', { params: buildQueryParams(params) }),
  verifySubscriptionPayment: (id, data) => api.patch(`/admin/subscription-payments/${id}/verify`, data),

  // Domains
  getDomains: (params) => api.get('/admin/domains', { params: buildQueryParams(params) }),
  verifyDomain: (id, data) => api.patch(`/admin/domains/${id}/verify`, data),
  updateDomainStatus: (id, status) => api.patch(`/admin/domains/${id}/status`, { status }),

  // Support Tickets
  getTickets: (params) => api.get('/admin/support-tickets', { params: buildQueryParams(params) }),
  replyTicket: (id, data) => api.post(`/admin/support-tickets/${id}/reply`, data),
  updateTicketStatus: (id, status) => api.patch(`/admin/support-tickets/${id}/status`, { status }),

  // Audit Logs & Settings
  getAuditLogs: (params) => api.get('/admin/audit-logs', { params: buildQueryParams(params) }),
  getPlatformSettings: () => api.get('/admin/settings'),
  updatePlatformSettings: (data) => api.put('/admin/settings', data),
};

export default adminService;

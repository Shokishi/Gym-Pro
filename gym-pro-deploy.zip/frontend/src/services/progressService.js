import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const progressService = {
  getByCustomer: (customerId, params) =>
    api.get(`/progress/customer/${customerId}`, { params: buildQueryParams(params) }),
  getMyProgress: (params) => api.get('/progress/me', { params: buildQueryParams(params) }),
  create: (data) => api.post('/progress', data),
  update: (id, data) => api.put(`/progress/${id}`, data),
  delete: (id) => api.delete(`/progress/${id}`),
};

export default progressService;

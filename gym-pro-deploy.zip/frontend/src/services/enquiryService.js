import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const enquiryService = {
  getAll: (params) => api.get('/enquiries', { params: buildQueryParams(params) }),
  create: (data) => api.post('/enquiries', data),
  update: (id, data) => api.put(`/enquiries/${id}`, data),
  updateStatus: (id, status) => api.patch(`/enquiries/${id}/status`, { status }),
  convertToCustomer: (id, data) => api.post(`/enquiries/${id}/convert`, data),
  delete: (id) => api.delete(`/enquiries/${id}`),
};

export default enquiryService;

import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const invoiceService = {
  getAll: (params) => api.get('/invoices', { params: buildQueryParams(params) }),
  getById: (id) => api.get(`/invoices/${id}`),
  create: (data) => api.post('/invoices', data),
  update: (id, data) => api.put(`/invoices/${id}`, data),
  markPaid: (id, data) => api.patch(`/invoices/${id}/pay`, data),
  sendEmail: (id) => api.post(`/invoices/${id}/send`),
  delete: (id) => api.delete(`/invoices/${id}`),
};

export default invoiceService;

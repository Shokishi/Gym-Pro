import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const equipmentService = {
  getAll: (params) => api.get('/equipment', { params: buildQueryParams(params) }),
  create: (data) => api.post('/equipment', data),
  update: (id, data) => api.put(`/equipment/${id}`, data),
  logMaintenance: (id, data) => api.post(`/equipment/${id}/maintenance`, data),
  delete: (id) => api.delete(`/equipment/${id}`),
};

export default equipmentService;

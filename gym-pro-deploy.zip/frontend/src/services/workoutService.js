import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const workoutService = {
  getAll: (params) => api.get('/workouts', { params: buildQueryParams(params) }),
  getById: (id) => api.get(`/workouts/${id}`),
  create: (data) => api.post('/workouts', data),
  update: (id, data) => api.put(`/workouts/${id}`, data),
  delete: (id) => api.delete(`/workouts/${id}`),
  assign: (id, customerId) => api.post(`/workouts/${id}/assign`, { customerId }),
  getMyWorkout: () => api.get('/workouts/me'),
  toggleExerciseComplete: (planId, exerciseId, completed) =>
    api.patch(`/workouts/me/${planId}/exercises/${exerciseId}`, { completed }),
  completeDay: (planId, day) => api.post(`/workouts/me/${planId}/complete`, { day }),
};

export default workoutService;

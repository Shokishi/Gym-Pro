import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const appointmentService = {
  getAll: (params) => api.get('/appointments', { params: buildQueryParams(params) }),
  getById: (id) => api.get(`/appointments/${id}`),
  create: (data) => api.post('/appointments', data),
  update: (id, data) => api.put(`/appointments/${id}`, data),
  updateStatus: (id, status) => api.patch(`/appointments/${id}/status`, { status }),
  delete: (id) => api.delete(`/appointments/${id}`),
  getMyAppointments: (params) => api.get('/appointments/me', { params: buildQueryParams(params) }),
  bookAppointment: (data) => api.post('/appointments/me/book', data),
  cancelMyAppointment: (id) => api.patch(`/appointments/me/${id}/cancel`),
};

export default appointmentService;

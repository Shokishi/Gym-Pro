import api from './api';

export const authService = {
  login: (credentials) => api.post('/auth/login', credentials),
  adminLogin: (credentials) => api.post('/auth/admin/login', credentials),
  registerOwner: (data) => api.post('/auth/register', data),
  registerTrainer: (data) => api.post('/auth/register/trainer', data),
  registerCustomer: (data) => api.post('/auth/register/customer', data),
  forgotPassword: (data) => api.post('/auth/forgot-password', data),
  verifyOtp: (data) => api.post('/auth/verify-otp', data),
  resetPassword: (data) => api.post('/auth/reset-password', data),
  sendOtp: (data) => api.post('/auth/send-otp', data),
  getPublicPlans: () => api.get('/auth/plans'),
  refreshToken: (refreshToken) => api.post('/auth/refresh-token', { refreshToken }),
  logout: () => api.post('/auth/logout'),
  me: () => api.get('/auth/me'),
  validateInvite: (code) => api.get(`/auth/invite/${code}`),
};

export default authService;

import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const attendanceService = {
  getAll: (params) => api.get('/attendance', { params: buildQueryParams(params) }),
  getReport: (params) => api.get('/attendance/report', { params: buildQueryParams(params) }),
  markAttendance: (data) => api.post('/attendance/mark', data),
  checkInByQr: (qrPayload) => api.post('/attendance/qr-checkin', qrPayload),
  checkOut: (id) => api.patch(`/attendance/${id}/checkout`),
  getMyAttendance: (params) => api.get('/attendance/me', { params: buildQueryParams(params) }),
  getMyQrToken: () => api.get('/attendance/my-qr'),
};

export default attendanceService;

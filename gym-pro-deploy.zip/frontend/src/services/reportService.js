import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const reportService = {
  getOwnerReport: (params) => api.get('/reports/owner', { params: buildQueryParams(params) }),
  getAdminReport: (params) => api.get('/reports/admin', { params: buildQueryParams(params) }),
  getRevenueReport: (params) => api.get('/reports/revenue', { params: buildQueryParams(params) }),
  getAttendanceReport: (params) => api.get('/reports/attendance', { params: buildQueryParams(params) }),
  getMembershipReport: (params) => api.get('/reports/memberships', { params: buildQueryParams(params) }),
  exportReport: (type, params) =>
    api.get(`/reports/export/${type}`, { params: buildQueryParams(params), responseType: 'blob' }),
};

export default reportService;

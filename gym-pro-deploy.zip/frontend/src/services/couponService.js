import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const couponService = {
  getAll: (params) => api.get('/coupons', { params: buildQueryParams(params) }),
  create: (data) => api.post('/coupons', data),
  update: (id, data) => api.put(`/coupons/${id}`, data),
  toggleStatus: (id, active) => api.patch(`/coupons/${id}/status`, { active }),
  validate: (code, amount) => api.post('/coupons/validate', { code, amount }),
  delete: (id) => api.delete(`/coupons/${id}`),
};

export default couponService;

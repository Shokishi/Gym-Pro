import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const paymentService = {
  getAll: (params) => api.get('/payments', { params: buildQueryParams(params) }),
  getById: (id) => api.get(`/payments/${id}`),
  create: (data) => api.post('/payments', data),
  verify: (id, data) => api.patch(`/payments/${id}/verify`, data),
  reject: (id, reason) => api.patch(`/payments/${id}/reject`, { reason }),
  getMyPayments: (params) => api.get('/payments/me', { params: buildQueryParams(params) }),
  submitCustomerPayment: (data) => api.post('/payments/me/submit', data),
  getQrSettings: () => api.get('/payments/qr-settings'),
  updateQrSettings: (data) => api.put('/payments/qr-settings', data),
};

export default paymentService;

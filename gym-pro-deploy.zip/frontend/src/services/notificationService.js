import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const notificationService = {
  getAll: (params) => api.get('/notifications', { params: buildQueryParams(params) }),
  send: (data) => api.post('/notifications', data),
  markRead: (id) => api.patch(`/notifications/${id}/read`),
  markAllRead: () => api.patch('/notifications/read-all'),
  delete: (id) => api.delete(`/notifications/${id}`),
};

export default notificationService;

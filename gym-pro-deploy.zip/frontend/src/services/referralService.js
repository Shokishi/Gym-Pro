import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const referralService = {
  getAll: (params) => api.get('/referrals', { params: buildQueryParams(params) }),
  create: (data) => api.post('/referrals', data),
  updateStatus: (id, status, rewardAmount) =>
    api.patch(`/referrals/${id}/status`, { status, rewardAmount }),
  markRewarded: (id, data) => api.patch(`/referrals/${id}/reward`, data),
  delete: (id) => api.delete(`/referrals/${id}`),
};

export default referralService;

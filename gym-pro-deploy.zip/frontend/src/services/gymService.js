import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const gymService = {
  getDashboard: (params) => api.get('/gym/dashboard', { params: buildQueryParams(params) }),
  getGymProfile: () => api.get('/gym/profile'),
  updateGymProfile: (data) => api.put('/gym/profile', data),
  getSettings: () => api.get('/gym/settings'),
  updateSettings: (data) => api.put('/gym/settings', data),

  // Branches
  getBranches: (params) => api.get('/gym/branches', { params: buildQueryParams(params) }),
  createBranch: (data) => api.post('/gym/branches', data),
  updateBranch: (id, data) => api.put(`/gym/branches/${id}`, data),
  deleteBranch: (id) => api.delete(`/gym/branches/${id}`),

  // Permissions
  getPermissions: (params) => api.get('/gym/permissions', { params: buildQueryParams(params) }),
  updatePermissions: (userId, data) => api.put(`/gym/permissions/${userId}`, data),

  // Audit logs
  getAuditLogs: (params) => api.get('/gym/audit-logs', { params: buildQueryParams(params) }),

  // SaaS Subscription
  getMySubscription: () => api.get('/gym/subscription'),
  getAvailablePlans: () => api.get('/gym/subscription/plans'),
  upgradeSubscription: (data) => api.post('/gym/subscription/upgrade', data),
  cancelSubscription: () => api.post('/gym/subscription/cancel'),
};

export default gymService;

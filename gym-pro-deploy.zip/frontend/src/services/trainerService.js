import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const trainerService = {
  getAll: (params) => api.get('/trainers', { params: buildQueryParams(params) }),
  getById: (id) => api.get(`/trainers/${id}`),
  create: (data) => api.post('/trainers', data),
  update: (id, data) => api.put(`/trainers/${id}`, data),
  delete: (id) => api.delete(`/trainers/${id}`),
  getAssignedCustomers: (params) => api.get('/trainers/portal/customers', { params: buildQueryParams(params) }),
  getDashboard: () => api.get('/trainers/portal/dashboard'),
  getSchedule: (params) => api.get('/trainers/portal/schedule', { params: buildQueryParams(params) }),
  generateInvite: () => api.post('/trainers/invite'),
};

export default trainerService;

import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const customerService = {
  getAll: (params) => api.get('/customers', { params: buildQueryParams(params) }),
  getById: (id) => api.get(`/customers/${id}`),
  create: (data) => api.post('/customers', data),
  update: (id, data) => api.put(`/customers/${id}`, data),
  delete: (id) => api.delete(`/customers/${id}`),
  assignTrainer: (id, trainerId) => api.patch(`/customers/${id}/assign-trainer`, { trainerId }),
  updateStatus: (id, status) => api.patch(`/customers/${id}/status`, { status }),
  getHomeSummary: () => api.get('/customers/portal/home'),
};

export default customerService;

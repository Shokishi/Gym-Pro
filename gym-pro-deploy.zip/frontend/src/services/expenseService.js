import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const expenseService = {
  getAll: (params) => api.get('/expenses', { params: buildQueryParams(params) }),
  getSummary: (params) => api.get('/expenses/summary', { params: buildQueryParams(params) }),
  create: (data) => api.post('/expenses', data),
  update: (id, data) => api.put(`/expenses/${id}`, data),
  delete: (id) => api.delete(`/expenses/${id}`),
};

export default expenseService;

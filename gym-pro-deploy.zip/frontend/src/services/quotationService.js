import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const quotationService = {
  getAll: (params) => api.get('/quotations', { params: buildQueryParams(params) }),
  getById: (id) => api.get(`/quotations/${id}`),
  create: (data) => api.post('/quotations', data),
  update: (id, data) => api.put(`/quotations/${id}`, data),
  convertToInvoice: (id) => api.post(`/quotations/${id}/convert`),
  updateStatus: (id, status) => api.patch(`/quotations/${id}/status`, { status }),
  delete: (id) => api.delete(`/quotations/${id}`),
};

export default quotationService;

import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const membershipService = {
  getPlans: (params) => api.get('/memberships/plans', { params: buildQueryParams(params) }),
  createPlan: (data) => api.post('/memberships/plans', data),
  updatePlan: (id, data) => api.put(`/memberships/plans/${id}`, data),
  deletePlan: (id) => api.delete(`/memberships/plans/${id}`),

  getAll: (params) => api.get('/memberships', { params: buildQueryParams(params) }),
  getById: (id) => api.get(`/memberships/${id}`),
  assign: (data) => api.post('/memberships', data),
  renew: (id, data) => api.post(`/memberships/${id}/renew`, data),
  freeze: (id, data) => api.patch(`/memberships/${id}/freeze`, data),
  cancel: (id) => api.patch(`/memberships/${id}/cancel`),
  getMyMembership: () => api.get('/memberships/me'),
  requestRenewal: (data) => api.post('/memberships/me/renew', data),
};

export default membershipService;

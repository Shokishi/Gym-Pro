import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const dietService = {
  getAll: (params) => api.get('/diets', { params: buildQueryParams(params) }),
  getById: (id) => api.get(`/diets/${id}`),
  create: (data) => api.post('/diets', data),
  update: (id, data) => api.put(`/diets/${id}`, data),
  delete: (id) => api.delete(`/diets/${id}`),
  assign: (id, customerId) => api.post(`/diets/${id}/assign`, { customerId }),
  getMyDiet: () => api.get('/diets/me'),
  logMealAdherence: (planId, mealId, completed) =>
    api.patch(`/diets/me/${planId}/meals/${mealId}`, { completed }),
};

export default dietService;

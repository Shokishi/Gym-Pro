import api from './api';

export const profileService = {
  getProfile: () => api.get('/profile'),
  updateProfile: (data) => api.put('/profile', data),
  changePassword: (data) => api.put('/profile/password', data),
  uploadAvatar: (formData) => api.post('/profile/avatar', formData),
  getLoginHistory: () => api.get('/profile/login-history'),
  sendMobileOtp: (data) => api.post('/profile/send-mobile-otp', data),
  updateMobile: (data) => api.put('/profile/mobile', data),
};

export default profileService;

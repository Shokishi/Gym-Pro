import api from './api';
import { buildQueryParams } from '../utils/apiHelpers';

export const salaryService = {
  getAll: (params) => api.get('/salaries', { params: buildQueryParams(params) }),
  create: (data) => api.post('/salaries', data),
  update: (id, data) => api.put(`/salaries/${id}`, data),
  markPaid: (id, data) => api.patch(`/salaries/${id}/pay`, data),
  delete: (id) => api.delete(`/salaries/${id}`),
  generatePayroll: (data) => api.post('/salaries/generate', data),
};

export default salaryService;
